#pragma once 
#include <string>
#include <iostream>
#include <PCLExtend.h>
#include <V3.hpp>
#include <StringExtend.h>
using namespace std;
void CaclulateAccuracy(string path_of_raw, string output_prefix);
void CaclulateAccuracy_by_distance(string path_of_raw, string path_of_correct);