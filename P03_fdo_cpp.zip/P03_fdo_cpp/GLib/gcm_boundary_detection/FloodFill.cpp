#include "FloodFill.h"

FloodFill::FloodFill(cv::Mat& img){
    img_=img;
}

void FloodFill::SetBackgroundColor(int r, int g, int b)
{
    background_r_=r;
    background_g_=g;
    background_b_=b;
}

void FloodFill::SetReplaceColor(int r, int g, int b)
{
    replace_r_=r;
    replace_g_=g;
    replace_b_=b;
}

bool FloodFill::Apply(int x, int y)
{
    /* Step 01: obtain the color of seed */
    seed_r_=img_.at<cv::Vec3b>(x,y)[0];
    seed_g_=img_.at<cv::Vec3b>(x,y)[1];
    seed_b_=img_.at<cv::Vec3b>(x,y)[2];

    /* Step 02: gather all the pixel with seed color*/
    for(int i=0;i<img_.rows;i++){
        for(int j=0;j<img_.cols;j++){               
            if(img_.at<cv::Vec3b>(i,j)[0]==seed_r_ && 
               img_.at<cv::Vec3b>(i,j)[1]==seed_g_ && 
               img_.at<cv::Vec3b>(i,j)[2]==seed_b_)
                active_vertices_.Insert(i,j);		
        }
    }

    /* Step 03: flood fill */
	floodFillUtil(x, y, ant_);

    /* Step 04: test whether all the pixel with seed color have been visited*/
    if(active_vertices_.number_==0)
        return true;
    else
        return false;
}

void FloodFill::floodFillUtil(int x, int y, Vertices& ant) 
{ 
    // Base cases	
    if ( x < 0 || x >= img_.rows || y < 0 || y >= img_.cols) 
        return; 

    // if find seed color
    if (img_.at<cv::Vec3b>(x,y)[0] != seed_r_ || 
        img_.at<cv::Vec3b>(x,y)[1] != seed_g_ ||
        img_.at<cv::Vec3b>(x,y)[2] != seed_b_) 
        return; 
  
    // Replace the color at (x, y) 
    img_.at<cv::Vec3b>(x,y)[0] = (uchar) replace_r_; 
    img_.at<cv::Vec3b>(x,y)[1] = (uchar) replace_g_; 
    img_.at<cv::Vec3b>(x,y)[2] = (uchar) replace_b_; 
	Vertex* vtmp=active_vertices_.Remove(x,y);
    
	ant.Insert(vtmp);
  
    // Recur for north, east, south and west 
    floodFillUtil(x+1, y,ant); 
    floodFillUtil(x-1, y,ant); 
    floodFillUtil(x, y+1,ant); 
    floodFillUtil(x, y-1,ant); 
}