#include <heat_map.h>

bool HeatMap::Generate(vector<float>& data_A, vector<float>& data_B, int thresh, int mode)
{
    pcl::PointCloud<PointType>::Ptr cloud(new pcl::PointCloud<PointType>());
    pcl::search::KdTree<PointType>::Ptr kdtree(new pcl::search::KdTree<PointType>());
    float data_A_min=INT_MAX;
    float data_A_max=-INT_MAX;
    float data_B_min=INT_MAX;
    float data_B_max=-INT_MAX;
    for(int i=0; i<data_A.size(); i++){
        PointType ptmp;
        ptmp.x=data_A[i];
        ptmp.y=data_B[i];
        ptmp.z=0;
        cloud->points.push_back(ptmp);

        data_A_min=MIN2(data_A_min, data_A[i]);
        data_A_max=MAX2(data_A_max, data_A[i]);
        data_B_min=MIN2(data_B_min, data_B[i]);
        data_B_max=MAX2(data_B_max, data_B[i]);
    }
    kdtree->setInputCloud(cloud);
    

    float data_A_span=data_A_max-data_A_min;
    float data_B_span=data_B_max-data_B_min;
    data_A_min= data_A_min- 0.3*data_A_span;
    data_A_max= data_A_max+ 0.3*data_A_span;
    data_B_min= data_B_min- 0.3*data_B_span;
    data_B_max= data_B_max+ 0.3*data_B_span;
    data_A_span=data_A_max-data_A_min;
    data_B_span=data_B_max-data_B_min;
    float interval=data_A_span/30.0;
    num_of_x_= floor(data_A_span/interval)+1;
    num_of_y_= floor(data_B_span/interval)+1;

    /* Step 02: calculate unsigned distance field */
    VectorExtend<float> udf;
    udf.Resize(num_of_x_* num_of_y_, 0);
    int num_of_ngbr=2;
    for(int i=0; i<num_of_y_; i++){
        for(int j=0; j<num_of_x_; j++){
            float current_A= (j+0.5)*interval+data_A_min;
            float current_B= (i+0.5)*interval+data_B_min;

            // get its neighbours
            vector<int> idx;
            vector<float> dist;
            kdtree->nearestKSearch(PointType(current_A, current_B,0), num_of_ngbr, idx, dist);

            for(int k=0; k<idx.size(); k++){          
                int itmp=idx[k];
                udf[i*num_of_x_+j]+= pow(current_A - data_A[itmp],2) + pow(current_B- data_B[itmp],2);
            }       
            udf[i*num_of_x_+j]=sqrt(udf[i*num_of_x_+j]/num_of_ngbr);     
        }
    }


    colors_=udf.GetColors();    
    img_bk_= cv::Mat::zeros(num_of_y_, num_of_x_, CV_8UC3);
    int is_first_visit_front=1;
    int front_i, front_j;
    int is_first_visit_background=1;
    int background_i, background_j;
    for(int i=0; i<img_bk_.rows; i++){
        for(int j=0; j<img_bk_.cols; j++){
            if((uchar)colors_[i*num_of_x_+j].r==0 && (uchar)colors_[i*num_of_x_+j].g<thresh && (uchar)colors_[i*num_of_x_+j].b==255){
                img_bk_.at<cv::Vec3b>(img_bk_.rows-i-1,j)[0]=0x97;
                img_bk_.at<cv::Vec3b>(img_bk_.rows-i-1,j)[1]=0;
                img_bk_.at<cv::Vec3b>(img_bk_.rows-i-1,j)[2]=0xff;
                if(is_first_visit_front==1){
                    front_i=img_bk_.rows-i-1;
                    front_j=j;
                    is_first_visit_front=0;
                }
            }
            else{
                img_bk_.at<cv::Vec3b>(img_bk_.rows-i-1,j)[0]=255;
                img_bk_.at<cv::Vec3b>(img_bk_.rows-i-1,j)[1]=255;
                img_bk_.at<cv::Vec3b>(img_bk_.rows-i-1,j)[2]=255;
                if(is_first_visit_background==1){
                    background_i=img_bk_.rows-i-1;
                    background_j=j;
                    is_first_visit_background=0;
                }
            }
        }
    }

    FloodFill ff(img_bk_);
    bool is_close;
    if(mode==USE_BACKGROUND)
        is_close=ff.Apply(background_i,background_j);    
    else if(mode== USE_FRONT) 
        is_close=ff.Apply(front_i, front_j);
    else 
        cout<<"Mode error!"<<endl;

    /* Debug */
    #if IS_DEBUG_CLOSURE_TESINT
    cv::Mat img_heat_map(num_of_y_, num_of_x_, CV_8UC3, cv::Scalar(0,0,0));
        for(int i=0; i<img_heat_map.rows; i++){
        for(int j=0; j<img_heat_map.cols; j++){               
            img_heat_map.at<cv::Vec3b>(img_heat_map.rows-i-1,j)[0]=(uchar)colors_[i*num_of_x_+j].b;
            img_heat_map.at<cv::Vec3b>(img_heat_map.rows-i-1,j)[1]=(uchar)colors_[i*num_of_x_+j].g;
            img_heat_map.at<cv::Vec3b>(img_heat_map.rows-i-1,j)[2]=(uchar)colors_[i*num_of_x_+j].r;
        }
    }
    
    cv::imwrite("/media/i9/alpha/experiment_nc/1_special_cases/tmp/img_ff.png", ff.img_);
    cv::imwrite("/media/i9/alpha/experiment_nc/1_special_cases/tmp/img_heat_map.png",img_heat_map);
    // cv::imwrite("result/img_bk.png",img_bk);
    #endif
    
    return is_close;
}

void HeatMap::ExtractImageBK(string opath)
{
    cv::imwrite(opath, img_bk_);
}

void HeatMap::ExtractImageHeatmap(string opath)
{
    img_heat_map_=cv::Mat(num_of_y_, num_of_x_, CV_8UC3, cv::Scalar(0,0,0));
    for(int i=0; i<img_heat_map_.rows; i++){
        for(int j=0; j<img_heat_map_.cols; j++){               
            img_heat_map_.at<cv::Vec3b>(img_heat_map_.rows-i-1,j)[0]=(uchar)colors_[i*num_of_x_+j].b;
            img_heat_map_.at<cv::Vec3b>(img_heat_map_.rows-i-1,j)[1]=(uchar)colors_[i*num_of_x_+j].g;
            img_heat_map_.at<cv::Vec3b>(img_heat_map_.rows-i-1,j)[2]=(uchar)colors_[i*num_of_x_+j].r;
        }
    }
    cv::imwrite(opath, img_heat_map_);
}

/**
 * Description: generate heat map
 * @thresh_of_heatmap: Greater values lead to greater expansion.
 */
void HeatMap::GenerateHeatMap(int thresh_of_heatmap)
{
    /* Step 01: calculate unsigned distance field (UDF) */
    VectorExtend<float> udf;
    udf.Resize(num_of_x_* num_of_y_, 0);
    int num_of_ngbr=2;
    for(int i=0; i<num_of_y_; i++){
        for(int j=0; j<num_of_x_; j++){
            float current_x= (j+0.5)*gap_+xmin_;
            float current_y= (i+0.5)*gap_+ymin_;

            // get its neighbours
            vector<int> idx;
            vector<float> dist;
            kdtree_->nearestKSearch(PointType(current_x, current_y, 0), num_of_ngbr, idx, dist);

            for(int k=0; k<idx.size(); k++){          
                int itmp=idx[k];
                udf[i*num_of_x_+j]+= pow(current_x - datX_[itmp],2) + pow(current_y- datY_[itmp],2);
            }       
            udf[i*num_of_x_+j]=sqrt(udf[i*num_of_x_+j]/num_of_ngbr);     
        }        
    }    

    /* Step 02: */
    colors_=udf.GetColors();
    img_bk_=cv::Mat::zeros(num_of_y_, num_of_x_, CV_8UC3);

    int is_first_visit_front=1;
    int front_i, front_j;
    int is_first_visit_background=1;
    int background_i, background_j;
    for(int i=0; i<img_bk_.rows; i++){
        for(int j=0; j<img_bk_.cols; j++){
            if((uchar)colors_[i*num_of_x_+j].r==0 && (uchar)colors_[i*num_of_x_+j].g<thresh_of_heatmap && (uchar)colors_[i*num_of_x_+j].b==255){
                img_bk_.at<cv::Vec3b>(img_bk_.rows-i-1,j)[0]=0x97;
                img_bk_.at<cv::Vec3b>(img_bk_.rows-i-1,j)[1]=0;
                img_bk_.at<cv::Vec3b>(img_bk_.rows-i-1,j)[2]=0xff;
                if(is_first_visit_front==1){
                    front_i=img_bk_.rows-i-1;
                    front_j=j;
                    is_first_visit_front=0;
                }
            }
            else{
                img_bk_.at<cv::Vec3b>(img_bk_.rows-i-1,j)[0]=255;
                img_bk_.at<cv::Vec3b>(img_bk_.rows-i-1,j)[1]=255;
                img_bk_.at<cv::Vec3b>(img_bk_.rows-i-1,j)[2]=255;
                if(is_first_visit_background==1){
                    background_i=img_bk_.rows-i-1;
                    background_j=j;
                    is_first_visit_background=0;
                }
            }
        }
    }
   
}

bool HeatMap::IsWithin(float px, float py, string path)
{
    auto [u_of_pt, v_of_pt]=GetPixelLocation(px, py);
    if(u_of_pt<0 | u_of_pt> num_of_x_)
        return false;
    
    if(v_of_pt<0 | v_of_pt> num_of_y_)
        return false;

    if(path!=""){
        img_bk_.at<cv::Vec3b>(img_bk_.rows-v_of_pt-1, u_of_pt)[0]=0;
        img_bk_.at<cv::Vec3b>(img_bk_.rows-v_of_pt-1, u_of_pt)[1]=0xff;
        img_bk_.at<cv::Vec3b>(img_bk_.rows-v_of_pt-1, u_of_pt)[2]=0;
        cv::imwrite(path, img_bk_);
    }

    if(img_bk_.at<cv::Vec3b>(img_bk_.rows-v_of_pt-1, u_of_pt)[0]==0x97 && 
       img_bk_.at<cv::Vec3b>(img_bk_.rows-v_of_pt-1, u_of_pt)[1]==0 &&
       img_bk_.at<cv::Vec3b>(img_bk_.rows-v_of_pt-1, u_of_pt)[2]==0xff){
        return true;
    }
    else 
        return false;
}

void HeatMap::SetInputData(vector<vector<float>>& dat)
{
    for(int i=0; i<dat.size(); i++){
        datX_.push_back(dat[i][0]);
        datY_.push_back(dat[i][1]);
    }

    /* set cloud */
    cloud_=pcl::PointCloud<PointType>::Ptr(new pcl::PointCloud<PointType>());
    for(int i=0; i<datX_.size(); i++){
        PointType ptmp;
        ptmp.x=datX_[i];
        ptmp.y=datY_[i];
        ptmp.z=0;
        cloud_->points.push_back(ptmp);
    }

    /* set kdtree */
    kdtree_=pcl::search::KdTree<PointType>::Ptr(new pcl::search::KdTree<PointType>());
    kdtree_->setInputCloud(cloud_);

    SetProperties();
}

void HeatMap::SetInputData(vector<float>& datA, vector<float>& datB)
{
    datX_=datA;
    datY_=datB;

    /* set cloud */
    cloud_=pcl::PointCloud<PointType>::Ptr(new pcl::PointCloud<PointType>());
    for(int i=0; i<datX_.size(); i++){
        PointType ptmp;
        ptmp.x=datX_[i];
        ptmp.y=datY_[i];
        ptmp.z=0;
        cloud_->points.push_back(ptmp);
    }

    /* set kdtree */
    kdtree_=pcl::search::KdTree<PointType>::Ptr(new pcl::search::KdTree<PointType>());
    kdtree_->setInputCloud(cloud_);

    SetProperties();
}

void HeatMap::SetInputData(pcl::PointCloud<PointType>::Ptr cloud)
{
    cloud_=cloud;

    /* set kdtree_ */
    kdtree_=pcl::search::KdTree<PointType>::Ptr(new pcl::search::KdTree<PointType>());
    kdtree_->setInputCloud(cloud_);

    /* set data */
    for(int i=0; i<cloud_->points.size(); i++){
        datX_.push_back(cloud_->points[i].x);
        datY_.push_back(cloud_->points[i].y);
    }
    SetProperties();
}

void HeatMap::SetProperties(float num_of_division, float scale)
{
    xmin_=*min_element(datX_.begin(), datX_.end());
    xmax_=*max_element(datX_.begin(), datX_.end());
    ymin_=*min_element(datY_.begin(), datY_.end());
    ymax_=*max_element(datY_.begin(), datY_.end());

    xspan_=xmax_-xmin_;
    yspan_=ymax_-ymin_;
    xmin_= xmin_- scale * xspan_;
    xmax_= xmax_+ scale * xspan_;
    ymin_= ymin_- scale * yspan_;
    ymax_= ymax_+ scale * yspan_;
    xspan_=xmax_-xmin_;
    yspan_=ymax_-ymin_;
    gap_=xspan_/num_of_division;
    num_of_x_= floor(xspan_/gap_)+1;
    num_of_y_= floor(yspan_/gap_)+1;
}

tuple<int,int> HeatMap::GetPixelLocation(float px, float py)
{
    int u_of_pt= floor((px - xmin_)/gap_);
    int v_of_pt= floor((py - ymin_)/gap_);
    return make_tuple(u_of_pt, v_of_pt);
}