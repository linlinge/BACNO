#include <BoundaryDetection.h>
#include <fstream>
#include <heat_map.h>
using namespace std;

float clock01_start, clock01_end;
float clock01_sum=0; 
float clock02_start, clock02_end;
float clock02_sum=0; 
float clock03_start, clock03_end;
float clock03_sum=0; 
float clock04_start, clock04_end;
float clock04_sum=0; 

float TranZ_clock01_start, TranZ_clock01_end;
float TranZ_clock01_sum=0; 
float TranZ_clock02_start, TranZ_clock02_end;
float TranZ_clock02_sum=0; 
float TranZ_clock03_start, TranZ_clock03_end;
float TranZ_clock03_sum=0; 
float TranZ_clock04_start, TranZ_clock04_end;
float TranZ_clock04_sum=0; 
float TranZ_clock05_start, TranZ_clock05_end;
float TranZ_clock05_sum=0; 

std::tuple<vector<vector<int>>, int> GetConnectedComponents(pcl::PointCloud<PointType>::Ptr cloud, PointType& query_pt, int K)
{
    int num_of_pts_in_cloud = cloud->points.size();
    pcl::search::KdTree<PointType>::Ptr mykdtree(new pcl::search::KdTree<PointType>);
    mykdtree->setInputCloud(cloud);

    /* find the indices of query pt */
    vector<int> indices_of_finding_query_pt;
    vector<float> dist_of_finding_query_pt;
    mykdtree->nearestKSearch(query_pt, 1, indices_of_finding_query_pt, dist_of_finding_query_pt);
    int indice_of_query_pt = indices_of_finding_query_pt[0];


    /* create graph */
    BoostGraph g;    
    for(int i=0; i < num_of_pts_in_cloud; i++){
        vector<int> idx;
        vector<float> dist;
        mykdtree->nearestKSearch(i, K, idx, dist);

        for(int j=1; j<K; j++){
            add_edge(idx[0], idx[j], g);
        }
    }

    // This vector will hold the component index for each vertex
    std::vector<int> component(num_vertices(g));

    // The total number of components
    int num = boost::connected_components(g, &component[0]);

    // Map from component number to its vertices
    std::map<int, std::vector<int>> component_map;

    for (size_t i = 0; i != component.size(); ++i) {
        component_map[component[i]].push_back(i);
    }

    // Convert map to vector<vector<int>>
    std::vector<std::vector<int>> components(num);
    for (const auto& pair : component_map) {
        components[pair.first] = pair.second;
    }

    int target=-1;
    for(int i=0; i<components.size(); i++){
         auto it = std::find(components[i].begin(), components[i].end(), indice_of_query_pt);
         if(it!= components[i].end()){
            target=i;
            break;
         }
    }

    if(target==-1){
        cout<<"Error: the target not find!"<<endl;
    }
    
    return std::make_tuple(components, target);
}


template <typename T>  
std::vector<T> selectData(const std::vector<T>& data, const std::vector<int>& indices) {  
    std::unordered_set<int> indexSet(indices.begin(), indices.end());  
    std::vector<T> selectedData;  
    for (int index = 0; index < data.size(); ++index) {  
        if (indexSet.count(index) > 0) {  
            selectedData.push_back(data[index]);  
        }  
    }  
    return selectedData;  
}  

// Method 01: |Ni-Nj| > delta
void DetectHoleEdge01(pcl::PointCloud<PointType>::Ptr cloud)
{
	int K=32;
	pcl::search::KdTree<PointType>::Ptr kdtree(new pcl::search::KdTree<PointType>());
	kdtree->setInputCloud(cloud);
	#pragma omp parallel for
	for(int i=0;i<cloud->points.size();i++){
		Eigen::MatrixXd Nc(3,1);
		Nc<<cloud->points[i].normal_x,cloud->points[i].normal_y,cloud->points[i].normal_z;
		vector<int> idx(K);
		vector<float> dist(K);
		kdtree->nearestKSearch(cloud->points[i], K, idx, dist);
		int count=0;
		for(int j=0;j<K;j++){			
			Eigen::MatrixXd Nn(3,1);
			Nn<<cloud->points[idx[j]].normal_x,cloud->points[idx[j]].normal_y,cloud->points[idx[j]].normal_z;
			Eigen::MatrixXd cos_arc=Nc.transpose()*Nn*1.0f/Nc.norm()/Nn.norm();
			float arc=acos(cos_arc(0));
			if(arc>M_PI/2.0){
				// cloud->points[idx[j]].r=255;
				// cloud->points[idx[j]].g=0;
				// cloud->points[idx[j]].b=0;
				count++;
			}
		}
		float ratio=count*1.0/K;
		if(ratio>0.8){
			cloud->points[i].r=255;
			cloud->points[i].g=0;
			cloud->points[i].b=0;
		}
	}
	pcl::io::savePLYFileASCII("/home/i9/experiment_nc/DTU/stl006_total_boundary.ply",*cloud);
}

// Method 02: centroid != sphere centre
// void DetectHoleEdge02_kNN(pcl::PointCloud<PointType>::Ptr cloud)
// {
// 	int K=200;
// 	pcl::search::KdTree<PointType>::Ptr kdtree(new pcl::search::KdTree<PointType>());
// 	kdtree->setInputCloud(cloud);
// 	float ngbr_mean_dist_=ComputeMeanDistance(cloud);
// 	#pragma omp parallel for
// 	for(int i=0;i<cloud->points.size();i++){		
// 		vector<int> idx(K);
// 		vector<float> dist(K);
// 		kdtree->nearestKSearch(cloud->points[i], K, idx, dist);
// 		float px,py,pz;
// 		px=py=pz=0;	
// 		for(int j=0;j<K;j++){			
// 			px=px+cloud->points[idx[j]].x;
// 			py=py+cloud->points[idx[j]].y;
// 			pz=pz+cloud->points[idx[j]].z;
// 		}
// 		px=px/K;
// 		py=py/K;
// 		pz=pz/K;
// 		float dist_centroid_centre=sqrt(pow(px-cloud->points[i].x,2)+pow(py-cloud->points[i].y,2)+pow(pz-cloud->points[i].z,2));
// 		if(dist_centroid_centre>3*ngbr_mean_dist_){
// 			cloud->points[i].r=0;
// 			cloud->points[i].g=255;
// 			cloud->points[i].b=0;
// 		}
// 	}
// 	pcl::io::savePLYFileASCII("/home/i9/experiment_nc/DTU/stl001_total_cca_2_or_boundary.ply",*cloud);
// }

// Method 02: centroid != sphere centre
// void DetectHoleEdge02_r(pcl::PointCloud<PointType>::Ptr cloud)
// {	
// 	pcl::search::KdTree<PointType>::Ptr kdtree(new pcl::search::KdTree<PointType>());
// 	kdtree->setInputCloud(cloud);
// 	float ngbr_mean_dist_=ComputeMeanDistance(cloud);
// 	#pragma omp parallel for
// 	for(int i=0;i<cloud->points.size();i++){
// 		vector<int> idx;
// 		vector<float> dist;
// 		kdtree->radiusSearch (cloud->points[i], 10*ngbr_mean_dist_, idx, dist);
// 		int K=idx.size();
// 		float px,py,pz;
// 		px=py=pz=0;
// 		for(int j=0;j<K;j++){
// 			px=px+cloud->points[idx[j]].x;
// 			py=py+cloud->points[idx[j]].y;
// 			pz=pz+cloud->points[idx[j]].z;
// 		}
// 		px=px/K;
// 		py=py/K;
// 		pz=pz/K;
// 		float dist_centroid_centre=sqrt(pow(px-cloud->points[i].x,2)+pow(py-cloud->points[i].y,2)+pow(pz-cloud->points[i].z,2));
// 		if(dist_centroid_centre>3*ngbr_mean_dist_){
// 			cloud->points[i].r=0;
// 			cloud->points[i].g=255;
// 			cloud->points[i].b=0;
// 		}
// 	}
// 	pcl::io::savePLYFileASCII("EdgeDetect.ply",*cloud);
// }

// Method 03: Direction Distribution
// void DetectHoleEdge03_Radius(pcl::PointCloud<PointType>::Ptr cloud)
// {
//     pcl::search::KdTree<PointType>::Ptr kdtree(new pcl::search::KdTree<PointType>());
//     pcl::PointCloud<PointType>::Ptr cloud_boundary(new pcl::PointCloud<PointType>());
//     pcl::PointCloud<PointType>::Ptr cloud_subject(new pcl::PointCloud<PointType>());
// 	kdtree->setInputCloud(cloud);
// 	float ngbr_mean_dist_=ComputeMeanDistance(cloud);
//     vector<int> boundary_id;
//     vector<float> Kstatistical;
//     Kstatistical.resize(cloud->points.size());

// 	// #pragma omp parallel for
// 	for(int i=0;i<cloud->points.size();i++){
//         // Define
// 		vector<int> idx;
// 		vector<float> dist;
//         float roll_gap,max_roll_gap;
//         float pitch_gap,max_pitch_gap;
//         float yaw_gap,max_yaw_gap;
//         roll_gap=pitch_gap=yaw_gap=0;
//         max_roll_gap=max_pitch_gap=max_yaw_gap=0;

//         // Establish Kdtree
// 		kdtree->radiusSearch(cloud->points[i], 6*ngbr_mean_dist_, idx, dist);
// 		int K=idx.size();

//         Kstatistical[i]=K;
//         // temp cloud among radius
//         vector<Point> ptmp;
//         ptmp.resize(K);
//         for(int j=1;j<K;j++){
//             float delta_x=cloud->points[idx[j]].x-cloud->points[i].x;
//             float delta_y=cloud->points[idx[j]].y-cloud->points[i].y;
//             float delta_z=cloud->points[idx[j]].z-cloud->points[i].z;
//             ptmp[j].RollPitchYaw(idx[j],delta_x,delta_y,delta_z);
//         }

//         // Calculate 01: max_roll_gap
//         sort(ptmp.begin(),ptmp.end(),[](Point& e1, Point& e2){ return (e1.roll_<e2.roll_);});
//         for(int j=1;j<K;j++){
//             roll_gap=ptmp[j].roll_-ptmp[j-1].roll_;
//             max_roll_gap=max_roll_gap>roll_gap ? max_roll_gap:roll_gap;
//         }
//         roll_gap=2*M_PI-(ptmp[K-1].roll_-ptmp[0].roll_);
//         max_roll_gap=max_roll_gap>roll_gap ? max_roll_gap:roll_gap;

//         // Calculate 02: max_pitch_gap
//         sort(ptmp.begin(),ptmp.end(),[](Point& e1, Point& e2){ return (e1.pitch_<e2.pitch_);});
//         for(int j=1;j<K;j++){
//             pitch_gap=ptmp[j].pitch_-ptmp[j-1].pitch_;
//             max_pitch_gap=max_pitch_gap>pitch_gap ? max_pitch_gap:pitch_gap;
//         }
//         pitch_gap=2*M_PI-(ptmp[K-1].pitch_-ptmp[0].pitch_);
//         max_pitch_gap=max_pitch_gap>pitch_gap ? max_pitch_gap:pitch_gap;

//         // Calculate 03: max_gamma_gap
//         sort(ptmp.begin(),ptmp.end(),[](Point& e1, Point& e2){ return (e1.yaw_<e2.yaw_);});
//         for(int j=1;j<K;j++){
//             yaw_gap=ptmp[j].yaw_-ptmp[j-1].yaw_;
//             max_yaw_gap=max_yaw_gap>yaw_gap ? max_yaw_gap:yaw_gap;
//         }
//         yaw_gap=2*M_PI-(ptmp[K-1].yaw_-ptmp[0].yaw_);
//         max_yaw_gap=max_yaw_gap>yaw_gap ? max_yaw_gap:yaw_gap;

//         // roll,pitch,yaw threshould
//         if(max_roll_gap>M_PI/2.0 && max_pitch_gap>M_PI/2.0 && max_yaw_gap>M_PI/2.0){
//             // cloud->points[i].r=0;
//             // cloud->points[i].g=255;
//             // cloud->points[i].b=0;
//             boundary_id.push_back(i);
//             cloud_boundary->points.push_back(cloud->points[i]);
//         }
//         else{
//             cloud_subject->points.push_back(cloud->points[i]);
//         }
// 	}
//     cout<<"End!"<<endl;
//     ofstream fout("BoundaryID.csv");
//     for(int i=0;i<boundary_id.size();i++){
//         fout<<boundary_id[i]<<endl;
//     }
//     fout.close();
//     pcl::io::savePLYFileASCII("CloudSubject.ply",*cloud_subject);
// 	pcl::io::savePLYFileASCII("EdgeDetect.ply",*cloud_boundary);
// }


// Method 03: Direction Distribution (kNN)
// void DetectHoleEdge03_kNN(pcl::PointCloud<PointType>::Ptr cloud)
// {
//     pcl::search::KdTree<PointType>::Ptr kdtree(new pcl::search::KdTree<PointType>());    
// 	kdtree->setInputCloud(cloud);
// 	float ngbr_mean_dist_=ComputeMeanDistance(cloud);

//     vector<int> idx_boundary;

// 	// #pragma omp parallel for
// 	for(int i=0;i<cloud->points.size();i++){
//         cout<<i<<endl;
        
//         // Define
// 		vector<int> idx;
// 		vector<float> dist;
//         float roll_gap,max_roll_gap;
//         float pitch_gap,max_pitch_gap;
//         float yaw_gap,max_yaw_gap;
//         roll_gap=pitch_gap=yaw_gap=0;
//         max_roll_gap=max_pitch_gap=max_yaw_gap=0;

//         // Establish Kdtree
//         int K=40;
// 		kdtree->nearestKSearch (cloud->points[i], K, idx, dist);

//         // kNN temp cloud
//         vector<Point> ptmp;
//         ptmp.resize(K);
//         for(int j=1;j<K;j++){
//             float delta_x=cloud->points[idx[j]].x-cloud->points[i].x;
//             float delta_y=cloud->points[idx[j]].y-cloud->points[i].y;
//             float delta_z=cloud->points[idx[j]].z-cloud->points[i].z;
//             ptmp[j].RollPitchYaw(idx[j],delta_x,delta_y,delta_z);
//         }            

//         // Calculate 01: max_roll_gap
//         sort(ptmp.begin(),ptmp.end(),[](Point& e1, Point& e2){ return (e1.roll_<e2.roll_);});
//         for(int j=1;j<K;j++){
//             roll_gap=ptmp[j].roll_-ptmp[j-1].roll_;
//             max_roll_gap=max_roll_gap>roll_gap ? max_roll_gap:roll_gap;
//         }
//         roll_gap=2*M_PI-(ptmp[K-1].roll_-ptmp[0].roll_);
//         max_roll_gap=max_roll_gap>roll_gap ? max_roll_gap:roll_gap;

//         // Calculate 02: max_pitch_gap
//         sort(ptmp.begin(),ptmp.end(),[](Point& e1, Point& e2){ return (e1.pitch_<e2.pitch_);});
//         for(int j=1;j<K;j++){
//             pitch_gap=ptmp[j].pitch_-ptmp[j-1].pitch_;
//             max_pitch_gap=max_pitch_gap>pitch_gap ? max_pitch_gap:pitch_gap;
//         }
//         pitch_gap=2*M_PI-(ptmp[K-1].pitch_-ptmp[0].pitch_);
//         max_pitch_gap=max_pitch_gap>pitch_gap ? max_pitch_gap:pitch_gap;

//         // Calculate 03: max_gamma_gap
//         sort(ptmp.begin(),ptmp.end(),[](Point& e1, Point& e2){ return (e1.yaw_<e2.yaw_);});
//         for(int j=1;j<K;j++){
//             yaw_gap=ptmp[j].yaw_-ptmp[j-1].yaw_;
//             max_yaw_gap=max_yaw_gap>yaw_gap ? max_yaw_gap:yaw_gap;
//         }
//         yaw_gap=2*M_PI-(ptmp[K-1].yaw_-ptmp[0].yaw_);
//         max_yaw_gap=max_yaw_gap>yaw_gap ? max_yaw_gap:yaw_gap;

//         // roll, pitch, yaw threshould
//         if((max_roll_gap>M_PI/2.0) && (max_pitch_gap>M_PI/2.0 || max_yaw_gap>M_PI/2.0)){
//             // if(max_pitch_gap>M_PI/2.0 && max_yaw_gap>M_PI/2.0){
                
//             // }
//             // else{
//             //     cloud->points[i].r=255;
//             //     cloud->points[i].g=0;
//             //     cloud->points[i].b=0;
//             // }

            
//             cloud->points[i].r=255;
//             cloud->points[i].g=0;
//             cloud->points[i].b=0;

//             idx_boundary.push_back(i);
//         }
// 	}

//     pcl::PointCloud<PointType>::Ptr cloud_out(new pcl::PointCloud<PointType>());
//     pcl::copyPointCloud(*cloud, idx_boundary, *cloud_out);

//     vector<vector<float>> pts;
//     for(int i=0; i<cloud_out->points.size(); i++){
//         vector<float> ptmp;
//         ptmp.push_back(cloud_out->points[i].x);
//         ptmp.push_back(cloud_out->points[i].y);
//         ptmp.push_back(cloud_out->points[i].z);

//         pts.push_back(ptmp);
//     }
    
//     // DBSCAN db(pts, 0.5);

//     //  pcl::copyPointCloud(cloud, db.c2p_[0], cloud_out);
// 	pcl::io::savePLYFileASCII("/home/i9/experiment_nc/DTU/stl006_total_ryp_boundary.ply", *cloud_out);
// }


// Method 04: pcl api (based on normal estimation)
// void EdgeDetection(pcl::PointCloud<PointType>::Ptr cloud)
// {
//     pcl::PointCloud<pcl::Normal>::Ptr normals (new pcl::PointCloud<pcl::Normal>);
//     pcl::PointCloud<pcl::Boundary> boundaries;
//     pcl::BoundaryEstimation<PointType,pcl::Normal,pcl::Boundary> est;
//     pcl::search::KdTree<PointType>::Ptr tree(new pcl::search::KdTree<PointType>());
//     pcl::NormalEstimation<PointType,pcl::Normal> normEst;  //其中pcl::PointXYZ表示输入类型数据，pcl::Normal表示输出类型,且pcl::Normal前三项是法向，最后一项是曲率
//     normEst.setInputCloud(cloud);
//     normEst.setSearchMethod(tree);
//     // normEst.setRadiusSearch(2);  //法向估计的半径
//     normEst.setKSearch(50);  //法向估计的点数
//     normEst.compute(*normals);
//     cout<<"normal size is "<< normals->size()<<endl;

//     //normal_est.setViewPoint(0,0,0); //这个应该会使法向一致
//     est.setInputCloud(cloud);
//     est.setInputNormals(normals);
//     est.setAngleThreshold(M_PI/4.0);
//     //   est.setSearchMethod (pcl::search::KdTree<pcl::PointXYZ>::Ptr (new pcl::search::KdTree<pcl::PointXYZ>));
//     est.setSearchMethod (tree);
//     est.setKSearch(100);  //一般这里的数值越高，最终边界识别的精度越好
//     //  est.setRadiusSearch(everagedistance);  //搜索半径
//     est.compute (boundaries);

//     //  pcl::PointCloud<pcl::PointXYZ> boundPoints;
//     pcl::PointCloud<PointType>::Ptr boundPoints (new pcl::PointCloud<PointType>);
//     pcl::PointCloud<PointType> noBoundPoints;
//     int countBoundaries = 0;
//     for(int i=0; i<cloud->size(); i++){
//         int x = (boundaries.points[i].boundary_point);
//         int a = static_cast<int>(x); //该函数的功能是强制类型转换
//         if(a == 1)
//         {
//             //  boundPoints.push_back(cloud->points[i]);
//             (*boundPoints).push_back(cloud->points[i]);
//             countBoundaries++;
//             cloud->points[i].r=255;
//             cloud->points[i].g=0;
//             cloud->points[i].b=0;
//         }
//         else
//             noBoundPoints.push_back(cloud->points[i]);
//     }
//     std::cout<<"boudary size is:" <<countBoundaries <<std::endl;
//     pcl::io::savePLYFileBinary("/home/i9/experiment_nc/DTU/stl006_total_pcl_api_boundary.ply",*boundPoints);
// }


void ClosureTesting::SetInputCloud(pcl::PointCloud<PointType>::Ptr cloud)
{
    cloud_=cloud;
}

void TransZ(vector<vector<float>>& pts, vector<vector<float>>& pts_tf)
{
    #if WHETHER_ENABLE_TIMER
    TranZ_clock01_start = omp_get_wtime(); 
    #endif 

    pts_tf.resize(pts.size(), vector<float>(3));

    #if WHETHER_ENABLE_TIMER
    TranZ_clock01_end =  omp_get_wtime(); 
    TranZ_clock01_sum += TranZ_clock01_end - TranZ_clock01_start;
    #endif 

    #if WHETHER_ENABLE_TIMER
    TranZ_clock02_start = omp_get_wtime(); 
    #endif 

    Plane pl(pts);

    #if WHETHER_ENABLE_TIMER
    TranZ_clock02_end =  omp_get_wtime(); 
    TranZ_clock02_sum += TranZ_clock02_end - TranZ_clock02_start;
    #endif

    #if WHETHER_ENABLE_TIMER
    TranZ_clock03_start = omp_get_wtime(); 
    #endif 
    Quaterniond trans_=Quaterniond::FromTwoVectors(Vector3d(pl.A_, pl.B_, pl.C_), Vector3d(0,0,1));

    #if WHETHER_ENABLE_TIMER
    TranZ_clock03_end =  omp_get_wtime(); 
    TranZ_clock03_sum += TranZ_clock03_end - TranZ_clock03_start;
    #endif 

    #if WHETHER_ENABLE_TIMER
    TranZ_clock04_start = omp_get_wtime(); 
    #endif 

    auto rotation_matrix = trans_.toRotationMatrix();
    double& r00 = rotation_matrix(0,0);
    double& r01 = rotation_matrix(0,1);
    double& r02 = rotation_matrix(0,2);
    double& r10 = rotation_matrix(1,0);
    double& r11 = rotation_matrix(1,1);
    double& r12 = rotation_matrix(1,2);
    double& r20 = rotation_matrix(2,0);
    double& r21 = rotation_matrix(2,1);
    double& r22 = rotation_matrix(2,2);
    // float 
    #if WHETHER_ENABLE_TIMER
    TranZ_clock04_end =  omp_get_wtime(); 
    TranZ_clock04_sum += TranZ_clock04_end - TranZ_clock04_start;
    #endif 

    #if WHETHER_ENABLE_TIMER
    TranZ_clock05_start = omp_get_wtime(); 
    #endif 

    for(int i=0; i<pts.size(); i++){
        // Vector3d ptmp=rotation_matrix*Vector3d(pts[i][0], pts[i][1], pts[i][2]);
        // pts_tf[i][0]=ptmp[0];
        // pts_tf[i][1]=ptmp[1];
        // pts_tf[i][2]=ptmp[2];

        auto& x = pts[i][0];     
        auto& y = pts[i][1];
        auto& z = pts[i][2];        
        pts_tf[i][0]=r00*x+r01*y+r02*z;
        pts_tf[i][1]=r10*x+r11*y+r12*z;
        pts_tf[i][2]=r20*x+r21*y+r22*z;
    }

    #if WHETHER_ENABLE_TIMER
    TranZ_clock05_end =  omp_get_wtime(); 
    TranZ_clock05_sum += TranZ_clock05_end - TranZ_clock05_start;
    #endif 
}


void ClosureTesting::Apply(int thresh)
{
    #if WHETHER_ENABLE_TIMER
    clock01_start = omp_get_wtime(); 
    #endif 

    vector<vector<float>> pts(cloud_->points.size(), vector<float>(3));
    for(int i=0; i<cloud_->points.size(); i++){
        const auto& point = cloud_->points[i];  // 避免重复索引
        pts[i][0] = point.x;
        pts[i][1] = point.y;
        pts[i][2] = point.z;
    }

    #if WHETHER_ENABLE_TIMER
    clock01_end = omp_get_wtime(); 
    clock01_sum += clock01_end - clock01_start;
    #endif

    #if WHETHER_ENABLE_TIMER
    clock02_start = omp_get_wtime();
    #endif 

    vector<vector<float>> pts_tf;
    TransZ(pts, pts_tf);

    #if WHETHER_ENABLE_TIMER
    clock02_end = omp_get_wtime(); 
    clock02_sum += clock02_end - clock02_start;
    #endif

    #if WHETHER_ENABLE_TIMER
    clock03_start = omp_get_wtime();
    #endif 

    x_.resize(pts_tf.size());
    y_.resize(pts_tf.size());
    z_.resize(pts_tf.size());
    for(int i=0; i<pts_tf.size(); i++){
        x_[i]=pts_tf[i][0];
        y_[i]=pts_tf[i][1];
        z_[i]=pts_tf[i][2];
    }

    #if WHETHER_ENABLE_TIMER
    clock03_end = omp_get_wtime(); 
    clock03_sum += clock03_end - clock03_start;
    #endif
    
    #if WHETHER_ENABLE_TIMER
    clock04_start = omp_get_wtime();
    #endif 

    is_disc_ = hm_.Generate(x_,y_, thresh, 0);

    #if WHETHER_ENABLE_TIMER
    clock04_end = omp_get_wtime(); 
    clock04_sum += clock04_end - clock04_start;
    #endif
}

bool ClosureTesting::IsDisc()
{
    return is_disc_;
}

/******************************************************** Edge Detection ******************************************************/
/**
 * Description: apply edge detection algorithm
 * @param scale_of_radius: the larger it is, the large of the neighbourhood
 * @param thresh_of_HeatMap: the threshold of converting to black color in heatmap
*/
void EdgeDetection::Apply(float scale_of_radius, int thresh_of_HeatMap)
{   cout<<"   * Apply ..."<<endl;   
    // if(numOfPts_>50000){
    //     ApplyClosureTesting_BestFittingPlane_Fast(scale_of_radius, thresh_of_HeatMap);        
    // }            
    // else{
        ComputeDensity(); 
        ApplyClosureTesting_BestFittingPlane(cloud_raw_, indices_of_candidate_edge_pts_, scale_of_radius, thresh_of_HeatMap);    
    // }
    cout<<"   * Apply finished!"<<endl;   
}

void EdgeDetection::SetCloudProperties(string ipath_of_raw)
{   
    cout<<"   * SetCloudProperties ..."<<endl;
    cp_=CloudProperties(ipath_of_raw);
    cloud_raw_=cp_.cloud_;
    ngbr_min_dist_=cp_.GetMinimumDistance();
    ngbr_mean_dist_=cp_.GetMeanDistance();
    ngbr_max_dist_=cp_.GetMaximumDistance();
    kdtree_raw_=pcl::search::KdTree<PointType>::Ptr(new pcl::search::KdTree<PointType>());
    kdtree_raw_->setInputCloud(cloud_raw_);
    numOfPts_ = cp_.GetNumberOfPts();

    // set competitor
    indices_of_competitor_.resize(cloud_raw_->points.size());
    for(int i=0; i<cloud_raw_->points.size(); i++)
        indices_of_competitor_[i]=i;
    
    cout<<"   * SetCloudProperties finished!"<<endl;
}

void EdgeDetection::SetPrefix(string prefix)
{
    prefix_=prefix;
}

/**
 * @brief pre screening through point density
 * 
 */
void EdgeDetection::PreScreening()
{
    vector<float> dsty=cp_.GetDensityViaRadius(5*ngbr_max_dist_);
    VectorExtend<float> ve(dsty);
    indices_of_competitor_=ve.GetIndicesOfBlue();
    flag_of_pre_sceening_=1;
}

/**
 * @brief detect edge via closure testing
 * 
 * @param raw_cloud                 pointer to raw point cloud
 * @param scale_of_radius           scale_of_radius * max_distance_in_nearest_neighbour
 * @param thresh_of_MinMaxRatio     eig[0]/eigen[1] threshold, which is used to filter high curvature regions
 * @param thresh_of_HeatMap         heatmap -> binary map threshold, the larger it is , the larger the range is
 */
void EdgeDetection::ApplyClosureTesting_BestFittingPlane(pcl::PointCloud<PointType>::Ptr cloud_active, vector<int>& indices_of_candidate, float scale_of_radius, int thresh_of_HeatMap)
{   
    int num_of_pts_in_cloud_active = cloud_active->points.size();    
    pcl::search::KdTree<PointType>::Ptr kdtree_active(new pcl::search::KdTree<PointType>);
    kdtree_active->setInputCloud(cloud_active);

    /* ST02: apply edge detection */
    flag_is_edge_pts_in_active_cloud_.resize(num_of_pts_in_cloud_active,0);    
    CloudProperties cp_cloud_dwn(cloud_active);
    // ngbr_max_dist_=cp_cloud_dwn.GetMaximumDistance();
    float r=scale_of_radius * ngbr_max_dist_;
    
    float clock1_start, clock1_end, clock1_sum; 
    float clock2_start, clock2_end, clock2_sum;
    float clock3_start, clock3_end, clock3_sum;
    clock1_sum = clock2_sum = clock3_sum = 0; 
    
    // ofstream fout("1.txt");

    #if IS_DEBUG_BOUNDARY_DETECTION
    for(int i= 0; i<indices_of_candidate.size(); i++){
    #else 
    #pragma omp parallel for
    for(int i = 0; i<indices_of_candidate.size(); i++){
    #endif
        int current_i = indices_of_candidate[i];
        // fout<<current_i<<endl;
        // cout<<current_i<<endl;
        #if WHETHER_ENABLE_TIMER
        clock1_start = omp_get_wtime(); 
        #endif 

        pcl::PointCloud<PointType>::Ptr local_cloud(new pcl::PointCloud<PointType>);        
        vector<int> idx_local_cloud;
        vector<float> dist_local_cloud;                     
        kdtree_active->radiusSearch(cloud_active->points[current_i], r, idx_local_cloud, dist_local_cloud);
        if(idx_local_cloud.size()<5){ // if the radius is too small, try larger radius
            kdtree_active->radiusSearch(cloud_active->points[current_i], 2*r, idx_local_cloud, dist_local_cloud);
        }
        local_cloud->reserve(idx_local_cloud.size());
        pcl::copyPointCloud(*cloud_active, idx_local_cloud, *local_cloud);

        #if WHETHER_ENABLE_TIMER
        clock1_end = omp_get_wtime(); 
        clock1_sum+=clock1_end- clock1_start;
        #endif

        /* if local_cloud contains two sub clouds, remove the useless sub cloud */
        // auto [components, idx_of_in]=GetConnectedComponents(local_cloud, cloud_active->points[i]);
        // if(components.size()>1){
        //     pcl::copyPointCloud(*local_cloud, components[idx_of_in], *local_cloud);
        //     idx_local_cloud = selectData(idx_local_cloud, components[idx_of_in]);
        //     dist_local_cloud = selectData(dist_local_cloud, components[idx_of_in]);
        // }
   
        /* extract local disk */
        #if WHETHER_ENABLE_TIMER
        clock2_start = omp_get_wtime(); 
        #endif 

        pcl::PointCloud<PointType>::Ptr local_disk(new pcl::PointCloud<PointType>);
        vector<int> idx_local_disk; 
        for(int j=0; j<dist_local_cloud.size(); j++){
            if(abs(r-sqrt(dist_local_cloud[j]))<0.4*r){
                idx_local_disk.push_back(idx_local_cloud[j]);
            }
        }
        local_disk->reserve(idx_local_disk.size());
        pcl::copyPointCloud(*cloud_active, idx_local_disk, *local_disk);

        #if WHETHER_ENABLE_TIMER
        clock2_end = omp_get_wtime(); 
        clock2_sum+=clock2_end- clock2_start;
        #endif

        // #if IS_DEBUG_BOUNDARY_DETECTION
        // pcl::io::savePLYFileBinary("/media/i9/alpha/experiment_nc/1_special_cases/tmp/local_disk.ply", *local_disk);
        // #endif

        // #if IS_DEBUG_BOUNDARY_DETECTION  
        // if(current_i==29030){
        //     pcl::io::savePLYFileBinary("/media/i9/phi/experiment_nc/local_cloud.ply", *local_cloud);
        //     pcl::io::savePLYFileBinary("/media/i9/phi/experiment_nc/local_disk.ply", *local_disk);
        // }                  
        // #endif

        #if WHETHER_ENABLE_TIMER
        clock3_start = omp_get_wtime(); 
        #endif  

        if(local_disk->points.size()>3){
            // Delaunay2D dy_local_disk(local_disk);
            // dy_local_disk.Recon();
            // dy_local_disk.FilterFace(ngbr_max_dist_);
            // dy_local_disk.Upsampling();
            // pcl::PointCloud<PointType>::Ptr local_cloud_upsampling(new pcl::PointCloud<PointType>);
            // for(int i=0; i<dy_local_disk.pts_.size(); i++){
            //     local_cloud_upsampling->points.push_back(PointType((float)dy_local_disk.pts_[i][0],
            //                                                     (float)dy_local_disk.pts_[i][1],
            //                                                     (float)dy_local_disk.pts_[i][2]));
            // }             


            ClosureTesting bpg;
            // bpg.SetInputCloud(local_cloud_upsampling);
            bpg.SetInputCloud(local_disk);
            bpg.Apply(thresh_of_HeatMap);

            // if(current_i==29030){
            //     bpg.ExtractImageBK("/media/i9/phi/experiment_nc/img_bk.png");
            //     pcl::io::savePLYFileBinary("/media/i9/phi/experiment_nc/local_cloud.ply", *local_cloud);
            //     pcl::io::savePLYFileBinary("/media/i9/phi/experiment_nc/local_disk.ply", *local_disk);
            //     pcl::io::savePLYFileBinary("/media/i9/phi/experiment_nc/local_cloud_upsampling.ply", *local_cloud_upsampling);
            //     cout<<"wokaka"<<endl;
            // }

            if(bpg.IsDisc()==true)
                flag_is_edge_pts_in_active_cloud_[current_i]=1;
        }
        
        #if WHETHER_ENABLE_TIMER
        clock3_end = omp_get_wtime(); 
        clock3_sum+=clock3_end- clock3_start;
        #endif

        // if(i==100)
        //     break;
    }
    // cout<<"clock1:"<<clock1_sum<<endl;
    // cout<<"clock2:"<<clock2_sum<<endl;
    // cout<<"clock3:"<<clock3_sum<<endl;

    // cout<<"clock01:"<<clock01_sum<<endl;
    // cout<<"clock02:"<<clock02_sum<<endl;
    // cout<<"clock03:"<<clock03_sum<<endl;
    // cout<<"clock04:"<<clock04_sum<<endl;

    // cout<<"TranZ_clock01:"<<TranZ_clock01_sum<<endl;
    // cout<<"TranZ_clock02:"<<TranZ_clock02_sum<<endl;
    // cout<<"TranZ_clock03:"<<TranZ_clock03_sum<<endl;
    // cout<<"TranZ_clock04:"<<TranZ_clock04_sum<<endl;
    // cout<<"TranZ_clock05:"<<TranZ_clock05_sum<<endl;

    /* ST03: */
    for(int i=0; i < num_of_pts_in_cloud_active; i++){
        if(flag_is_edge_pts_in_active_cloud_[i]==1){            
            indices_of_edge_pts_in_raw_cloud_.push_back(i);
        }            
    }
    
    // fout.close();
}

void ClosureTesting::ExtractImageBK(string opath)
{
    hm_.ExtractImageBK(opath);
}

/**
 * @brief detect edge via closure testing (To accelerate the algorithm, we use the LPC to replace RPC.)
 * 
 * @param raw_cloud                 pointer to raw point cloud
 * @param scale_of_radius           scale_of_radius * max_distance_in_nearest_neighbour
 * @param thresh_of_HeatMap         heatmap -> binary map threshold, the larger it is , the larger the range is
 */
void EdgeDetection::ApplyClosureTesting_BestFittingPlane_Fast(float scale_of_radius, int thresh_of_HeatMap)
{   
    /* ST00: Initialization */        
    pcl::search::KdTree<PointType>::Ptr kdtree_raw_(new pcl::search::KdTree<PointType>());
    kdtree_raw_->setInputCloud(cloud_raw_);
        
    /* ST01: downsampling */
    cout<<"Info: this cloud is downsampled!"<<endl;
    cloud_dwn_=pcl::PointCloud<PointType>::Ptr(new pcl::PointCloud<PointType>);
    pcl::VoxelGrid<PointType> filter;
    filter.setInputCloud(cloud_raw_);
    float leaf_size= cp_.GetCellSize(9);
    // float leaf_size = cp_.GetMeanDistance();
    filter.setLeafSize(leaf_size, leaf_size, leaf_size);
    filter.filter(*cloud_dwn_);   

    /* ST02: Detect Edge */
    ApplyClosureTesting_BestFittingPlane(cloud_dwn_, indices_of_candidate_edge_pts_, scale_of_radius, thresh_of_HeatMap);
}

void EdgeDetection::ComputeDensity()
{
    CloudProperties cp;
    cp.SetInputCloud(cloud_raw_);

    float radius = 1.5 * cp.GetMaximumDistance();
    VectorExtend<float> density;
    density.Resize(cloud_raw_->points.size());

    #pragma omp parallel for
    for(int i=0; i<density.size(); i++){
        vector<int> idx;
        vector<float> dist;
        kdtree_raw_->radiusSearch(cloud_raw_->points[i], radius, idx, dist);
        density[i] = idx.size();
    }

    float threshold_low = density.Quantile(0.2);
    for(int i=0; i<density.size(); i++){
        if(density[i]<threshold_low){
            indices_of_candidate_edge_pts_.push_back(i);
        }
    }

    pcl::PointCloud<PointType>::Ptr ocloud(new pcl::PointCloud<PointType>);
    pcl::copyPointCloud(*cloud_raw_, indices_of_candidate_edge_pts_, *ocloud);
    // pcl::io::savePLYFileBinary("/media/i9/phi/experiment_nc/1.ply", *ocloud);
}

void EdgeDetection::ExtractEdgeCloud(string path_of_edge)
{
    if(indices_of_edge_pts_in_raw_cloud_.size()>0){
        pcl::PointCloud<PointType>::Ptr cloud_edge(new pcl::PointCloud<PointType>);
        pcl::copyPointCloud(*cloud_raw_, indices_of_edge_pts_in_raw_cloud_, *cloud_edge);
        pcl::io::savePLYFileBinary(path_of_edge,*cloud_edge);        
    }
    else 
        cout<<"Warning: no edge points found!"<<endl;
}

void EdgeDetection::ExtractDwnCloud(string path_to_dwn)
{
    if(cloud_dwn_==NULL){
        cout<<"No downsampling point cloud available!"<<endl;
        return;
    }    
    pcl::io::savePLYFileBinary(path_to_dwn, *cloud_dwn_);
}

/**
 * @brief PCL api
 * 
 * @return vector<int> return indices of the edge 
 */
vector<int> EdgeDetection::ApplyPCLAPI()
{
    pcl::PointCloud<pcl::Normal>::Ptr normals(new pcl::PointCloud<pcl::Normal>);
    pcl::PointCloud<pcl::Boundary> boundaries;
    pcl::BoundaryEstimation<PointType,pcl::Normal,pcl::Boundary> est;
    pcl::search::KdTree<PointType>::Ptr tree(new pcl::search::KdTree<PointType>());
    pcl::NormalEstimation<PointType,pcl::Normal> normEst;  //其中pcl::PointXYZ表示输入类型数据，pcl::Normal表示输出类型,且pcl::Normal前三项是法向，最后一项是曲率
    normEst.setInputCloud(cloud_raw_);
    normEst.setSearchMethod(tree);
    // normEst.setRadiusSearch(2);  //法向估计的半径
    normEst.setKSearch(50);  //法向估计的点数
    normEst.compute(*normals);    

    //normal_est.setViewPoint(0,0,0); //这个应该会使法向一致
    est.setInputCloud(cloud_raw_);
    est.setInputNormals(normals);
    est.setAngleThreshold(M_PI/4.0);
    //   est.setSearchMethod (pcl::search::KdTree<pcl::PointXYZ>::Ptr (new pcl::search::KdTree<pcl::PointXYZ>));
    est.setSearchMethod (tree);
    est.setKSearch(100);  //一般这里的数值越高，最终边界识别的精度越好
    //  est.setRadiusSearch(everagedistance);  //搜索半径
    est.compute (boundaries);

    pcl::PointCloud<PointType>::Ptr boundPoints(new pcl::PointCloud<PointType>);
    pcl::PointCloud<PointType> noBoundPoints;
    int countBoundaries = 0;
    for(int i=0; i<cloud_raw_->size(); i++){
        int x = (boundaries.points[i].boundary_point);
        int a = static_cast<int>(x); //该函数的功能是强制类型转换
        if(a == 1){            
            (*boundPoints).push_back(cloud_raw_->points[i]);
            countBoundaries++;
        }
        else
            noBoundPoints.push_back(cloud_raw_->points[i]);
    }    
    pcl::io::savePLYFileBinary(prefix_+"_edge.ply",*boundPoints);
    return {};
}

/**
 * @brief implimentation of paper "Detecting Holes in Point Set Surfaces"
 * 
 * @return vector<int> 
 */
vector<int> EdgeDetection::ApplyAngleCriterion()
{
    /* estimate normal */
    pcl::search::KdTree<PointType>::Ptr tree(new pcl::search::KdTree<PointType>());
    pcl::PointCloud<pcl::Normal>::Ptr cloud_nrm(new pcl::PointCloud<pcl::Normal>);
    pcl::NormalEstimation<PointType,pcl::Normal> normEst;  //其中pcl::PointXYZ表示输入类型数据，pcl::Normal表示输出类型,且pcl::Normal前三项是法向，最后一项是曲率
    normEst.setInputCloud(cloud_raw_);
    normEst.setSearchMethod(tree);    
    normEst.setKSearch(50);  //法向估计的点数
    normEst.compute(*cloud_nrm);    

    /*pcl计算边界*/
    pcl::PointCloud<pcl::Boundary>::Ptr boundaries(new pcl::PointCloud<pcl::Boundary>); //声明一个boundary类指针，作为返回值
    boundaries->points.resize(cloud_raw_->points.size()); //初始化大小
    pcl::BoundaryEstimation<PointType, pcl::Normal, pcl::Boundary> boundary_estimation; //声明一个BoundaryEstimation类
    boundary_estimation.setInputCloud(cloud_raw_); //设置输入点云
    boundary_estimation.setInputNormals(cloud_nrm); //设置输入法线
    pcl::search::KdTree<PointType>::Ptr kdtree_ptr(new pcl::search::KdTree<PointType>); 
    boundary_estimation.setSearchMethod(kdtree_ptr); //设置搜寻k近邻的方式
    boundary_estimation.setKSearch(40); //设置k近邻数量
    boundary_estimation.setAngleThreshold(M_PI * 0.9); //设置角度阈值，大于阈值为边界,
    boundary_estimation.compute(*boundaries); //计算点云边界，结果保存在boundaries中

    vector<int> edge_idx;
    for(int i=0; i<boundaries->points.size();i++){
        if(boundaries->points[i].boundary_point==1){
            edge_idx.push_back(i);
        }
    }

    pcl::PointCloud<PointType>::Ptr cloud_edge(new pcl::PointCloud<PointType>);
    pcl::copyPointCloud(*cloud_raw_, edge_idx, *cloud_edge);
    cout<<prefix_+"_ac_edge.ply"<<endl;
    pcl::io::savePLYFileBinary(prefix_+"_edge.ply",*cloud_edge);
    return {};
}
