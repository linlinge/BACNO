#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <StringExtend.h>
#include <opencv2/core.hpp>
#include <opencv2/opencv.hpp>
#include <VectorExtend.h>
#include <PCLExtend.h>
#include <FloodFill.h>
#include <Config.h>
using namespace std;
enum HeatMapMode{USE_BACKGROUND, USE_FRONT};
class HeatMap
{
    public:
        /* used for range test */
        void SetInputData(vector<vector<float>>& dat);
        void SetInputData(vector<float>& datA, vector<float>& datB);
        void SetInputData(pcl::PointCloud<PointType>::Ptr cloud); 
        void GenerateHeatMap(int thresh_of_heatmap=240); 
        bool IsWithin(float px, float py, string path="");      
        
        /* used for edge detection */
        bool Generate(vector<float>& datA, vector<float>& datB, int thresh, int mode=USE_BACKGROUND); 
        void ExtractImageBK(string opath);
        void ExtractImageHeatmap(string opath);
    
    private:
        vector<float> datX_, datY_;
        vector<V3> colors_;
        float xmin_, ymin_;
        float xmax_, ymax_;
        float xspan_, yspan_;
        int num_of_x_, num_of_y_;
        float gap_;
        cv::Mat img_bk_, img_heat_map_;
        pcl::PointCloud<PointType>::Ptr cloud_;
        pcl::search::KdTree<PointType>::Ptr kdtree_;
        void SetProperties(float num_of_division=30, float scale=0.3);
        tuple<int,int> GetPixelLocation(float px, float py);
};