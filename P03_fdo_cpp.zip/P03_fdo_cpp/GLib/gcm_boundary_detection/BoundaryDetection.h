#pragma once
#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/connected_components.hpp>
#include <CloudProperties.h>
#include <Clustering.h>
#include <Geometry.h>
#include <LocalMeshGenerator.h>
#include <Config.h>

// Define the graph using adjacency_list
typedef boost::adjacency_list<boost::vecS, boost::vecS, boost::undirectedS> BoostGraph;
typedef boost::graph_traits<BoostGraph>::edge_descriptor BoostEdge;


/***
 * Description: Get the indices of all connected components. Besides, make sure the first component is the query point where
 *              it located in.
 * @param cloud:    the input point cloud, we will construct a k nearest graph on this point cloud
 * @param query_pt: the query point that where the first component located in
 * @return:         the indices of alll components
*/
std::tuple<vector<vector<int>>, int>  GetConnectedComponents(pcl::PointCloud<PointType>::Ptr cloud, PointType& query_pt, int K=5);


/**  
 * Selects the data from a vector based on the given indices.  
 * @param data The vector containing the data.  
 * @param indices The vector containing the indices to select.  
 * @return A new vector containing the selected data.  
 */  
template <typename T>  
std::vector<T> selectData(const std::vector<T>& data, const std::vector<int>& indices);

class Point
{
    public:
        int id_;
        float x_,y_,z_;
        float roll_,pitch_,yaw_;

        void RollPitchYaw(int id, float x, float y, float z){
            id_=id;
            float r=sqrt(pow(x,2)+pow(y,2)+pow(z,2));
            
            // X axis
            roll_=atan2(z,y);
            if(roll_<M_PI) roll_+=M_PI;

            // Y axis
            pitch_=atan2(x,z);
            if(pitch_<M_PI)  pitch_+=M_PI;

            // Z axis
            yaw_=atan2(y,x);
            if(yaw_<M_PI) yaw_+=M_PI;
        }
};


class ClosureTesting
{
    public:        
        void SetInputCloud(pcl::PointCloud<PointType>::Ptr cloud);
        void Apply(int thresh);  
        bool IsDisc();
        void ExtractImageBK(string opath);
    
    private:
        HeatMap hm_;
        pcl::PointCloud<PointType>::Ptr cloud_;
        vector<float> x_, y_, z_;
        bool is_disc_=false;       
};

extern float clock01_start, clock01_end;
extern float clock01_sum; 
extern float clock02_start, clock02_end;
extern float clock02_sum; 
extern float clock03_start, clock03_end;
extern float clock03_sum; 
extern float clock04_start, clock04_end;
extern float clock04_sum; 

extern float TranZ_clock01_start, TranZ_clock01_end;
extern float TranZ_clock01_sum; 
extern float TranZ_clock02_start, TranZ_clock02_end;
extern float TranZ_clock02_sum; 
extern float TranZ_clock03_start, TranZ_clock03_end;
extern float TranZ_clock03_sum; 
extern float TranZ_clock04_start, TranZ_clock04_end;
extern float TranZ_clock04_sum; 
extern float TranZ_clock05_start, TranZ_clock05_end;
extern float TranZ_clock05_sum; 


class EdgeDetection{
    public:
        pcl::PointCloud<PointType>::Ptr cloud_raw_;
        pcl::PointCloud<PointType>::Ptr cloud_dwn_;
        pcl::search::KdTree<PointType>::Ptr kdtree_raw_;
        CloudProperties cp_;
        float ngbr_min_dist_, ngbr_max_dist_, ngbr_mean_dist_;
        int numOfPts_;
        int is_pre_screening=0;
        int flag_of_pre_sceening_=0;
        vector<int> indices_of_competitor_;
        vector<int> indices_of_edge_pts_in_raw_cloud_;
     
        void SetCloudProperties(string ipath_of_raw);        
        void SetPrefix(string prefix);
        void ExtractDwnCloud(string path_of_dwn);     
        void ExtractEdgeCloud(string path_of_edge);
        void PreScreening();
        void Apply(float scale_of_radius=2.5, int thresh_of_HeatMap=250);
        
        /* Compute */
        void ComputeDensity();
       

        vector<int> ApplyPCLAPI();       
        vector<int> ApplyAngleCriterion();
    private:
        string prefix_;
        vector<int> flag_is_edge_pts_in_active_cloud_;      
        vector<int> indices_of_candidate_edge_pts_;  
                
        void ApplyClosureTesting_BestFittingPlane_Fast(float scale_of_radius=2.5, int thresh_of_HeatMap=250);        
        void ApplyClosureTesting_BestFittingPlane(pcl::PointCloud<PointType>::Ptr cloud_active, vector<int>& indices_of_candidate, float scale_of_radius=2.5, int thresh_of_HeatMap=250);
};

// // Method 01: |Ni-Nj| > delta
// void DetectHoleEdge01(pcl::PointCloud<PointType>::Ptr cloud);

// // Method 02: Centroid != Sphere Centre
// void DetectHoleEdge02_kNN(pcl::PointCloud<PointType>::Ptr cloud);  // work: sensity to point density
// void DetectHoleEdge02_r(pcl::PointCloud<PointType>::Ptr cloud);    // work

// // Method 03: Direction Distribution
// void DetectHoleEdge03_kNN(pcl::PointCloud<PointType>::Ptr cloud);   // work
// void DetectHoleEdge03_Radius(pcl::PointCloud<PointType>::Ptr cloud);

// // 
// void EdgeDetection(pcl::PointCloud<PointType>::Ptr cloud);