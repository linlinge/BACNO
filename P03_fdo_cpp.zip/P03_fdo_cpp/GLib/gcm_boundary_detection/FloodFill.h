#pragma once
#include <vector>
#include <opencv2/opencv.hpp>
#include <stdio.h>
#include <omp.h>
using namespace std;



class Vertex
{
	public:
		int i_,j_;
		Vertex* next;
};

class Vertices
{
	public:
		Vertex* head_;
		int number_;
		
		Vertices(){
			Vertex* p=new Vertex;
			p->i_=INT_MAX;
			p->j_=INT_MAX;
			head_=p;
			head_->next=NULL;
			number_=0;
		}
		void Insert(int i,int j){
			Vertex* p=new Vertex;
			p->i_=i;
			p->j_=j;
			p->next=head_->next;
			head_->next=p;
			number_++;
		}
		void Insert(Vertex* p){
			p->next=head_->next;
			head_->next=p;
			number_++;
		}
		int Delete(int i,int j){
			Vertex* p=head_;
			Vertex* q=NULL;
			
			while(p->next!=NULL){
				if(p->next->i_==i && p->next->j_==j)
					break;
				p=p->next;					
			}
			if(p->next==NULL)
				return -1;
			else{
				q=p->next;
				p->next=q->next;
				delete q;
				number_--;
				return 1;
			}
		}
		Vertex* Remove(int i,int j){
			Vertex* p=head_;
			Vertex* q=NULL;
			while(p->next!=NULL){
				if(p->next->i_==i && p->next->j_==j)
					break;
				p=p->next;					
			}
			if(p->next==NULL)
				return NULL;
			else{
				q=p->next;
				p->next=q->next;
				number_--;
				return q;
			}
		}
};



class FloodFill
{
	public:		
		Vertices ant_;
		cv::Mat img_;
		int background_r_, background_g_, background_b_;
		int seed_r_, seed_g_, seed_b_;
		int replace_r_, replace_g_, replace_b_;

		FloodFill(cv::Mat& img);
		void SetBackgroundColor(int r=255, int g=255, int b=255);
		void SetReplaceColor(int r=100, int g=100, int b=100);
		bool Apply(int x, int y);

	private:
		Vertices active_vertices_;	// mark the vertices which are not be used
		// Internal Function
		void floodFillUtil(int x, int y, Vertices& ant);
};