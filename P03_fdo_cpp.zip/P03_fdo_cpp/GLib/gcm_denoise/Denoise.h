#pragma once 
#include <CloudProperties.h>
#include <pcl/surface/mls.h>
#include <string>
using namespace std;
class Denoise
{
    public:
        pcl::PointCloud<PointType>::Ptr cloud_, cloud_filtered_;
        CloudProperties* cp_;
        Denoise(CloudProperties& cp){
            cp_=&cp;
            cloud_=cp.cloud_;
            cloud_filtered_=pcl::PointCloud<PointType>::Ptr(new pcl::PointCloud<PointType>);
        }
        Denoise(pcl::PointCloud<PointType>::Ptr cloud){
            cp_=new CloudProperties(cloud);
            cloud_=cloud;
            cloud_filtered_=pcl::PointCloud<PointType>::Ptr(new pcl::PointCloud<PointType>);
        }
        void ApplyMLS();
        void ApplyGassainFilter();
        void ExtractResult(string path);
};