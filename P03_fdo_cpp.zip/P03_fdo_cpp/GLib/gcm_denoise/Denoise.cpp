#include <Denoise.h>
void Denoise::ApplyMLS()
{
    // Create a KD-Tree
    pcl::search::KdTree<PointType>::Ptr tree (new pcl::search::KdTree<PointType>);

    // Init object (second point type is for the normals, even if unused)
    pcl::MovingLeastSquares<PointType, PointType> mls;

    mls.setComputeNormals (false);

    double rd=cp_->GetMaximumDistance();
    // Set parameters
    mls.setInputCloud (cloud_);
    mls.setPolynomialOrder (2);
    mls.setSearchMethod (tree);
    mls.setSearchRadius (1.5*rd);

    // Reconstruct
    mls.process(*cloud_filtered_);
}
void Denoise::ApplyGassainFilter()
{
    pcl::PointCloud<PointType>::Ptr cloud_filtered_(new pcl::PointCloud<PointType>);

	//-----------基于高斯核函数的卷积滤波实现------------------------
	pcl::filters::GaussianKernel<PointType, PointType> kernel;
	kernel.setSigma(4);									//高斯函数的标准方差，决定函数的宽度
	kernel.setThresholdRelativeToSigma(4);				//设置相对Sigma参数的距离阈值
	kernel.setThreshold(0.05);							//设置距离阈值，若点间距离大于阈值则不予考虑
	pcl::search::KdTree<PointType>::Ptr tree(new pcl::search::KdTree<PointType>);
	tree->setInputCloud(cloud_);

	//---------设置Convolution 相关参数---------------------------
	pcl::filters::Convolution3D<PointType, PointType, pcl::filters::GaussianKernel<PointType, PointType>> convolution;
	convolution.setKernel(kernel);//设置卷积核
	convolution.setInputCloud(cloud_);
	convolution.setNumberOfThreads(8);
	convolution.setSearchMethod(tree);
	convolution.setRadiusSearch(2);    
	convolution.convolve(*cloud_filtered_);

    for(int i=0; i<cloud_->points.size(); i++){
        cloud_filtered_->points[i].r=cloud_->points[i].r;
        cloud_filtered_->points[i].g=cloud_->points[i].g;
        cloud_filtered_->points[i].b=cloud_->points[i].b;
    }
}
void Denoise::ExtractResult(string path)
{
    pcl::io::savePLYFileBinary(path, *cloud_filtered_);
}