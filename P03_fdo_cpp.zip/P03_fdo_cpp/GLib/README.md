# <p align="center"> Geometry of Cloud & Mesh (gcm) </p>
![Static Badge](https://img.shields.io/badge/Version-0.1-blue)
![Static Badge](https://img.shields.io/badge/Basic_Type-float-blue)

## Containing Modules 
* gcm_core
* gcm_denoise
* gcm_boundary_detection
* gcm_outlier_removal
* gcm_resampling

## Dependencies
* PCL 1.11.0
* CGAL 5.5.1
* Eigen3
* OpenCV

