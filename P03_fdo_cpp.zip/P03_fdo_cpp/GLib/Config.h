#pragma once 

// typedef double bsc_;

/* is debug */
#define IS_DEBUG_BOUNDARY_DETECTION 0
#define IS_DEBUG_CLOSURE_TESINT 0
#define IS_DEBUG_NARROW_BAND_CreateNarrowBandGrid 1
#define IS_DEBUG_NARROW_BAND_CreateNarrowBandGridParallel 1
#define IS_DEBUG_NARROW_BAND_CreateConnectedGraph 0
#define IS_DEBUG_NARROW_BAND_QueryIntersectVoxelWithRay_Fast 0
#define IS_DEBUG_NARROW_BAND_QueryIntersectVoxelWithLineSegment_Fast 0
#define IS_DEBUG_NARROW_BAND_LabelCellsByGTNormal 0
#define IS_DEBUG_NARROW_BAND_CreateCloudOnAndOff 0

/* is print info */
#define IS_PRINT_INFO_NARROW_BAND_CreateNarrowBandGrid 0
#define IS_PRINT_INFO_NARROW_BAND_CreateConnectedGraph 0

/* timer */
#define WHETHER_ENABLE_TIMER 0

// extern double clock01_start, clock01_end, clock01_sum; 
// extern double clock02_start, clock02_end, clock02_sum; 
// extern double clock03_start, clock03_end, clock03_sum; 