#pragma once 
#include <pcl/surface/mls.h>
#include "PCLExtend.h"
#include "CloudProperties.h"

class Resampling{
    public:
        CloudProperties cp_;
        pcl::PointCloud<PointType>::Ptr ocloud_;

        /* Init */
        Resampling(){
            ocloud_= pcl::PointCloud<PointType>::Ptr(new pcl::PointCloud<PointType>);
        }

        /* Set */
        void SetInputCloud(string ipath);

        /* Apply */
        void ApplyMLS();

        /* save */
        void ExtractCloud(string path);
};