#include "Resampling.h"

void Resampling::SetInputCloud(string ipath)
{
    cp_.SetInputCloud(ipath);
}

void Resampling::ApplyMLS()
{
    // Create a KD-Tree
    pcl::search::KdTree<PointType>::Ptr tree(new pcl::search::KdTree<PointType>);

    // Init object (second point type is for the normals, even if unused)
    pcl::MovingLeastSquares<PointType, PointType> mls;
    mls.setComputeNormals (true);

    // Set parameters
    mls.setInputCloud(cp_.cloud_);
    mls.setPolynomialOrder (3);
    mls.setSearchMethod (tree);
    mls.setSearchRadius (0.01);

    // Reconstruct
    mls.process(*ocloud_);
    
}

void Resampling::ExtractCloud(string path)
{
    pcl::io::savePLYFileBinary(path, *ocloud_);
}