#include "Upsampling.h"

void Upsampling::SetInputCloud(string ipath)
{
    cp_.SetInputCloud(ipath);
}

void Upsampling::ApplyMLS()
{
    // Create a KD-Tree
    pcl::search::KdTree<PointType>::Ptr tree(new pcl::search::KdTree<PointType>);

    // Init object (second point type is for the normals, even if unused)
    pcl::MovingLeastSquares<PointType, PointType> mls;
    mls.setComputeNormals(true);

    // Set parameters
    mls.setInputCloud(cp_.cloud_);
    mls.setPolynomialOrder(3);
    mls.setSearchMethod(tree);

    float radius = cp_.GetMaximumDistance();
    mls.setSearchRadius(2.0*radius);

    //Upsampling 采样的方法还有 DISTINCT_CLOUD, RANDOM_UNIFORM_DENSITY
    mls.setUpsamplingMethod(pcl::MovingLeastSquares<PointType, PointType>::SAMPLE_LOCAL_PLANE);     //对点云进行上采样
    mls.setUpsamplingRadius(0.4*radius);    // the larger it is, the more range it will expand
    mls.setUpsamplingStepSize(0.08*radius);  // the small it is, the span will be smaller
    mls.process(*ocloud_);      //执行采样操作
}

// 最近邻插值函数实现
void Upsampling::ApplyNearestNeighborInterpolation()
{
    // 创建KdTree对象进行最近邻搜索
    pcl::search::KdTree<PointType>::Ptr kdtree(new pcl::search::KdTree<PointType>);    
    kdtree->setInputCloud(cp_.cloud_);


    pcl::copyPointCloud(*cp_.cloud_, *ocloud_);
    // 对每个点进行最近邻搜索并插值
    for (size_t i = 0; i < cp_.cloud_->points.size(); ++i) {
        std::vector<int> pointIdxNKNSearch(1);
        std::vector<float> pointNKNSquaredDistance(1);

        // 寻找最近邻点
        if (kdtree->nearestKSearch(cp_.cloud_->points[i], 2, pointIdxNKNSearch, pointNKNSquaredDistance) > 0) {
            // 在原始点和其最近邻点之间插入一个点
            PointType newPoint;
            newPoint.x = (cp_.cloud_->points[i].x + cp_.cloud_->points[pointIdxNKNSearch[1]].x) / 2.0;
            newPoint.y = (cp_.cloud_->points[i].y + cp_.cloud_->points[pointIdxNKNSearch[1]].y) / 2.0;
            newPoint.z = (cp_.cloud_->points[i].z + cp_.cloud_->points[pointIdxNKNSearch[1]].z) / 2.0;
            ocloud_->push_back(newPoint);
        }
    }
}

void Upsampling::ExtractCloud(string path)
{
    pcl::io::savePLYFileBinary(path, *ocloud_);
}