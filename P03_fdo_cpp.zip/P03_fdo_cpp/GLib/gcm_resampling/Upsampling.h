#pragma once
#include <string>
#include <pcl/surface/mls.h>
#include "PCLExtend.h"
#include "CloudProperties.h"
using namespace std;

class Upsampling
{
    public:
        CloudProperties cp_;
        pcl::PointCloud<PointType>::Ptr ocloud_;

        /* Init */
        Upsampling(){
            ocloud_= pcl::PointCloud<PointType>::Ptr(new pcl::PointCloud<PointType>);
        }

        /* Set */
        void SetInputCloud(string ipath);

        /* Apply */
        void ApplyMLS();
        void ApplyNearestNeighborInterpolation();

        /* save */
        void ExtractCloud(string path);
};
