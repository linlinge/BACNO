#pragma once
#include <vector>
#include <string>
#include <fstream>
#include <StringExtend.h>
#include <MeshManagement.h>
#include <Geometry.h>
using namespace std;

class OBJManagement
{
    public:
        vector<vector<float>> vtx_;
        vector<vector<int>> faces_;
        vector<vector<int>> lines_;
        vector<vector<int>> adj_list_;

        OBJManagement(){};
        // void ReadMesh(string path);
        void AddMesh(vector<vector<float>> v, vector<vector<int>> f);
        void AddMesh(vector<vector<float>> v, vector<vector<int>> f, vector<vector<int>> lines);
        void AddRay(vector<vector<int>> lines);  
        void AddPoints(vector<vector<float>> pts);      
        void AddPoints(vector<vector<float>> pts, vector<vector<float>> colors);
        void AddLine(vector<float> pt_start, vector<float> pt_end);
        void AddLine(LineSegment line);
        void AddLines(vector<vector<float>> pts, vector<vector<int>> fid);
        void AddLines(vector<vector<int>> fid);
        void SaveOBJ(string save_path);    
        MeshManagement<PositionNormalColor> ReadOBJ(string read_path);   
        void EstablishAdjacentList();
};

class OBJManagerGeometricEx: public OBJManagement{
	public:		
		OBJManagerGeometricEx(){};	        
		OBJManagerGeometricEx(Triangle tri);
        OBJManagerGeometricEx(Ray ry);
        OBJManagerGeometricEx(LineSegment ry);
		void AddMesh(Triangle& tri);
		void AddMesh(vector<vector<float>> pts, vector<vector<int>> faces);		
		void AddBox(AABB* bb);
		void AddLineSegment(LineSegment lg);
		void AddPlane(Plane pl, AABB* bb);
		void AddRay(Ray ry);
		void AddTriangle(Triangle tri);
};