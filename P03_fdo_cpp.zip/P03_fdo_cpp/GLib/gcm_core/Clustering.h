#pragma once
#include <vector>
#include <iostream>
#include <math.h>
#include <Geometry.h>
#include <algorithm>
#include <CloudProperties.h>
#include <VectorExtend.h>
#include <random>
using namespace std;

/*
*   @样本点类型
*-- DB_CORE:   邻域半径R内样本点的数量大于等于minpoints的点叫做核心点。
*-- DB_BORDER: 不属于核心点但在某个核心点的邻域内的点叫做边界点。
*-- DB_NOISE:  既不是核心点也不是边界点的是噪声点。
*/
enum DBSCAN_POINT_Type{DB_CORE, DB_BORDER, DB_NOISE};

class DBPointN: public PointN
{
    public:
        int cluster=0;               // 所属类（一个标识代号，属于同一类的样本具有相同的cluster）
        int pointType = DB_NOISE;	 // 1:noise 	2:border 	3:core  （初始默认为噪声点）
        int num_of_ngbrs_ = 0;		 // points in MinPts （指定领域内样本点的个数）
        vector<int> neighborCoreIdx; // 对所有的corepoint，记录其eps范围内的core point下标
        int visited = 0;			 // 是否被遍历访问过
        
        DBPointN(float idata): PointN(idata){
            key_++;
            dat_.push_back(idata);
        }

        DBPointN(vector<float> idata): PointN(idata){
            key_++;
            dat_=idata;
        }

        float DistTo(DBPointN& b){
            float r=0;
            for(int i=0; i<dat_.size(); i++){
                r+=pow(dat_[i]-b.dat_[i],2);
            }
            return sqrt(r);
        }
};

class DBSCAN
{
    public:
        vector<int> p2c_;
        vector<vector<int>> c2p_;
        int num_of_clusters_;

        DBSCAN(vector<float> pts, float eps, int minPts=1);
        DBSCAN(vector<vector<float>> pts, float eps, int minPts=1);

    private:
        tuple<vector<vector<int>>, vector<int>> Apply(vector<DBPointN*> pts, float eps, int minPts);
};

/********************************************** KMeans *********************************************/

class KMPoint
{
public:
    static int key_counter_;
    int key_;
    int clusterId;
    int dimensions_;
    vector<float> values;

    KMPoint(vector<float>& idata);
    KMPoint(float& idata);
    int getDimensions() { return dimensions_; }
    int getCluster() { return clusterId; }
    int getID() { return key_; }
    void setCluster(int val) { clusterId = val; }
    float getVal(int pos) { return values[pos]; }
};

class KMCluster
{
public:
    int clusterId;
    vector<float> centroid;
    vector<KMPoint> points;


    KMCluster(int clusterId, KMPoint centroid);
    void addPoint(KMPoint p);
    bool removePoint(int pointId);
    void removeAllPoints() { points.clear(); }
    int getId() { return clusterId; }
    KMPoint getPoint(int pos) { return points[pos]; }
    int getSize() { return points.size(); }
    float getCentroidByPos(int pos) { return centroid[pos]; }
    void setCentroidByPos(int pos, float val) { this->centroid[pos] = val; }
};

class KMeans
{
    public:      
      int K_, iters_, dimensions_, num_of_pts_;
      int debug_;
      vector<KMCluster> clusters;
      vector<KMPoint> all_points;
      vector<vector<int>> c2i_;

      void clearClusters();
      int getNearestClusterId(KMPoint point);


      KMeans(int K, int iterations=100);
      void EnableDebug();
      void DisableDebug();
      void SetInputData(vector<float>& idata);
      void SetInputData(vector<vector<float>>& idata);
      void Run();
};



class STING
{
    public:      
        /* Set */        
        void SetInputCloud(pcl::PointCloud<PointType>::Ptr cloud);
        void SetInputCloud(string path);
        void SetResolution(float resolution);
        void SetAutoResolution(bool yes_or_no = true, int level=8);
     
        // void RegionGrowth_kIQR(float level=8, float thresh_kIQR=3.0);
        // void RegionGrowth_Max(float level=8);

        /* Get */
        vector<vector<int>> GetIndicesOfClouds();

        /* Result */
        void ExtractResult(string save_path);
    
    private:
        float resolution_;
        void Apply();
        pcl::PointCloud<PointType>::Ptr cloud_raw_,cloud_out_;
		vector<vector<int>> clusters_;
        pcl::search::KdTree<PointType>::Ptr kdtree_;
};