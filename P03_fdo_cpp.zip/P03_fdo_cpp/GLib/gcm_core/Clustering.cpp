#include <Clustering.h>
DBSCAN::DBSCAN(vector<float> idata, float eps, int minPts)
{
    vector<DBPointN*> pts;
    for(int i=0; i<idata.size(); i++){
        pts.push_back(new DBPointN(idata[i]));
    }
    Apply(pts, eps, minPts);
    num_of_clusters_=c2p_.size();
}

DBSCAN::DBSCAN(vector<vector<float>> idata, float eps, int minPts)
{
    vector<DBPointN*> pts;
    for(int i=0; i<idata.size(); i++){
        pts.push_back(new DBPointN(idata[i]));
    }
    Apply(pts, eps, minPts);
    num_of_clusters_=c2p_.size();
}

tuple<vector<vector<int>>, vector<int>>  DBSCAN::Apply(vector<DBPointN*> pts, float eps, int minPts)
{
    int count=0;
    int len=pts.size();

    /* calculate number of neghbours of each point */
    for(int i=0; i < pts.size(); i++){
        for(int j=i; j<pts.size(); j++){
            if(pts[i]->DistTo(*pts[j])<eps){
                pts[i]->num_of_ngbrs_++;
                pts[j]->num_of_ngbrs_++;
            }
        }
    }

    // core point ，若某个点在其领域Eps范围内的点个数>=MinPts，称该点为core point核心点	
	// 核心点集合索引（索引为样本点原本的索引，从0开始）
    vector<int> corePtInxVec;
    for(int i=0; i<pts.size(); i++){
        if(pts[i]->num_of_ngbrs_>=minPts){
            pts[i]->pointType=DB_CORE;
            pts[i]->cluster=(count++);
            corePtInxVec.push_back(i);
        }
    }

    //合并core point
    for (int i = 0; i < corePtInxVec.size(); i++){
		for (int j = i + 1; j < corePtInxVec.size(); j++){
            //对所有的corepoint，将其eps范围内的core point下标添加到vector<int> corepts中
			if (pts[corePtInxVec[i]]->DistTo(*pts[corePtInxVec[j]]) < eps){
				pts[corePtInxVec[i]]->neighborCoreIdx.push_back(corePtInxVec[j]);
				pts[corePtInxVec[j]]->neighborCoreIdx.push_back(corePtInxVec[i]);
			}
        }
    }

    //对于所有的corepoint，采用深度优先的方式遍历每个core point的所有corepts，使得相互连接的core point具有相同的cluster编号
	for (int i = 0; i < corePtInxVec.size(); i++){
		for (int j = 0; j < pts[corePtInxVec[i]]->neighborCoreIdx.size(); j++){
			int idx = pts[corePtInxVec[i]]->neighborCoreIdx[j];
			pts[idx]->cluster = pts[corePtInxVec[i]]->cluster;
		}
	}

    //不属于核心点但在某个核心点的邻域内的点叫做边界点
	//border point, joint border point to core point
	for (int i = 0; i < len; i++){
		if(pts[i]->pointType == DB_CORE) //忽略核心点
			continue;

		for (int j = 0; j < corePtInxVec.size(); j++){
			int idx = corePtInxVec[j]; //核心点索引
			if(pts[i]->DistTo(*pts[idx]) < eps){
				pts[i]->pointType = DB_BORDER;
				pts[i]->cluster = pts[idx]->cluster;				
				break;
			}
		}
	}

    // 
    int max_cid=-INT16_MAX;
    for(int i=0; i<pts.size(); i++)
        max_cid= max_cid > pts[i]->cluster ? max_cid: pts[i]->cluster;

    vector<vector<int>> redundancy_cluster_info(max_cid+1);
    for(int i=0; i<pts.size(); i++){
        redundancy_cluster_info[pts[i]->cluster].push_back(i);
    }
    
    for(int i=0; i<redundancy_cluster_info.size(); i++){
        if(redundancy_cluster_info[i].size()>0){
            c2p_.push_back(redundancy_cluster_info[i]);
        }
    }

    for(int i=0; i<c2p_.size(); i++){
        for(int j=0; j<c2p_[i].size(); j++){
            pts[c2p_[i][j]]->cluster=i;
        }
    }

    // 
    p2c_.resize(pts.size());
    for(int i=0; i<c2p_.size(); i++){
        for(int j=0; j< c2p_[i].size(); j++){
            p2c_[c2p_[i][j]]=i;
        }
    }
    return make_tuple(c2p_, p2c_);
}



/********************************************** KMeans *********************************************/

int KMPoint::key_counter_=0;

KMPoint::KMPoint(vector<float>& idata)
{
    key_ = key_counter_++;
    values = idata;
    dimensions_ = values.size();
    clusterId = -1; // Initially not assigned to any cluster
}

KMPoint::KMPoint(float& idata)
{
    key_ = key_counter_++;
    values.push_back(idata);
    dimensions_ = values.size();
    clusterId = -1; // Initially not assigned to any cluster
}


/************************************** KMCluster *******************************/
KMCluster::KMCluster(int clusterId, KMPoint centroid)
{
    this->clusterId = clusterId;
    for (int i = 0; i < centroid.getDimensions(); i++)
    {
        this->centroid.push_back(centroid.getVal(i));
    }
    this->addPoint(centroid);
}

void KMCluster::addPoint(KMPoint p)
{
    p.setCluster(this->clusterId);
    points.push_back(p);
}

bool KMCluster::removePoint(int key_)
{
    int size = points.size();

    for (int i = 0; i < size; i++)
    {
        if (points[i].getID() == key_)
        {
            points.erase(points.begin() + i);
            return true;
        }
    }
    return false;
}

/************************************** KMeans *******************************/
void KMeans::clearClusters()
{
    for (int i = 0; i < K_; i++)
    {
        clusters[i].removeAllPoints();
    }
}

int KMeans::getNearestClusterId(KMPoint point)
{
    float sum = 0.0, min_dist;
    int NearestClusterId;
    if(dimensions_==1) {
        min_dist = abs(clusters[0].getCentroidByPos(0) - point.getVal(0));
    }	
    else 
    {
        for (int i = 0; i < dimensions_; i++)
        {
            sum += pow(clusters[0].getCentroidByPos(i) - point.getVal(i), 2.0);
            // sum += abs(clusters[0].getCentroidByPos(i) - point.getVal(i));
        }
        min_dist = sqrt(sum);
    }
    NearestClusterId = clusters[0].getId();

    for (int i = 1; i < K_; i++)
    {
        float dist;
        sum = 0.0;
        
        if(dimensions_==1) {
                dist = abs(clusters[i].getCentroidByPos(0) - point.getVal(0));
        } 
        else {
            for (int j = 0; j < dimensions_; j++)
            {
                sum += pow(clusters[i].getCentroidByPos(j) - point.getVal(j), 2.0);
                // sum += abs(clusters[i].getCentroidByPos(j) - point.getVal(j));
            }

            dist = sqrt(sum);
            // dist = sum;
        }
        if (dist < min_dist)
        {
            min_dist = dist;
            NearestClusterId = clusters[i].getId();
        }
    }

    return NearestClusterId;
}

KMeans::KMeans(int K, int iterations)
{
    K_ = K;
    iters_ = iterations;    
    debug_=0;
}   

void KMeans::EnableDebug()
{
    debug_=1;
}

void KMeans::DisableDebug()
{
    debug_=-1;
}

void KMeans::SetInputData(vector<float>& idata)
{
    num_of_pts_ = idata.size();
    dimensions_ = 1;
    for(int i=0; i<num_of_pts_; i++){
        all_points.push_back( KMPoint(idata[i]));
    }
}

void KMeans::SetInputData(vector<vector<float>>& idata)
{
    num_of_pts_ = idata.size();
    dimensions_ = idata[0].size();
    for(int i=0; i<num_of_pts_; i++){
        all_points.push_back(KMPoint(idata[i]));
    }
}

void KMeans::Run()
{
    // Initializing Clusters
    vector<int> used_key_s;

    for (int i = 0; i < K_; i++)
    {
        while (true)
        {
            int index = rand() % num_of_pts_;

            if (find(used_key_s.begin(), used_key_s.end(), index) ==
                used_key_s.end())
            {
                used_key_s.push_back(index);
                all_points[index].setCluster(i);
                KMCluster cluster(i, all_points[index]);
                clusters.push_back(cluster);
                break;
            }
        }
    }
    if(debug_==1){
        cout << "Clusters initialized = " << clusters.size() << endl << endl;
        cout << "Running K-Means Clustering.." << endl;
    }
    

    int iter = 1;
    while (true)
    {
        if(debug_==1)
            cout << "Iter - " << iter << "/" << iters_ << endl;

        bool done = true;

        // Add all points to their nearest cluster
        #pragma omp parallel for reduction(&&: done) num_threads(16)
        for (int i = 0; i < num_of_pts_; i++)
        {
            int currentClusterId = all_points[i].clusterId;
            int nearestClusterId = getNearestClusterId(all_points[i]);

            if (currentClusterId != nearestClusterId)
            {
                all_points[i].setCluster(nearestClusterId);
                done = false;
            }
        }

        // clear all existing clusters
        clearClusters();

        // reassign points to their new clusters
        for (int i = 0; i < num_of_pts_; i++)
        {
            // cluster index is ID-1
            clusters[all_points[i].clusterId].addPoint(all_points[i]);
        }

        // Recalculating the center of each cluster
        for (int i = 0; i < K_; i++)
        {
            int ClusterSize = clusters[i].getSize();

            for (int j = 0; j < dimensions_; j++)
            {
                float sum = 0.0;
                if (ClusterSize > 0)
                {
                    // #pragma omp parallel for reduction(+: sum) num_threads(16)
                    for (int p = 0; p < ClusterSize; p++)
                    {
                        sum += clusters[i].getPoint(p).getVal(j);
                    }
                    clusters[i].setCentroidByPos(j, sum / ClusterSize);
                }
            }
        }

        if (done || iter >= iters_)
        {
            if(debug_==1)
                cout << "Clustering completed in iteration : " << iter << endl << endl;
            break;
        }
        iter++;
    }

    
    // obtain the cluster -> point id
    c2i_.resize(K_);
    for(int i=0; i<num_of_pts_; i++){        
        c2i_[all_points[i].clusterId].push_back(i);
    }
}


/************************************************************************************************************************/
bool customEuclidean(const PointType& point_a, const PointType& point_b, float squared_distance)
{
    return true;
}

void STING::SetResolution(float resolution)
{
    resolution_=resolution;
}

void STING::SetAutoResolution(bool yes_or_no, int level)
{
    if(yes_or_no==true)
    {
        CloudProperties cp;
        cp.SetInputCloud(cloud_raw_);
        resolution_= 2*cp.GetMaximumDistance();
    }
    else
    {
        PointType vmin,vmax;
        pcl::getMinMax3D(*cloud_raw_, vmin, vmax);
        float box_diagonal=sqrt(pow(vmax.x-vmin.x,2) + pow(vmax.y-vmin.y,2) + pow(vmax.z-vmin.z, 2));
        resolution_=box_diagonal/pow(2,level);
    }
}

void STING::SetInputCloud(pcl::PointCloud<PointType>::Ptr cloud)
{
    cloud_raw_=cloud;
}

void STING::SetInputCloud(string path)
{
    cloud_raw_=pcl::PointCloud<PointType>::Ptr(new pcl::PointCloud<PointType>());
    pcl::io::loadPLYFile(path, *cloud_raw_);
}

vector<vector<int>> STING::GetIndicesOfClouds()
{
   Apply();
   return clusters_;
}

void STING::Apply()
{
	pcl::IndicesClustersPtr clusters(new pcl::IndicesClusters);    

    /* components */
    pcl::ConditionalEuclideanClustering<PointType> cec(true);
    cec.setInputCloud(cloud_raw_);
    cec.setConditionFunction(&customEuclidean);
    cec.setClusterTolerance(resolution_);
    cec.segment(*clusters);

    /* obtain clusters */ 
    clusters_.resize(clusters->size());
    for(int i=0;i<clusters->size();i++){   
        for(int j=0; j<(*clusters)[i].indices.size(); j++){
            clusters_[i].push_back((*clusters)[i].indices[j]);
        }            
    }
    sort(clusters_.begin(), clusters_.end(), [](vector<int>& e1, vector<int>& e2){ return e1.size()>e2.size();});
}

void STING::ExtractResult(string save_path)
{
    pcl::io::savePLYFileBinary(save_path,*cloud_out_);
}