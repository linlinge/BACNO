#pragma once 
#include <V3.hpp>
#include <PCLExtend.h>

class CloudProperties
{
    public:
        pcl::PointCloud<PointType>::Ptr cloud_;
        pcl::search::KdTree<PointType>::Ptr kdtree_;
        vector<vector<float>> cloud_xyz_, cloud_nrm_;        

        CloudProperties(){}
        CloudProperties(string path_to_raw_cloud);
        CloudProperties(pcl::PointCloud<PointType>::Ptr cloud);

        /* Set */
        void SetInputCloud(pcl::PointCloud<PointType>::Ptr cloud);        
        void SetInputCloud(string path_to_raw_cloud);

        /* Get */
        float GetMinimumDistance();
        float GetMeanDistance();
        float GetMaximumDistance();        
        vector<vector<float>> GetCloudXYZ();
        vector<vector<float>> GetCloudNrm();
        vector<float> GetDensityViaK(int k);
        vector<float> GetDensityViaRadius(float r);
        float GetMinorEigenvalue();
        float GetMinMaxRatio();
        vector<float> GetMinorEigenvector();
        PointType GetCentroid();
        float GetCellSize(int level);
        int GetNumberOfPts();
    
    private:
        float min_dist_, mean_dist_, max_dist_;
        vector<float> eval_;
        vector<vector<float>> evec_;
        int flag_is_mmm_computed_=0;
        int flag_is_eval_evec_computed_=0;
        void ComputeMMMDistance();
        void ExtractXYZNrm();
        void GetEvalAndEvec();
};