#include <CloudProperties.h>
/************************************************ CloudProperties *******************************************************/
CloudProperties::CloudProperties(string path_to_raw_cloud){
	SetInputCloud(path_to_raw_cloud);
}

CloudProperties::CloudProperties(pcl::PointCloud<PointType>::Ptr cloud){
	SetInputCloud(cloud);
}

void CloudProperties::SetInputCloud(string path_to_raw_cloud)
{
	cloud_=pcl::PointCloud<PointType>::Ptr(new pcl::PointCloud<PointType>);
	pcl::io::loadPLYFile(path_to_raw_cloud,*cloud_);
	kdtree_=pcl::search::KdTree<PointType>::Ptr(new pcl::search::KdTree<PointType>);
	kdtree_->setInputCloud(cloud_);
}

void CloudProperties::SetInputCloud(pcl::PointCloud<PointType>::Ptr cloud)
{
	cloud_=cloud;    
	kdtree_=pcl::search::KdTree<PointType>::Ptr(new pcl::search::KdTree<PointType>);
	kdtree_->setInputCloud(cloud_);
}

float CloudProperties::GetMinimumDistance()
{
	ComputeMMMDistance();
	return min_dist_;
}

float CloudProperties::GetMeanDistance()
{
	ComputeMMMDistance();
	return mean_dist_;
}

float CloudProperties::GetMaximumDistance()
{
	ComputeMMMDistance();
	return max_dist_;
}

vector<vector<float>> CloudProperties::GetCloudXYZ()
{
	ExtractXYZNrm();
	return cloud_xyz_;
}

vector<vector<float>> CloudProperties::GetCloudNrm()
{
	ExtractXYZNrm();
	return cloud_nrm_;
}

vector<float> CloudProperties::GetDensityViaK(int k)
{
	vector<float> dsty(cloud_->points.size());
	for(int i=0; i<cloud_->points.size(); i++){
		vector<int> idx;
		vector<float> dist;
		kdtree_->nearestKSearch(cloud_->points[i], k, idx, dist);
		dsty[i]=1.0/sqrt(dist[k-1]);
	}
	return dsty;
}

vector<float> CloudProperties::GetDensityViaRadius(float r)
{
	vector<float> dsty(cloud_->points.size());
	for(int i=0; i<cloud_->points.size(); i++){
		vector<int> idx;
		vector<float> dist;
		kdtree_->radiusSearch(cloud_->points[i], r, idx, dist);
		dsty[i]=idx.size();
	}
	return dsty;
}

void CloudProperties::ComputeMMMDistance()
{
	if(flag_is_mmm_computed_==0){
		float sum = 0.0;
		min_dist_=INT_MAX;
		max_dist_=-INT_MAX;        
        
		for(int i = 0; i < cloud_->points.size(); i++){
			vector<int> idx;
			vector<float> dist;
			kdtree_->nearestKSearch(i, 2, idx, dist);			
			float dtmp= sqrt(dist[1]);
			sum += dtmp;
			min_dist_=MIN2(min_dist_, dtmp);
			max_dist_=MAX2(max_dist_, dtmp);
		}
		
		mean_dist_ = sum/cloud_->points.size();
	}	
}

void CloudProperties::ExtractXYZNrm()
{
	if(cloud_xyz_.size()==0){
		cloud_xyz_.resize(cloud_->points.size());
		cloud_nrm_.resize(cloud_->points.size());
		for(int i=0;i<cloud_->points.size();i++){
			cloud_xyz_[i].push_back(cloud_->points[i].x);
			cloud_xyz_[i].push_back(cloud_->points[i].y);
			cloud_xyz_[i].push_back(cloud_->points[i].z);
			cloud_nrm_[i].push_back(cloud_->points[i].normal_x);
			cloud_nrm_[i].push_back(cloud_->points[i].normal_y);
			cloud_nrm_[i].push_back(cloud_->points[i].normal_z);
		}   
	}
}

int CloudProperties::GetNumberOfPts()
{
	return cloud_->points.size();
}

float CloudProperties::GetMinorEigenvalue()
{
	GetEvalAndEvec();
	return eval_[0];
}

float CloudProperties::GetMinMaxRatio()
{
	GetEvalAndEvec();
	return eval_[0]/eval_[2];
}

vector<float> CloudProperties::GetMinorEigenvector()
{
	GetEvalAndEvec();
	return evec_[0];
}

PointType CloudProperties::GetCentroid()
{
	PointType *ptmp=new PointType();
	ptmp->x=0;
	ptmp->y=0;
	ptmp->z=0;
	for(int i=0; i<cloud_->points.size(); i++){
		ptmp->x+=cloud_->points[i].x;
		ptmp->y+=cloud_->points[i].y;
		ptmp->z+=cloud_->points[i].z;
	}
	ptmp->x=ptmp->x/cloud_->points.size();
	ptmp->y=ptmp->y/cloud_->points.size();
	ptmp->z=ptmp->z/cloud_->points.size();
	return *ptmp;
}

void CloudProperties::GetEvalAndEvec()
{
	if(flag_is_eval_evec_computed_==0){
		// Init
		eval_.resize(3);
		
		// Calculate Evec and Eval
		Eigen::Vector4f centroid;
		Eigen::Matrix3f covariance;
		pcl::compute3DCentroid(*cloud_, centroid);
		pcl::computeCovarianceMatrixNormalized(*cloud_, centroid, covariance);
		Eigen::SelfAdjointEigenSolver<Eigen::Matrix3f> eigen_solver(covariance, Eigen::ComputeEigenvectors);
		Eigen::Matrix3f eig_vec = eigen_solver.eigenvectors();
		Eigen::Vector3f eig_val = eigen_solver.eigenvalues();
		
		// eigenvalue
		eval_[0]=eig_val(0);
		eval_[1]=eig_val(1);
		eval_[2]=eig_val(2);

		// eigenvector
		eig_vec.col(2) = eig_vec.col(0).cross(eig_vec.col(1));
		eig_vec.col(0) = eig_vec.col(1).cross(eig_vec.col(2));
		eig_vec.col(1) = eig_vec.col(2).cross(eig_vec.col(0));

		evec_.push_back({eig_vec(0,0), eig_vec(0,1), eig_vec(0,2)});
		evec_.push_back({eig_vec(1,0), eig_vec(1,1), eig_vec(1,2)});
		evec_.push_back({eig_vec(2,0), eig_vec(2,1), eig_vec(2,2)});

		flag_is_eval_evec_computed_=1;
	}
}

float CloudProperties::GetCellSize(int level)
{
	PointType pmin, pmax;
    pcl::getMinMax3D(*cloud_, pmin, pmax);
    /*
    Get the minimum and maximum values on each of tud	the point cloud data message
        [out]	min_pt	the resultant minimum bounds
        [out]	max_pt	the resultant maximum boundshe 3 (x-y-z) dimensions in a
    given pointcloud. Parameters [in]	clo
    */
    float cellsize = MAX3(abs(pmax.x - pmin.x), abs(pmax.y - pmin.y), abs(pmax.z - pmax.z));  // abs函数是计算绝对值
    return cellsize / pow(2, level);
}
