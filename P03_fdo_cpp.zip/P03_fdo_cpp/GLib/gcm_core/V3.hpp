#pragma once
#include <string>
#include <vector>
#include <math.h>
#include <limits.h>
#include <iostream>
#include <eigen3/Eigen/Core>
#define PI 3.1415926535897
#define X_AXIS 0
#define Y_AXIS 1
#define Z_AXIS 2
#define XOY 3
#define XOZ 4
#define YOZ 5
using namespace std;

class V3
{
public:
	union {
		struct {
			float x, y, z;
		};

		struct {
			float r, g, b;
		};
	};
	V3() :r(0.0f), g(0.0f), b(0.0f) {};
	V3(float r1, float g1, float b1)
	{
		r = r1;
		g = g1;
		b = b1;
	}	
    V3(vector<float> dat)
    {
        x=dat[0];
        y=dat[1];
        z=dat[2];
    }
	
	V3& operator=(const V3 & obj)
	{
		r = obj.r;
		g = obj.g;
		b = obj.b;
		return (*this);
	}
	
	bool operator==(V3& dat)
	{
		return ((x == dat.x) && (y == dat.y) && (z == dat.z));
	}

	bool operator!=(V3& dat)
	{
		if ((x == dat.x) && (y == dat.y) && (z == dat.z))
			return false;
		else
			return true;		
	}	

	float DistanceXY(V3 & dat)
	{
		return sqrt(pow(x - dat.x, 2.0f) + pow(y - dat.y, 2.0f));
	}
	friend float Distance(V3& dat1,V3& dat2)
	{
		return sqrt(pow(dat1.x - dat2.x, 2.0f) + pow(dat1.y - dat2.y, 2.0f) + pow(dat1.z - dat2.z, 2.0f));
	}

	V3 operator *(float scale)
	{
		V3 temp;
		temp.x = x * scale;
		temp.y = y * scale;
		temp.z = z * scale;
		return temp;
	}

	vector<float> ToFloat()
	{
		vector<float> dat(3);
		dat[0]=x;
		dat[1]=y;
		dat[2]=z;
		return dat;
	}
	vector<vector<float>> ToFloat2D()
	{
		vector<vector<float>> dat(1, vector<float>(3));
		dat[0][0]=x;
		dat[0][1]=y;
		dat[0][2]=z;
		return dat;
	}

	vector<int> ToInt()
	{
		vector<int> dat(3);
		dat[0]=x;
		dat[1]=y;
		dat[2]=z;
		return dat;
	}

	tuple<float,float,float> GetElements()
	{
		return make_tuple(x,y,z);
	}

	friend V3 operator*(float scale, V3 dat)
	{
		dat.x = scale * dat.x;
		dat.y = scale * dat.y;
		dat.z = scale * dat.z;
		return dat;
	}

	V3 operator*(V3 dat)
	{
		dat.x = dat.x*x;
		dat.y = dat.y*y;
		dat.z = dat.z*z;
		return dat;
	}


	V3& operator /(float scale)
	{
		x = x / scale;
		y = y / scale;
		z = z / scale;
		return *this;
	}
	friend V3 operator +(V3 dat1, V3 dat2)
	{
		V3 rst;
		rst.x = dat1.x + dat2.x;
		rst.y = dat1.y + dat2.y;
		rst.z = dat1.z + dat2.z;
		return rst;
	}

	V3 operator+ (float dat)
	{
		V3 temp;
		temp.x = x + dat;
		temp.y = y + dat;
		temp.z = z + dat;

		return temp;
	}

	friend V3 operator+(float dat1, V3 dat2)
	{
		V3 temp;
		temp.x = dat1 + dat2.x;
		temp.y = dat1 + dat2.y;
		temp.z = dat1 + dat2.z;
		return temp;
	}


	V3  operator -(V3  dat)
	{
		V3 rst;
		rst.x = x - dat.x;
		rst.y = y - dat.y;
		rst.z = z - dat.z;
		return rst;
	}
	V3 operator-(float dat)
	{
		V3 rst;
		rst.x -= dat;
		rst.y -= dat;
		rst.z -= dat;
		return rst;
	}

	friend float Dot(V3 dat1,V3 dat2)
	{	
		return (dat1.x*dat2.x+dat1.y*dat2.y+dat1.z*dat2.z);
	}

	float Dot(V3 dat){
		return (x*dat.x+y*dat.y+ z*dat.z);
	}
	V3 Cross(V3& dat){
		V3 rst;
		rst.x = y*dat.z - dat.y*z;
		rst.y = dat.x*z - x*dat.z;
		rst.z = x*dat.y - y*dat.x;
		return rst;
	}

	friend V3 Cross(V3& dat1, V3& dat2)
	{
		V3 rst;
		rst.x = dat1.y*dat2.z - dat2.y*dat1.z;
		rst.y = dat2.x*dat1.z - dat1.x*dat2.z;
		rst.z = dat1.x*dat2.y - dat1.y*dat2.x;
		return rst;
	}

	float GetLength()
	{		
		return sqrt(x*x + y * y + z * z);
	}	
	
	V3 Normalize()
	{
		float a = sqrt(x*x + y * y + z * z);
		x = x / a;
		y = y / a;
		z = z / a;
		return *this;		
	}

	void Clear()
	{
		x = y = z = INT_MAX;
	}

	friend std::ostream& operator <<(std::ostream& os, const V3 dat)
	{
		os << dat.x << " " << dat.y << " " << dat.z;
		return os;
	}
	
	float GetArcToPlane(int rotation_axis, int plane)
	{
		float arc;		
		if(rotation_axis == X_AXIS && plane == XOZ)
		{	
			if(y==0)
				arc=PI/2.0f;
			else if(z==0)
				arc=0;
			else if(y*z>0)
			{
				arc=atan(y/z);
			}
			else
			{
				arc=PI+atan(y/z);
			}
		}
		else if(rotation_axis == X_AXIS && plane == XOY)
		{		
			if(y==0)
				arc=0;
			else if(z==0)
				arc=PI/2.0f;
			else 
				arc=PI/2.0f+atan(y/z);
		}		
		else if(rotation_axis == Y_AXIS && plane == XOY)
		{		
			if(x==0)
				arc=PI/2.0f;
			else if(z==0)
				arc=0;
			else if(x*z>0)
				arc=atan(z/x);
			else 
				arc=PI+atan(z/x);
		}
		else if(rotation_axis == Y_AXIS && plane == YOZ)
		{		
			if(x==0)
				arc=0;
			else if(z==0)
				arc=PI/2.0f;
			else
				arc=PI/2.0f+atan(z/x);
		}
		else if(rotation_axis == Z_AXIS && plane == YOZ)
		{		
			if(x==0)
				arc=PI/2.0f;
			else if(y==0)
				arc=0;
			else if(x*y>0)
				arc=atan(x/y);
			else
				arc=PI+atan(x/y);
		}
		else if(rotation_axis == Z_AXIS && plane == XOZ)
		{			
			if(x==0)				
				arc=PI/2.0f;			
			else if(y==0)				
				arc=0;			
			else
				arc=PI/2.0f+atan(x/y);			
		}
		
		return arc;
	}

	float EuclideanDistance(V3 dat){
		return sqrt(pow(x-dat.x,2)+pow(y-dat.y,2)+pow(z-dat.z,2));
	}

	Eigen::MatrixXd ToMatrixXd_1x3()
	{
		Eigen::MatrixXd pt(1,3);
		pt<<x,y,z;
		return pt;
	}

	Eigen::MatrixXd ToMatrixXd_3x1()
	{
		Eigen::MatrixXd pt(3,1);
		pt<<x,y,z;
		return pt;
	}
};
