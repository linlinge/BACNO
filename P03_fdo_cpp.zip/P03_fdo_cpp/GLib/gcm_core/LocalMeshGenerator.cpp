#include <LocalMeshGenerator.h>

PoissonRecon::PoissonRecon(vector<vector<float>>& pts)
{
    pts_=pts;
}

vector<vector<int>> PoissonRecon::Recon()
{
    Plane pl(pts_);

    // construct point cloud
    pcl::PointCloud<PointType>::Ptr cloud(new pcl::PointCloud<PointType>);
    for(int i=0; i< pts_.size(); i++){
        cloud->points.push_back(PointType((float)pts_[i][0], (float)pts_[i][1], (float)pts_[i][2]));
    }

    pcl::NormalEstimation<PointType , pcl::Normal> n ;//法线估计对象
    pcl::PointCloud<pcl::Normal>::Ptr normals(new pcl::PointCloud<pcl::Normal>) ;//存储估计的法线
    pcl::search::KdTree<PointType>::Ptr tree(new pcl::search::KdTree<PointType>) ;
    Eigen::Vector4f centroid;  //质心 
    pcl::compute3DCentroid(*cloud,centroid); // 计算质心

    tree->setInputCloud(cloud) ;
    n.setViewPoint(centroid.x(),centroid.y(),centroid.z());
    n.setInputCloud(cloud) ;
    n.setSearchMethod(tree) ;
    n.setKSearch(12) ;
    n.compute(*normals) ;
    for(int i=0; i<normals->points.size(); i++){
        cloud->points[i].normal_x=normals->points[i].normal_x;
        cloud->points[i].normal_y=normals->points[i].normal_y;
        cloud->points[i].normal_z=normals->points[i].normal_z;
    }

    pcl::search::KdTree<PointType>::Ptr tree2(new pcl::search::KdTree<PointType>) ;
    tree2->setInputCloud(cloud) ;
    pcl::Poisson<PointType> pn ;
    pn.setSearchMethod(tree2) ;
    pn.setInputCloud(cloud) ;    
    pn.setConfidence(true) ; // 设置置信标志，为true时，使用法线向量长度作为置信度信息，false则需要对法线进行归一化处理
    pn.setManifold(false) ; // 设置流行标志，如果设置为true，则对多边形进行细分三角话时添加重心，设置false则不添加
    pn.setOutputPolygons(false) ;//设置是否输出为多边形
    pn.setIsoDivide(5) ;
    pn.setDepth(3);
    pn.setSamplesPerNode(1.5) ;//设置每个八叉树节点上最少采样点数目

    pcl::PolygonMesh mesh ;
    pn.performReconstruction(mesh);
    
    
    pcl::PointCloud<pcl::PointXYZ>::Ptr out_cloud(new pcl::PointCloud<pcl::PointXYZ>);
    pcl::fromPCLPointCloud2(mesh.cloud, *out_cloud);
    vector<vector<float>> out_pts(out_cloud->points.size(), vector<float>(3));
    for(int i=0; i<out_cloud->points.size(); i++){
        out_pts[i][0]=out_cloud->points[i].x;
        out_pts[i][1]=out_cloud->points[i].y;
        out_pts[i][2]=out_cloud->points[i].z;
    }

    vector<vector<int>> out_fid(mesh.polygons.size(), vector<int>(3));
    fid_.resize(mesh.polygons.size());
    for(int i=0;i<out_fid.size(); i++){
        fid_[i].push_back(mesh.polygons[i].vertices[0]);
        fid_[i].push_back(mesh.polygons[i].vertices[1]);
        fid_[i].push_back(mesh.polygons[i].vertices[2]);
    }

    vector<vector<int>> out;
    return out;
}


Delaunay2D::Delaunay2D(vector<vector<float>>& pts)
{
    debug=0;
    pts_=pts;
}

Delaunay2D::Delaunay2D(pcl::PointCloud<PointType>::Ptr cloud)
{
    debug=0;
    for(int i=0; i<cloud->points.size(); i++){
        pts_.push_back({cloud->points[i].x, cloud->points[i].y, cloud->points[i].z});
    }
}

void Delaunay2D::EnableDebug()
{
    debug=1;
}

void Delaunay2D::DisableDebug()
{
    debug=0;
}

vector<vector<int>> Delaunay2D::Recon()
{
    /*     */
    AABB* bb=new AABB(pts_);
    Plane pl(pts_);	
	Quaterniond trans_=Quaterniond::FromTwoVectors(Vector3d(pl.A_,pl.B_,pl.C_), Vector3d(0,0,1));
	MatrixXd T_=trans_.toRotationMatrix();

    MatrixXd D(pts_.size(), 3); // nx3
	for(int i=0; i< pts_.size(); i++){
		D(i,0)=pts_[i][0];
		D(i,1)=pts_[i][1];
		D(i,2)=pts_[i][2];
	}	
    MatrixXd D_bar_repeat_n=MatrixXd::Ones(pts_.size(), pts_.size())*D;
	D_bar_repeat_n=D_bar_repeat_n/pts_.size();
    MatrixXd D_tf=(T_*(D-D_bar_repeat_n).transpose()).transpose();
    vector<vector<float>> pts_tf(pts_.size(), vector<float>(3));
	for(int i=0; i<pts_.size(); i++){		
		pts_tf[i][0]=D_tf(i,0);
		pts_tf[i][1]=D_tf(i,1);
		pts_tf[i][2]=D_tf(i,2);		
	}


    vector<pair<point_2,unsigned> > pointsList;    
    pointsList.resize(pts_.size());
    for(int i=0; i<pts_.size(); i++){
        // pointsList.push_back(std::make_pair( point_2(pts_tf[i][0],pts_tf[i][1]), i )); 
        pointsList[i]=std::make_pair( point_2(pts_tf[i][0],pts_tf[i][1]), i );
    }
        
    triangulation_.insert(pointsList.begin(),pointsList.end());


    vector<vector<int>> out;
    for(delaunay_2::Finite_faces_iterator fit = triangulation_.finite_faces_begin(); fit != triangulation_.finite_faces_end(); ++fit) {
        delaunay_2::Face_handle face = fit;
        out.push_back({face->vertex(0)->info(),face->vertex(1)->info(),face->vertex(2)->info()});
    }

    
    return out;
}

int Delaunay2D::IsIntersect2(Ray ry)
{
    vector<vector<float>> set_of_itsc;
    for(int i=0; i<fid_.size(); i++){
        V3 v0(pts_[fid_[i][0]]);
        V3 v1(pts_[fid_[i][1]]);
        V3 v2(pts_[fid_[i][2]]);
        Triangle tri(v0, v1, v2);
        auto [num_of_itsc, itsc]=ry.IsIntersect(tri);     
        if(num_of_itsc>0)
            set_of_itsc.push_back(itsc);
    }
    if(set_of_itsc.size()>1){
        DBSCAN db(set_of_itsc,0.00001);
        return db.num_of_clusters_;
    }
    else 
        return set_of_itsc.size();    
}


int Delaunay2D::IsIntersect(Ray ry)
{  
    std::list<Cartesian_Triangle_3> triangles;    
    for(int i=0; i< fid_.size(); i++){
        Cartesian_Point_3 a(pts_[fid_[i][0]][0], pts_[fid_[i][0]][1], pts_[fid_[i][0]][2]);
        Cartesian_Point_3 b(pts_[fid_[i][1]][0], pts_[fid_[i][1]][1], pts_[fid_[i][1]][2]);
        Cartesian_Point_3 c(pts_[fid_[i][2]][0], pts_[fid_[i][2]][1], pts_[fid_[i][2]][2]);
        triangles.push_back(Cartesian_Triangle_3(a,b,c));
    }

    // constructs AABB tree
    Tree tree(triangles.begin(), triangles.end());

    Cartesian_Point_3 o(ry.origin_.x, ry.origin_.y, ry.origin_.z);
    Cartesian_Point_3 e(ry.origin_.x+ry.direction_.x, ry.origin_.y + ry.direction_.y, ry.origin_.z+ry.direction_.z);
    Cartesian_Ray_3 ray_query(o, e);
    int num_of_itsc=tree.number_of_intersected_primitives(ray_query);
    return num_of_itsc;
}

int Delaunay2D::IsIntersect(LineSegment ls)
{  
    std::list<Cartesian_Triangle_3> triangles;    
    for(int i=0; i< fid_.size(); i++){
        Cartesian_Point_3 a(pts_[fid_[i][0]][0], pts_[fid_[i][0]][1], pts_[fid_[i][0]][2]);
        Cartesian_Point_3 b(pts_[fid_[i][1]][0], pts_[fid_[i][1]][1], pts_[fid_[i][1]][2]);
        Cartesian_Point_3 c(pts_[fid_[i][2]][0], pts_[fid_[i][2]][1], pts_[fid_[i][2]][2]);
        triangles.push_back(Cartesian_Triangle_3(a,b,c));
    }

    // constructs AABB tree
    Tree tree(triangles.begin(), triangles.end());

    Cartesian_Point_3 o(ls.origin_.x, ls.origin_.y, ls.origin_.z);
    Cartesian_Point_3 e(ls.end_.x,    ls.end_.y,    ls.end_.z);
    Cartesian_Segment_3 ls_query(o, e);
    int num_of_itsc=tree.number_of_intersected_primitives(ls_query);
    return num_of_itsc;
}



void Delaunay2D::FilterFace(float thresh)
{
    if(thresh<0){
        for(delaunay_2::Finite_faces_iterator fit = triangulation_.finite_faces_begin(); fit != triangulation_.finite_faces_end(); ++fit) {
            delaunay_2::Face_handle face = fit;        
            fid_.push_back(V3(face->vertex(0)->info(), face->vertex(1)->info(), face->vertex(2)->info()).ToInt());        
        }
    }
    else{
        int i=0;
        for(delaunay_2::Finite_faces_iterator fit = triangulation_.finite_faces_begin(); fit != triangulation_.finite_faces_end(); ++fit, i++) {
            delaunay_2::Face_handle face = fit;        
            int itmp0=face->vertex(0)->info();
            int itmp1=face->vertex(1)->info();
            int itmp2=face->vertex(2)->info();
            V3 ptmp_0(pts_[itmp0][0],pts_[itmp0][1],pts_[itmp0][2]);
            V3 ptmp_1(pts_[itmp1][0],pts_[itmp1][1],pts_[itmp1][2]);
            V3 ptmp_2(pts_[itmp2][0],pts_[itmp2][1],pts_[itmp2][2]);
        
            float dist_0=ptmp_0.EuclideanDistance(ptmp_1);
            float dist_1=ptmp_1.EuclideanDistance(ptmp_2);
            float dist_2=ptmp_2.EuclideanDistance(ptmp_0);

            if(dist_0<thresh && dist_1<thresh && dist_2<thresh){
                fid_.push_back({itmp0, itmp1, itmp2});        
            }            
        }            
    }
}
void Delaunay2D::Upsampling()
{
    for(int i=0; i<fid_.size(); i++){
        V3 pt_0(pts_[fid_[i][0]][0], pts_[fid_[i][0]][1], pts_[fid_[i][0]][2]);
        V3 pt_1(pts_[fid_[i][1]][0], pts_[fid_[i][1]][1], pts_[fid_[i][1]][2]);
        V3 pt_2(pts_[fid_[i][2]][0], pts_[fid_[i][2]][1], pts_[fid_[i][2]][2]);

        V3 centre=(pt_0+pt_1+pt_2)/3.0;
        V3 new_pt_0=(pt_0 + pt_1 + centre)/3.0;
        V3 new_pt_1=(pt_1 + pt_2 + centre)/3.0;
        V3 new_pt_2=(pt_2 + pt_0 + centre)/3.0;
        pts_.push_back(centre.ToFloat());
        pts_.push_back(new_pt_0.ToFloat());
        pts_.push_back(new_pt_1.ToFloat());
        pts_.push_back(new_pt_2.ToFloat());
    }
}

float Delaunay2D::GetMinimumLengthOfEdge()
{
    GetMMMLengthOfEdge();
    return min_length_of_edge_;
}

float Delaunay2D::GetMeanLengthOfEdge()
{
    GetMMMLengthOfEdge();
    return max_length_of_edge_;
}

float Delaunay2D::GetMaximumLengthOfEdge()
{
    GetMMMLengthOfEdge();
    return mean_length_of_edge_;
}

void Delaunay2D::GetMMMLengthOfEdge()
{   
    if(is_edge_length_calculated_==0){
        for(int i=0;i<fid_.size(); i++){  
            int itmp0=fid_[i][0];
            int itmp1=fid_[i][1];
            int itmp2=fid_[i][2];
            V3 ptmp_0(pts_[itmp0][0],pts_[itmp0][1],pts_[itmp0][2]);
            V3 ptmp_1(pts_[itmp1][0],pts_[itmp1][1],pts_[itmp1][2]);
            V3 ptmp_2(pts_[itmp2][0],pts_[itmp2][1],pts_[itmp2][2]);

            float dist_0=ptmp_0.EuclideanDistance(ptmp_1);
            float dist_1=ptmp_1.EuclideanDistance(ptmp_2);
            float dist_2=ptmp_2.EuclideanDistance(ptmp_0);    

            min_length_of_edge_=MIN2(min_length_of_edge_, dist_0);
            min_length_of_edge_=MIN2(min_length_of_edge_, dist_1);
            min_length_of_edge_=MIN2(min_length_of_edge_, dist_2);

            max_length_of_edge_=MAX2(max_length_of_edge_, dist_0);
            max_length_of_edge_=MAX2(max_length_of_edge_, dist_1);
            max_length_of_edge_=MAX2(max_length_of_edge_, dist_2);

            mean_length_of_edge_+=dist_0;
            mean_length_of_edge_+=dist_1;
            mean_length_of_edge_+=dist_2;
        }
        mean_length_of_edge_=mean_length_of_edge_/(3.0*fid_.size());
    }
}


Delaunay3D::Delaunay3D(vector<vector<float>>& pts)
{
    pts_=pts;
}

vector<vector<int>> Delaunay3D::Recon()
{
    // construction from a list of points :
    std::vector<std::pair<point_3, int>> pointsList;
    // make pair with index
    for(int i=0; i<pts_.size(); i++)
        pointsList.push_back(std::make_pair(point_3(pts_[i][0], pts_[i][1], pts_[i][2]), i));


    delaunay_3 triangulation;
    triangulation.insert(pointsList.begin(), pointsList.end());

    for (delaunay_3::Finite_facets_iterator it = triangulation.finite_facets_begin(); it != triangulation.finite_facets_end(); it++) 
    {
        std::pair<delaunay_3::Cell_handle, int> facet = *it;
        delaunay_3::Vertex_handle v1 = facet.first->vertex( (facet.second+1)%4 );
        delaunay_3::Vertex_handle v2 = facet.first->vertex( (facet.second+2)%4 );
        delaunay_3::Vertex_handle v3 = facet.first->vertex( (facet.second+3)%4 );
        fid_.push_back(V3(v1->info(), v2->info(), v3->info()).ToInt());
    }

    vector<vector<int>> out;
    return out;
}