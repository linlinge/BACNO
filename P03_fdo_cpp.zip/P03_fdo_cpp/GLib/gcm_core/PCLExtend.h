#pragma once
#include <math.h>
#include <omp.h>
#include <string>
#include <pcl/point_types.h>
#include <pcl/io/ply_io.h>
#include <pcl/geometry/polygon_mesh.h>
#include <pcl/kdtree/kdtree_flann.h>
#include <pcl/features/boundary.h>
#include <pcl/features/normal_3d.h>
#include <pcl/surface/gp3.h>
#include <pcl/surface/mls.h>

// #include <pcl/console/print.h>  

#include <pcl/octree/octree.h>
#include <pcl/point_cloud.h>
#include <pcl/segmentation/conditional_euclidean_clustering.h>
#include <pcl/segmentation/region_growing.h>
#include <pcl/features/moment_of_inertia_estimation.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/filters/convolution_3d.h>
#include <pcl/filters/project_inliers.h>
#include <pcl/filters/voxel_grid.h>

#include <Eigen/Dense>
#include <fstream>
#include <iostream>
#include <vector>
#include <LibGlobal.h>
#ifndef PointType
#define PointType pcl::PointXYZRGBNormal
#endif
using namespace std;
float GetCellSize(pcl::PointCloud<PointType>::Ptr cloud, int level);
vector<vector<int>> SearchKNearestFaces(pcl::PolygonMesh::Ptr mesh, pcl::PointCloud<PointType>::Ptr mesh_pts, PointType find_pt, int k);
vector<vector<float>> ToVector(pcl::PointCloud<PointType>::Ptr cloud);
vector<vector<float>> GetOBB(pcl::PointCloud<PointType>::Ptr cloud);
float projection(pcl::PointCloud<PointType>::Ptr cloud,float a, float b, float c, float d);
void FindCorrespondingIndices(pcl::search::KdTree<PointType>::Ptr kdtree, pcl::PointCloud<PointType>::Ptr acloud, vector<int>& indices);
vector<vector<float>> GetXYZ(pcl::PointCloud<PointType>::Ptr cloud);
bool customRegionGrowing(const PointType& point_a, const PointType& point_b, float squared_distance);
float CalculateUDF_by_WassteinDistance(pcl::PointCloud<PointType>::Ptr icloud, pcl::search::KdTree<PointType>::Ptr ikdtree, PointType pt, int K);
