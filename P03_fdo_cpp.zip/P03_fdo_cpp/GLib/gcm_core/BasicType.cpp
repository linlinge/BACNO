#include <BasicType.h>
int V2I::type_id_=TwoInt;
int Position::type_id_=Point3DXYZ;
int PositionNormal::type_id_=Point3DXYZNxNyNz;
int PositionColor::type_id_=Point3DXYZRGB;
int PositionNormalColor::type_id_=Point3DXYZNxNyNzRGB;

int V2I::key_counter_=0;
int Position::key_counter_=0;
int PositionNormal::key_counter_=0;
int PositionColor::key_counter_=0;
int PositionNormalColor::key_counter_=0;