#include "FileExtend.h"
// remove adjacent duplicate substring in string
void remove_adjacent_duplicate(string& dat1, string dat2)
{
	vector<int> pos;
	int cur = dat1.find(dat2, 0);
	if (cur != -1)
	{
		while (cur != -1)
		{
			if (cur != -1)
				pos.push_back(cur);
			cur = dat1.find(dat2, cur + 1);
		}

		// remove duplicate
		int adjust = 0;
		for (int i = 0; i < pos.size() - 1; i++)
		{
			if (pos[i] + 1 == pos[i + 1])
			{
				dat1.erase(pos[i] + adjust, 1);
				adjust--;
			}
		}
	}
}

vector<string> split(string dat, string separator)
{
	vector<string> rst;
	int start, end;
	do
	{
		start = dat.find(separator);
		end = start + separator.size();
		rst.push_back(dat.substr(0, start));
		dat.erase(0, end);
	} while (start != -1);
	return rst;
}

// template<class T>
void WriteVector(string path, vector<int>& out)
{
	ofstream fout(path);
	for(int i=0;i<out.size();i++){
		fout<<out[i]<<endl;
	}
	fout.close();
}

void list_all_files(string path, vector<string>& filepath, vector<string>& filename)
{
	vector<string> files;
	if (auto dir = opendir(path.c_str())) {
		while (auto f = readdir(dir)) {
			if (!f->d_name || f->d_name[0] == '.')
				continue; // Skip everything that starts with a dot

			string str=f->d_name;
			filepath.push_back(path+"/"+str);
			filename.push_back(str);
		}
		closedir(dir);
	}
}

bool file_exists(string name) 
{
    ifstream f(name);
    return f.good();
}

namespace fs = std::filesystem;
bool createFolderIfNotExists(const std::string& folderPath) {  
    if (fs::exists(folderPath)) {  
        // std::cout << "文件夹已经存在" << std::endl;  
        return true;  
    } else {  
        if (fs::create_directory(folderPath)) {  
            // std::cout << "文件夹创建成功" << std::endl;  
            return true;  
        } else {  
            // std::cout << "文件夹创建失败" << std::endl;  
            return false;  
        }  
    }  
}  

void WriteStringToFilename(string filename, string content)
{
	ofstream fout(filename);
	fout<<content<<endl;
	fout.close();
}

string ReadStringFromFilename(string filename)
{
	ifstream fin(filename);
	string line;
	if(fin.is_open()){
        std::getline(fin, line);  // 读取文件内容  
        fin.close();  
        return line;  
    } 
	else {  
        return "null";  		// 文件不存在时返回 "null"  
    }  
}