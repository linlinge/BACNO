#include "PCLExtend.h"


float GetCellSize(pcl::PointCloud<PointType>::Ptr cloud, int level)  // level是？ 计算获得cell的size
{
    PointType pmin, pmax;
    pcl::getMinMax3D(*cloud, pmin, pmax);
    /*
    Get the minimum and maximum values on each of the 3 (x-y-z) dimensions in a
    given pointcloud. Parameters [in]	cloud	the point cloud data message
        [out]	min_pt	the resultant minimum bounds
        [out]	max_pt	the resultant maximum bounds
    */
    float cellsize = MAX3(abs(pmax.x - pmin.x), abs(pmax.y - pmin.y), abs(pmax.z - pmax.z));  // abs函数是计算绝对值
    return cellsize / pow(2, level);
}


vector<vector<int>> SearchKNearestFaces(pcl::PolygonMesh::Ptr mesh, pcl::PointCloud<PointType>::Ptr mesh_pts, PointType find_pt, int k)
{
    pcl::search::KdTree<PointType>::Ptr kdtree(new pcl::search::KdTree<PointType>);
    kdtree->setInputCloud(mesh_pts);
    vector<int> idx;
    vector<float> dist;
    kdtree->nearestKSearch(find_pt, k, idx, dist);
    
    vector<vector<int>> fid(idx.size(), vector<int>(3));
    for(int i=0; i<idx.size(); i++){
        fid[i][0]=mesh->polygons[i].vertices[0];
        fid[i][1]=mesh->polygons[i].vertices[1];
        fid[i][2]=mesh->polygons[i].vertices[2];
    }

    return fid;
}

float ComputeMeanDistance(const pcl::PointCloud<PointType>::ConstPtr cloud)
{
	float res = 0.0;
	int n_points = 0;
	int nres;
	std::vector<int> indices(2);
	std::vector<float> sqr_distances(2);
	pcl::search::KdTree<PointType> tree;
	tree.setInputCloud(cloud);

	for (size_t i = 0; i < cloud->size(); ++i)
	{
		if (!std::isfinite((*cloud)[i].x))
		{
			continue;
		}
		nres = tree.nearestKSearch(i, 2, indices, sqr_distances);
		if (nres == 2)
		{
			res += sqrt(sqr_distances[1]);
			++n_points;
		}
	}
	if (n_points != 0)
	{
		res /= n_points;
	}
	return res;
}


vector<vector<float>> ToVector(pcl::PointCloud<PointType>::Ptr cloud)
{
	vector<vector<float>> out(cloud->points.size(), vector<float>(3)); 
	for(int i=0; i<cloud->points.size(); i++){
		out[i][0]=cloud->points[i].x;
		out[i][1]=cloud->points[i].y;
		out[i][2]=cloud->points[i].z;
	}
	return out;
}

vector<vector<float>> GetOBB(pcl::PointCloud<PointType>::Ptr cloud)
{
	pcl::MomentOfInertiaEstimation<PointType> feature_extractor;
	feature_extractor.setInputCloud(cloud);
	feature_extractor.compute();
	PointType min_point_OBB;
	PointType max_point_OBB;
	PointType position_OBB;
	Eigen::Matrix3f rotational_matrix_OBB;
	Eigen::Vector3f major_vector, middle_vector, minor_vector;
	Eigen::Vector3f mass_center;
	feature_extractor.getOBB(min_point_OBB, max_point_OBB, position_OBB, rotational_matrix_OBB);	

	vector<vector<float>> out(3,vector<float>(3));
	out[0][0]=min_point_OBB.x;
	out[0][1]=min_point_OBB.y;
	out[0][2]=min_point_OBB.z;

	out[1][0]=max_point_OBB.x;
	out[1][1]=max_point_OBB.y;
	out[1][2]=max_point_OBB.z;

	out[2][0]=max_point_OBB.x-min_point_OBB.x;
	out[2][1]=max_point_OBB.y-min_point_OBB.y;
	out[2][2]=max_point_OBB.z-min_point_OBB.z;
	return out;
}


float projection(pcl::PointCloud<PointType>::Ptr cloud, float a, float b, float c, float d)
{
	pcl::ModelCoefficients::Ptr coefficients(new pcl::ModelCoefficients());
	coefficients->values.resize(4);
	coefficients->values[0] = a;
	coefficients->values[1] = b;
	coefficients->values[2] = c;
	coefficients->values[3] = d;

	// 创建滤波器对象
	pcl::PointCloud<PointType>::Ptr cloud_prj(new pcl::PointCloud<PointType>);
	pcl::ProjectInliers<PointType> proj;//创建滤波器对象
	proj.setModelType(pcl::SACMODEL_PLANE); //设置对象对应的投影模型
	proj.setInputCloud(cloud);
	proj.setModelCoefficients(coefficients);//设置投影模型的参数因子
	proj.filter(*cloud_prj);

	vector<vector<float>> obb=GetOBB(cloud_prj);

	return MIN3(obb[2][0], obb[2][1], obb[2][2]);
}

void FindCorrespondingIndices(pcl::search::KdTree<PointType>::Ptr kdtree, pcl::PointCloud<PointType>::Ptr acloud, vector<int>& indices)
{
	for(int i=0;i<acloud->points.size();i++){
		vector<float> dist;
		vector<int> idx;
		kdtree->nearestKSearch(acloud->points[i],1,idx,dist);		
		indices.push_back(idx[0]);
	}
}

vector<vector<float>> GetXYZ(pcl::PointCloud<PointType>::Ptr cloud)
{
	vector<vector<float>> cloud_xyz;
	cloud_xyz.resize(cloud->points.size(), vector<float>(3));
	for(int i=0; i<cloud->points.size(); i++)
	{
		cloud_xyz[i][0]=cloud->points[i].x;
		cloud_xyz[i][1]=cloud->points[i].y;
		cloud_xyz[i][2]=cloud->points[i].z;
	}
	return cloud_xyz;
}

/**
 * compute the wasstein distance from pt to icloud
 * @param icloud: the input cloud
 * @param ikdtree: the kdtree of the input cloud
 * @param pt: the point to compute 
 * @param K: the k number for compute wasstein distance
*/
float CalculateUDF_by_WassteinDistance(pcl::PointCloud<PointType>::Ptr icloud, pcl::search::KdTree<PointType>::Ptr ikdtree, PointType pt, int K)
{
	vector<int> idx;
	vector<float> dist;
	ikdtree->nearestKSearch(pt, K, idx, dist);
	float wdist=0;
    for(int i=0; i<idx.size(); i++){
        // float dtmp = pow(pt.x - icloud->points[idx[i]].x,2) +  pow(pt.y - icloud->points[idx[i]].y,2) + pow(pt.z - icloud->points[idx[i]].z,2);
        wdist+=dist[i];
    }
    wdist = sqrt(wdist/K);

	return wdist;
}

bool customRegionGrowing(const PointType& point_a, const PointType& point_b, float squared_distance)
{
    return true;
}