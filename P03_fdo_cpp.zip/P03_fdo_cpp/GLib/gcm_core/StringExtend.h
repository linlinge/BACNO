#pragma once
#include <iostream>
#include <string>
#include <string.h>
#include <vector>
using namespace std;
void Str2Vec(string str, string delimiters, vector<int>& dat);
vector<string> StrSplit(const string& input, const string& delimiter);
void StrPrint(vector<int>& dat);
int get_num_in_string(string str);
string GetFileRoot(string filepath);
string GetFileName(string filepath);
string GetFileTitle(string filepath);