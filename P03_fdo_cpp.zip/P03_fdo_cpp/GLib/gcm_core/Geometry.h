#pragma once
#include "V3.hpp"
#include <iostream>
#include <eigen3/Eigen/Dense>
#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Geometry>
#include <fstream>
#include <stack>
#include <set>
#include <map>
#include <queue>
#include <algorithm>
#include <LibGlobal.h>
#include <heat_map.h>
using namespace std;
using namespace Eigen;

enum LineInitType{point_with_direction,point_to_point};
enum ProjectionType{XY,XZ,YZ};
class Plane;
class AABB;
class Triangle;
class PointN;

/************************************************************* 
 * N-dimension Point
**************************************************************/
class PointN
{
    public:
		static int key_counter_;
        int key_;
        vector<float> dat_;		

		PointN(float idata){
			key_++;
			dat_.push_back(idata);
		}

        PointN(vector<float> dat);

        virtual float DistTo(PointN& b){
            float r=0;
            for(int i=0; i<dat_.size(); i++){
                r+=pow(dat_[i]-b.dat_[i],2);
            }
            return sqrt(r);
        }

		float operator[](int i){
			if(i<dat_.size())
				return dat_[i];
			else{
				cout<<"Error: out of range!"<<endl;
				return -1;
			}
		}

		virtual int Size(){
			return dat_.size();
		}
};


/************************************************************* 
 * Pointwise Equation:
       (x-x1)/d.x=(y-y1)/d.y=(z-z1)/d.z
**************************************************************/
class Ray
{
	public:
		// represent by parameter	
		V3 origin_,direction_;
		
		// convert point-direction equation to parameter equation
		Ray(V3 dat1, V3 dat2, LineInitType mode);    

		// is intersect
		V3 IsIntersect(Plane& dat);
		tuple<bool, float>        IsIntersect(AABB obj);
		tuple<int,vector<float>> IsIntersect(Triangle ob);

		// transform
		V3    GetProjectionVector(ProjectionType mode);
		float GetProjectionArc(ProjectionType mode);
		V3 TransformTo(ProjectionType mode);
		Ray operator=(Ray obj);
};


/****************************************************************************************************************************
 * @brief Line
 * 
 ***************************************************************************************************************************/
class Line
{
	public:
		V3 origin_, direction_;
		float t_itsc_, t_o2e_;

		Line(V3 e1, V3 e2, int mode);		
		float GetDistTo(V3 pt);
		V3 GetItsc(V3 pt);
		tuple<V3, float> GetItscAndDist(V3 pt);
};

/************************************************************  Line Segments *************************************************/
class LineSegment
{
	public:
		// variables
		V3 origin_, end_;
		V3 direction_;
		float t_o2e_; // value of t: from origin to end
		float t_;

		// function
		LineSegment(V3 origin, V3 end);
		tuple<bool, float>        IsIntersect(AABB* bb);
		tuple<bool,vector<float>> IsIntersect(Triangle ob);
		tuple<bool,int> IsIntersect(vector<vector<float>> pts, vector<vector<int>> fid);

		/* Get */
		float GetLength();
		V3 GetQuantile(float quantile);

		/* Set */

		/* overwrite*/
		bool operator==(const LineSegment& dat);
		
};

/************************************************************* 
 * AABB
**************************************************************/
class AABB{
public:
    V3 bmin_, bmax_;	
	vector<vector<float>> corners_;	
    AABB(V3 bmin, V3 bmax);
	AABB(V3 center, float semi_width);
	AABB(){};
	AABB(vector<vector<float>> pts);
	V3 GetCentre();
	bool IsWithin(V3 pt);
	bool IsWithin(float x, float y, float z);
	vector<vector<float>> GenerateEightCorners();
	vector<vector<int>> GenerateSelfLines();
	friend AABB* UnionAABB(AABB* idata1, AABB* idata2);
	
};

/************************************************************* 
 * Plane
**************************************************************/
class Plane
{
	public:
		float A_, B_, C_, D_;
		Plane(){};
		Plane(float a, float b, float c, float d);
		Plane(V3 P1, V3 P2, V3 P3);
		Plane(V3 pt_on_plane, V3 normal);
		Plane(vector<vector<float>>& pts);
		void SetInputCloud(vector<vector<float>>& pts);

		/* Intersect */
		// Ray
		bool IsIntersect(Ray& dat);
		V3 GetIntersect(Ray& dat);
		// Line Segment
		bool IsIntersect(LineSegment& lseg);
		V3 GetIntersect(LineSegment& lseg);

		bool IsIntersect(AABB* bb);
		float Apply(float x, float y);
		float Distance(V3 pt);
		int SignToPlane(V3 pt);	
	private:
		int flag_is_intersect_with_ray_computed_=0;
		int flag_is_intersect_with_line_segment_computed_=0;
		V3 intersect_point_;
		float t_;
		void ComputeIntersect(Ray& dat);
		void ComputeIntersect(LineSegment& lseg);
};

/************************************************************* 
 * Angle
**************************************************************/
class Angle
{
public:
	float arc_, angle_;	
	Angle(V3& mid,V3& left,V3& right);
};

/************************************************************* 
 * Triangle
**************************************************************/
class Triangle
{
	public:
		V3 vtx_[3];
		Triangle(V3 v0, V3 v1, V3 v2);
		Triangle(vector<vector<float>> pts);
		tuple<int,vector<float>> IsIntersect(Ray ry);
		tuple<bool,vector<float>> IsIntersect(LineSegment ry);
		Triangle operator=(Triangle dat);
};


/*************************** Quad *************************/
template<class T>
class QuadNode{
	public:
		float xmin_, ymin_;
        float xmax_, ymax_;
		vector<T*> dat_;
		// vector<int> dat_idx_;
		QuadNode* parent_;
		vector<QuadNode*> child_;
		// QuadNode* child_;
		vector<float> centroid_;
		int deg_;
		int level_;
		int key_;

		QuadNode(){
			centroid_.resize(2);
			xmin_=ymin_=INT_MAX;
			xmax_=ymax_=-INT_MAX;
			centroid_[0]=INT_MAX;
			
			// cout<<sizeof(child_)<<endl;

			deg_=INT_MAX;
		}
		~QuadNode(){			
			// vector<T*>().swap(dat_);			
		}

		void SetInputCloud(vector<T*>& idata){
			// dat_=idata;
			// cout<<dat_[0]<<" "<<idata[0]<<endl;

			dat_.resize(idata.size());
			for(int i=0; i<idata.size(); i++){
				dat_[i]=idata[i];
			}
			GetAABB();
		}

		float GetTheta(float x, float y){
			float d=GetD();
			vector<float> centroid=GetCentroid();
			float r=sqrt(pow(x-centroid[0],2) + pow(y-centroid[1],2));
			return d/r;
		}		

		float GetDeg(){
			if(deg_==INT_MAX){
				deg_=0;
				for(int i=0; i<dat_.size(); i++){
					deg_+=dat_[i]->deg_;
				}				
			}			
			return deg_;
		}

		vector<float> GetCentroid(){
			if(centroid_[0]==INT_MAX){
				centroid_[0]=0;				
				for(int i=0; i<dat_.size(); i++){
					centroid_[0]+=dat_[i]->pos_x_;
					centroid_[1]+=dat_[i]->pos_y_;
				}
				centroid_[0]=centroid_[0]/dat_.size();
				centroid_[1]=centroid_[1]/dat_.size();
			}			
			return centroid_;
		}

		
	
	private:
		float GetD(){
			GetAABB();
			return MAX2(xmax_-xmin_, ymax_-ymin_);
		}
		void GetAABB(){
			if(xmin_==INT_MAX){
				for(int i=0; i<dat_.size(); i++){
					xmin_=MIN2(xmin_, dat_[i]->pos_x_);
					ymin_=MIN2(ymin_, dat_[i]->pos_y_);        
					xmax_=MAX2(xmax_, dat_[i]->pos_x_);
					ymax_=MAX2(ymax_, dat_[i]->pos_y_);
				}
			}
		}
};

template<class T>
class QuadTree{
	private:						
		int depth_;
		int node_key_generator_;
		int tmptmp;
		vector<float> width_in_each_level_;
	public:
		vector<T*> dat_;
		QuadNode<T>* header_;
		// vector<vector<QuadNode<T>*>> root_;

		QuadTree(){
			SetDepth(8);
			node_key_generator_=0;
		}

		~QuadTree(){			
			// dat_.clear();
			// width_in_each_level_.clear();

			stack<QuadNode<T>*> sck;
			sck.push(header_);
			while(sck.size()!=0){
				QuadNode<T>* ctmp=sck.top();
				if(ctmp->child_.size()==0){
					QuadNode<T>* parent=ctmp->parent_;
					
					for(auto it=parent->child_.begin(); it!=parent->child_.end(); it++){
						if(*it ==ctmp){							
							parent->child_.erase(it);
							break;
						}
					}	
					
					// cout<<ctmp->key_<<endl;
					sck.pop();
					delete ctmp;
				}
				else{
					for(int i=ctmp->child_.size()-1; i>=0; i--){
						sck.push(ctmp->child_[i]);
					}
				}				
			} 
		}

		void SetInputCloud(vector<T*>& idata){
			dat_=idata;
		}
		
		void SetDepth(int depth){
			width_in_each_level_.resize(depth);
			auto [x_width, x_min, xmax]=GetWidthMinimumMaximum(dat_, 0);			
			width_in_each_level_[depth-1]= x_width/pow(2,depth);
			for(int i=depth-2; i>=0; i--){
				width_in_each_level_[i]=width_in_each_level_[i+1]*2;
			}
			depth_=depth;
		}

		void BuildOctree(){	
			// root_.resize(depth_);	
			tmptmp=0;
			header_=CreateOctree(dat_, 0);
		}
	
	private:	
		tuple<float, float, float> GetWidthMinimumMaximum(vector<T*> idata, int axis){
			if(axis==0){
				float xmin=INT_MAX;
				float xmax=-INT_MAX;
				for(int i=0; i<idata.size(); i++){
					xmin=MIN2(xmin,idata[i]->pos_x_);
					xmax=MAX2(xmax,idata[i]->pos_x_);
				}
				return make_tuple(xmax-xmin, xmin, xmax);
			}
			else{
				float ymin=INT_MAX;
				float ymax=-INT_MAX;
				for(int i=0; i<idata.size(); i++){
					ymin=MIN2(ymin, idata[i]->pos_y_);
					ymax=MAX2(ymax, idata[i]->pos_y_);
				}
				return make_tuple(ymax-ymin, ymin, ymax);
			}			
		}

		QuadNode<T>* CreateOctree(vector<T*>& idata, int level){

			// stop recursive 
			if(idata.size()==0){
				return NULL;
			}

			QuadNode<T>* cnode= new QuadNode<T>();
			cnode->level_=level;
			cnode->key_=node_key_generator_++;


			// root_[level].push_back(cnode);

			if(level==(depth_-1)){
				return cnode;
			}

						
			vector<vector<T*>> buf;
			auto [x_width, x_min, x_max] =GetWidthMinimumMaximum(idata,0);
			auto [y_width, y_min, y_max] =GetWidthMinimumMaximum(idata,1);
			int col_num= floor(x_width/width_in_each_level_[level])+1;
			int row_num= floor(y_width/width_in_each_level_[level])+1; 
			buf.resize(row_num*col_num);

			
			for(int i=0; i<idata.size(); i++){
				int col=(int)((idata[i]->pos_x_ - x_min)/width_in_each_level_[level]);
				int row=(int)((idata[i]->pos_y_ - y_min)/width_in_each_level_[level]);				
				buf[row*col_num +col].push_back(idata[i]);
			}

			for(int i=0; i<buf.size(); i++){
				if(buf[i].size()!=0){
					QuadNode<T>* child=CreateOctree(buf[i], level+1);
					child->parent_=cnode;
					cnode->child_.push_back(child);
				}
			}

			return cnode;
		}
};

/*************************** Octree *************************/
class OctreeNode
{
	private:
		vector<PointN*> dat_;
	public:	
		OctreeNode* child_[8];
		void SetInputCloud(vector<PointN*>& idata){
			dat_=idata;
		}
		PointN* GetCentroid(){
			PointN* centroid;
			for(int i=0; i<dat_.size(); i++){
				centroid->dat_[0]+=dat_[i]->dat_[0];
				centroid->dat_[1]+=dat_[i]->dat_[1];
				centroid->dat_[2]+=dat_[i]->dat_[2];
			}
			centroid->dat_[0]=centroid->dat_[0]/dat_.size();
			centroid->dat_[1]=centroid->dat_[1]/dat_.size();
			centroid->dat_[2]=centroid->dat_[2]/dat_.size();
			return centroid;
		}
};

class gOctree{
	public:
		OctreeNode* root_;
		vector<PointN*> dat_;

		void BuildOctree();
		void SetInputCloud(vector<vector<float>> idata);

	private:
		OctreeNode* CreateOctree(vector<PointN*>& idata);
};


/**************************************************************
 * 
 **************************************************************/
tuple<int, float, float> Poly2Solve(float a, float b, float c);


/************************************************************* 
 * Surface Fitting
**************************************************************/
class SurfaceFitting
{
    public:
        vector<vector<float>> pts_;
		AABB* bb_;
};

class Poly33Fitting: public SurfaceFitting
{
    public:
        float p00_, p10_, p01_, p20_, p11_, p02_, p30_, p21_, p12_, p03_;        
        void Fit(vector<vector<float>> pts);
		int IsIntersect(Ray ry);
};

class Poly22Fitting: public SurfaceFitting
{
	public:
		float p00_, p10_, p01_, p20_, p11_, p02_;				

		/* Basic */
		void SetInputCloud(vector<vector<float>> pts);

		/* Fit  */
		void Fit_XYPlane();	
		void Fit_BestFittingPlane();				

		/* Get */
		float GetZ(float x, float y);
		vector<vector<float>> GetMesh(string path="", int num=40, float scale=1.0);
		float GetWassersteinDistance(V3 pt);	
		V3 GetFoot(V3 pt);

		/* intersect */ 
		bool IsIntersect(Ray& ry);
		bool IsIntersect(LineSegment& lseg);
		vector<V3> GetIntersect(Ray& ry);
		vector<V3> GetIntersect(LineSegment& lseg);
		bool IsWithinRange(V3 pt, float scale=0.2);
		bool IsWithinWD(V3 pt, int tensity=240, string path="");
		int WhichSide(V3 pt);
		bool IsWithin(float x, float y, float z);	

	private:
		int mode=-1;		
		MatrixXd R_, T_;		
		MatrixXd D_tf_nx3_;
		int flag_is_intersect_with_ray_computed_=0;
		int flag_is_intersect_wity_line_segment_computed_=0;
		int num_of_itsc_=0;
		float t1_, t2_;
		V3 itsc1_, itsc2_;
		void ComputeIntersect(Ray& ry);
		void ComputeIntersect(LineSegment& lseg);
		V3 ComputeFoot(V3 pt);
		MatrixXd Transform_3x1(MatrixXd pt);
		MatrixXd Transform_1x3(MatrixXd pt);
		MatrixXd InverseTransform_3x1(MatrixXd pt_tf);
		MatrixXd InverseTransform_1x3(MatrixXd pt_tf);
};