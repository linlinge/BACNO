#include <Geometry.h>


int PointN::key_counter_=-1;

/* Plane Fitting */
#include <CGAL/Simple_cartesian.h>
#include <CGAL/linear_least_squares_fitting_3.h>
typedef CGAL::Simple_cartesian<float>::Plane_3  		CGAL_Plane;
typedef CGAL::Simple_cartesian<float>::Point_3         CGAL_Point;

/*********************************************** PointN ************************************************/
PointN::PointN(vector<float> dat){
	key_=(++key_counter_);
	dat_=dat;
}


/************************************************ Ray *************************************************/
Ray::Ray(V3 dat1, V3 dat2, LineInitType mode=point_with_direction)
{
	switch(mode)
	{
		case point_with_direction: // represent line with point and direction
			origin_=dat1;
			direction_=dat2;
			direction_.Normalize();
			break;
			
		case point_to_point: // represent line with two points
			origin_=dat1;
			direction_=dat2-dat1;
			direction_.Normalize();
			break;
	} 
}

V3 Ray::IsIntersect(Plane& dat)
{
	float t = -(dat.A_*origin_.x + dat.B_*origin_.y + dat.C_*origin_.z + dat.D_) / (dat.A_*direction_.x + dat.B_*direction_.y + dat.C_*direction_.z);
	return V3(direction_.x * t + origin_.x, direction_.y * t + origin_.y, direction_.z * t + origin_.z);
}

/**
 * @brief 
 * 
 * @param a 
 * @return (bool) whether intersect, (float) distance to AABB
 */
tuple<bool, float> Ray::IsIntersect(AABB a)
{
    float tmin = 0.0f;
	float tmax = 1000000.0f;
 
	//The plane perpendicular to x-axie
	if(abs(direction_.x) < 0.000001f) //If the ray parallel to the plane
	{
		//If the ray is not within AABB box, then not intersecting
		if(origin_.x < a.bmin_.x || origin_.x > a.bmax_.x)			
			return make_tuple(false, INT_MAX);
	}
	else
	{
		//Compute the distance of ray to the near plane and far plane
		float ood = 1.0f / direction_.x;
		float t1 = (a.bmin_.x - origin_.x) * ood;
		float t2 = (a.bmax_.x - origin_.x) * ood;
 
		//Make t1 be intersecting with the near plane, t2 with the far plane
		if(t1 > t2)
		{
			float temp = t1;
			t1 = t2;
			t2 = temp;
		}
 
		//Compute the intersection of slab intersection intervals
		if(t1 > tmin) tmin = t1;
		if(t2 < tmax) tmax = t2;
 
		//Exit with no collision as soon as slab intersection becomes empty
		if(tmin > tmax) return make_tuple(false,INT_MAX);
	}// end for perpendicular to x-axie
 
	//The plane perpendicular to y-axie
	if(abs(direction_.y) < 0.000001f) //If the ray parallel to the plane
	{
		//If the ray is not within AABB box, then not intersecting
		if(origin_.y < a.bmin_.y || origin_.y > a.bmax_.y)
			return make_tuple(false, INT_MAX);
	}
	else
	{
		//Compute the distance of ray to the near plane and far plane
		float ood = 1.0f / direction_.y;
		float t1 = (a.bmin_.y - origin_.y) * ood;
		float t2 = (a.bmax_.y - origin_.y) * ood;
 
		//Make t1 be intersecting with the near plane, t2 with the far plane
		if(t1 > t2)
		{
			float temp = t1;
			t1 = t2;
			t2 = temp;
		}
 
		//Compute the intersection of slab intersection intervals
		if(t1 > tmin) tmin = t1;
		if(t2 < tmax) tmax = t2;
 
		//Exit with no collision as soon as slab intersection becomes empty
		if(tmin > tmax) return make_tuple(false, INT_MAX);
	}// end for perpendicular to y-axie
 
	//The plane perpendicular to z-axie
	if(abs(direction_.z) < 0.000001f) //If the ray parallel to the plane
	{
		//If the ray is not within AABB box, then not intersecting
		if(origin_.z < a.bmin_.z || origin_.z > a.bmax_.z)
			return make_tuple(false, INT_MAX);
	}
	else
	{
		//Compute the distance of ray to the near plane and far plane
		float ood = 1.0f / direction_.z;
		float t1 = (a.bmin_.z - origin_.z) * ood;
		float t2 = (a.bmax_.z - origin_.z) * ood;
 
		//Make t1 be intersecting with the near plane, t2 with the far plane
		if(t1 > t2)
		{
			float temp = t1;
			t1 = t2;
			t2 = temp;
		}
 
		//Compute the intersection of slab intersection intervals
		if(t1 > tmin) tmin = t1;
		if(t2 < tmax) tmax = t2;
 
		//Exit with no collision as soon as slab intersection becomes empty
		if(tmin > tmax) return make_tuple(false, INT_MAX);
	}
	// end for perpendicular to z-axie
    
    V3 vcHit;
	if(IS_BETWEEN(origin_.x,a.bmin_.x,a.bmax_.x) && IS_BETWEEN(origin_.y,a.bmin_.y,a.bmax_.y) && IS_BETWEEN(origin_.z,a.bmin_.z,a.bmax_.z)){
		vcHit.x = origin_.x + tmax * direction_.x;
		vcHit.y = origin_.y + tmax * direction_.y;
		vcHit.z = origin_.z + tmax * direction_.z;
		return make_tuple(true, tmax);
	}
	else{
		vcHit.x = origin_.x + tmin * direction_.x;
		vcHit.y = origin_.y + tmin * direction_.y;
		vcHit.z = origin_.z + tmin * direction_.z;
		return make_tuple(true, tmin);
	}	
	// return true;
}

tuple<int,vector<float>> Ray::IsIntersect(Triangle obj)
{
	auto [num_of_itsc, itsc]=obj.IsIntersect(*this);
	return make_tuple(num_of_itsc,itsc);
}

V3 Ray::GetProjectionVector(ProjectionType mode)
{
	if(mode==XY)
	{
		return V3(direction_.x, direction_.y, 0);
	}
	else if(mode==XZ)
	{
		return V3(direction_.x, 0, direction_.z);
	}
	else if(mode==YZ)
	{
		return V3(0, direction_.y, direction_.z);
	}
	else{
		cout<<"Geometry.cpp -> GetProjectionVector error!"<<endl;
		return V3(-1, -1, -1);
	}
}

float Ray::GetProjectionArc(ProjectionType mode)
{
	if(mode==XY)
	{
		return atan(direction_.z/sqrt(pow(direction_.x,2)+pow(direction_.y,2)));
	}
	else if(mode==XZ)
	{
		return atan(direction_.y/sqrt(pow(direction_.x,2)+pow(direction_.z,2)));
	}
	else if(mode==YZ)
	{
		return atan(direction_.x/sqrt(pow(direction_.y,2)+pow(direction_.z,2)));
	}
	else{
		cout<<"Geometry.cpp -> GetProjectionArc error!"<<endl;
		return -1;
	}
}

V3 Ray::TransformTo(ProjectionType mode)
{
	if(mode==XY)
	{
		return GetProjectionVector(XY).Normalize()*direction_.GetLength() + origin_;
	} 
	else if(mode == YZ)
	{
		return GetProjectionVector(YZ).Normalize()*direction_.GetLength() + origin_;
	}
	else if(mode == XZ)
	{
		return GetProjectionVector(XZ).Normalize()*direction_.GetLength() + origin_;
	}
	else{
		cout<<"Geometry.cpp -> TransformTo"<<endl;
		return V3(-1, -1, -1);
	}
}

Ray Ray::operator=(Ray obj){
	origin_=obj.origin_;
	direction_=obj.direction_;
	return *this;
}

/**************************************** Line ***************************************/
Line::Line(V3 e1, V3 e2, int mode)
{
	if(mode==point_with_direction){
		origin_=e1;
		direction_=e2;	
		direction_.Normalize();
	}
	else if(mode==point_to_point){
		origin_=e1;
		direction_=e2-e1;
		t_o2e_=direction_.GetLength();
		direction_.Normalize();
	}
	else
		cout<<"Error: line mode error!"<<endl;	
}

float Line::GetDistTo(V3 pt)
{	
	auto [xo, yo, zo]=origin_.GetElements();
	auto [xn, yn, zn]=direction_.GetElements();
	auto [xa, ya, za]=pt.GetElements();
	t_itsc_=- (xo*xn - xa*xn + yo*yn - ya*yn + zo*zn - za*zn)/(xn*xn+yn*yn+zn*zn);
	float dist= sqrt(pow(xo + t_itsc_*xn - xa, 2) + pow(yo + t_itsc_*yn - ya, 2) + pow(zo + t_itsc_*zn - za, 2));
	return dist;
}

V3 Line::GetItsc(V3 pt)
{
	auto [xo, yo, zo]=origin_.GetElements();
	auto [xn, yn, zn]=direction_.GetElements();
	auto [xa, ya, za]=pt.GetElements();
	t_itsc_=- (xo*xn - xa*xn + yo*yn - ya*yn + zo*zn - za*zn)/(xn*xn+yn*yn+zn*zn);
	V3 itsc= origin_ + t_itsc_*direction_;
	return itsc;
}

tuple<V3, float> Line::GetItscAndDist(V3 pt)
{
	auto [xo, yo, zo]=origin_.GetElements();
	auto [xn, yn, zn]=direction_.GetElements();
	auto [xa, ya, za]=pt.GetElements();
	t_itsc_=- (xo*xn - xa*xn + yo*yn - ya*yn + zo*zn - za*zn)/(xn*xn+yn*yn+zn*zn);
	V3 itsc= origin_ + t_itsc_*direction_;
	float dist= itsc.EuclideanDistance(pt);
	return make_tuple(itsc, dist);
}

/**************************************** Line Segment ***************************************/
LineSegment::LineSegment(V3 origin, V3 end)
{
	origin_=origin;
	end_=end;
	direction_=(end_-origin_).Normalize();
	t_o2e_=(end_-origin_).GetLength();
}

/**
 * @brief 
 * 
 * @param a 
 * @return (bool) whether intersect, (float) distance to AABB
 */
tuple<bool, float> LineSegment::IsIntersect(AABB* idata)
{
	if(IS_BETWEEN(origin_.x, idata->bmin_.x, idata->bmax_.x) && 
	   IS_BETWEEN(origin_.y, idata->bmin_.y, idata->bmax_.y) &&
	   IS_BETWEEN(origin_.z, idata->bmin_.z, idata->bmax_.z))
	   return make_tuple(true, -INT_MAX);
	
	if(IS_BETWEEN(end_.x, idata->bmin_.x, idata->bmax_.x) && 
	   IS_BETWEEN(end_.y, idata->bmin_.y, idata->bmax_.y) &&
	   IS_BETWEEN(end_.z, idata->bmin_.z, idata->bmax_.z))
	   return make_tuple(true, -INT_MAX);


    float tmin = 0.0f;
	float tmax = 1000000.0f;
 
	//The plane perpendicular to x-axie
	if(abs(direction_.x) < 0.000001f) //If the ray parallel to the plane
	{
		//If the ray is not within AABB box, then not intersecting
		if(origin_.x < idata->bmin_.x || origin_.x > idata->bmax_.x)			
			return make_tuple(false, INT_MAX);
	}
	else
	{
		//Compute the distance of ray to the near plane and far plane
		float ood = 1.0f / direction_.x;
		float t1 = (idata->bmin_.x - origin_.x) * ood;
		float t2 = (idata->bmax_.x - origin_.x) * ood;
 
		//Make t1 be intersecting with the near plane, t2 with the far plane
		if(t1 > t2)
		{
			float temp = t1;
			t1 = t2;
			t2 = temp;
		}
 
		//Compute the intersection of slab intersection intervals
		if(t1 > tmin) tmin = t1;
		if(t2 < tmax) tmax = t2;
 
		//Exit with no collision as soon as slab intersection becomes empty
		if(tmin > tmax) return make_tuple(false,INT_MAX);
	}// end for perpendicular to x-axie
 
	//The plane perpendicular to y-axie
	if(abs(direction_.y) < 0.000001f) //If the ray parallel to the plane
	{
		//If the ray is not within AABB box, then not intersecting
		if(origin_.y < idata->bmin_.y || origin_.y > idata->bmax_.y)
			return make_tuple(false, INT_MAX);
	}
	else
	{
		//Compute the distance of ray to the near plane and far plane
		float ood = 1.0f / direction_.y;
		float t1 = (idata->bmin_.y - origin_.y) * ood;
		float t2 = (idata->bmax_.y - origin_.y) * ood;
 
		//Make t1 be intersecting with the near plane, t2 with the far plane
		if(t1 > t2)
		{
			float temp = t1;
			t1 = t2;
			t2 = temp;
		}
 
		//Compute the intersection of slab intersection intervals
		if(t1 > tmin) tmin = t1;
		if(t2 < tmax) tmax = t2;
 
		//Exit with no collision as soon as slab intersection becomes empty
		if(tmin > tmax) return make_tuple(false, INT_MAX);
	}// end for perpendicular to y-axie
 
	//The plane perpendicular to z-axie
	if(abs(direction_.z) < 0.000001f) //If the ray parallel to the plane
	{
		//If the ray is not within AABB box, then not intersecting
		if(origin_.z < idata->bmin_.z || origin_.z > idata->bmax_.z)
			return make_tuple(false, INT_MAX);
	}
	else
	{
		//Compute the distance of ray to the near plane and far plane
		float ood = 1.0f / direction_.z;
		float t1 = (idata->bmin_.z - origin_.z) * ood;
		float t2 = (idata->bmax_.z - origin_.z) * ood;
 
		//Make t1 be intersecting with the near plane, t2 with the far plane
		if(t1 > t2)
		{
			float temp = t1;
			t1 = t2;
			t2 = temp;
		}
 
		//Compute the intersection of slab intersection intervals
		if(t1 > tmin) tmin = t1;
		if(t2 < tmax) tmax = t2;
 
		//Exit with no collision as soon as slab intersection becomes empty
		if(tmin > tmax) return make_tuple(false, INT_MAX);
	}
	// end for perpendicular to z-axie
    
    V3 vcHit;
	if(IS_BETWEEN(origin_.x,idata->bmin_.x,idata->bmax_.x) && 
	   IS_BETWEEN(origin_.y,idata->bmin_.y,idata->bmax_.y) && 
	   IS_BETWEEN(origin_.z,idata->bmin_.z,idata->bmax_.z)){
		vcHit.x = origin_.x + tmax * direction_.x;
		vcHit.y = origin_.y + tmax * direction_.y;
		vcHit.z = origin_.z + tmax * direction_.z;
		
		if(tmax<=t_o2e_)
			return make_tuple(true, tmax);
		else 
			return make_tuple(false, INT_MAX);
	}
	else{
		vcHit.x = origin_.x + tmin * direction_.x;
		vcHit.y = origin_.y + tmin * direction_.y;
		vcHit.z = origin_.z + tmin * direction_.z;

		if(tmin<=t_o2e_)
			return make_tuple(true, tmin);
		else 	
			return make_tuple(false,INT_MAX);
	}	
	// return true;
}

/***************************************  Axis-aligned bounding box ********************************************/
AABB::AABB(V3 bmin, V3 bmax){
	bmin_=bmin;
	bmax_=bmax;
}

AABB::AABB(V3 center, float semi_width)
{
	bmin_ = V3(center.x - semi_width, center.y - semi_width, center.z - semi_width);
	bmax_ = V3(center.x + semi_width, center.y + semi_width, center.z + semi_width);
}

AABB::AABB(vector<vector<float>> pts)
{
	bmin_=V3(INT_MAX, INT_MAX, INT_MAX);
	bmax_=V3(-INT_MAX, -INT_MAX, -INT_MAX);

	for(int i=0; i< pts.size(); i++){
		bmin_.x= bmin_.x < pts[i][0] ? bmin_.x : pts[i][0];
		bmin_.y= bmin_.y < pts[i][1] ? bmin_.y : pts[i][1];
		bmin_.z= bmin_.z < pts[i][2] ? bmin_.z : pts[i][2];

		bmax_.x= bmax_.x > pts[i][0] ? bmax_.x : pts[i][0];
		bmax_.y= bmax_.y > pts[i][1] ? bmax_.y : pts[i][1];
		bmax_.z= bmax_.z > pts[i][2] ? bmax_.z : pts[i][2];
	}
}

V3 AABB::GetCentre()
{
	return V3((bmin_.x+bmax_.x)/2.0, (bmin_.y+bmax_.y)/2.0, (bmin_.z+bmax_.z)/2.0);
}

bool AABB::IsWithin(V3 pt)
{
    if((pt.x> bmin_.x) && (pt.x< bmax_.x) &&
       (pt.y> bmin_.y) && (pt.y< bmax_.y) && 
       (pt.z> bmin_.z) && (pt.z< bmax_.z)){
        return true;
    }
    else 
        return false;
}

bool AABB::IsWithin(float x, float y, float z)
{
	int count=0;
	if(IS_BETWEEN(x, bmin_.x, bmax_.x)) count++;
	if(IS_BETWEEN(y, bmin_.y, bmax_.y)) count++;
	if(IS_BETWEEN(z, bmin_.z, bmax_.z)) count++;

	if(count==3)
		return true;
	else 
		return false;
}

vector<vector<float>> AABB::GenerateEightCorners(){    
    if(corners_.size()==0){
        corners_.resize(8); 
        corners_[0].push_back(bmin_.x);
        corners_[0].push_back(bmin_.y);
        corners_[0].push_back(bmin_.z);

        corners_[1].push_back(bmin_.x);
        corners_[1].push_back(bmax_.y);
        corners_[1].push_back(bmin_.z);

        corners_[2].push_back(bmax_.x);
        corners_[2].push_back(bmax_.y);
        corners_[2].push_back(bmin_.z);

        corners_[3].push_back(bmax_.x);
        corners_[3].push_back(bmin_.y);
        corners_[3].push_back(bmin_.z);

        corners_[4].push_back(bmin_.x);
        corners_[4].push_back(bmin_.y);
        corners_[4].push_back(bmax_.z);

        corners_[5].push_back(bmin_.x);
        corners_[5].push_back(bmax_.y);
        corners_[5].push_back(bmax_.z);

        corners_[6].push_back(bmax_.x);
        corners_[6].push_back(bmax_.y);
        corners_[6].push_back(bmax_.z);

        corners_[7].push_back(bmax_.x);
        corners_[7].push_back(bmin_.y);
        corners_[7].push_back(bmax_.z);
    }       
    return corners_;   
}


vector<vector<int>> AABB::GenerateSelfLines()
{
	vector<vector<int>> lines_by_self_id;

	lines_by_self_id.resize(12);
	// line 0
	lines_by_self_id[0].push_back(0);
	lines_by_self_id[0].push_back(1);
	// line 1
	lines_by_self_id[1].push_back(1);
	lines_by_self_id[1].push_back(2);
	// line 2
	lines_by_self_id[2].push_back(2);
	lines_by_self_id[2].push_back(3);
	// line 3
	lines_by_self_id[3].push_back(3);
	lines_by_self_id[3].push_back(0);
	// line 4
	lines_by_self_id[4].push_back(4);
	lines_by_self_id[4].push_back(5);
	// line 5
	lines_by_self_id[5].push_back(5);
	lines_by_self_id[5].push_back(6);
	// line 6
	lines_by_self_id[6].push_back(6);
	lines_by_self_id[6].push_back(7);
	// line 7
	lines_by_self_id[7].push_back(7);
	lines_by_self_id[7].push_back(4);
	// line 8
	lines_by_self_id[8].push_back(4);
	lines_by_self_id[8].push_back(0);
	// line 9
	lines_by_self_id[9].push_back(5);
	lines_by_self_id[9].push_back(1);
	// line 10
	lines_by_self_id[10].push_back(6);
	lines_by_self_id[10].push_back(2);
	// line 11
	lines_by_self_id[11].push_back(7);
	lines_by_self_id[11].push_back(3);  

    return lines_by_self_id;    
}

AABB* UnionAABB(AABB* idata1, AABB* idata2)
{
	AABB* odata= new AABB();
	odata->bmin_.x= idata1->bmin_.x < idata2->bmin_.x ? idata1->bmin_.x : idata2->bmin_.x;
	odata->bmin_.y= idata1->bmin_.y < idata2->bmin_.y ? idata1->bmin_.y : idata2->bmin_.y;
	odata->bmin_.z= idata1->bmin_.z < idata2->bmin_.z ? idata1->bmin_.z : idata2->bmin_.z;

	odata->bmax_.x= idata1->bmax_.x > idata2->bmax_.x ? idata1->bmax_.x : idata2->bmax_.x;
	odata->bmax_.y= idata1->bmax_.y > idata2->bmax_.y ? idata1->bmax_.y : idata2->bmax_.y;
	odata->bmax_.z= idata1->bmax_.z > idata2->bmax_.z ? idata1->bmax_.z : idata2->bmax_.z;
	return odata;
}


/********************************************  Plane *****************************************/
Plane::Plane(float a, float b, float c, float d)
{
	A_=a;
	B_=b;
	C_=c;
	D_=d;
}
Plane::Plane(V3 P1, V3 P2, V3 P3)
{
	A_ = (P2.y - P1.y)*(P3.z - P1.z) - (P3.y - P1.y)*(P2.z - P1.z);
	B_ = (P2.z - P1.z)*(P3.x - P1.x) - (P3.z - P1.z)*(P2.x - P1.x);
	C_ = (P2.x - P1.x)*(P3.y - P1.y) - (P3.x - P1.x)*(P2.y - P1.y);
	D_ = -A_ * P1.x - B_ * P1.y - C_ * P1.z;
}

Plane::Plane(V3 pt_on_plane, V3 normal)
{
	normal.Normalize();
	A_=normal.x;
	B_=normal.y;
	C_=normal.z;
	D_=-(A_*pt_on_plane.x+B_*pt_on_plane.y+C_*pt_on_plane.z);
}

Plane::Plane(vector<vector<float>>& pts)
{	
	std::vector<CGAL_Point> cgal_pts;
	for(int i=0; i<pts.size();i++){
		CGAL_Point ptmp(pts[i][0],pts[i][1],pts[i][2]);
		cgal_pts.push_back(ptmp);
	}
	CGAL_Plane cgal_plane;
	linear_least_squares_fitting_3(cgal_pts.begin(),cgal_pts.end(), cgal_plane, CGAL::Dimension_tag<0>());
	A_=cgal_plane.a();
	B_=cgal_plane.b();
	C_=cgal_plane.c();
	D_=cgal_plane.d();


	// MatrixXf P(3,3);
	// MatrixXf b(3,1);
	// for(int i=0; i<pts.size(); i++){
	// 	P(0,0)=P(0,0)+pts[i][0]*pts[i][0];
	// 	P(0,1)=P(0,1)+pts[i][0]*pts[i][1];
	// 	P(0,2)=P(0,2)+pts[i][0];
	// 	P(1,0)=P(0,1);
	// 	P(1,1)=P(1,1)+pts[i][1]*pts[i][1];
	// 	P(1,2)=P(1,2)+pts[i][1];
	// 	P(2,0) = P(0,2);
	// 	P(2,1) = P(1,2);
	// 	P(2,2) = pts.size();

	// 	b(0,0)=b(0,0)+pts[i][0]*pts[i][2];
    // 	b(1,0)=b(1,0)+pts[i][1]*pts[i][2];
    // 	b(2,0)=b(2,0)+pts[i][2];
	// } 

	// MatrixXf X=P.inverse()*b;
	// A_=X(0,0);
	// B_=X(1,0);
	// C_=-1;
	// D_=X(2,0);

	// float nrm=sqrt(A_*A_+B_*B_+C_*C_);
	// A_=A_/nrm;
	// B_=B_/nrm;
	// C_=C_/nrm;
	// D_=D_/nrm;PointType
}

void Plane::SetInputCloud(vector<vector<float>>& pts)
{
	std::vector<CGAL_Point> cgal_pts;
	for(int i=0; i<pts.size();i++){
		CGAL_Point ptmp(pts[i][0],pts[i][1],pts[i][2]);
		cgal_pts.push_back(ptmp);
	}
	CGAL_Plane cgal_plane;
	linear_least_squares_fitting_3(cgal_pts.begin(),cgal_pts.end(), cgal_plane, CGAL::Dimension_tag<0>());
	A_=cgal_plane.a();
	B_=cgal_plane.b();
	C_=cgal_plane.c();
	D_=cgal_plane.d();
}

bool Plane::IsIntersect(Ray& ry)
{	
	ComputeIntersect(ry);
	if(t_>=0)
		return true;
	else
		return false;
}

V3 Plane::GetIntersect(Ray& ry)
{	
	ComputeIntersect(ry);
	return intersect_point_;
}

void Plane::ComputeIntersect(Ray& dat)
{
	if(flag_is_intersect_with_ray_computed_==0){
		t_ = -(A_*dat.origin_.x + B_ * dat.origin_.y + C_ * dat.origin_.z + D_) / 
			 (A_*dat.direction_.x + B_ * dat.direction_.y + C_ * dat.direction_.z);
		intersect_point_=V3(dat.direction_.x * t_ + dat.origin_.x, dat.direction_.y * t_ + dat.origin_.y, dat.direction_.z * t_ + dat.origin_.z);
	}
}

bool Plane::IsIntersect(LineSegment& lseg)
{
	ComputeIntersect(lseg);
	if(t_<0 | t_>lseg.t_o2e_){
		return false;
	}
	else{
		return true;
	}
}

V3 Plane::GetIntersect(LineSegment& lseg)
{
	ComputeIntersect(lseg);
	return intersect_point_;
}

void Plane::ComputeIntersect(LineSegment& lseg)
{
	if(flag_is_intersect_with_line_segment_computed_==0){
		t_ = -(A_*lseg.origin_.x + B_ * lseg.origin_.y + C_ * lseg.origin_.z + D_) / 
			 (A_*lseg.direction_.x + B_ * lseg.direction_.y + C_ * lseg.direction_.z);
		intersect_point_=V3(lseg.direction_.x * t_ + lseg.origin_.x, lseg.direction_.y * t_ + lseg.origin_.y, lseg.direction_.z * t_ + lseg.origin_.z);
	}
}

bool Plane::IsIntersect(AABB* bb)
{	
	int s0=SignToPlane(bb->bmin_); 	
	int s1=SignToPlane(V3(bb->bmin_.x, bb->bmax_.y, bb->bmin_.z));
	if(s0!=s1)
		return true;
		
	int s2=SignToPlane(V3(bb->bmax_.x, bb->bmax_.y, bb->bmin_.z));
	if(s1!=s2)
		return true;
	
	int s3=SignToPlane(V3(bb->bmax_.x, bb->bmin_.y, bb->bmin_.z));
	if(s2!=s3)
		return true;
	
	int s4=SignToPlane(V3(bb->bmin_.x, bb->bmin_.y, bb->bmax_.z));
	if(s3!=s4)
		return true;
	
	int s5=SignToPlane(V3(bb->bmin_.x, bb->bmax_.y, bb->bmax_.z));
	if(s4!=s5)
		return true;
	
	int s6=SignToPlane(V3(bb->bmax_.x, bb->bmax_.y, bb->bmax_.z));
	if(s5!=s6)
		return true;
	
	int s7=SignToPlane(V3(bb->bmax_.x, bb->bmin_.y, bb->bmax_.z));
	if(s6!=s7)
		return true;
	
	return false;
}

float Plane::Apply(float x, float y)
{
	return (A_*x+B_*y+D_)/(-C_);
}

float Plane::Distance(V3 pt)
{
	float numerator= abs(A_*pt.x + B_*pt.y + C_*pt.z + D_);
	float denominator=sqrt(A_*A_+B_*B_+C_*C_);
	return numerator/denominator;
}

int Plane::SignToPlane(V3 pt)
{
	int numeric=  (A_*pt.x + B_*pt.y + C_*pt.z + D_) >0 ? 1:-1;	
	return numeric;
}

/*************************************** Line Segment ******************************************/
tuple<bool,vector<float>> LineSegment::IsIntersect(Triangle ob)
{
	auto [whether, itsc]=ob.IsIntersect(*this);
	return make_tuple(whether, itsc);
}

/*************************************** Triangle ******************************************/
tuple<int,vector<float>> Triangle::IsIntersect(Ray ry)
{
	float kEpsilon=0.0000000001;
	float t;
	V3 itsc;

	// compute plane's normal
    V3 v0_1 = vtx_[1] - vtx_[0]; 
    V3 v0_2 = vtx_[2] - vtx_[0]; 

    // no need to normalize
    V3 N = v0_1.Cross(v0_2);  //N 
    float area2 = N.GetLength(); 
 
    /*********************************************************** 
	 * Step 1: finding P 
	 * *********************************************************/
    // check if ray and plane are parallel ?
    float NdotRayDirection = N.Dot(ry.direction_); 
    if (fabs(NdotRayDirection) < kEpsilon)  //almost 0 
		return make_tuple(0, itsc.ToFloat());  //they are parallel so they don't intersect !         
 
    // compute d parameter using equation 2
    float d = -N.Dot(vtx_[0]); 
 
    // compute t (equation 3)
    t = -(N.Dot(ry.origin_) + d) / NdotRayDirection; 
	itsc=ry.origin_+t*ry.direction_;

 
    // check if the triangle is in behind the ray
    if (t < 0) return make_tuple(0, itsc.ToFloat());  //the triangle is behind 
 
    // compute the intersection point using equation 1
    V3 P = ry.origin_ + t * ry.direction_; 
 

    /*************************************************************
	 *  Step 2: inside-outside test
	 * ***********************************************************/
    V3 C;  //vector perpendicular to triangle's plane 
 
    // edge 0
    V3 edge0 = vtx_[1] - vtx_[0]; 
    V3 vp0 = P - vtx_[0]; 
    C = edge0.Cross(vp0); 
    if (N.Dot(C) < 0) return make_tuple(0, itsc.ToFloat());  //P is on the right side 
 
    // edge 1
    V3 edge1 = vtx_[2] - vtx_[1]; 
    V3 vp1 = P - vtx_[1]; 
    C = edge1.Cross(vp1); 
    if (N.Dot(C) < 0)  return make_tuple(0, itsc.ToFloat());  //P is on the right side 
 
    // edge 2
    V3 edge2 = vtx_[0] - vtx_[2]; 
    V3 vp2 = P - vtx_[2]; 
    C = edge2.Cross(vp2); 
    if (N.Dot(C) < 0) return make_tuple(0, itsc.ToFloat());  //P is on the right side; 
 
    return make_tuple(1, itsc.ToFloat());  //this ray hits the triangle 
}

Triangle::Triangle(V3 v0, V3 v1, V3 v2){
	vtx_[0]=v0;
	vtx_[1]=v1;
	vtx_[2]=v2;
}
Triangle::Triangle(vector<vector<float>> pts){
	vtx_[0]=V3(pts[0]);
	vtx_[1]=V3(pts[1]);
	vtx_[2]=V3(pts[2]);
}
Triangle Triangle::operator=(Triangle dat){
	vtx_[0]=dat.vtx_[0];
	vtx_[1]=dat.vtx_[1];
	vtx_[2]=dat.vtx_[2];
	return *this;
}
tuple<bool,vector<float>> Triangle::IsIntersect(LineSegment lseg)
{
	float kEpsilon=0.0000000001;
	float t;
	bool whether_intersect;
	V3 itsc;

	// compute plane's normal
    V3 v0_1 = vtx_[1] - vtx_[0]; 
    V3 v0_2 = vtx_[2] - vtx_[0]; 

    // no need to normalize
    V3 N = v0_1.Cross(v0_2);  //N 
    float area2 = N.GetLength(); 
 
    /*********************************************************** 
	 * Step 1: finding P 
	 * *********************************************************/
    // check if ray and plane are parallel ?
    float NdotRayDirection = N.Dot(lseg.direction_); 
    if (fabs(NdotRayDirection) < kEpsilon)  //almost 0 
		return make_tuple(false,itsc.ToFloat());  //they are parallel so they don't intersect !         
 
    // compute d parameter using equation 2
    float d = -N.Dot(vtx_[0]); 
 
    // compute t (equation 3)
    t = -(N.Dot(lseg.origin_) + d) / NdotRayDirection; 
	itsc=lseg.origin_+t*lseg.direction_;

	// check if the triangle is out of range
	if(t> lseg.t_o2e_)
		return make_tuple(false, itsc.ToFloat());

    // check if the triangle is in behind the ray
    if (t < 0) return make_tuple(false, itsc.ToFloat());  //the triangle is behind 
 
    // compute the intersection point using equation 1
    V3 P = lseg.origin_ + t * lseg.direction_; 
 

    /*************************************************************
	 *  Step 2: inside-outside test
	 * ***********************************************************/
    V3 C;  //vector perpendicular to triangle's plane 
 
    // edge 0
    V3 edge0 = vtx_[1] - vtx_[0]; 
    V3 vp0 = P - vtx_[0]; 
    C = edge0.Cross(vp0); 
	if(N.Dot(C)< 0){
		return make_tuple(false, itsc.ToFloat());  //P is on the right side 
	} 
 
    // edge 1
    V3 edge1 = vtx_[2] - vtx_[1]; 
    V3 vp1 = P - vtx_[1]; 
    C = edge1.Cross(vp1); 
    if(N.Dot(C)< 0){
		 return make_tuple(false, itsc.ToFloat());  //P is on the right side 
	}
 
    // edge 2
    V3 edge2 = vtx_[0] - vtx_[2]; 
    V3 vp2 = P - vtx_[2]; 
    C = edge2.Cross(vp2); 
    if(N.Dot(C)< 0){
		return make_tuple(false, itsc.ToFloat());  //P is on the right side; 
	}
 
    return make_tuple(true, itsc.ToFloat());  //this ray hits the triangle 
}

/************************************* Octree ****************************************/
int a=0;
void gOctree::BuildOctree(){						
	root_=CreateOctree(dat_);
}

void gOctree::SetInputCloud(vector<vector<float>> idata){
	for(int i=0; i<idata.size(); i++){
		dat_.push_back(new PointN(idata[i]));
	}			
}

OctreeNode* gOctree::CreateOctree(vector<PointN*>& idata){
	// stop recursive 
	if(idata.size()==0){
		return NULL;
	}

	OctreeNode* cnode= new OctreeNode();
	cnode->SetInputCloud(idata);
	
	set<int> xpos, xneg, ypos, yneg, zpos, zneg;
	int idx_mid=idata.size()/2;

	// x-axis
	sort(idata.begin(), idata.end(), [](PointN* e1, PointN* e2){	return e1->dat_[0] < e2->dat_[0];});
	for(int i=0; i<idata.size(); i++){
		if(i<=idx_mid){
			xneg.insert(idata[i]->key_);
		}
		else{
			xpos.insert(idata[i]->key_);
		}
	}

	// y-axis
	sort(idata.begin(), idata.end(), [](PointN* e1, PointN* e2){ return e1->dat_[1] < e2->dat_[1];});
	for(int i=0; i<idata.size(); i++){
		if(i<=idx_mid){
			yneg.insert(idata[i]->key_);
		}
		else{
			ypos.insert(idata[i]->key_);
		}
	}

	// z-axis
	sort(idata.begin(), idata.end(), [](PointN* e1, PointN* e2){	return e1->dat_[2] < e2->dat_[2];});
	for(int i=0; i<idata.size(); i++){
		if(i<=idx_mid){
			zneg.insert(idata[i]->key_);
		}
		else{
			zpos.insert(idata[i]->key_);
		}
	}


	/* mapping */
	map<int,int> mapping_from_key_to_id;
	for(int i=0; i<idata.size(); i++){
		mapping_from_key_to_id.insert(pair<int,int>(idata[i]->key_, i));
	}
	sort(idata.begin(), idata.end(), [](PointN* e1, PointN* e2){ return e1->key_ < e2->key_;});

	std::set<int> quadrant[8];
	// get the idx of first quadrant
	set<int> set_tmp0;
	std::set_intersection(xpos.begin(), xpos.end(), ypos.begin(), ypos.end(), inserter(set_tmp0, set_tmp0.begin()));
	std::set_intersection(set_tmp0.begin(), set_tmp0.end(), zpos.begin(), zpos.end(), inserter(quadrant[0], quadrant[0].begin()));

	vector<PointN*> data_quad_01;
	for(std::set<int>::iterator it=quadrant[0].begin(); it!=quadrant[0].end(); it++){
		int idx=mapping_from_key_to_id[*it];
		data_quad_01.push_back(idata[idx]);
	}
	cnode->child_[0]=CreateOctree(data_quad_01);


	// get the idx of second quadrant
	set<int> set_tmp1;
	set_intersection(xneg.begin(), xneg.end(), ypos.begin(), ypos.end(), inserter(set_tmp0, set_tmp0.begin()));
	set_intersection(set_tmp0.begin(), set_tmp0.end(), zpos.begin(), zpos.end(), inserter(quadrant[1], quadrant[1].begin()));
	vector<PointN*> data_quad_02;	
	for(auto it=quadrant[1].begin(); it!=quadrant[1].end(); it++){
		int idx=mapping_from_key_to_id[*it];
		data_quad_02.push_back(idata[idx]);
	}
	cnode->child_[1]=CreateOctree(data_quad_02);

	// get the idx of third quadrant
	set<int> set_tmp2;
	set_intersection(xneg.begin(), xneg.end(), yneg.begin(), yneg.end(), inserter(set_tmp0, set_tmp0.begin()));
	set_intersection(set_tmp0.begin(), set_tmp0.end(), zpos.begin(), zpos.end(), inserter(quadrant[2], quadrant[2].begin()));
	vector<PointN*> data_quad_03;
	for(auto it=quadrant[0].begin(); it!=quadrant[0].end(); it++){
		int idx=mapping_from_key_to_id[*it];
		data_quad_03.push_back(idata[idx]);
	}
	cnode->child_[2]=CreateOctree(data_quad_03);

	// get the idx of fourth quadrant
	set<int> set_tmp3;
	set_intersection(xpos.begin(), xpos.end(), yneg.begin(), yneg.end(), inserter(set_tmp0, set_tmp0.begin()));
	set_intersection(set_tmp0.begin(), set_tmp0.end(), zpos.begin(), zpos.end(), inserter(quadrant[3], quadrant[3].begin()));
	vector<PointN*> data_quad_04;
	for(auto it=quadrant[0].begin(); it!=quadrant[0].end(); it++){
		int idx=mapping_from_key_to_id[*it];
		data_quad_04.push_back(idata[idx]);
	}
	cnode->child_[3]=CreateOctree(data_quad_04);

	// get the idx of fifth quadrant
	set<int> set_tmp4;
	set_intersection(xpos.begin(), xpos.end(), ypos.begin(), ypos.end(), inserter(set_tmp0, set_tmp0.begin()));
	set_intersection(set_tmp0.begin(), set_tmp0.end(), zneg.begin(), zneg.end(), inserter(quadrant[4], quadrant[4].begin()));
	vector<PointN*> data_quad_05;
	for(auto it=quadrant[0].begin(); it!=quadrant[0].end(); it++){
		int idx=mapping_from_key_to_id[*it];
		data_quad_05.push_back(idata[idx]);
	}
	cnode->child_[4]=CreateOctree(data_quad_05);

	// get the idx of sixth quadrant
	set<int> set_tmp5;
	set_intersection(xneg.begin(), xneg.end(), ypos.begin(), ypos.end(), inserter(set_tmp0, set_tmp0.begin()));
	set_intersection(set_tmp0.begin(), set_tmp0.end(), zneg.begin(), zneg.end(), inserter(quadrant[5], quadrant[5].begin()));
	vector<PointN*> data_quad_06;
	for(auto it=quadrant[0].begin(); it!=quadrant[0].end(); it++){
		int idx=mapping_from_key_to_id[*it];
		data_quad_06.push_back(idata[idx]);
	}
	cnode->child_[5]=CreateOctree(data_quad_06);

	// get the idx of seventh quadrant
	set<int> set_tmp6;
	set_intersection(xneg.begin(), xneg.end(), yneg.begin(), yneg.end(), inserter(set_tmp0, set_tmp0.begin()));
	set_intersection(set_tmp0.begin(), set_tmp0.end(), zneg.begin(), zneg.end(), inserter(quadrant[6], quadrant[6].begin()));
	vector<PointN*> data_quad_07;
	for(auto it=quadrant[0].begin(); it!=quadrant[0].end(); it++){
		int idx=mapping_from_key_to_id[*it];
		data_quad_07.push_back(idata[idx]);
	}
	cnode->child_[6]=CreateOctree(data_quad_07);

	// get the idx of eighth quadrant
	set<int> set_tmp7;
	set_intersection(xpos.begin(), xpos.end(), yneg.begin(), yneg.end(), inserter(set_tmp0, set_tmp0.begin()));
	set_intersection(set_tmp0.begin(), set_tmp0.end(), zneg.begin(), zneg.end(), inserter(quadrant[7], quadrant[7].begin()));
	vector<PointN*> data_quad_08;
	for(auto it=quadrant[0].begin(); it!=quadrant[0].end(); it++){
		int idx=mapping_from_key_to_id[*it];
		data_quad_08.push_back(idata[idx]);
	}
	cnode->child_[7]=CreateOctree(data_quad_08);

	return cnode;
}



/******************************************* Line Segment *******************************************/
/**
 * @brief 
 * 
 * @param pts 
 * @param fid 
 * @return （bool) is intersect, (int) number of intersect points
 */
tuple<bool,int> LineSegment::IsIntersect(vector<vector<float>> pts, vector<vector<int>> fid)
{
	int count=0;
	vector<Triangle> tri;
	for(int i=0;i<fid.size(); i++){
		V3 v1=V3(pts[fid[i][0]][0],pts[fid[i][0]][1],pts[fid[i][0]][2]);
		V3 v2=V3(pts[fid[i][1]][0],pts[fid[i][1]][1],pts[fid[i][1]][2]);
		V3 v3=V3(pts[fid[i][2]][0],pts[fid[i][2]][1],pts[fid[i][2]][2]);
		Triangle tri_tmp(v1,v2,v3);

		// ParseObj scene_tri;
		// scene_tri.AddMesh(tri_tmp);
		// scene_tri.SaveOBJ("/home/i9/experiment_nc/scene_tri.obj");

		// ofstream fout("/home/i9/experiment_nc/scene_tri.obj");
		// fout<<"v "<<v1.x<<" "<< v1.y<<" "<< v1.z<<endl;
		// fout<<"v "<<v2.x<<" "<< v2.y<<" "<< v2.z<<endl;
		// fout<<"v "<<v3.x<<" "<< v3.y<<" "<< v3.z<<endl;
		// fout<<"f 1 2 3"<<endl;
		// fout.close();

		auto [whether, itsc]=this->IsIntersect(tri_tmp);
		if(whether==true)
			count++;
		tri.push_back(tri_tmp);
	}

	if(count==0)
		return make_tuple(false, count);
	else 
		return make_tuple(true, count);
}


float LineSegment::GetLength()
{
	return (end_ - origin_).GetLength();
}

V3 LineSegment::GetQuantile(float quantile)
{
	float t_o2t = t_o2e_*quantile; // t: from origin to target
	V3 quantile_pt= origin_ + direction_* t_o2t;
	return quantile_pt;
}

bool LineSegment::operator==(const LineSegment& dat)
{
	float dist_A2A = origin_.EuclideanDistance(dat.origin_);
	if(dist_A2A<0.001){
		float dist_B2B = end_.EuclideanDistance(dat.end_);
		if(dist_B2B<0.001){
			return true;
		}	
	}

	float dist_A2B = origin_.EuclideanDistance(dat.end_);
	if(dist_A2B<0.001){
		float dist_B2A = end_.EuclideanDistance(dat.origin_);
		if(dist_B2A<0.001){
			return true;
		}
	}
	
	return false;
}

/*******************************************************************************************
 * XOY Polynomial fitting
 * *****************************************************************************************/
void Poly33Fitting::Fit(vector<vector<float>> pts)
{
    pts_=pts;
    Eigen::MatrixXd dat(pts.size(), pts[0].size());
    Eigen::MatrixXd b(pts.size(),1);
    Eigen::MatrixXd A(pts.size(),10);
    for(int i=0; i<pts.size(); i++){
        float x=pts[i][0];
        float y=pts[i][1];
        float z=pts[i][2];
        for(int j=0; j< pts[i].size(); j++){
            dat(i,j)=pts[i][j];
        }
        b(i,0)=pts[i][2];

        A(i,0)=1;
        A(i,1)=x;
        A(i,2)=y;
        A(i,3)=x*x;
        A(i,4)=x*y;
        A(i,5)=y*y;
        A(i,6)=x*x*x;
        A(i,7)=x*x*y;
        A(i,8)=x*y*y;
        A(i,9)=y*y*y;
    }
    
    Eigen::MatrixXd P= (A.transpose()*A).inverse()*A.transpose()*b;
    p00_=P(0,0);
	p10_=P(1,0);
	p01_=P(2,0);
	p20_=P(3,0);
	p11_=P(4,0);
	p02_=P(5,0);
	p30_=P(6,0);
	p21_=P(7,0);
	p12_=P(8,0);
	p03_=P(9,0);
}

int Poly33Fitting::IsIntersect(Ray ry)
{
	float xo=ry.origin_.x;
	float yo=ry.origin_.y;
	float zo=ry.origin_.z;
	float xd=ry.direction_.x;
	float yd=ry.direction_.y;
	float zd=ry.direction_.z;
	
	float a=p30_*pow(xd,3) + p21_*pow(xd,2)*yd  + p12_*xd*pow(yd,2)   + p03_*pow(yd,3);
	float b=3*p30_*xo*pow(xd,2) + 2*p21_*xo*xd*yd  + p12_*xo*pow(yd,2) + p21_*yo*pow(xd,2) + 2*p12_*yo*xd*yd  + 3*p03_*yo*pow(yd,2) + p20_*pow(xd,2) + p11_*xd*yd + p02_*pow(yd,2);
	float c=3*p30_*pow(xo,2)*xd + p21_*pow(xo,2)*yd + 2*p21_*xo*yo*xd + 2*p12_*xo*yo*yd  + 2*p20_*xo*xd+ p11_*xo*yd+ p12_*pow(yo,2)*xd + 3*p03_*pow(yo,2)*yd 
			+ p11_*yo*xd+ 2*p02_*yo*yd+ p10_*xd+ p01_*yd -zd;
	float d=p30_*pow(xo,3) + p21_*pow(xo,2)*yo + p20_*pow(xo,2) + p12_*xo*pow(yo,2) + p11_*xo*yo+ p10_*xo + p03_*pow(yo,3)+ p02_*pow(yo,2)+ p01_*yo+ p00_ -zo;
	
	float A=pow(b,2)-3*a*c;
	float B=b*c-9*a*d;
	float C=pow(c,2)-3*b*d;
	float delta=B*B-4*A*C;

	if(A==B && A==0)
		return 3;
	else if(delta>0)
		return 1;
	else if(delta==0)
		return 3;
	else if(delta<0)
		return 3;
	else{
		cout<<"Geometry.cpp -> IsIntersect error!"<<endl;
		return -10000000;
	}
}

/*******************************************************************************************
 * Poly22 Fitting
 * *****************************************************************************************/
void Poly22Fitting::SetInputCloud(vector<vector<float>> pts)
{
	pts_=pts;
}

void Poly22Fitting::Fit_XYPlane()
{	
	/* get bounding box */
	bb_=new AABB(pts_);

	/* obtain the rotation matrix from normal to z-axis */
	MatrixXd D(pts_.size(), 3);
	for(int i=0; i< pts_.size(); i++){
		D(i,0)=pts_[i][0];
		D(i,1)=pts_[i][1];
		D(i,2)=pts_[i][2];
	}

	/* obtain coffes */
    Eigen::MatrixXd dat(pts_.size(), pts_[0].size());
    Eigen::MatrixXd b(pts_.size(),1);
    Eigen::MatrixXd A(pts_.size(),6);
    for(int i=0; i<pts_.size(); i++){
        float x=D(i,0);
        float y=D(i,1);
        float z=D(i,2);
        for(int j=0; j< pts_[i].size(); j++){
            dat(i,j)=pts_[i][j];
        }
        b(i,0)=pts_[i][2];

        A(i,0)=1;
        A(i,1)=x;
        A(i,2)=y;
        A(i,3)=x*x;
        A(i,4)=x*y;
        A(i,5)=y*y;
    }
    Eigen::MatrixXd P= (A.transpose()*A).inverse()*A.transpose()*b;
    p00_=P(0,0);
	p10_=P(1,0);
	p01_=P(2,0);
	p20_=P(3,0);
	p11_=P(4,0);
	p02_=P(5,0);

	/* */
	mode=1;
}

void Poly22Fitting::Fit_BestFittingPlane()
{
	/* step 01: get rotation and translation matrix */
    Plane pl(pts_);	

	/* step 02: translation matrix*/
	MatrixXd D(pts_.size(), 3); 		// nx3
	for(int i=0; i< pts_.size(); i++){
		D(i,0)=pts_[i][0];
		D(i,1)=pts_[i][1];
		D(i,2)=pts_[i][2];
	}
	T_=	MatrixXd::Ones(1, pts_.size())*D/pts_.size();
		
	Quaterniond trans_=Quaterniond::FromTwoVectors(Vector3d(pl.A_,pl.B_,pl.C_), Vector3d(0,0,1)); 	
	R_=trans_.toRotationMatrix();

	/* step 02: apply transfrom (Rotation + Translation) */
    MatrixXd centre_repeat_n=T_.replicate(pts_.size(), 1);
    D_tf_nx3_=(R_*(D-centre_repeat_n).transpose()).transpose();
    vector<vector<float>> pts_tf(pts_.size(), vector<float>(3));
	for(int i=0; i<pts_.size(); i++){		
		pts_tf[i][0]=D_tf_nx3_(i,0);
		pts_tf[i][1]=D_tf_nx3_(i,1);
		pts_tf[i][2]=D_tf_nx3_(i,2);		
	}
	

	/* step 03: get bounding box */
    bb_=new AABB(pts_tf);

	/* step 04: compute coefficent */
	Poly22Fitting pf_tmp; 
	pf_tmp.SetInputCloud(pts_tf);
	pf_tmp.Fit_XYPlane();
	p00_=pf_tmp.p00_;
	p10_=pf_tmp.p10_;
	p01_=pf_tmp.p01_;
	p20_=pf_tmp.p20_;
	p11_=pf_tmp.p11_;
	p02_=pf_tmp.p02_;	

	/* step 05: tag mode */
	mode=2;	
}

bool Poly22Fitting::IsIntersect(Ray& ry)
{
	ComputeIntersect(ry);
	if(num_of_itsc_>0)
		return true;
	else 
		return false;
}

vector<V3> Poly22Fitting::GetIntersect(Ray& ry)
{
	ComputeIntersect(ry);
	vector<V3> itsc;
	if(num_of_itsc_==1)
		itsc.push_back(itsc1_);
	else if(num_of_itsc_==2){
		itsc.push_back(itsc1_);
		itsc.push_back(itsc2_);
	}
	return itsc;		
}

bool Poly22Fitting::IsIntersect(LineSegment& lseg)
{
	ComputeIntersect(lseg);
	if(num_of_itsc_>0)
		return true;
	else 
		return false;
}

vector<V3> Poly22Fitting::GetIntersect(LineSegment& lseg)
{
	ComputeIntersect(lseg);
	vector<V3> itsc;
	if(num_of_itsc_==1)
		itsc.push_back(itsc1_);
	else if(num_of_itsc_==2){
		itsc.push_back(itsc1_);
		itsc.push_back(itsc2_);
	}
	return itsc;		
}



bool Poly22Fitting::IsWithinRange(V3 pt, float scale)
{
	float Xspan= bb_->bmax_.x - bb_->bmin_.x;
	float Yspan= bb_->bmax_.y - bb_->bmin_.y;
	
	MatrixXd M_pt_tf=Transform_3x1(pt.ToMatrixXd_3x1());
	if(IS_BETWEEN(M_pt_tf(0,0), bb_->bmin_.x + scale*Xspan, bb_->bmax_.x - scale*Xspan) && 
	   IS_BETWEEN(M_pt_tf(1,0), bb_->bmin_.y + scale*Yspan, bb_->bmax_.y - scale*Yspan))
	{
		return true;
	}
	else 
		return false;
}

float Poly22Fitting::GetWassersteinDistance(V3 pt)
{
	MatrixXd pt_tf_1x3=Transform_1x3(pt.ToMatrixXd_1x3());
	MatrixXd pt_tf_nx3= pt_tf_1x3.replicate(D_tf_nx3_.rows(), 1);
	MatrixXd pt_minus_D_tf= pt_tf_nx3-D_tf_nx3_;

	float dist=0;
	for(int i=0; i< pt_minus_D_tf.rows(); i++){
		dist+= sqrt(pow(pt_minus_D_tf(i,0),2) + pow(pt_minus_D_tf(i,1),2) + pow(pt_minus_D_tf(i,2),2));		
	}
	return dist;
}


V3 Poly22Fitting::GetFoot(V3 pt)
{
	MatrixXd pt_tf=Transform_1x3(pt.ToMatrixXd_1x3());
	float xa=pt_tf(0,0);
	float ya=pt_tf(0,1);
	float za=pt_tf(0,2);

	float xf= (p01_*p11_ - 2*p02_*p10_)/(- p11_*p11_ + 4*p02_*p20_);
	float yf= -(2*p01_*p20_ - p10_*p11_)/(- p11_*p11_ + 4*p02_*p20_);
	float zf= -(p20_*p01_*p01_ - p01_*p10_*p11_ + p02_*p10_*p10_ + p00_*p11_*p11_ - 4*p00_*p02_*p20_)/(- p11_*p11_ + 4*p02_*p20_);
	V3 foot_tf(xf, yf, zf);
	MatrixXd m_foot=InverseTransform_1x3(foot_tf.ToMatrixXd_1x3());
	return V3(m_foot(0,0), m_foot(0,1), m_foot(0,2));
}

/**
 * Whether projection is near 
 * @tensity: Greater values lead to greater expansion
*/
bool Poly22Fitting::IsWithinWD(V3 pt, int tensity, string path)
{
	// ofstream fout("/home/i9/experiment_nc/DTU/Result/D_tf.xyz");
	// fout<<D_tf_nx3_<<endl;
	// fout.close();


	MatrixXd pt_tf= Transform_1x3(pt.ToMatrixXd_1x3());
	// cout<<pt_tf<<endl;


	// fout.open("/home/i9/experiment_nc/DTU/Result/pt_tf.xyz");
	// fout<<pt_tf<<endl;
	// fout.close();

	vector<float> datX, datY;
	for(int i=0; i<D_tf_nx3_.rows(); i++){
		datX.push_back(D_tf_nx3_(i,0));
		datY.push_back(D_tf_nx3_(i,1));
	}

	HeatMap ht;
	ht.SetInputData(datX, datY);
	ht.GenerateHeatMap(tensity);
	bool is_within=ht.IsWithin(pt_tf(0,0), pt_tf(0,1), path);
	return is_within;
}

int Poly22Fitting::WhichSide(V3 pt)
{
	MatrixXd m_pt_tf=Transform_1x3(pt.ToMatrixXd_1x3());
	float z=GetZ(m_pt_tf(0,0), m_pt_tf(0,1));
	if(m_pt_tf(0,2)<z){
		return 1;
	}
	else 
		return -1;
}

MatrixXd Poly22Fitting::Transform_3x1(MatrixXd pt)
{
	MatrixXd pt_tf= R_*(pt-T_.transpose());
	return pt_tf;
}

MatrixXd Poly22Fitting::Transform_1x3(MatrixXd pt)
{
	MatrixXd pt_tf= R_*(pt.transpose()-T_.transpose());
	return pt_tf.transpose();
}

MatrixXd Poly22Fitting::InverseTransform_3x1(MatrixXd pt_tf)
{
	MatrixXd pt= (R_.inverse() * pt_tf) + T_.transpose();
	return pt;
}

MatrixXd Poly22Fitting::InverseTransform_1x3(MatrixXd pt_tf)
{
	MatrixXd pt= (R_.inverse() * pt_tf.transpose()) + T_.transpose();
	return pt.transpose();
}

bool Poly22Fitting::IsWithin(float x, float y, float z)
{
	if(IS_BETWEEN(x, bb_->bmin_.x, bb_->bmax_.x) && 
	   IS_BETWEEN(y, bb_->bmin_.y, bb_->bmax_.y) &&
	   IS_BETWEEN(z, bb_->bmin_.z, bb_->bmax_.z))
		return true;
	else
		return false;
}

tuple<int, float, float> Poly2Solve(float a, float b, float c)
{
	int num_of_real_root=0;
	float root1,root2;
	float delta=b*b -4*a*c;
	if(delta<0){
		num_of_real_root=0;
	}
	else if(delta==0){
		num_of_real_root=1;
		root1=root2= - b/(2*a);		
	}
	else{
		num_of_real_root=2;
		float sqrt_delta=sqrt(delta);
		root1=(-b-sqrt_delta)/(2*a);
		root2=(-b+sqrt_delta)/(2*a);
	}
	return make_tuple(num_of_real_root, root1, root2);
}

vector<vector<float>> Poly22Fitting::GetMesh(string path, int num, float scale)
{
	// step 02: obtain span in xyz axis		
	float xspan=bb_->bmax_.x -bb_->bmin_.x;
	float yspan=bb_->bmax_.y -bb_->bmin_.y;		
	float xgap = xspan*(2*scale+1)/num;
	float ygap = yspan*(2*scale+1)/num;

	// step 03: obtain some points on the surfaces
	vector<float> xi,yi;
	float x_start=bb_->bmin_.x-(scale*xspan);
	float y_start=bb_->bmin_.y-(scale*yspan);
	float x_end= bb_->bmax_.x + (scale*xspan);
	float y_end= bb_->bmax_.y + (scale*yspan);
	for(int i=0; x_start + i*xgap < x_end; i++){
		xi.push_back(x_start + i*xgap);
		yi.push_back(y_start + i*ygap);
	}

	/* fitting xy plane */
	vector<vector<float>> new_pts;
	if(mode==1){				
		for(int i=0;i<xi.size(); i++){
			for(int j=0; j< yi.size(); j++){				
				new_pts.push_back({xi[i], yi[j], GetZ(xi[i], yi[j])});
			}
		}
	}
	/* best fitting plane*/
	else if(mode==2){
		MatrixXd out_pts=MatrixXd::Zero(xi.size()*yi.size(), 3);
		int k=0;
		for(int i=0;i<xi.size(); i++){
			for(int j=0; j< yi.size(); j++){
				out_pts(k,0)=xi[i];
				out_pts(k,1)=yi[j];
				out_pts(k,2)=GetZ(xi[i],yi[j]);
				k++;
			}
		}

		// MatrixXd out_pts_translation=out_pts-T_.replicate(out_pts.rows(),1);
		out_pts=(R_.inverse()*(out_pts.transpose())).transpose() + T_.replicate(out_pts.rows(),1);		
		for(int i=0; i<out_pts.rows(); i++){
			new_pts.push_back({(float)out_pts(i,0), (float)out_pts(i,1), (float)out_pts(i,2)});
		}		
	}

	return new_pts;
}

float Poly22Fitting::GetZ(float x, float y)
{
	return (p00_ + p10_*x + p01_*y + p20_*x*x + p02_*y*y +p11_*x*y);
}

void Poly22Fitting::ComputeIntersect(Ray& ry)
{
	if(flag_is_intersect_with_ray_computed_==0){		
		if(mode==1){

		}
		else if(mode==2){
			/* tansform origin and direction */
			MatrixXd o(3,1), d(3,1);
			o<< ry.origin_.x, ry.origin_.y, ry.origin_.z;
			d<< ry.direction_.x, ry.direction_.y, ry.direction_.z;
			MatrixXd o_tf= R_*(o-T_.transpose());
			MatrixXd d_tf= R_*d;
			MatrixXd e_tf= o_tf+d_tf;
			
			/*  */
			float xo, yo, zo, xd, yd, zd;
			xo=o_tf(0,0); yo=o_tf(1,0);zo=o_tf(2,0);
			xd=d_tf(0,0); yd=d_tf(1,0);zd=d_tf(2,0);
			float a=p20_*pow(xd,2) + p11_*xd*yd + p02_*pow(yd,2);
			float b=2*p20_*xd*xo + p11_*xd*yo + p10_*xd + p11_*xo*yd + 2*p02_*yd*yo + p01_*yd - zd;
			float c=p20_*pow(xo,2) + p11_*xo*yo + p10_*xo + p02_*pow(yo,2) + p01_*yo + p00_ - zo;
			float delta= b*b-4*a*c;

			if(delta<0){
				num_of_itsc_=0;
				return;
			}
			else if(delta==0){
				num_of_itsc_=1;
			}
			
				
			/* get intersect point */			
			t1_=(sqrt(delta)-b)/(2*a);	
			t2_=(-sqrt(delta)-b)/(2*a);

			if(t1_>=0 && t2_>=0){
				num_of_itsc_=2;
			}
			else if(t1_>=0 && t2_<0){
				num_of_itsc_=1;
			}
			else if(t1_<0 && t2_>=0){
				num_of_itsc_=1;
			}


			MatrixXd itsc1_tf(3,1);
			itsc1_tf<< xo+t1_*xd, yo+t1_*yd, zo+t1_*zd;
			MatrixXd itsc1= R_.inverse()*itsc1_tf + T_.transpose();	
			itsc1_= V3(itsc1(0,0), itsc1(1,0), itsc1(2,0));		

			
			MatrixXd itsc2_tf(3,1);
			itsc2_tf<<xo+t2_*xd, yo+t2_*yd, zo+t2_*zd;
			MatrixXd itsc2= R_.inverse()* itsc2_tf + T_.transpose();			
			itsc2_=V3(itsc2(0,0), itsc2(1,0), itsc2(2,0));
		}
	
		flag_is_intersect_with_ray_computed_=1;
	}
}

void Poly22Fitting::ComputeIntersect(LineSegment& lseg)
{
	num_of_itsc_=0;
	if(mode==1){

	}
	else if(mode==2){
		/* tansform origin and direction */
		MatrixXd o(3,1), e(3,1), d_tf(3,1);
		o<< lseg.origin_.x, lseg.origin_.y, lseg.origin_.z;
		e<< lseg.end_.x, lseg.end_.y, lseg.end_.z;
		MatrixXd o_tf= R_*(o-T_.transpose());			
		MatrixXd e_tf= R_*(e-T_.transpose());
		d_tf<< e_tf(0,0) - o_tf(0,0), e_tf(1,0) - o_tf(1,0), e_tf(2,0) - o_tf(2,0);
		d_tf.col(0).normalize();		
		
		/*  */
		float xo, yo, zo, xd, yd, zd;
		xo=o_tf(0,0); yo=o_tf(1,0);zo=o_tf(2,0);
		xd=d_tf(0,0); yd=d_tf(1,0);zd=d_tf(2,0);
		float a=p20_*pow(xd,2) + p11_*xd*yd + p02_*pow(yd,2);
		float b=2*p20_*xd*xo + p11_*xo*yd + p11_*xd*yo + p10_*xd  + 2*p02_*yd*yo + p01_*yd - zd;
		float c=p20_*pow(xo,2) + p11_*xo*yo + p10_*xo + p02_*pow(yo,2) + p01_*yo + p00_ - zo;
		float delta= b*b-4*a*c;

		if(delta<=0){
			num_of_itsc_=0;
			return;
		}
			
		/* get intersect point */			
		t1_=(-b + sqrt(delta))/(2*a);
		if(t1_>0 && t1_<lseg.t_o2e_){
			num_of_itsc_+=1;
		}

		t2_=(-b -sqrt(delta))/(2*a);			
		if(t2_>0 && t2_<lseg.t_o2e_){
			num_of_itsc_+=1;
		}

		MatrixXd itsc1_tf(3,1);
		itsc1_tf<< xo+t1_*xd, yo+t1_*yd, zo+t1_*zd;
		MatrixXd itsc1= R_.inverse()*itsc1_tf + T_.transpose();	
		itsc1_= V3(itsc1(0,0), itsc1(1,0), itsc1(2,0));		

		MatrixXd itsc2_tf(3,1);
		itsc2_tf<<xo+t2_*xd, yo+t2_*yd, zo+t2_*zd;
		MatrixXd itsc2= R_.inverse()* itsc2_tf +T_.transpose();			
		itsc2_=V3(itsc2(0,0), itsc2(1,0), itsc2(2,0));

		// cout<<"o_tf:      "<<o_tf.transpose()<<endl;
		// cout<<"e_tf:      "<<e_tf.transpose()<<endl;
		// cout<<"d_tf:      "<<d_tf.transpose()<<endl;
		// cout<<"itsc1_tf:  "<<itsc1_tf.transpose()<<endl;
		// cout<<"itsc2_tf:  "<<itsc2_tf.transpose()<<endl;
		// cout<<"t1:        "<<t1_<<endl;
		// cout<<"t2:        "<<t2_<<endl;
		// cout<<"t_o2e:     "<<lseg.t_o2e_<<endl;
		// cout<<"num_of_itsc"<<num_of_itsc_<<endl;

		// OBJManagerGeometricEx scene_pts;
		// scene_pts.AddPoints(itsc1_.ToFloat2D());
		// scene_pts.AddPoints(itsc2_.ToFloat2D());
		// scene_pts.SaveOBJ("/home/i9/experiment_nc/DTU/Result/pts.obj");

		// OBJManagerGeometricEx scene_lseg;
		// scene_lseg.AddLineSegment(lseg);
		// scene_lseg.SaveOBJ("/home/i9/experiment_nc/DTU/Result/lseg.obj");

		// cout<<endl<<endl;
	}

}

