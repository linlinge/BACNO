#pragma once
#include <pcl/surface/poisson.h>
#include <PCLExtend.h>
#include <vector>
#include <V3.hpp>
#include <Geometry.h>
#include <Clustering.h>
#include <LibGlobal.h>
using namespace std;

/* AABB */
#include <CGAL/Simple_cartesian.h>
#include <CGAL/AABB_tree.h>
#include <CGAL/AABB_traits.h>
#include <CGAL/AABB_triangle_primitive.h>
typedef CGAL::Simple_cartesian<float>                                      Kernel_Cartesian;
typedef Kernel_Cartesian::FT                                                Cartesian_FT;
typedef Kernel_Cartesian::Segment_3                                         Cartesian_Segment_3;
typedef Kernel_Cartesian::Ray_3                                             Cartesian_Ray_3;
typedef Kernel_Cartesian::Point_3                                           Cartesian_Point_3;
typedef Kernel_Cartesian::Triangle_3                                        Cartesian_Triangle_3;
typedef std::list<Cartesian_Triangle_3>::iterator                           Iterator;
typedef CGAL::AABB_triangle_primitive<Kernel_Cartesian, Iterator>           Primitive;
typedef CGAL::AABB_traits<Kernel_Cartesian, Primitive>                      AABB_triangle_traits;
typedef CGAL::AABB_tree<AABB_triangle_traits>                               Tree;
typedef Tree::Primitive_id                                                  Primitive_id;


/* Delaunay Triangular */
#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>
#include <CGAL/Triangulation_vertex_base_with_info_2.h>
#include <CGAL/Triangulation_vertex_base_with_info_3.h>
#include <CGAL/Triangulation_cell_base_with_info_3.h>
#include <CGAL/Delaunay_triangulation_2.h>
#include <CGAL/Delaunay_triangulation_3.h>
typedef CGAL::Exact_predicates_inexact_constructions_kernel                 Kernel;
typedef CGAL::Triangulation_vertex_base_with_info_2<unsigned int, Kernel>   Vb_2;
typedef CGAL::Triangulation_data_structure_2<Vb_2>                          Tds;
typedef CGAL::Delaunay_triangulation_2<Kernel, Tds>                         delaunay_2;
typedef Kernel::Point_2                                                     point_2;
typedef CGAL::Triangulation_vertex_base_with_info_3<unsigned int, Kernel>   Vb_3;
typedef CGAL::Triangulation_cell_base_3<Kernel>                             Cb;
typedef CGAL::Triangulation_cell_base_with_info_3<int, Kernel, Cb>          CbI;
typedef CGAL::Triangulation_data_structure_3<Vb_3, CbI>                     cdTds;
typedef CGAL::Delaunay_triangulation_3<Kernel, cdTds>                       delaunay_3;
typedef delaunay_3::Point_3                                                 point_3;


class BaseRecon
{
    public:
        vector<vector<float>> pts_; // points
        vector<vector<int>> fid_;  // local faces indices
        virtual vector<vector<int>> Recon()=0;
};

class PoissonRecon: public BaseRecon
{
    public:
        PoissonRecon(vector<vector<float>>& pts);
        vector<vector<int>> Recon();
};

class Delaunay2D: public BaseRecon
{
    public:
        int debug;
        int is_edge_length_calculated_=0;
        AABB* bb_;
        Plane pl_;
        delaunay_2 triangulation_;
        float max_length_of_edge_=-INT32_MAX; 
        float min_length_of_edge_=INT32_MAX;
        float mean_length_of_edge_=0;
        Delaunay2D(vector<vector<float>>& pts);
        Delaunay2D(pcl::PointCloud<PointType>::Ptr cloud);
        void EnableDebug();
        void DisableDebug();
        vector<vector<int>> Recon();
        int IsIntersect(Ray ry);
        int IsIntersect2(Ray ry);
        int IsIntersect(LineSegment ls);

        void FilterFace(float thresh=-1);
        float GetMinimumLengthOfEdge();
        float GetMeanLengthOfEdge();
        float GetMaximumLengthOfEdge();
        void Upsampling();

    private:
        void GetMMMLengthOfEdge();
};

class Delaunay3D: public BaseRecon
{
    public:
        Delaunay3D(vector<vector<float>>& pts);
        vector<vector<int>> Recon();
};

