#include <VectorExtend.h>
void VecFindPos(vector<int>& buf1,vector<int>& buf2, vector<int>& out)
{
    for(int i=0;i<buf2.size();i++){
        for(int j=0;j<buf1.size();j++){
            if(buf1[j]==buf2[i])
                out.push_back(j);
        }            
    }
}

