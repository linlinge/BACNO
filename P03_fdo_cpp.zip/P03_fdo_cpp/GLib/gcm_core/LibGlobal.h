#pragma once 
#define IS_BETWEEN(DAT, A,B)   ((DAT>=A)&&(DAT<=B))
#define MIN2(A,B) (A<B ? A:B)
#define MAX2(A,B) (A>B ? A:B)
#define MAX3(A, B, C) MAX2(MAX2(A, B), C)
#define MIN3(A, B, C) MIN2(MIN2(A, B), C)