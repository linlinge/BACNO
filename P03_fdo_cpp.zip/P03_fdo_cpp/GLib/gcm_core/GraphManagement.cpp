#include <GraphManagement.h>
Graph::Graph(vector<int> nodes, vector<vector<int>> adj_list)
{
    nodes_=nodes;
    adj_list_=adj_list;
    flag_collapsed.resize(nodes.size(),0);
}

void Graph::SetNodes(vector<int> nodes)
{
    nodes_=nodes;
    GetNode2Idx();
}

void Graph::SetAdjacentList(vector<vector<int>>& adj_list)
{
    adj_list_=adj_list;
}

void Graph::ReadNodesCSV(string path, bool header)
{
    fstream fin(path);
    string line;
    if(header==true)
        getline(fin, line);
    
    while(getline(fin, line)){
        vector<string> ss=StrSplit(line,",");
        int ntmp=atoi(ss[0].c_str());
        nodes_.push_back(ntmp);    
        // update mapping of n2i_ 
        n2i_[ntmp]=nodes_.size()-1; 
    }
    fin.close();

    // 
    flag_collapsed.resize(nodes_.size(), 0);
}

void Graph::ReadEdgesCSV(string path, bool header)
{
    fstream fin(path);
    string line;
    if(header==true)
        getline(fin, line);

    // if nodes have not readed
    if(nodes_.size()!=0){
        adj_list_.resize(nodes_.size());
        while(getline(fin, line)){
            vector<string> ss=StrSplit(line,",");
            int utmp=atoi(ss[0].c_str());
            int vtmp=atoi(ss[1].c_str());
            adj_list_[n2i_[utmp]].push_back(vtmp);
        }
    }   
    else{
        /* get nodes */
        while(getline(fin, line)){
            vector<string> ss=StrSplit(line,",");
            int utmp=atoi(ss[0].c_str());
            int vtmp=atoi(ss[1].c_str());
            nodes_.push_back(utmp);
            nodes_.push_back(vtmp);
        }
        VecUnique(nodes_);
        for(int i=0; i<nodes_.size(); i++)
            n2i_[nodes_[i]]=i;

        /* get adjacent list */
        adj_list_.resize(nodes_.size());
        while(getline(fin, line)){
            vector<string> ss=StrSplit(line,",");
            int utmp=atoi(ss[0].c_str());
            int vtmp=atoi(ss[1].c_str());
            adj_list_[n2i_[utmp]].push_back(vtmp);
        }
    }   
    fin.close();
}

void Graph::ReadGraphByNodesAndEdgesCSV(string path_of_nodes, string path_of_edges)
{
   ReadNodesCSV(path_of_nodes);
   ReadEdgesCSV(path_of_edges);
}

map<int,int> Graph::GetNode2Idx()
{  
    for(int i=0; i<nodes_.size(); i++){
        n2i_[nodes_[i]]=i;
    }
    return n2i_;
}

void Graph::AddEdgeToAdjList(int snode, int tnode)
{
    adj_list_[n2i_[snode]].push_back(tnode);
}

Graph Graph::GetSubGraph(vector<int>& sub_nodes)
{
    Graph subgraph;
    subgraph.SetNodes(sub_nodes);

    // flag the nodes which are still useful
    vector<int> flag(nodes_.size(), 0);
    for(int i=0; i<sub_nodes.size(); i++){
        flag[sub_nodes[i]]=1;
    }

    // update adj_list
    auto sub_adj_list= GetSubAdjacentList(sub_nodes);
    subgraph.SetAdjacentList(sub_adj_list);
    return subgraph;
}

vector<vector<int>> Graph::GetConnectedComponents()
{
    /* init */
    stack<int> sk;                
    GetNode2Idx();
    vector<int> flag_is_visited(nodes_.size(),0);
    int num_of_visited=0;

    /* find components */
    vector<vector<int>> cmpts;        
    int current_seed=nodes_[0];
    while(current_seed!=INT_MAX)
    {     
        /* traverse one component */
        vector<int> cmpt;   
        sk.push(current_seed);
        flag_is_visited[n2i_[current_seed]]=1;
        while(sk.size()!=0){
            /* get all not visited nodes and push it to stack */
            vector<int> ngbrs_not_visited;
            vector<int>& ngbrs=adj_list_[n2i_[sk.top()]];
            for(auto n: ngbrs){
                if(flag_is_visited[n2i_[n]]==0)
                    ngbrs_not_visited.push_back(n);
            }
            
            /* update stack */                    
            cmpt.push_back(sk.top());                    
            sk.pop(); 
            for(int i=0; i<ngbrs_not_visited.size(); i++){
                sk.push(ngbrs_not_visited[i]);                    
                flag_is_visited[n2i_[ngbrs_not_visited[i]]]=1;
            }
        }
        cmpts.push_back(cmpt);

        /* get seed */
        current_seed=INT_MAX;
        for(int i=0; i<flag_is_visited.size(); i++){
            if(flag_is_visited[i]==0){
                current_seed=nodes_[i];
                break;
            }
        }
    }

    sort(cmpts.begin(), cmpts.end(), [](auto& e1, auto& e2){ return e1.size()>e2.size();});
    for(int i=0; i<cmpts.size(); i++)
        sort(cmpts[i].begin(), cmpts[i].end());
    return cmpts;
}

vector<int> Graph::GetNgbrsOfSubGraph(Graph& subgraph)
{
    /* get involved indices of nodes*/
    vector<int> involved_nodes_;
    involved_nodes_.insert(involved_nodes_.end(), subgraph.nodes_.begin(), subgraph.nodes_.end());
    for(int i=0; i<subgraph.nodes_.size(); i++){
        int itmp=subgraph.nodes_[i];
        involved_nodes_.insert(involved_nodes_.end(), adj_list_[itmp].begin(), adj_list_[itmp].end());
    }
    sort(involved_nodes_.begin(), involved_nodes_.end());
    involved_nodes_.erase(unique(involved_nodes_.begin(), involved_nodes_.end()), involved_nodes_.end());

    /* get neighbours of subgraph */
    vector<int> idx_of_ngbrs;
    set_difference(involved_nodes_.begin(), involved_nodes_.end(), 
                    subgraph.nodes_.begin(), subgraph.nodes_.end(), back_inserter(idx_of_ngbrs));
    return idx_of_ngbrs;
}

int Graph::GetIdxOfNode(int node)
{
    return n2i_[node];
}

vector<vector<int>> Graph::GetSubAdjacentList(vector<int>& sub_nodes)
{
    /* flag which nodes require to be extract */
    vector<int> flag(nodes_.size(),0);
    for(int i=0; i<sub_nodes.size(); i++){
        /* get index of this node*/
        int itmp=GetIdxOfNode(sub_nodes[i]);
        flag[itmp]=1;
    }

    
    vector<vector<int>> odata(sub_nodes.size());
    /* extract adjacent list */
    for(int i=0; i<sub_nodes.size(); i++){
        /* get index of this node*/
        int itmp=GetIdxOfNode(sub_nodes[i]);
        for(auto ngbr: adj_list_[itmp]){            
            int ngbr_idx=GetIdxOfNode(ngbr);
            if(flag[ngbr_idx]==1){
                odata[i].push_back(ngbr);
            }
        }
    }
    return odata;
}

vector<Graph> Graph::GetConnectedSubGraph()
{
    vector<Graph> odata;
    auto cmpts=GetConnectedComponents();
    for(auto cmpt: cmpts){
        odata.push_back(Graph(cmpt, GetSubAdjacentList(cmpt)));
    }
    return odata;
}

vector<int> Graph::GetNgbrsOfNodes(vector<int>& nodes)
{
    /* flag all nodes*/
    vector<int> flag(nodes_.size(), 0);
    for(int i=0; i<nodes.size(); i++){
        int itmp= GetIdxOfNode(nodes[i]);
        flag[itmp]=1;
    }

    /*  */
    vector<int> odata;
    for(int i=0; i<nodes.size(); i++){
        int itmp= GetIdxOfNode(nodes[i]);        
        for(auto ngbr: adj_list_[itmp]){
            if(flag[ngbr]==0){
                odata.push_back(ngbr);
            }
        }
    }
    return odata;
}

void Graph::SetFold(vector<int>& collapsed_nodes)
{
    SetFlagOfCollapsed(collapsed_nodes);

    // get neigbhours of collapsed_nodes that required to fold
    auto ngbrs=GetNgbrsOfNodes(collapsed_nodes);
    adj_list_.push_back(ngbrs);

    // get new node
    int parent_node=nodes_.size();
    nodes_.push_back(parent_node);
    flag_collapsed.push_back(0);

    //
    auto adj_list_of_collapsed_nodes= GetSubAdjacentList(collapsed_nodes);

    // record folding information
    fold_info_.AddRecord(parent_node, collapsed_nodes, adj_list_of_collapsed_nodes);
}

vector<int> Graph::GetIdxOfNodes(vector<int>& nodes)
{
    vector<int> odata;
    for(int i=0; i<nodes.size(); i++)
        odata.push_back(GetIdxOfNode(nodes[i]));
    return odata;
}

void Graph::WriteFold(string opath_of_collapsed_nodes, string opath_of_adj_list_of_collased_nodes)
{
    fold_info_.WriteTo(opath_of_collapsed_nodes, opath_of_adj_list_of_collased_nodes);
}

void Graph::SetFlagOfCollapsed(vector<int>& collapsed_nodes)
{
    auto collapsed_indices=GetIdxOfNodes(collapsed_nodes);
    for(auto e: collapsed_nodes)
        flag_collapsed[e]=1;
}

void Graph::WriteGraph(string opath_of_nodes, string opath_of_adj_list)
{
    ofstream fout_nodes(opath_of_nodes);
    ofstream fout_adj_list(opath_of_adj_list);
    for(int i=0; i<flag_collapsed.size(); i++){
        if(flag_collapsed[i]==0){
            fout_nodes<<nodes_[i]<<endl;
            if(adj_list_[i].size()>0){
                fout_adj_list<<adj_list_[i][0];
                for(int j=1; j<adj_list_[i].size(); j++){
                    fout_adj_list<<" "<<adj_list_[i][j];
                }
                fout_adj_list<<endl;
            }               
        }
    }
    fout_nodes.close();
    fout_adj_list.close();
}

void Graph::WriteNodes(string opath_of_nodes)
{
    ofstream fout_nodes(opath_of_nodes);
    fout_nodes<<"id"<<endl;
    for(int i=0; i<flag_collapsed.size(); i++){
        if(flag_collapsed[i]==0){
            fout_nodes<<nodes_[i]<<endl;             
        }
    }
    fout_nodes.close();    
}

void Graph::WriteEdges(string opath_of_edges)
{
    ofstream fout_edges(opath_of_edges);
    fout_edges<<"source, target"<<endl;
    for(int i=0; i<flag_collapsed.size(); i++){
        if(flag_collapsed[i]==0){
            for(int j=0; j<adj_list_[i].size(); j++){
                fout_edges<<nodes_[i]<<","<<adj_list_[i][j]<<endl;
            }
        }
    }
    fout_edges.close();
}

void Graph::WriteAdjacentList(string opath_of_adjacent_list)
{
    ofstream fout_adjacent_list(opath_of_adjacent_list);
    for(int i=0; i<flag_collapsed.size(); i++){
        if(flag_collapsed[i]==0){
            if(adj_list_[i].size()>0){
                fout_adjacent_list<<adj_list_[i][0];
                for(int j=1; j<adj_list_[i].size(); j++){
                    fout_adjacent_list<<" "<<adj_list_[i][j];
                }
            }
            fout_adjacent_list<<endl;
        }
    }
    fout_adjacent_list.close();
}