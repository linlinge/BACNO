#pragma once 
#include <vector>
#include <PCLExtend.h>
#include <string.h>
#include <BasicType.h>
#include <StringExtend.h>
using namespace std;

template<class T>
class MeshManagement
{
    public:
        vector<T> points_;    
        vector<vector<float>> vtx_;
        vector<vector<float>> normals_;
        vector<vector<int>> faces_;
        vector<vector<uchar>> colors_;
        vector<vector<int>> lines_;
        vector<vector<int>> adj_list_;

        void ReadOBJ(string read_path)
        {
            ifstream fin;
            fin.open(read_path);    
            string line;
            while(getline(fin,line)){
                vector<string> ss=StrSplit(line," ");
                if(ss[0]=="v"){            
                    vtx_.push_back({atof(ss[1].c_str()), atof(ss[2].c_str()), atof(ss[3].c_str())});            
                }
                else if(ss[0]=="f"){
                    faces_.push_back({atoi(ss[1].c_str())-1, atoi(ss[2].c_str())-1, atoi(ss[3].c_str())-1});
                }
                else if(ss[0]=="l"){
                    lines_.push_back({atoi(ss[1].c_str())-1, atoi(ss[2].c_str())-1});
                }
                else if(ss[0]=="vn"){
                    normals_.push_back({atof(ss[1].c_str()), atof(ss[2].c_str()), atof(ss[3].c_str())});            
                }
            }
            fin.close();
        }

        void WriteOBJ(string write_path)
        {
            ofstream fout(write_path);
            // write vertex
            for(int i=0;i< vtx_.size(); i++){
                fout<<"v";
                for(int j=0; j<vtx_[i].size(); j++)
                    fout<<" "<<vtx_[i][j];
                fout<<endl;
            }

            // write faces
            for(int i=0;i< faces_.size(); i++){
                fout<<"f "<<faces_[i][0]+1<<" "<<faces_[i][1]+1<<" "<<faces_[i][2]+1<<endl;
            }

            // write lines
            for(int i=0;i< lines_.size(); i++){
                fout<<"l "<<lines_[i][0]+1<<" "<<lines_[i][1]+1<<endl;
            }
            fout.close();
        }


        void EstablishCloud()
        {
            if(std::is_same<T,Position>::value){
                for(int i=0; i<vtx_.size(); i++){
                    points_.push_back(T(vtx_[i][0], vtx_[i][1], vtx_[i][2]));
                }
            }
            else if(std::is_same<T,PositionNormal>::value){
                for(int i=0; i<vtx_.size(); i++){
                    points_.push_back(T(vtx_[i][0], vtx_[i][1], vtx_[i][2], normals_[i][0], normals_[i][1], normals_[i][2]));
                }
            }
            else if(std::is_same<T,PositionColor>::value){
                for(int i=0; i<vtx_.size(); i++){
                    points_.push_back(T(vtx_[i][0], vtx_[i][1], vtx_[i][2], colors_[i][0], colors_[i][1], colors_[i][2]));
                }
            }
            else if(std::is_same<T,PositionNormalColor>::value){
                for(int i=0; i<vtx_.size(); i++){
                    points_.push_back(T(vtx_[i][0], vtx_[i][1], vtx_[i][2], 
                                        normals_[i][0], normals_[i][1], normals_[i][2],
                                        colors_[i][0],colors_[i][1],colors_[i][2]));
                }
            }
        }

        vector<vector<int>> EstablishAdjacentList()
        {
            adj_list_.resize(vtx_.size());
            for(int i=0; i<lines_.size(); i++){
                adj_list_[lines_[i][0]].push_back(lines_[i][1]);
            }
            return adj_list_;
        }

        void UpdateAdjacentList(vector<vector<int>>& adj_list)
        {
            adj_list_=adj_list;
        }

        vector<vector<float>> ExtractXYZ()
        {
            vector<vector<float>> cloud_xyz(points_.size(), vector<float>(3));
            for(int i=0; i<points_.size(); i++){
                cloud_xyz[i][0]=points_[i].x_;
                cloud_xyz[i][1]=points_[i].y_;
                cloud_xyz[i][2]=points_[i].z_;
            }
            return cloud_xyz;
        }

        T GetCentroid()
        {
            T ptmp;
            ptmp.x_=0;
            ptmp.y_=0;
            ptmp.z_=0;
            for(int i=0; i<points_.size(); i++){
                ptmp.x_+=points_[i].x_;
                ptmp.y_+=points_[i].y_;
                ptmp.z_+=points_[i].z_;
            }
            ptmp.x_=ptmp.x_/points_.size();
            ptmp.y_=ptmp.y_/points_.size();
            ptmp.z_=ptmp.z_/points_.size();
            return ptmp;
        }

        /************************************************** PCL ******************************************************/
        pcl::PointCloud<PointType>::Ptr ExtractCloud()
        {
            pcl::PointCloud<PointType>::Ptr cloud(new pcl::PointCloud<PointType>);
            for(int i=0; i<points_.size(); i++){
                cloud->points.push_back(PointType((float)points_[i].x_, (float)points_[i].y_, (float)points_[i].z_));
            }
            return cloud;
        }

        void SetInputCloud(pcl::PointCloud<PointType>::Ptr cloud)
        {
            if(T::type_id_==Point3DXYZ){
                for(int i=0; i<cloud->points.size(); i++){
                    points_.push_back(T(cloud->points[i].x, cloud->points[i].y, cloud->points[i].z));
                }
            }
            else if(T::type_id_==Point3DXYZNxNyNz){
                for(int i=0; i<cloud->points.size(); i++){
                    points_.push_back(T(cloud->points[i].x, cloud->points[i].y, cloud->points[i].z,
                                        cloud->points[i].normal_x, cloud->points[i].normal_y, cloud->points[i].normal_z));
                }
            }
            else if(T::type_id_==Point3DXYZRGB){
                for(int i=0; i<cloud->points.size(); i++){
                    points_.push_back(T(cloud->points[i].x, cloud->points[i].y, cloud->points[i].z,
                                        cloud->points[i].r, cloud->points[i].g, cloud->points[i].b));
                }
            }
            else if(T::type_id_==Point3DXYZNxNyNzRGB){
                for(int i=0; i<cloud->points.size(); i++){
                    points_.push_back(T(cloud->points[i].x, cloud->points[i].y, cloud->points[i].z,
                                        cloud->points[i].normal_x, cloud->points[i].normal_y, cloud->points[i].normal_z,
                                        cloud->points[i].r, cloud->points[i].g, cloud->points[i].b));
                }
            }
            else{
                cout<<"Error: type out of range!"<<endl;
            }
        }
};
