#pragma once 
#include <KDTree.h>
#include <StringExtend.h>
#include <map>
#include <VectorExtend.h>
#include <time.h>
typedef V2I Edge;

class UndirectedEdgeSet
{
    public:
        vector<Edge> dat_;        
        void push_back(Edge e){        
            dat_.push_back(e);                    
        }
        void remove_duplicate(){
            KDTree2D<Edge> mykdtree;
            mykdtree.SetInputCloud(dat_);
            vector<int> idx_need_to_remove;
            sort(dat_.begin(), dat_.end());

            for(int i=0; i<dat_.size(); i++){
                if(dat_[i].u_<= dat_[i].v_){
                    auto [itmp, dtmp]=mykdtree.radiusSearch(Edge{dat_[i].v_, dat_[i].u_},0.001);                    
                    idx_need_to_remove.insert(idx_need_to_remove.end(), itmp.begin(), itmp.end());
                }
                else{
                    break;
                }
            }
            
            sort(dat_.begin(), dat_.end(), [](Edge& e1, Edge& e2){ return e1.key_< e2.key_;});
            sort(idx_need_to_remove.begin(), idx_need_to_remove.end());
            for(int i=idx_need_to_remove.size()-1; i>=0; i--){
                dat_.erase(dat_.begin()+idx_need_to_remove[i]);
            }

            update_key();
        }
    
    private:
        void update_key()
        {
            for(int i=0; i<dat_.size(); i++){
                dat_[i].key_=i;
            }
            Edge::key_counter_=dat_.size();
        }

};

class FoldRecord
{
    public:
        int node_;
        vector<int> folded_nodes_;
        vector<vector<int>> ngbrs_;       

        FoldRecord(){}
        FoldRecord(int node, vector<int>& folded_nodes, vector<vector<int>>& ngbrs){
            node_=node;
            folded_nodes_=folded_nodes;    
            ngbrs_=ngbrs;        
        }
};

class FoldInfo
{
    public:
        vector<FoldRecord> records_;
        void AddRecord(int node, vector<int>& folded_nodes, vector<vector<int>>& ngbrs){
            records_.push_back(FoldRecord(node, folded_nodes, ngbrs));
        }

        void WriteTo(string path_of_collapsed_nodes, string path_of_adj_list){
            ofstream fout(path_of_collapsed_nodes);
            /* step 01: parent node -> collapsed nodes */            
            for(int i=0; i<records_.size(); i++){
                fout<<records_[i].node_;
                // fold node
                fout<<records_[i].folded_nodes_[0];
                for(int j=0; j<records_[i].folded_nodes_.size(); j++){
                    fout<<" "<<records_[i].folded_nodes_[j];
                }
                fout<<endl;
            }
            fout.close();

            /* step 02: adjacent list of collapsed nodes */
            fout.open(path_of_adj_list);
            for(int k=0; k<records_.size(); k++){
                for(int i=0; i<records_[k].ngbrs_.size(); i++){
                    if(records_[k].ngbrs_[i].size()>0){
                        fout<<records_[k].ngbrs_[i][0];                    
                        for(int j=1; j<records_[k].ngbrs_[i].size(); j++){
                            fout<<" "<<records_[k].ngbrs_[i][j];
                        }
                    }                   
                    fout<<endl;
                }
            }
            fout.close();
        }
};


class Graph
{
    public:
        vector<vector<int>> adj_list_;
        vector<int> nodes_;
        FoldInfo fold_info_;

        /* Create Graph */
        void ReadNodesCSV(string path, bool header=true);
        void ReadEdgesCSV(string path, bool header=true);        
        void ReadGraphByNodesAndEdgesCSV(string path_of_nodes, string path_of_edges);
        Graph(){};
        Graph(vector<int> nodes, vector<vector<int>> adj_list);

        /* Get */
        Graph GetSubGraph(vector<int>& sub_nodes);
        vector<vector<int>> GetSubAdjacentList(vector<int>& sub_nodes);
        vector<Graph> GetConnectedSubGraph();
        vector<vector<int>> GetConnectedComponents();
        vector<int> GetNgbrsOfSubGraph(Graph& subgraph);
        vector<int> GetNgbrsOfNodes(vector<int>& nodes);
        int GetIdxOfNode(int node);
        vector<int> GetIdxOfNodes(vector<int>& nodes);

        /* Set */
        void SetNodes(vector<int> nodes);       
        void SetAdjacentList(vector<vector<int>>& adj_list);
        void SetFold(vector<int>& nodes);
        void SetFlagOfCollapsed(vector<int>& collapsed_nodes);

        /* Write */
        void WriteFold(string opath_of_collapsed_nodes, string opath_of_adj_list_of_collased_nodes);
        void WriteGraph(string opath_of_nodes, string opath_of_adj_list);
        void WriteNodes(string opath_of_nodes);
        void WriteEdges(string opath_of_edges);
        void WriteAdjacentList(string opath_of_adjacent_list);
    
    private:
        vector<vector<int>> edges_;
        map<int, int> n2i_;
        vector<int> flag_collapsed;
        map<int,int> GetNode2Idx();
        void AddEdgeToAdjList(int snode, int tnode);
};