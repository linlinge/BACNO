#pragma once
#include <fstream>
#include <iostream>
#include <vector>
#include <limits.h>
#include <algorithm>
#include <set>
#include <V3.hpp>
using namespace std;

void VecFindPos(vector<int>& buf1,vector<int>& buf2, vector<int>& out);

/**
 * @brief Difference set of two vectors
 * 
 * @param dat1 
 * @param dat2 
 * @param out 
 */
template<class T>
vector<T> VecDifference(vector<T> dat1,vector<T> dat2)
{
    vector<T> out;
    sort(dat1.begin(),dat1.end());
    sort(dat2.begin(),dat2.end());
    set_difference(dat1.begin(),dat1.end(),dat2.begin(),dat2.end(),std::back_inserter(out));
}

template<class T>
static void VecRemove_StableViaValue(vector<T>& dat, T e)
{
    vector<int> idx_record;
    for(int i=0; i<dat.size(); i++){
        if(dat[i]==e)
            idx_record.push_back(i);
    }

    for(int i=idx_record.size()-1; i>=0; i--){
        dat.erase(dat.begin() + idx_record[i]);
    }
}

/**
 * @brief copy the tail element to the position of specified element, and then remove the last one
 * @shortcomings unstable       
 * @param dat the input data
 * @param e specify the value of the element which required to remove
 */
template<class T>
static void VecRemove_Fast_Unstable_ViaValue(vector<T>& dat, T e)
{
    for(int i=0; i<dat.size(); i++){
        if(dat[i]==e){
            dat[i]=dat[dat.size()-1];
            dat.erase(dat.end()-1);
        }
    }
}

template<class T>
static void VecRemove_Fast_Unstable_ViaIndex(vector<T>& dat, int idx)
{
    dat[idx]=dat[dat.size()-1];
    dat.erase(dat.end()-1);
}


template<class T>
static void VecUnique(vector<T>& dat)
{
    sort(dat.begin(), dat.end());
    dat.erase(unique(dat.begin(), dat.end()), dat.end());
}

template<class T>
static vector<T> VecIntersection(vector<T> dat1, vector<T> dat2)
{
    vector<T> odata;
    sort(dat1.begin(), dat1.end());
    sort(dat2.begin(), dat2.end());
    set_intersection(dat1.begin(), dat1.end(), dat2.begin(), dat2.end(), back_inserter(odata));
    return odata;
}

template<class T>
static vector<int> FindElement(vector<T>& idata, T e)
{
    vector<int> idx_out;
    for(int i=0; i<idata.size(); i++)
    {
        if(idata[i]==e){
            idx_out.push_back(i);
        }
    }
    return idx_out;
}



template<class T>
class VectorExtend{
    public:
        vector<T> dat_;        
        VectorExtend(){};
        VectorExtend(vector<T> dat){
            dat_=dat;
        }
        VectorExtend(int n, int v){
            dat_.resize(n);
            for(int i=0; i<n; i++)
                dat_[i]=v;
        }

        void Resize(int n){
            dat_.resize(n);
        }
        void Resize(int n, T val){
            dat_.resize(n);
            for(int i=0; i<dat_.size(); i++)
                dat_[i]=val;
        }

        T Mean(){
            T rst=0;
            for(int i=0;i<dat_.size();i++)
                rst+=dat_[i];
            
            return rst/dat_.size();
        }

        T Minimum(){
            auto vmin=std::min_element(dat_.begin(),dat_.end());
            return *vmin;
        }

        T Maximum(){
            auto vmax=std::max_element(dat_.begin(),dat_.end());
            return *vmax;
        } 
        
        T& operator[](int i){
            if(i>dat_.size()){
                cout<<"Out of range!"<<endl;
                return dat_[0];
            }
            return dat_[i];
        }

        void Zscore()
        {   
            T vmean=Mean();
            T vstd= Std();
            for(int i=0; i<size(); i++){
                dat_[i]=(dat_[i]-vmean)/vstd;
            }            
        }

        vector<V3> GetColors(){
            float vmin=Minimum();
            float vmax=Maximum();
            vector<V3> out(dat_.size());
            for(int i=0; i<dat_.size(); i++){
                out[i]=GetColor(vmin, vmax, dat_[i]);
            }
            return out;
        }

        V3 GetColor(float min,float max,float confidence){
            V3 color_temp;
            float n=4.0; //
            float step=(max-min)/n;
            float c=confidence-min;
            if(c<step){
                color_temp.r=0;
                color_temp.g=c/step*255;
                color_temp.b=255;
            }
            else if(c<2*step){
                color_temp.r=0;
                color_temp.g=255;
                color_temp.b=255-(c-step)/step*255;
            }
            else if(c<3*step){
                color_temp.r=(c-2*step)/step*255;
                color_temp.g=255;
                color_temp.b=0;
            }
            else{
                color_temp.r=255;
                color_temp.g=255-(c-3*step)/step*255;
                color_temp.b=0;
            }

            return color_temp;
        }

        void Tanh()
        {
            for(int i=0; i<dat_.size(); i++){
                dat_[i]=tanh(dat_[i]);
            }
        }

        void Sigmoid()
        {
            for(int i=0; i<dat_.size(); i++){
                dat_[i]=1.0/(1+ exp(-dat_[i])) -1;
            }
        }

        T Std(){
            T rst=0;
            T dat_mean=Mean();
            for(int i=0;i<dat_.size();i++){
                rst+=(dat_[i]-dat_mean)*(dat_[i]-dat_mean);
            }
            return rst/(dat_.size()-1);
        }

        T Quantile(T p){
            vector<T> dat=dat_;
            sort(dat.begin(),dat.end());
            T Q_idx=1+(dat.size()-1)*p;
            int Q_idx_integer=(int)Q_idx;
            T Q_idx_decimal=Q_idx-Q_idx_integer;
            T Q=dat[Q_idx_integer-1]+(dat[Q_idx_integer]-dat[Q_idx_integer-1])*Q_idx_decimal;    
            return Q;
        }


        T calculateQuantile(float quantile) {
            if (dat_.empty()) {
                cout<<"The data is empty"<<endl;
                return -1;
            }

            if (quantile < 0.0 || quantile > 1.0) {
                throw std::invalid_argument("Quantile must be between 0 and 1");
            }

            // Make a copy of the data to avoid changing the original order
            std::vector<T> sortedData = dat_;
            std::sort(sortedData.begin(), sortedData.end());

            float index = (sortedData.size() - 1) * quantile;
            size_t lowerIndex = static_cast<size_t>(index);
            size_t upperIndex = lowerIndex + 1;

            if (upperIndex >= sortedData.size()) {
                return sortedData[lowerIndex];
            }

            T lowerValue = sortedData[lowerIndex];
            T upperValue = sortedData[upperIndex];
            return lowerValue + (upperValue - lowerValue) * (index - lowerIndex);
        }


        T Sum(){
            T sum=0;
            for(int i=0;i<dat_.size();i++)
            {
                sum+=dat_[i];
            }
            return sum;
        }

        void VectorDelete(int index){
            dat_[index]=dat_[dat_.size()-1];
            dat_.pop_back();
        }

        void VectorDelete(vector<int>& delete_dat){
            if(delete_dat.size()!=0){
                vector<int> target;
                sort(dat_.begin(),dat_.end());
                sort(delete_dat.begin(),delete_dat.end());
                set_difference(dat_.begin(),dat_.end(),delete_dat.begin(),delete_dat.end(),std::back_inserter(target));
                dat_.clear();

                for(int i=0;i<target.size();i++) 
                    dat_.push_back(target[i]);
            }
        }

        float IQR()
        {
            float IQR=Quantile(0.75)-Quantile(0.25);
            return IQR;
        }

        void Normalize()
        {
            T dat_min=Minimum();
            T dat_max=Maximum();
            #pragma omp parrallel for
            for(int i=0;i<dat_.size();i++){
                dat_[i]=(dat_[i]-dat_min)/(dat_max-dat_min);
            }  
        }

        /* Logical Operation */
        vector<T> Difference(vector<T> dat2){
            set<T> st1(dat_.begin(),dat_.end());
            set<T> st2(dat2.begin(),dat2.end());    
            set<T> out_set;
            set_difference(st1.begin(),st1.end(),st2.begin(),st2.end(),std::back_inserter(out_set));

            vector<T> out_vec;
            out_vec.assign(out_set.begin(), out_set.end());
            return out_vec;
        }

        vector<T> Union(vector<T> dat2){
            vector<T> out;
            sort(dat_.begin(),dat_.end());
            sort(dat2.begin(),dat2.end());
            set_union(dat_.begin(),dat_.end(),dat2.begin(),dat2.end(),std::back_inserter(out));
            return out;
        }

        vector<T> Intersection(vector<T> dat2){
            vector<T> out;
            sort(dat_.begin(),dat_.end());
            sort(dat2.begin(),dat2.end());
            set_intersection(dat_.begin(),dat_.end(),dat2.begin(),dat2.end(),std::back_inserter(out));
            return out;
        }

        /* Get the indices of all elements of buf2 in buf1*/
        void Print(){
            for(int i=0;i<dat_.size();i++)
                cout<<dat_[i]<<" ";
            cout<<endl;
        }

        void Unique(){
            vector<int> v;
            v.insert(v.end(),dat_.begin(),dat_.end());
            sort(v.begin(),v.end());
            v.erase(unique(v.begin(),v.end()),v.end());
        }

        /* write */
        void Write(string filename,string mode="append,column"){
            std::ofstream file;
            if (file.bad())
                std::cout << "cannot open file" << std::endl;
            if(mode=="append,row"){
                file.open(filename, ios::out | std::ios::app);
                for(int i=0;i<dat_.size()-1;i++)
                    file<<dat_[i]<<",";
                file<<dat_[dat_.size()-1]<<endl;
            }
            else if(mode=="append,column"){
                file.open(filename, ios::out | std::ios::app);
                for(int i=0;i<dat_.size()-1;i++)
                    file<<dat_[i]<<","<<endl;
                file<<dat_[dat_.size()-1]<<endl;
            }          
            else if(mode=="cover,row"){
                file.open(filename, ios::out);
                for(int i=0;i<dat_.size()-1;i++)
                    file<<dat_[i]<<",";
                file<<dat_[dat_.size()-1]<<endl;
            }
            else if(mode=="cover,column"){
                file.open(filename, ios::out);
                for(int i=0;i<dat_.size()-1;i++)
                    file<<dat_[i]<<","<<endl;
                file<<dat_[dat_.size()-1]<<endl;
            }
            else
            {
                cout<<"Write mode error!"<<endl;
            }
            file.close();
        }

        vector<int> GetIndicesOfBlue(){
            T vmin=Minimum();
            T vmax=Maximum();
            T span=vmax-vmin;
            T thresh=vmin+span*0.25;
            vector<int> idx;
            for(int i=0; i<dat_.size(); i++){
                if(dat_[i]<thresh){
                    idx.push_back(i);
                }
            }
            return idx;
        }
        
        std::tuple<T, vector<int>> TukeyFence(string mode, float kIQR)
        {
            T thresh;
            vector<int> idx_out;
            float val_of_IQR=IQR();            
            if(mode=="<"){
                thresh= Quantile(0.25) - kIQR * val_of_IQR;
                for(int i=0; i<dat_.size(); i++){
                    if(dat_[i]<thresh)
                        idx_out.push_back(i);
                }
            }
            else if(mode==">"){
                thresh= Quantile(0.75) + kIQR * val_of_IQR;
                for(int i=0; i<dat_.size(); i++){
                    if(dat_[i]>thresh)
                        idx_out.push_back(i);
                }
            }
            return std::make_tuple(thresh, idx_out);
        }

        void push_back(T dat)
        {
            dat_.push_back(dat);
        }

        VectorExtend<T>& operator=(VectorExtend<T>& idata)
        {
            VectorExtend<T> odata;
            odata.Resize(idata.size());

            for(int i=0; i<odata.size(); i++){
                odata[i]=idata[i];
            }
            return odata;
        }
        int size()        {
            return dat_.size();
        }

        friend VectorExtend<T> operator +(VectorExtend<T> dat1, VectorExtend<T> dat2)
        {
            VectorExtend<T> rst;
            rst.Resize(dat1.size());
            for(int i=0; i<dat1.size(); i++){
                rst[i]=dat1[i]+dat2[i];
            }
            return rst;
        }

        vector<int> GetRange(string str)
        {
            vector<int> idx_out;
            T lower_bound, upper_bound;
            if(str==""){}
            else if(str[0]=='('){

            }
            else if(str[0]=='['){

            }
            else if(str[0]=='<'){
                if(str[1]=='='){
                    upper_bound=atof(str.substr(2, str.length()-2).c_str());
                    for(int i=0; i<size(); i++){
                        if(dat_[i]<=upper_bound)
                            idx_out.push_back(i);
                    }
                }
                else{
                    upper_bound=atof(str.substr(1, str.length()-1).c_str());
                    for(int i=0; i<size(); i++){
                        if(dat_[i]<upper_bound)
                            idx_out.push_back(i);
                    }
                }
            }
            else if(str[0]=='>'){

            }
            return idx_out;
        }
};