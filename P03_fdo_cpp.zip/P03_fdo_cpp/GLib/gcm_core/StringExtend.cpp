#include "StringExtend.h"
void Str2Vec(string str, string delimiters, vector<int>& dat)
{
   if(str.find(delimiters)!=string::npos)
   {
        dat.clear();
        vector<string> tokens;
        string::size_type lastPos=str.find_first_not_of(delimiters,0);
        string::size_type pos=str.find_first_of(delimiters,lastPos);
        while(string::npos!=pos || string::npos !=lastPos){
            tokens.push_back(str.substr(lastPos,pos-lastPos));
                lastPos=str.find_first_not_of(delimiters,pos);
                pos=str.find_first_of(delimiters,lastPos);
        }

        for(int i=0;i<tokens.size();i++){
            dat.push_back(stoi(tokens[i]));
        }
   }
   else{
       dat.push_back(atoi(str.c_str()));
   }
}

std::vector<std::string> StrSplit(const std::string& input, const std::string& delimiter)
{  
    std::vector<std::string> tokens;  
    std::size_t start = 0;  
    std::size_t end = 0;  
    while ((end = input.find(delimiter, start)) != std::string::npos) {  
        tokens.push_back(input.substr(start, end - start));  
        start = end + delimiter.length();  
    }  
    tokens.push_back(input.substr(start));  
    return tokens;  
}  

void StrPrint(vector<int>& dat)
{
    for(int i=0;i<dat.size();i++)
        cout<<dat[i]<<" ";
    cout<<endl;
}

int get_num_in_string(string str)
{
	int rst=0;
	for(int i=0;i<str.size();i++){		
		if(str[i]>='0' && str[i]<='9'){
			rst=rst*10+(str[i]-'0');
		}
	}
	return rst;
}

string GetFileRoot(string filepath)
{
    vector<string> ss=StrSplit(filepath,"/");
    string file_root="";
    for(int i=0; i<ss.size()-1; i++){
        file_root=file_root+"/"+ss[i];
    }
    return file_root;
}

string GetFileName(string filepath)
{
    vector<string> ss=StrSplit(filepath,"/");
    return ss[ss.size()-1];
}

string GetFileTitle(string filepath)
{
    vector<string> ss=StrSplit(filepath,"/");
    string file_title=StrSplit(ss[ss.size()-1],".")[0];
    return file_title;
}