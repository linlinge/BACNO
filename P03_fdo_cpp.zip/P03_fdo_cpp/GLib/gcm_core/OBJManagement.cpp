#include <OBJManagement.h>
// void OBJManagement::ReadMesh(string path)
// {
//     ifstream fin(path);
//     while(!fin.eof()){
//         string line;
//         getline(fin,line);
//         if(line!=""){
//             vector<string> ss=StrSplit(line," ");

//             // if it is vertex
//             if(ss.size()>0){
//                 if(ss[0]=="v"){
//                     vector<float> tmp;
//                     for(int i=1;i<ss.size(); i++)
//                         tmp.push_back(atof(ss[i].c_str()));
//                     vtx_.push_back(tmp);
//                 }
//                 else if(ss[0]=="f"){
//                     vector<int> tmp;
//                     for(int i=1;i<ss.size(); i++)
//                         tmp.push_back(atoi(ss[i].c_str()));
//                     faces_.push_back(tmp);
//                 }
//             }
//             else 
//                 cout<<"obj file format error!"<<endl;
//         }              
//     }
// }
void OBJManagement::AddMesh(vector<vector<float>> v, vector<vector<int>> f)
{
    vtx_.insert(vtx_.end(), v.begin(), v.end());
    int start_pos=faces_.size();
    for(int i=0; i<f.size(); i++){
        for(int j=0; j<3; j++){
            f[i][j]+=start_pos;
        }
        faces_.push_back(f[i]);
    }
}
void OBJManagement::AddMesh(vector<vector<float>> v, vector<vector<int>> f, vector<vector<int>> lines)
{    
    vtx_.insert(vtx_.end(), v.begin(), v.end());
    int start_pos=faces_.size();
    for(int i=0; i<f.size(); i++){
        for(int j=0; j<3; j++){
            f[i][j]+=start_pos;
        }
        faces_.push_back(f[i]);
    }
    
    start_pos=lines_.size();
    for(int i=0; i< lines.size(); i++){
        for(int j=0; j<2; j++){
            lines[i][j]+=start_pos;
        }
        lines_.push_back(lines[i]);
    }
}



void OBJManagement::AddPoints(vector<vector<float>> pts)
{
    vtx_.insert(vtx_.end(), pts.begin(), pts.end());
}

void OBJManagement::AddPoints(vector<vector<float>> pts, vector<vector<float>> colors)
{
    for(int i=0;i<pts.size(); i++){
        vector<float> line;
        line.insert(line.end(), pts[i].begin(), pts[i].end());
        line.insert(line.end(), colors[i].begin(), colors[i].end());
        vtx_.push_back(line);
    }
}

void OBJManagement::SaveOBJ(string save_path)
{
    ofstream fout(save_path);
    // write vertex
    for(int i=0;i< vtx_.size(); i++){
        fout<<"v";
        for(int j=0; j<vtx_[i].size(); j++)
            fout<<" "<<vtx_[i][j];
        fout<<endl;
    }

    // write faces
    for(int i=0;i< faces_.size(); i++){
        fout<<"f "<<faces_[i][0]+1<<" "<<faces_[i][1]+1<<" "<<faces_[i][2]+1<<endl;
    }

    // write lines
    for(int i=0;i< lines_.size(); i++){
        fout<<"l "<<lines_[i][0]+1<<" "<<lines_[i][1]+1<<endl;
    }
    fout.close();
}

MeshManagement<PositionNormalColor> OBJManagement::ReadOBJ(string read_path)
{
    ifstream fin;
    fin.open(read_path);    
    string line;
    while(getline(fin,line)){
        vector<string> ss=StrSplit(line," ");
        if(ss[0]=="v"){            
            vtx_.push_back({atof(ss[1].c_str()), atof(ss[2].c_str()), atof(ss[3].c_str())});            
        }
        else if(ss[0]=="f"){
            faces_.push_back({atoi(ss[1].c_str())-1, atoi(ss[2].c_str())-1, atoi(ss[3].c_str())-1});
        }
        else if(ss[0]=="l"){
            lines_.push_back({atoi(ss[1].c_str())-1, atoi(ss[2].c_str())-1});
        }
    }
    fin.close();
}

void OBJManagement::EstablishAdjacentList()
{
    adj_list_.resize(vtx_.size());
    for(int i=0; i<lines_.size(); i++){
        adj_list_[lines_[i][0]].push_back(lines_[i][1]);
    }
}

void OBJManagement::AddLine(vector<float> pt_start, vector<float> pt_end)
{
    vector<int> line;
    vtx_.push_back(pt_start);
    line.push_back(vtx_.size()-1);

    vtx_.push_back(pt_end);
    line.push_back(vtx_.size()-1);

    lines_.push_back(line);    
}

void OBJManagement::AddLine(LineSegment line)
{
    AddLine({line.origin_.x, line.origin_.y, line.origin_.z},
            {line.end_.x, line.end_.y, line.end_.z});
}

void OBJManagement::AddLines(vector<vector<float>> pts, vector<vector<int>> fid)
{
    int offset=vtx_.size();
    vtx_.insert(vtx_.end(), pts.begin(), pts.end());
    for(int i=0; i< fid.size(); i++){
        fid[i][0]+=offset;
        fid[i][1]+=offset;
    }
    lines_.insert(lines_.end(), fid.begin(), fid.end());
}

void OBJManagement::AddLines(vector<vector<int>> lines)
{
    lines_.insert(lines_.end(), lines.begin(), lines.end());
}

/**************************************************** ParseObj Geometric Extend ***************************************************************/
OBJManagerGeometricEx::OBJManagerGeometricEx(Triangle tri)
{
    vector<int> face;

    vtx_.push_back(tri.vtx_[0].ToFloat());
    face.push_back(vtx_.size()-1);

    vtx_.push_back(tri.vtx_[1].ToFloat());
    face.push_back(vtx_.size()-1);

    vtx_.push_back(tri.vtx_[2].ToFloat());
    face.push_back(vtx_.size()-1);

    faces_.push_back(face);
}

OBJManagerGeometricEx::OBJManagerGeometricEx(Ray ry)
{
    vector<int> line;
    vtx_.push_back(ry.origin_.ToFloat());
    line.push_back(vtx_.size()-1);

    vtx_.push_back((ry.origin_+ry.direction_).ToFloat());
    line.push_back(vtx_.size()-1); 

    lines_.push_back(line);
}

OBJManagerGeometricEx::OBJManagerGeometricEx(LineSegment lsg)
{
    vector<int> line;
    vtx_.push_back(lsg.origin_.ToFloat());
    line.push_back(vtx_.size()-1);

    vtx_.push_back(lsg.end_.ToFloat());
    line.push_back(vtx_.size()-1); 

    lines_.push_back(line);
}

void OBJManagerGeometricEx::AddMesh(Triangle& tri)
{
    vector<int> f;
    vtx_.push_back(tri.vtx_[0].ToFloat());
    f.push_back(vtx_.size()-1);
    vtx_.push_back(tri.vtx_[1].ToFloat());
    f.push_back(vtx_.size()-1);
    vtx_.push_back(tri.vtx_[2].ToFloat());
    f.push_back(vtx_.size()-1);
    faces_.push_back(f);
}

void OBJManagerGeometricEx::AddMesh(vector<vector<float>> pts, vector<vector<int>> faces)
{
	for(int i=0; i<faces.size(); i++){
		for(int j=0; j<faces[i].size(); j++){
			faces[i][j]+=vtx_.size();
		}
	}

	vtx_.insert(vtx_.end(), pts.begin(), pts.end());
	faces_.insert(faces_.end(), faces.begin(), faces.end());
}

void OBJManagerGeometricEx::AddLineSegment(LineSegment lg)
{
    vector<int> line;
    vtx_.push_back(lg.origin_.ToFloat());
    line.push_back(vtx_.size()-1);
    vtx_.push_back(lg.end_.ToFloat());
    line.push_back(vtx_.size()-1);
    lines_.push_back(line);
}

void OBJManagerGeometricEx::AddBox(AABB* bb)
{
	vector<vector<float>> corners=bb->GenerateEightCorners();
	vector<vector<int>>   line_by_self_id=bb->GenerateSelfLines();
	int base=vtx_.size();
	for(int i=0; i<line_by_self_id.size(); i++){
		for(int j=0; j<line_by_self_id[i].size(); j++){
			line_by_self_id[i][j]+=base;
		}
	}
	AddPoints(corners);
	AddLines(line_by_self_id);
}

void OBJManagerGeometricEx::AddPlane(Plane pl, AABB* bb)
{
	// step 02: obtain span in xyz axis
	float num=30;
	float xspan=(bb->bmax_.x -bb->bmin_.x)/num;
	float yspan=(bb->bmax_.y -bb->bmin_.y)/num;
	float zspan=(bb->bmax_.z -bb->bmin_.z)/num;

	// step 03: obtain some points on the surfaces
	vector<float> xi,yi;
	float start_x=bb->bmin_.x-(3*xspan);
	float start_y=bb->bmin_.y-(3*yspan);
	for(int i=0; start_x + i*xspan < bb->bmax_.x+3*xspan; i++){
		xi.push_back(start_x + i*xspan);
		yi.push_back(start_y + i*yspan);
	}

	vector<vector<float>> out_pts;
	for(int i=0; i<xi.size(); i++){
		for(int j=0; j<yi.size(); j++){
			float z=pl.Apply(xi[i],yi[j]);

			vector<float> ptmp;
			ptmp.push_back(xi[i]);
			ptmp.push_back(yi[j]);
			ptmp.push_back(z);

			out_pts.push_back(ptmp);
		}
	}
	AddPoints(out_pts);
}

void OBJManagerGeometricEx::AddRay(Ray ry)
{
	AddPoints(ry.origin_.ToFloat2D());
	AddPoints((ry.origin_+300*ry.direction_).ToFloat2D());
	vector<int> tmp(2);
	tmp[0]=vtx_.size()-2;
	tmp[1]=vtx_.size()-1;
	lines_.push_back(tmp);
}

void OBJManagerGeometricEx::AddTriangle(Triangle tri)
{
	vector<vector<float>> v={{tri.vtx_[0].x, tri.vtx_[0].y, tri.vtx_[0].z},
							 {tri.vtx_[1].x, tri.vtx_[1].y, tri.vtx_[1].z},
							 {tri.vtx_[2].x, tri.vtx_[2].y, tri.vtx_[2].z},};
	
	int base=vtx_.size();
	vtx_.insert(vtx_.end(),v.begin(), v.end());
	vector<int> new_id={0+base, 1+base, 2+base};
	faces_.push_back(new_id);
}