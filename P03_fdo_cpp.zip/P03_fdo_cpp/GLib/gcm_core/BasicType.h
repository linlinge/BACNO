#pragma once
#include <iostream>
#include <math.h>
#include <vector>
#include <string.h>
using namespace std;
typedef unsigned char uchar;
enum TypeSet{Point3DXYZ, Point3DXYZNxNyNz, Point3DXYZRGB, Point3DXYZNxNyNzRGB, TwoInt};

class V2I
{
    public:
        union{
            struct{
                int u_, v_;
            };
            struct{
                int x_, y_;
            };
            struct{
                int xy_[2];
            };
        };
        int key_;      
        static int type_id_;
        static int key_counter_;

        V2I(int u, int v){
            u_=u;
            v_=v;
            key_=key_counter_++;
        }
        V2I(vector<int> e){
            u_=e[0];
            v_=e[1];
            key_=key_counter_++;
        }
        bool operator<(V2I e){
            if(u_<e.u_){
                return true;
            }
            else if(u_==e.u_){
                if(v_<e.v_){
                    return true;
                }
                else 
                    return false;
            }
            else 
                return false;
        }
        float DistTo(V2I& e){
            return sqrt(pow(u_-e.u_,2)+ pow(v_-e.v_,2));
        }
};

class Position
{
    public: 
        union{
            struct{
                float x_, y_, z_;
            };
            struct{
                float xyz_[3];
            };
        };    
        
        int key_;      
        static int type_id_;
        static int key_counter_;
        Position(){
            x_=y_=z_=0;
        }
        Position(float x, float y, float z){
            x_=x; y_=y; z_=z;
            key_=key_counter_++;
        }
        Position(float x, float y, float z, float nx, float ny){
            cout<<"Warning: This function is forbidden to use. Please replace it with a more suitable type!"<<endl;
        }
        Position(float x, float y, float z, uchar r, uchar g, uchar b){
            cout<<"Warning: This function is forbidden to use. Please replace it with a more suitable type!"<<endl;
        }
        Position(float x, float y, float z, float nx, float ny, float nz, uchar r, uchar g, uchar b){
            cout<<"Warning: This function is forbidden to use. Please replace it with a more suitable type!"<<endl;
        }
        float DistTo(Position& pt){
            return sqrt(pow(x_-pt.x_, 2)+pow(y_- pt.y_, 2)+pow(z_-pt.z_,2));
        }
};

class PositionNormal
{
    public:       
        union{
            struct{
                float x_, y_, z_;
            };
            struct{
                float xyz_[3];
            };
        };       
        float nx_, ny_, nz_;
        int key_;
        static int type_id_;
        static int key_counter_;
        PositionNormal(){
            x_=y_=z_=0;
        }
        PositionNormal(float x, float y, float z){
            cout<<"Warning: This function is forbidden to use. Please replace it with a more suitable type!"<<endl;
        }
        PositionNormal(float x, float y, float z, float nx, float ny, float nz){
            x_=x; y_=y; z_=z;
            nx_=nx; ny_=ny; nz_=nz;
            key_=key_counter_++;
        }
        PositionNormal(float x, float y, float z, uchar r, uchar g, uchar b){
            cout<<"Warning: This function is forbidden to use. Please replace it with a more suitable type!"<<endl;
        }
        PositionNormal(float x, float y, float z, float nx, float ny, float nz, uchar r, uchar g, uchar b){
            cout<<"Warning: This function is forbidden to use. Please replace it with a more suitable type!"<<endl;
        }
        float DistTo(PositionNormal& pt){
            return sqrt(pow(x_-pt.x_, 2)+pow(y_- pt.y_, 2)+pow(z_-pt.z_,2));
        }
};

class PositionColor
{
    public:        
        union{
            struct{
                float x_, y_, z_;
            };
            struct{
                float xyz_[3];
            };
        };      
        uchar r_, g_, b_;
        int key_;
        static int type_id_;
        static int key_counter_;
        PositionColor(){
            x_=y_=z_=0;
        }
        PositionColor(float x, float y, float z){
            cout<<"Warning: This function is forbidden to use. Please replace it with a more suitable type!"<<endl;
        }
        PositionColor(float x, float y, float z, float nx, float ny, float nz){
            cout<<"Warning: This function is forbidden to use. Please replace it with a more suitable type!"<<endl;
        }
        PositionColor(float x, float y, float z, uchar r, uchar g, uchar b){
            x_=x; y_=y; z_=z;
            r_=r; g_=g; b_=b;
            key_=key_counter_++;
        }
        PositionColor(float x, float y, float z, float nx, float ny, float nz, uchar r, uchar g, uchar b){
            cout<<"Warning: This function is forbidden to use. Please replace it with a more suitable type!"<<endl;
        }
        float DistTo(PositionColor& pt){
            return sqrt(pow(x_-pt.x_, 2)+pow(y_- pt.y_, 2)+pow(z_-pt.z_,2));
        }
};

class PositionNormalColor
{   
    public:
        union{
            struct{
                float x_, y_, z_;
            };
            struct{
                float xyz_[3];
            };
        };     
        float nx_, ny_, nz_;
        int r_, g_, b_;
        int key_;
        static int type_id_;
        static int key_counter_;
        PositionNormalColor(){
            x_=y_=z_=0;
        }
        PositionNormalColor(float x, float y, float z){
            cout<<"Warning: This function is forbidden to use. Please replace it with a more suitable type!"<<endl;
        }
        PositionNormalColor(float x, float y, float z, float nx, float ny, float nz){
            cout<<"Warning: This function is forbidden to use. Please replace it with a more suitable type!"<<endl;
        }
        PositionNormalColor(float x, float y, float z, uchar r, uchar g, uchar b){
            cout<<"Warning: This function is forbidden to use. Please replace it with a more suitable type!"<<endl;
        }
        PositionNormalColor(float x, float y, float z, float nx, float ny, float nz, uchar r, uchar g, uchar b){
            x_=x; y_=y; z_=z;
            nx_=nx; ny_=ny; nz_=nz;
            r_=r; g_=g; b_=b;
            key_=key_counter_++;
        }
        float DistTo(PositionNormalColor& pt){
            return sqrt(pow(x_-pt.x_, 2)+pow(y_- pt.y_, 2)+pow(z_-pt.z_,2));
        }     
};

