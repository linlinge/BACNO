/**
 * @file KDTree.h
 * @author linlinge (you@domain.com)
 * @brief   We reference the website https://github.com/gishi523/kd-tree .
 * @version 0.1
 * @date 2022-10-24
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#pragma once
#include <iostream>
#include <vector>
#include <queue>
#include <MeshManagement.h>
using namespace std;
class BinaryNode
{
    public:
        int axis_;
		// the split 
        double pivot_;
        int num_of_pts_=0;
        bool is_leaf=false;
		int is_visited_=0;
        int idx_of_points_;
        union{
            struct{
                BinaryNode* lchild_, *rchild_;                
            };
            struct{
                BinaryNode* child_[2];
            };
        };
        
        BinaryNode* parent_=NULL;
        BinaryNode(){
            lchild_=rchild_=NULL;
        }
};

/* @brief Bounded priority queue.*/
template <class T, class Compare = std::less<T>>
class BoundedPriorityQueue
{
public:

    BoundedPriorityQueue() = delete;
    BoundedPriorityQueue(size_t bound) : bound_(bound) { elements_.reserve(bound + 1); };

    void push(const T& val)
    {
        auto it = std::find_if(std::begin(elements_), std::end(elements_),
            [&](const T& element){ return Compare()(val, element); });
        elements_.insert(it, val);

        if (elements_.size() > bound_)
            elements_.resize(bound_);
    }

    const T& back() const { return elements_.back(); };
    const T& operator[](size_t index) const { return elements_[index]; }
    size_t size() const { return elements_.size(); }

private:
    size_t bound_;
    std::vector<T> elements_;
};

/** @brief Priority queue of <distance, index> pair.
*/
using KnnQueue = BoundedPriorityQueue<std::pair<double, int>>;

template<class T>
class KDTree3D
{
    public:
        vector<T> points_;
        BinaryNode* root_=NULL;
        KDTree3D(){}
        ~KDTree3D(){
            if(root_!=NULL){
                queue<BinaryNode*> q;
                q.push(root_);
                while (q.size()!=0){
                    BinaryNode* f = q.front();
                    if (f->lchild_ != NULL) q.push(f->lchild_);   //如果子女不为空就加入子女，一会儿删除
                    if (f->rchild_ != NULL) q.push(f->rchild_);
                    delete f;                               //删除当前节点
                    q.pop();                                //把没用的指针弹出
                }
                root_ = NULL;
            }               
        }


        void SetInputCloud(vector<T>& idata){
            points_=idata;            
            // make sure dat has values
            if(idata.size()==0){
                cout<<"Error: the input data is empty!"<<endl;
            }

            // Init cloud
            root_=new BinaryNode();

            // create binary tree
			CreateTree(root_, idata);
        }

        int nnSearch(const T& query, double* minDist = nullptr)
		{
			int guess;
			double _minDist = std::numeric_limits<double>::max();

			nnSearchRecursive(query, root_, &guess, &_minDist);

			if (minDist)
				*minDist = _minDist;

			return guess;
		}

        std::tuple<vector<int>, vector<double>> knnSearch(T query, int k)
		{
			KnnQueue queue(k);
			knnSearchRecursive(query, root_, queue, k);
			
			vector<int> indices(queue.size());
            vector<double> dist(queue.size());
			for (int i = 0; i < queue.size(); i++){
                indices[i] = queue[i].second;
                dist[i]=queue[i].first;
            }
				
			return make_tuple(indices, dist);
		}
        
		tuple<vector<int>, vector<double>> radiusSearch(T& query, double radius)
		{
            typedef tuple<int,double> Pair;
            vector<Pair> idx_dist;
			radiusSearchRecursive(query, root_, idx_dist, radius);
            sort(idx_dist.begin(), idx_dist.end(), [](Pair& e1, Pair& e2){ return get<1>(e1) < get<1>(e2);});
           
            vector<int> idx(idx_dist.size());
            vector<double> dist(idx_dist.size());
            for(int i=0; i<idx_dist.size(); i++){
                idx[i]=get<0>(idx_dist[i]);
                dist[i]=get<1>(idx_dist[i]);
            }
			return make_tuple(idx, dist);
		}

    private:
        void knnSearchRecursive(T& query, BinaryNode* node, KnnQueue& queue, int k)
		{
			if (node==NULL)
				return;

			T& train = points_[node->idx_of_points_];

			double dist = DistanceOf(query, train);
			queue.push(std::make_pair(dist, node->idx_of_points_));

			const int axis = node->axis_;
            if(query.xyz_[axis]<train.xyz_[axis]){
                knnSearchRecursive(query, node->lchild_, queue, k);
                const double diff = fabs(query.xyz_[axis] - train.xyz_[axis]);
                if((int)queue.size() < k || diff < queue.back().first)
                    knnSearchRecursive(query, node->rchild_, queue, k);
            }
            else{
                knnSearchRecursive(query, node->rchild_, queue, k);
                const double diff = fabs(query.xyz_[axis] - train.xyz_[axis]);
                if((int)queue.size() < k || diff < queue.back().first)
                    knnSearchRecursive(query, node->lchild_, queue, k);
            }            
		}

        /** @brief Searches the nearest neighbor recursively.
		*/
		void nnSearchRecursive(T& query, BinaryNode* node, int *guess, double *minDist)
		{
			if (node == nullptr)
				return;

			T& train = points_[node->idx_of_points_];

			double dist = DistanceOf(query, train);
			if (dist < *minDist)
			{
				*minDist = dist;
				*guess = node->idx_of_points_;
			}

			int axis = node->axis_;
            if(query.xyz_[axis] < train.xyz_[axis]){
                nnSearchRecursive(query, node->lchild_, guess, minDist);
                const double diff = fabs(query.xyz_[axis] - train.xyz_[axis]);
                if (diff < *minDist)
                    nnSearchRecursive(query, node->rchild_, guess, minDist);
            }
            else{
                nnSearchRecursive(query, node->rchild_, guess, minDist);
                const double diff = fabs(query.xyz_[axis] - train.xyz_[axis]);
                if (diff < *minDist)
                    nnSearchRecursive(query, node->lchild_, guess, minDist);
            }            
		}

        /** @brief Searches neighbors within radius.
		*/
		void radiusSearchRecursive(T& query, BinaryNode* node, vector<tuple<int, double>>& idx_dist, double radius)
		{
			if(node == NULL)
				return;
			T& train = points_[node->idx_of_points_];
			double dist = DistanceOf(query, train);
			if (dist < radius){                
                idx_dist.push_back(make_tuple(node->idx_of_points_, dist));
            }

			int axis = node->axis_;            
            if(query.xyz_[axis] < train.xyz_[axis]){
                radiusSearchRecursive(query, node->lchild_, idx_dist, radius);
                double diff = train.xyz_[axis] - query.xyz_[axis];
                if (diff < radius)
                    radiusSearchRecursive(query, node->rchild_, idx_dist, radius);
            }
            else{
                radiusSearchRecursive(query, node->rchild_, idx_dist, radius);
                double diff = query.xyz_[axis] - train.xyz_[axis];
                if (diff < radius)
                    radiusSearchRecursive(query, node->lchild_, idx_dist, radius);
            }            
		}

        double DistanceOf(T& e1, T& e2)
        {            
            return e1.DistTo(e2);
        }

        /* binary tree manager */
        void CreateTree(BinaryNode* parent, vector<T>& pts)
        {   
			// stop recursive
			if(pts.size()==1){                
				parent->is_leaf=true;
				parent->idx_of_points_=pts[0].key_;	
                parent->axis_=0;
                parent->pivot_=pts[0].x_;
                return;			
			}
				
			// establish new node
			// obtain split dim 
			int split_axis=GetSplitDim(pts);
			parent->axis_=split_axis;

			// obtain split data
			vector<T> left, right;
			auto [split_idx, split_val]=SplitData(pts, split_axis, left, right);
			parent->pivot_=split_val;
            parent->idx_of_points_=split_idx;
			
			if(left.size()>0){	
				BinaryNode* new_node=new BinaryNode();	
				parent->lchild_=new_node;
				CreateTree(new_node, left);
			}

			if(right.size()>0){
				BinaryNode* new_node=new BinaryNode();
				parent->rchild_=new_node;
				CreateTree(new_node, right);
			}
        }

		int GetSplitDim(vector<T>& pts){            
            vector<double> pts_mean(3,0);
            vector<double> pts_variance(3,0);
            
            /* mean in each dimention */
            for(int i=0; i<pts.size(); i++){
                pts_mean[0]+=pts[i].x_;
                pts_mean[1]+=pts[i].y_;
                pts_mean[2]+=pts[i].z_;
            }
            pts_mean[0]/=pts.size();
            pts_mean[1]/=pts.size();
            pts_mean[2]/=pts.size();

            /* variance in each dimension */                
            for(int i=0; i<pts.size(); i++){                    
                pts_variance[0]+=pow(pts[i].x_-pts_mean[0],2);
                pts_variance[1]+=pow(pts[i].y_-pts_mean[1],2);
                pts_variance[2]+=pow(pts[i].z_-pts_mean[2],2);
            }
            pts_variance[0]/=pts.size();
            pts_variance[1]/=pts.size();
            pts_variance[2]/=pts.size();

            if(pts_variance[0]>=0 && pts_variance[1]==0 && pts_variance[2]==0){
                return 0;
            }
            else if(pts_variance[1]>=0 && pts_variance[0]==0 && pts_variance[2]==0){
                return 1;
            }
            else if(pts_variance[2]>=0 && pts_variance[0]==0 && pts_variance[1]==0){
                return 2;
            }
            else if(pts_variance[0]<pts_variance[1] && pts_variance[0]<pts_variance[2]){
                return 0;
            }
            else if(pts_variance[1]< pts_variance[0] && pts_variance[1]<pts_variance[2]){
                return 1;
            }
            else if(pts_variance[2]< pts_variance[0] && pts_variance[2]<pts_variance[1]){
                return 2;
            }
            else{
                cout<<"wokaka"<<endl;
            }                            
		}


		tuple<int, double> SplitData(vector<T> pts, int split_dim, vector<T>& left, vector<T>& right){
			class CMP{
				public:
					CMP(int select_dim):select_dim_(select_dim){}
				
					bool operator()(T e1, T e2){ 
                        if(select_dim_==0){
                            return e1.x_ < e2.x_;
                        }
						else if(select_dim_==1){
                            return e1.y_ <e2.y_;
                        }
                        else if(select_dim_==2){
                            return e1.z_ <e2.z_;
                        }
                        else{
                            cout<<"Error: select dimension error!"<<endl;
                        }
					}
				private:
					int select_dim_;
			};
				

			sort(pts.begin(), pts.end(), CMP(split_dim));
			int split_num=pts.size()/2;
            int split_idx=pts[split_num].key_;

			left.insert(left.end(), pts.begin(), pts.begin() + split_num);
			right.insert(right.end(), pts.begin()+split_num+1, pts.end());
            
			double split_val;
            if(split_dim==0)
                split_val = (pts[split_num-1].x_ + pts[split_num].x_)/2.0;
            else if(split_dim==1)
                split_val = (pts[split_num-1].y_ + pts[split_num].y_)/2.0;
            else if(split_dim==2)
                split_val = (pts[split_num-1].z_ + pts[split_num].z_)/2.0;
            
			return make_tuple(split_idx, split_val);
		}
};


template<class T>
class KDTree2D
{
    public:
        vector<T> points_;
        BinaryNode* root_=NULL;
        KDTree2D(){}
        ~KDTree2D(){
            if(root_!=NULL){
                queue<BinaryNode*> q;
                q.push(root_);
                while (q.size()!=0){
                    BinaryNode* f = q.front();
                    if (f->lchild_ != NULL) q.push(f->lchild_);   //如果子女不为空就加入子女，一会儿删除
                    if (f->rchild_ != NULL) q.push(f->rchild_);
                    delete f;                               //删除当前节点
                    q.pop();                                //把没用的指针弹出
                }
                root_ = NULL;
            }               
        }


        void SetInputCloud(vector<T>& idata){
            points_=idata;            
            // make sure dat has values
            if(idata.size()==0){
                cout<<"Error: the input data is empty!"<<endl;
            }

            // Init cloud
            root_=new BinaryNode();

            // create binary tree
			CreateTree(root_, idata);
        }

        int nnSearch(const T& query, double* minDist = nullptr)
		{
			int guess;
			double _minDist = std::numeric_limits<double>::max();

			nnSearchRecursive(query, root_, &guess, &_minDist);

			if (minDist)
				*minDist = _minDist;

			return guess;
		}

        std::tuple<vector<int>, vector<double>> knnSearch(T query, int k)
		{
			KnnQueue queue(k);
			knnSearchRecursive(query, root_, queue, k);
			
			vector<int> indices(queue.size());
            vector<double> dist(queue.size());
			for (int i = 0; i < queue.size(); i++){
                indices[i] = queue[i].second;
                dist[i]=queue[i].first;
            }
				
			return make_tuple(indices, dist);
		}
        
		tuple<vector<int>, vector<double>> radiusSearch(T query, double radius)
		{
            typedef tuple<int,double> Pair;
            vector<Pair> idx_dist;
			radiusSearchRecursive(query, root_, idx_dist, radius);
            sort(idx_dist.begin(), idx_dist.end(), [](Pair& e1, Pair& e2){ return get<1>(e1) < get<1>(e2);});
           
            vector<int> idx(idx_dist.size());
            vector<double> dist(idx_dist.size());
            for(int i=0; i<idx_dist.size(); i++){
                idx[i]=get<0>(idx_dist[i]);
                dist[i]=get<1>(idx_dist[i]);
            }
			return make_tuple(idx, dist);
		}

    private:
        void knnSearchRecursive(T& query, BinaryNode* node, KnnQueue& queue, int k)
		{
			if (node==NULL)
				return;

			T& train = points_[node->idx_of_points_];

			double dist = DistanceOf(query, train);
			queue.push(std::make_pair(dist, node->idx_of_points_));

			const int axis = node->axis_;           
            if(query.xy_[axis]<train.xy_[axis]){
                knnSearchRecursive(query, node->lchild_, queue, k);
                const double diff = fabs(query.xy_[axis] - train.xy_[axis]);
                if((int)queue.size() < k || diff < queue.back().first)
                    knnSearchRecursive(query, node->rchild_, queue, k);
            }
            else{
                knnSearchRecursive(query, node->rchild_, queue, k);
                const double diff = fabs(query.xy_[axis] - train.xy_[axis]);
                if((int)queue.size() < k || diff < queue.back().first)
                    knnSearchRecursive(query, node->lchild_, queue, k);
            }
		}

        /** @brief Searches the nearest neighbor recursively.
		*/
		void nnSearchRecursive(T& query, BinaryNode* node, int *guess, double *minDist)
		{
			if (node == nullptr)
				return;

			T& train = points_[node->idx_of_points_];

			double dist = DistanceOf(query, train);
			if (dist < *minDist)
			{
				*minDist = dist;
				*guess = node->idx_of_points_;
			}

			int axis = node->axis_;
            if(query.xy_[axis] < train.xy_[axis]){
                nnSearchRecursive(query, node->lchild_, guess, minDist);
                const double diff = fabs(query.xy_[axis] - train.xy_[axis]);
                if (diff < *minDist)
                    nnSearchRecursive(query, node->rchild_, guess, minDist);
            }
            else{
                nnSearchRecursive(query, node->rchild_, guess, minDist);
                const double diff = fabs(query.xy_[axis] - train.xy_[axis]);
                if (diff < *minDist)
                    nnSearchRecursive(query, node->lchild_, guess, minDist);
            }            		
		}

        /** @brief Searches neighbors within radius.
		*/
		void radiusSearchRecursive(T query, BinaryNode* node, vector<tuple<int, double>>& idx_dist, double radius)
		{
			if(node == NULL)
				return;
			T& train = points_[node->idx_of_points_];
			double dist = DistanceOf(query, train);
			if (dist < radius){                
                idx_dist.push_back(make_tuple(node->idx_of_points_, dist));
            }

			int axis = node->axis_;            
            if(query.xy_[axis] < train.xy_[axis]){
                radiusSearchRecursive(query, node->lchild_, idx_dist, radius);
                double diff = train.xy_[axis] - query.xy_[axis];
                if (diff < radius)
                    radiusSearchRecursive(query, node->rchild_, idx_dist, radius);
            }
            else{
                radiusSearchRecursive(query, node->rchild_, idx_dist, radius);
                double diff = query.xy_[axis] - train.xy_[axis];
                if (diff < radius)
                    radiusSearchRecursive(query, node->lchild_, idx_dist, radius);
            }            	
		}

        double DistanceOf(T& e1, T& e2)
        {            
            return e1.DistTo(e2);
        }

        /* binary tree manager */
        void CreateTree(BinaryNode* parent, vector<T>& pts)
        {   
			// stop recursive
			if(pts.size()==1){                
				parent->is_leaf=true;
				parent->idx_of_points_=pts[0].key_;	
                parent->axis_=0;
                parent->pivot_=pts[0].x_;
                return;			
			}
				
			// establish new node
			// obtain split dim 
			int split_axis=GetSplitDim(pts);
			parent->axis_=split_axis;

			// obtain split data
			vector<T> left, right;
			auto [split_idx, split_val]=SplitData(pts, split_axis, left, right);
			parent->pivot_=split_val;
            parent->idx_of_points_=split_idx;
			
			if(left.size()>0){	
				BinaryNode* new_node=new BinaryNode();	
				parent->lchild_=new_node;
				CreateTree(new_node, left);
			}

			if(right.size()>0){
				BinaryNode* new_node=new BinaryNode();
				parent->rchild_=new_node;
				CreateTree(new_node, right);
			}
        }

		int GetSplitDim(vector<T>& pts){
            vector<double> pts_mean(2,0);
            vector<double> pts_variance(2,0);
            
            /* mean in each dimention */
            for(int i=0; i<pts.size(); i++){
                pts_mean[0]+=pts[i].x_;
                pts_mean[1]+=pts[i].y_;                    
            }
            pts_mean[0]/=pts.size();
            pts_mean[1]/=pts.size();                

            /* variance in each dimension */                
            for(int i=0; i<pts.size(); i++){                    
                pts_variance[0]+=pow(pts[i].x_-pts_mean[0],2);
                pts_variance[1]+=pow(pts[i].y_-pts_mean[1],2);                    
            }
            pts_variance[0]/=pts.size();
            pts_variance[1]/=pts.size();                

            if(pts_variance[0]!=0 && pts_variance[1]==0){
                return 0;
            }
            else if(pts_variance[1]==0 && pts_variance[0]!=0){
                return 1;
            }
            else if(pts_variance[0] < pts_variance[1]){
                return 0;
            }
            else if(pts_variance[0] >= pts_variance[1]){
                return 1;
            }
            else{
                cout<<"Error: wrong variance!"<<endl;
            }                            
		}


		tuple<int, double> SplitData(vector<T> pts, int split_dim, vector<T>& left, vector<T>& right){
			class CMP{
				public:
					CMP(int select_dim):select_dim_(select_dim){}
				
					bool operator()(T e1, T e2){ 
                        if(select_dim_==0){
                            return e1.x_ < e2.x_;
                        }
						else if(select_dim_==1){
                            return e1.y_ <e2.y_;
                        }
                        else{
                            cout<<"Error: select dimension error!"<<endl;
                        }
					}
				private:
					int select_dim_;
			};
				

			sort(pts.begin(), pts.end(), CMP(split_dim));
			int split_num=pts.size()/2;
            int split_idx=pts[split_num].key_;

			left.insert(left.end(), pts.begin(), pts.begin() + split_num);
			right.insert(right.end(), pts.begin()+split_num+1, pts.end());
            
			double split_val;
            if(split_dim==0)
                split_val = (pts[split_num-1].x_ + pts[split_num].x_)/2.0;
            else if(split_dim==1)
                split_val = (pts[split_num-1].y_ + pts[split_num].y_)/2.0;
            
			return make_tuple(split_idx, split_val);
		}
};
