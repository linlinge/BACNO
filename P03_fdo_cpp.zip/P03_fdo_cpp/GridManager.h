#pragma once
#include <vector>
#include <fstream>
#include <V3.hpp>
#include <PCLExtend.h>
#include <VectorExtend.h>
#include <Geometry.h>
#include <LocalMeshGenerator.h>
#include <OBJManagement.h>
#include <Clustering.h>
#include <stdlib.h>
#include <FileExtend.h>
#include <GraphManagement.h>
#include <Config.h>

#define UNFLAG 100
#define OneSide 0
#define TheOtherSide 1
#define UNDETERMINED 2
#define BOUNDARY 3
using namespace std;

struct VXEdge
{
    int id_;
    int sid_;
    int tid_;
    float weight_;

    // 重载 == 运算符，用于 std::unique
    bool operator==(const VXEdge& other) const {
        return sid_ == other.sid_ && tid_ == other.tid_;
        return (sid_ == other.sid_ && tid_ == other.tid_) ||
               (sid_ == other.tid_ && tid_ == other.sid_);
    }

    // 重载 < 运算符，用于 std::sort
    bool operator<(const VXEdge& other) const {
        if (sid_ < other.sid_)
            return true;
        else if(sid_ == other.sid_){
            if(tid_ < other.tid_)
                return true;
            else 
                return false;
        }        
    }
};


class VoxelInfo: public AABB{
    public:
        V3 centre_;
        
        vector<int> id_of_corners_; 
        vector<vector<int>> lines_by_id_;
        vector<vector<int>> faces_by_id_;
        vector<int> pts_idx_;
        int level_;
        int flag_;
        vector<VoxelInfo*> child_, child_on_;    // pointer to child voxel, pointer to child voxel on surface
        vector<VoxelInfo*> connected_voxels_;
        vector<VoxelInfo*> connected_off_voxels_; 
        vector<VoxelInfo*> connected_on_voxels_; 

        VoxelInfo* pParent_;   
        vector<vector<int>> mc_triangulated_id_;           // idx for triangular
        vector<int> mc_edge_pts_id_;
        int id_on_=-1;
        int id_off_=-1;

        VoxelInfo(V3& bmin, V3& bmax, int level);
        VoxelInfo(V3& centre, float radius);
        VoxelInfo(){};
        void operator =(VoxelInfo& dat);
        vector<vector<int>> GenerateLines();
        vector<vector<int>> GenerateFaces();        
        vector<vector<float>> GenerateTwelveMiddlePoints();         
};

VoxelInfo* UnionVoxel(VoxelInfo* idata1, VoxelInfo* idata2);

class NarrowBandVoxels{
    public:
        vector<vector<VoxelInfo*>> dat_;
        vector<vector<VoxelInfo*>> dat_on_surface_; // parent on surface
        vector<vector<float>> corners_;        
       
        V3 bmin_,bmax_;
        int depth_; 
        int flag_are_cells_labelled_;           

        /* octree cloud */
        pcl::PointCloud<PointType>::Ptr cloud_octree_ = NULL;
        pcl::search::KdTree<PointType>::Ptr kdtree_octree_;

        /* raw cloud */
        pcl::PointCloud<PointType>::Ptr     cloud_=NULL;
        pcl::search::KdTree<PointType>::Ptr kdtree_;
        int num_of_pts_in_cloud_;

        /* on cloud */
        pcl::PointCloud<PointType>::Ptr     cloud_on_=NULL;
        pcl::search::KdTree<PointType>::Ptr kdtree_on_;    
        int num_of_pts_in_cloud_on_;
        

        /* off cloud */
        pcl::PointCloud<PointType>::Ptr     cloud_off_=NULL;
        pcl::search::KdTree<PointType>::Ptr kdtree_off_; 
        int num_of_pts_in_cloud_off_;

        /* border-aware & off cloud */
        pcl::PointCloud<PointType>::Ptr     cloud_regular_voxels_=NULL; // within narrow band
        pcl::search::KdTree<PointType>::Ptr kdtree_regular_voxels_;            

        /* on and off cloud */
        pcl::PointCloud<PointType>::Ptr     cloud_on_and_off_=NULL;
        pcl::search::KdTree<PointType>::Ptr kdtree_on_and_off_;
        int num_of_voxels_;
        VectorExtend<float> udf_of_cloud_on_and_off_;
        VectorExtend<float> min_udf_of_each_line_;
        float lower_thresh_udf_=0;
        float lower2_thresh_udf_=0;
        
        /* cloud of voxel corners */
        pcl::PointCloud<PointType>::Ptr     cloud_corners_; // cloud of corners of voxels        
        pcl::search::KdTree<PointType>::Ptr kdtree_corners_; // kdtree of corners of voxels



        vector<int> idx_on_in_self_, idx_off_in_self_, idx_on_in_all_, idx_off_in_all_, idx2_on_in_all_;   
        vector<V3> drct_;              
        vector<vector<float>> mc_edge_pts_;
        vector<vector<float>> cloud_xyz_, cloud_nrm_;
        vector<vector<int>> off_surface_adjacent_list_26_;
        //  off_surface_adjacent_list_6_;
        vector<int> gt_labels_;
        float voxel_size_;
        ofstream fout;
        float mean_dist_, max_dist_, min_dist_;
        
        /* edge point cloud */
        pcl::PointCloud<PointType>::Ptr cloud_edge_;        
        pcl::search::KdTree<PointType>::Ptr kdtree_edge_;   
        int num_of_pts_in_cloud_edge_;     

        /* cloud border voxels */
        pcl::PointCloud<PointType>::Ptr cloud_border_voxels_;        
        pcl::search::KdTree<PointType>::Ptr kdtree_border_voxels_;   

        CloudProperties cp_raw_;    
        string opath_;    

        float narrow_band_lower_threshold_ = INT_MAX;
        float narrow_band_upper_threshold_ = INT_MAX;

    public:
    /* Function Section */
        /* Basic */
        NarrowBandVoxels(){
            cloud_ = pcl::PointCloud<PointType>::Ptr(new pcl::PointCloud<PointType>);
            kdtree_ = pcl::search::KdTree<PointType>::Ptr(new pcl::search::KdTree<PointType>);
            cloud_edge_ = pcl::PointCloud<PointType>::Ptr(new pcl::PointCloud<PointType>);  
            kdtree_edge_ = pcl::search::KdTree<PointType>::Ptr(new pcl::search::KdTree<PointType>);
            cloud_on_ = pcl::PointCloud<PointType>::Ptr(new pcl::PointCloud<PointType>);
            kdtree_on_ = pcl::search::KdTree<PointType>::Ptr(new pcl::search::KdTree<PointType>);
            cloud_off_ = pcl::PointCloud<PointType>::Ptr(new pcl::PointCloud<PointType>);
            kdtree_off_ = pcl::search::KdTree<PointType>::Ptr(new pcl::search::KdTree<PointType>);
            cloud_regular_voxels_ = pcl::PointCloud<PointType>::Ptr(new pcl::PointCloud<PointType>);
            kdtree_regular_voxels_ = pcl::search::KdTree<PointType>::Ptr(new pcl::search::KdTree<PointType>);
            cloud_border_voxels_ = pcl::PointCloud<PointType>::Ptr(new pcl::PointCloud<PointType>);
            kdtree_border_voxels_ = pcl::search::KdTree<PointType>::Ptr(new pcl::search::KdTree<PointType>);
        }

        /* Init */
        void InitNarrowBandVoxels(int depth);

        /* Create */
        void CreateConnectedOffVoxel();
        void CreateRepCloud();
        void CreateCloudOnAndOff();                     
        
        /* Set */
        void SetInputCloud(vector<vector<float>> cloud_xyz, vector<vector<float>> cloud_nrm={});
        void SetInputCloud(string path);
        void SetDwnCloud(string path);
        void SetEdgeCloud(string path);
        void SetPrefix(string prefix);
        void SetOpath(string opath);
        

        /* Extract */
        void ExtractCloudOff(string path); 
        void ExtractCloudOn(string path); 
        void ExtractCloud_BorderVoxels();
        void ExtractCloud_RegularVoxels();
        void ExtractBorderAwareNarrowBandVoxels_RegularVoxels();    
        void ExtractBorderAwareNarrowBandVoxels_BorderVoxels();        
        void ExtractNarrowBandVoxels(string path);        
        void ExtractAdjacent(string path);  
        
        /* Query */
        int  QueryIntersectVoxelWithRay_Fast(Ray ry);
        int  QueryIntersectVoxelWithLineSegment_Fast(LineSegment ls);
        bool QueryIntersectVoxelWithLineSegment_BruteForce_First(LineSegment ls);
        std::tuple<bool, float> QueryIntersectWithBandWidth(LineSegment ls, int num_of_splitting_segments);
        

        /* Get */
        vector<vector<float>> GetCornersOfNarrowBandGrid();
        vector<vector<int>>   GetLinesOfNarrowBandGrid();   // GetCornersOfNarrowBandGrid -> GetLinesOfNarrowBandGrid
        vector<vector<int>>   GetFacesOfNarrowBandGrid();   // GetCornersOfNarrowBandGrid -> GetFacesOfNarrowBandGrid
        vector<int>           GetCellsStatus();
        vector<vector<float>> GetColorsOfNarrowBandGrid();  // LabelCellsByGTNormal -> GetColorsOfNarrowBandGrid
        vector<vector<float>> GetMaximumCorners();          
        tuple<vector<float>, vector<float>> GetRay();         
        vector<vector<float>> GetOffCloud();
        float GetGridSize();
        float GetMahalanobisDistance(V3 current_pt, int k);
        int   GetIndexInCloudOff(V3 pt);

        
        /* find idx by point */
        void FindPointIdx(vector<float> pt);

        /* delaunay triangulation */        
        int IsIntersect(Ray ry, int i);
        void WhetherIntersect();        
        // void GenerateMarchingCubeEdgePoints();

        /* */
        vector<vector<float>> GetOffVoxelRepresentationCloud();

        /* Optional */
        void CollectNearestInfo();
        void LabelCellsByGTNormal();
        void CreatePointIdx();        
        tuple<int,vector<int>> IsTheVoxelInside(int idx);                      // CreateIndicesOnAndOff -> Get_One_IsIntersect_fast

        /* others */
        std::tuple<vector<float>, vector<float>, vector<float>> GetCell(int level, int idx);
        void CorrectBoxMinMax(V3& dmin, V3& dmax);
        void WriteVoxels();

    
        /* discard */
        vector<vector<int>> QueryIntersectVoxelWithRay(vector<float> pt1, vector<float> pt2);   // Query by traverse, discard becase it quite slow
        void WriteVoxels(string path);

    private:        
        VoxelInfo* CreateNarrowBandGrid(V3 bmin, V3 bmax, int level);
        void CreateNarrowBandGrid_Parallel(V3 bmin, V3 bmax);
        void CreateBorderAwareNarrowBand(); // CreateNarrowBandGrid_Parallel -> CreateBorderAwareNarrowBand
        void CreateZeroBandGrid();          // CreateNarrowBandGrid -> CreatePointIdx -> CreateZeroBandGrid           
        void ExpandBoundingBox(PointType minPt, PointType maxPt);
        void CreateCornersOfNarrowBandGrid();
        void CreateLinesOfNarrowBandGrid();                     
        int  CountValid(vector<float> dat, float& eps);
        void CreateConnectedGraph();    // create connected graph
        tuple<float,float,float> GetSideLengthOfVoxel();
        string out_prefix_;   
        float x_spacing_, y_spacing_, z_spacing_;    
        float length_of_voxel_diagonal_;  
        vector<VXEdge*> vx_edges_;  
};
