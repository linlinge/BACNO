#pragma once
#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/connected_components.hpp>
#include <PCLExtend.h>
#include <iostream>
#include <vector>
using namespace std;

// Define the graph using adjacency_list
typedef boost::adjacency_list<boost::vecS, boost::vecS, boost::undirectedS> BoostGraph;
typedef boost::graph_traits<BoostGraph>::edge_descriptor BoostEdge;

vector<vector<int>> GetConnectedComponents(pcl::PointCloud<PointType>::Ptr cloud);