myexe="/media/i9/gamma/workspace/P03_fdo_cpp/build/fdo_cpp --fun compute_accuracy "


# root="/media/i9/phi/experiment_nc/1_special_cases/1_anti_noise_test/ratio_0d00_mag_0d005"
# ${myexe} --ipath_of_gt ${root}/0_Raw/bunny_noise.ply     --ipath_of_correct ${root}/1_Disturbed/8_sno/bunny_sno.ply
# ${myexe} --ipath_of_gt ${root}/0_Raw/stl001_noise.ply    --ipath_of_correct ${root}/1_Disturbed/8_sno/stl001_sno.ply

# root="/media/i9/phi/experiment_nc/1_special_cases/1_anti_noise_test/ratio_0d25_mag_0d005"
# ${myexe} --ipath_of_gt ${root}/0_Raw/bunny_noise.ply     --ipath_of_correct ${root}/1_Disturbed/8_sno/bunny_sno.ply
# ${myexe} --ipath_of_gt ${root}/0_Raw/stl001_noise.ply    --ipath_of_correct ${root}/1_Disturbed/8_sno/stl001_sno.ply

# root="/media/i9/phi/experiment_nc/1_special_cases/1_anti_noise_test/ratio_0d50_mag_0d005"
# ${myexe} --ipath_of_gt ${root}/0_Raw/bunny_noise.ply     --ipath_of_correct ${root}/1_Disturbed/8_sno/bunny_sno.ply
# ${myexe} --ipath_of_gt ${root}/0_Raw/stl001_noise.ply    --ipath_of_correct ${root}/1_Disturbed/8_sno/stl001_sno.ply

# root="/media/i9/phi/experiment_nc/1_special_cases/1_anti_noise_test/ratio_0d75_mag_0d005"
# ${myexe} --ipath_of_gt ${root}/0_Raw/bunny_noise.ply     --ipath_of_correct ${root}/1_Disturbed/8_sno/bunny_sno.ply
# ${myexe} --ipath_of_gt ${root}/0_Raw/stl001_noise.ply    --ipath_of_correct ${root}/1_Disturbed/8_sno/stl001_sno.ply

# root="/media/i9/phi/experiment_nc/1_special_cases/1_anti_noise_test/ratio_1d00_mag_0d005"
# ${myexe} --ipath_of_gt ${root}/0_Raw/bunny_noise.ply     --ipath_of_correct ${root}/1_Disturbed/8_sno/bunny_sno.ply
# ${myexe} --ipath_of_gt ${root}/0_Raw/stl001_noise.ply    --ipath_of_correct ${root}/1_Disturbed/8_sno/stl001_sno.ply


root="/media/i9/phi/experiment_nc/1_special_cases/3_data_sparsity"
path_of_correct="/media/i9/phi/experiment_nc/1_special_cases/3_data_sparsity/disturbed/8_sno"
${myexe} --ipath_of_gt ${root}/cute_triceratops.ply     --ipath_of_correct ${path_of_correct}/cute_triceratops_correct_sno.ply
${myexe} --ipath_of_gt ${root}/decoration.ply           --ipath_of_correct ${path_of_correct}/decoration_correct_sno.ply



# root_of_gt="/media/i9/phi/experiment_nc/2_accuracy_performance/stanford_noise_bdry/GroundTruth"
# root_of_correct="/media/i9/phi/experiment_nc/2_accuracy_performance/stanford_noise_bdry/Raw_noise_bdry/bdry/results/6_ipsr"
# ${myexe} --ipath_of_gt ${root_of_gt}/Armadillo_noise.ply              --ipath_of_correct ${root_of_correct}/Armadillo_noise_renorm_bdry_correct_sno.ply         
# ${myexe} --ipath_of_gt ${root_of_gt}/bunny_sampling_noise.ply         --ipath_of_correct ${root_of_correct}/bunny_sampling_noise_renorm_bdry_correct_sno.ply    
# ${myexe} --ipath_of_gt ${root_of_gt}/dragon_sampling_noise.ply        --ipath_of_correct ${root_of_correct}/dragon_sampling_noise_renorm_bdry_correct_sno.ply   
# ${myexe} --ipath_of_gt ${root_of_gt}/hand_noise.ply                   --ipath_of_correct ${root_of_correct}/hand_pts_noise_renorm_bdry_correct_sno.ply          
# ${myexe} --ipath_of_gt ${root_of_gt}/happy_noise.ply                  --ipath_of_correct ${root_of_correct}/happy_vrip_noise_renorm_bdry_correct_sno.ply        
# ${myexe} --ipath_of_gt ${root_of_gt}/horse_sampling_noise.ply         --ipath_of_correct ${root_of_correct}/horse_sampling_noise_renorm_bdry_correct_sno.ply    
# ${myexe} --ipath_of_gt ${root_of_gt}/lucy_noise.ply                   --ipath_of_correct ${root_of_correct}/lucy_noise_renorm_bdry_correct_sno.ply              
# ${myexe} --ipath_of_gt ${root_of_gt}/statuette_sampling_noise.ply     --ipath_of_correct ${root_of_correct}/statuette_sampling_noise_renorm_bdry_correct_sno.ply


  
              



# root_of_gt="/media/i9/phi/experiment_nc/2_accuracy_performance/ThreeDScans_noise_bdry/GroundTruth"
# root_of_correct="/media/i9/phi/experiment_nc/2_accuracy_performance/ThreeDScans_noise_bdry/Raw/bdry/results/8_sno"
# ${myexe} --ipath_of_gt ${root_of_gt}/Alfred_Jacquemart_noise.ply                 --ipath_of_correct ${root_of_correct}/Alfred_Jacquemart_noise_renorm_bdry_correct_sno.ply             
# ${myexe} --ipath_of_gt ${root_of_gt}/Blue_Sea_Star_sampling_noise.ply            --ipath_of_correct ${root_of_correct}/Blue_Sea_Star_sampling_noise_renorm_bdry_correct_sno.ply        
# ${myexe} --ipath_of_gt ${root_of_gt}/Dark_Finger_Reef_Crab_sampling_noise.ply    --ipath_of_correct ${root_of_correct}/Dark_Finger_Reef_Crab_sampling_noise_renorm_bdry_correct_sno.ply
# ${myexe} --ipath_of_gt ${root_of_gt}/Eagle_sampling_noise.ply                    --ipath_of_correct ${root_of_correct}/Eagle_sampling_noise_renorm_bdry_correct_sno.ply                
# ${myexe} --ipath_of_gt ${root_of_gt}/Ghost_Crab_noise.ply                        --ipath_of_correct ${root_of_correct}/Ghost_Crab_noise_renorm_bdry_correct_sno.ply                    
# ${myexe} --ipath_of_gt ${root_of_gt}/Henri_IV_Enfant_noise.ply                   --ipath_of_correct ${root_of_correct}/Henri_IV_Enfant_noise_renorm_bdry_correct_sno.ply               
# ${myexe} --ipath_of_gt ${root_of_gt}/Hunde_Paar_noise.ply                        --ipath_of_correct ${root_of_correct}/Hunde_Paar_noise_renorm_bdry_correct_sno.ply                    
# ${myexe} --ipath_of_gt ${root_of_gt}/Murex_Romosus_sampling_noise.ply            --ipath_of_correct ${root_of_correct}/Murex_Romosus_sampling_noise_renorm_bdry_correct_sno.ply        
# ${myexe} --ipath_of_gt ${root_of_gt}/Puck_on_Toadstool_sampling_noise.ply        --ipath_of_correct ${root_of_correct}/Puck_on_Toadstool_sampling_noise_renorm_bdry_correct_sno.ply    
# ${myexe} --ipath_of_gt ${root_of_gt}/Scallop_noise.ply                           --ipath_of_correct ${root_of_correct}/Scallop_noise_renorm_bdry_correct_sno.ply                       
# ${myexe} --ipath_of_gt ${root_of_gt}/Willy_Selke_Tondo_sampling_noise.ply        --ipath_of_correct ${root_of_correct}/Willy_Selke_Tondo_sampling_noise_renorm_bdry_correct_sno.ply    
# ${myexe} --ipath_of_gt ${root_of_gt}/Xenophora_noise.ply                         --ipath_of_correct ${root_of_correct}/Xenophora_noise_renorm_bdry_correct_sno.ply    


                    

        

# root_of_gt="/media/i9/phi/experiment_nc/2_accuracy_performance/DTU/Raw/out"
# root_of_correct="/media/i9/phi/experiment_nc/2_accuracy_performance/DTU/Disturbed/8_sno"
# ${myexe} --ipath_of_gt ${root_of_gt}/stl001.ply    --ipath_of_correct ${root_of_correct}/stl001_correct_sno.ply
# ${myexe} --ipath_of_gt ${root_of_gt}/stl006.ply    --ipath_of_correct ${root_of_correct}/stl006_correct_sno.ply
# ${myexe} --ipath_of_gt ${root_of_gt}/stl013.ply    --ipath_of_correct ${root_of_correct}/stl013_correct_sno.ply
# ${myexe} --ipath_of_gt ${root_of_gt}/stl014.ply    --ipath_of_correct ${root_of_correct}/stl014_correct_sno.ply
# ${myexe} --ipath_of_gt ${root_of_gt}/stl019.ply    --ipath_of_correct ${root_of_correct}/stl019_correct_sno.ply
# ${myexe} --ipath_of_gt ${root_of_gt}/stl024.ply    --ipath_of_correct ${root_of_correct}/stl024_correct_sno.ply
# ${myexe} --ipath_of_gt ${root_of_gt}/stl030.ply    --ipath_of_correct ${root_of_correct}/stl030_correct_sno.ply
# ${myexe} --ipath_of_gt ${root_of_gt}/stl040.ply    --ipath_of_correct ${root_of_correct}/stl040_correct_sno.ply
# ${myexe} --ipath_of_gt ${root_of_gt}/stl041.ply    --ipath_of_correct ${root_of_correct}/stl041_correct_sno.ply
# ${myexe} --ipath_of_gt ${root_of_gt}/stl046.ply    --ipath_of_correct ${root_of_correct}/stl046_correct_sno.ply
# ${myexe} --ipath_of_gt ${root_of_gt}/stl048.ply    --ipath_of_correct ${root_of_correct}/stl048_correct_sno.ply
# ${myexe} --ipath_of_gt ${root_of_gt}/stl084.ply    --ipath_of_correct ${root_of_correct}/stl084_correct_sno.ply
# ${myexe} --ipath_of_gt ${root_of_gt}/stl089.ply    --ipath_of_correct ${root_of_correct}/stl089_correct_sno.ply
# ${myexe} --ipath_of_gt ${root_of_gt}/stl106.ply    --ipath_of_correct ${root_of_correct}/stl106_correct_sno.ply
