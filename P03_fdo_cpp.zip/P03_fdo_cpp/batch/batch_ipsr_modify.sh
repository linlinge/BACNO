# myexe="/media/i9/gamma/workspace/P03_fdo_cpp/build/fdo_cpp --fun ipsr_modify "
# path_of_disturbed="--ipath_of_disturbed /media/i9/phi/experiment_nc/2_accuracy_performance/DTU/Disturbed"
# path_of_raw="--ipath_of_raw /media/i9/phi/experiment_nc/2_accuracy_performance/DTU/Disturbed/6_ipsr/origin"
# path_of_opath="--opath_of_correct /media/i9/phi/experiment_nc/2_accuracy_performance/DTU/Disturbed/6_ipsr"

# ${myexe} ${path_of_disturbed}/stl001_disturbed.ply ${path_of_raw}/stl001_ipsr.ply   ${path_of_opath}/stl001_ipsr.ply
# ${myexe} ${path_of_disturbed}/stl006_disturbed.ply ${path_of_raw}/stl006_ipsr.ply   ${path_of_opath}/stl006_ipsr.ply
# ${myexe} ${path_of_disturbed}/stl013_disturbed.ply ${path_of_raw}/stl013_ipsr.ply   ${path_of_opath}/stl013_ipsr.ply
# ${myexe} ${path_of_disturbed}/stl014_disturbed.ply ${path_of_raw}/stl014_ipsr.ply   ${path_of_opath}/stl014_ipsr.ply
# ${myexe} ${path_of_disturbed}/stl019_disturbed.ply ${path_of_raw}/stl019_ipsr.ply   ${path_of_opath}/stl019_ipsr.ply
# ${myexe} ${path_of_disturbed}/stl024_disturbed.ply ${path_of_raw}/stl024_ipsr.ply   ${path_of_opath}/stl024_ipsr.ply
# ${myexe} ${path_of_disturbed}/stl030_disturbed.ply ${path_of_raw}/stl030_ipsr.ply   ${path_of_opath}/stl030_ipsr.ply
# ${myexe} ${path_of_disturbed}/stl040_disturbed.ply ${path_of_raw}/stl040_ipsr.ply   ${path_of_opath}/stl040_ipsr.ply
# ${myexe} ${path_of_disturbed}/stl041_disturbed.ply ${path_of_raw}/stl041_ipsr.ply   ${path_of_opath}/stl041_ipsr.ply
# ${myexe} ${path_of_disturbed}/stl046_disturbed.ply ${path_of_raw}/stl046_ipsr.ply   ${path_of_opath}/stl046_ipsr.ply
# ${myexe} ${path_of_disturbed}/stl048_disturbed.ply ${path_of_raw}/stl048_ipsr.ply   ${path_of_opath}/stl048_ipsr.ply
# ${myexe} ${path_of_disturbed}/stl084_disturbed.ply ${path_of_raw}/stl084_ipsr.ply   ${path_of_opath}/stl084_ipsr.ply
# ${myexe} ${path_of_disturbed}/stl089_disturbed.ply ${path_of_raw}/stl089_ipsr.ply   ${path_of_opath}/stl089_ipsr.ply
# ${myexe} ${path_of_disturbed}/stl106_disturbed.ply ${path_of_raw}/stl106_ipsr.ply   ${path_of_opath}/stl106_ipsr.ply


# myexe="/media/i9/gamma/workspace/P03_fdo_cpp/build/fdo_cpp --fun ipsr_modify "
# path_of_disturbed="--ipath_of_disturbed /media/i9/phi/experiment_nc/2_accuracy_performance/ThreeDScans_noise_bdry/Raw/bdry"
# path_of_raw="--ipath_of_raw /media/i9/phi/experiment_nc/2_accuracy_performance/ThreeDScans_noise_bdry/Raw/bdry/results/6_ipsr/origin"
# path_of_opath="--opath_of_correct /media/i9/phi/experiment_nc/2_accuracy_performance/ThreeDScans_noise_bdry/Raw/bdry/results/6_ipsr"

# ${myexe} ${path_of_disturbed}/Alfred_Jacquemart_noise_renorm_bdry.ply              ${path_of_raw}/Alfred_Jacquemart_noise_renorm_bdry_ipsr.ply                ${path_of_opath}/Alfred_Jacquemart_noise_renorm_bdry_ipsr.ply             
# ${myexe} ${path_of_disturbed}/Blue_Sea_Star_sampling_noise_renorm_bdry.ply         ${path_of_raw}/Blue_Sea_Star_sampling_noise_renorm_bdry_ipsr.ply           ${path_of_opath}/Blue_Sea_Star_sampling_noise_renorm_bdry_ipsr.ply        
# ${myexe} ${path_of_disturbed}/Dark_Finger_Reef_Crab_sampling_noise_renorm_bdry.ply ${path_of_raw}/Dark_Finger_Reef_Crab_sampling_noise_renorm_bdry_ipsr.ply   ${path_of_opath}/Dark_Finger_Reef_Crab_sampling_noise_renorm_bdry_ipsr.ply
# ${myexe} ${path_of_disturbed}/Eagle_sampling_noise_renorm_bdry.ply                 ${path_of_raw}/Eagle_sampling_noise_renorm_bdry_ipsr.ply                   ${path_of_opath}/Eagle_sampling_noise_renorm_bdry_ipsr.ply                
# ${myexe} ${path_of_disturbed}/Ghost_Crab_noise_renorm_bdry.ply                     ${path_of_raw}/Ghost_Crab_noise_renorm_bdry_ipsr.ply                       ${path_of_opath}/Ghost_Crab_noise_renorm_bdry_ipsr.ply                    
# ${myexe} ${path_of_disturbed}/Henri_IV_Enfant_noise_renorm_bdry.ply                ${path_of_raw}/Henri_IV_Enfant_noise_renorm_bdry_ipsr.ply                  ${path_of_opath}/Henri_IV_Enfant_noise_renorm_bdry_ipsr.ply               
# ${myexe} ${path_of_disturbed}/Hunde_Paar_noise_renorm_bdry.ply                     ${path_of_raw}/Hunde_Paar_noise_renorm_bdry_ipsr.ply                       ${path_of_opath}/Hunde_Paar_noise_renorm_bdry_ipsr.ply                    
# ${myexe} ${path_of_disturbed}/Murex_Romosus_sampling_noise_renorm_bdry.ply         ${path_of_raw}/Murex_Romosus_sampling_noise_renorm_bdry_ipsr.ply           ${path_of_opath}/Murex_Romosus_sampling_noise_renorm_bdry_ipsr.ply        
# ${myexe} ${path_of_disturbed}/Puck_on_Toadstool_sampling_noise_renorm_bdry.ply     ${path_of_raw}/Puck_on_Toadstool_sampling_noise_renorm_bdry_ipsr.ply       ${path_of_opath}/Puck_on_Toadstool_sampling_noise_renorm_bdry_ipsr.ply    
# ${myexe} ${path_of_disturbed}/Scallop_noise_renorm_bdry.ply                        ${path_of_raw}/Scallop_noise_renorm_bdry_ipsr.ply                          ${path_of_opath}/Scallop_noise_renorm_bdry_ipsr.ply                       
# ${myexe} ${path_of_disturbed}/Willy_Selke_Tondo_sampling_noise_renorm_bdry.ply     ${path_of_raw}/Willy_Selke_Tondo_sampling_noise_renorm_bdry_ipsr.ply       ${path_of_opath}/Willy_Selke_Tondo_sampling_noise_renorm_bdry_ipsr.ply    
# ${myexe} ${path_of_disturbed}/Xenophora_noise_renorm_bdry.ply                      ${path_of_raw}/Xenophora_noise_renorm_bdry_ipsr.ply                        ${path_of_opath}/Xenophora_noise_renorm_bdry_ipsr.ply



myexe="/media/i9/gamma/workspace/P03_fdo_cpp/build/fdo_cpp --fun ipsr_modify "
path_of_disturbed="--ipath_of_disturbed /media/i9/phi/experiment_nc/2_accuracy_performance/ThreeDScans_noise_bdry/Raw/bdry"
path_of_raw="--ipath_of_raw /media/i9/phi/experiment_nc/2_accuracy_performance/ThreeDScans_noise_bdry/Raw/bdry/results/8_sno/tf"
path_of_opath="--opath_of_correct /media/i9/phi/experiment_nc/2_accuracy_performance/ThreeDScans_noise_bdry/Raw/bdry/results/8_sno"

${myexe} ${path_of_disturbed}/Alfred_Jacquemart_noise_renorm_bdry.ply               ${path_of_raw}/Alfred_Jacquemart_noise_renorm_bdry_correct_sno.ply                ${path_of_opath}/Alfred_Jacquemart_noise_renorm_bdry_correct_sno.ply             
${myexe} ${path_of_disturbed}/Blue_Sea_Star_sampling_noise_renorm_bdry.ply          ${path_of_raw}/Blue_Sea_Star_sampling_noise_renorm_bdry_correct_sno.ply           ${path_of_opath}/Blue_Sea_Star_sampling_noise_renorm_bdry_correct_sno.ply        
${myexe} ${path_of_disturbed}/Dark_Finger_Reef_Crab_sampling_noise_renorm_bdry.ply  ${path_of_raw}/Dark_Finger_Reef_Crab_sampling_noise_renorm_bdry_correct_sno.ply   ${path_of_opath}/Dark_Finger_Reef_Crab_sampling_noise_renorm_bdry_correct_sno.ply
${myexe} ${path_of_disturbed}/Eagle_sampling_noise_renorm_bdry.ply                  ${path_of_raw}/Eagle_sampling_noise_renorm_bdry_correct_sno.ply                   ${path_of_opath}/Eagle_sampling_noise_renorm_bdry_correct_sno.ply                
${myexe} ${path_of_disturbed}/Ghost_Crab_noise_renorm_bdry.ply                      ${path_of_raw}/Ghost_Crab_noise_renorm_bdry_correct_sno.ply                       ${path_of_opath}/Ghost_Crab_noise_renorm_bdry_correct_sno.ply                    
${myexe} ${path_of_disturbed}/Henri_IV_Enfant_noise_renorm_bdry.ply                 ${path_of_raw}/Henri_IV_Enfant_noise_renorm_bdry_correct_sno.ply                  ${path_of_opath}/Henri_IV_Enfant_noise_renorm_bdry_correct_sno.ply               
${myexe} ${path_of_disturbed}/Hunde_Paar_noise_renorm_bdry.ply                      ${path_of_raw}/Hunde_Paar_noise_renorm_bdry_correct_sno.ply                       ${path_of_opath}/Hunde_Paar_noise_renorm_bdry_correct_sno.ply                    
${myexe} ${path_of_disturbed}/Murex_Romosus_sampling_noise_renorm_bdry.ply          ${path_of_raw}/Murex_Romosus_sampling_noise_renorm_bdry_correct_sno.ply           ${path_of_opath}/Murex_Romosus_sampling_noise_renorm_bdry_correct_sno.ply        
${myexe} ${path_of_disturbed}/Puck_on_Toadstool_sampling_noise_renorm_bdry.ply      ${path_of_raw}/Puck_on_Toadstool_sampling_noise_renorm_bdry_correct_sno.ply       ${path_of_opath}/Puck_on_Toadstool_sampling_noise_renorm_bdry_correct_sno.ply    
${myexe} ${path_of_disturbed}/Scallop_noise_renorm_bdry.ply                         ${path_of_raw}/Scallop_noise_renorm_bdry_correct_sno.ply                          ${path_of_opath}/Scallop_noise_renorm_bdry_correct_sno.ply                       
${myexe} ${path_of_disturbed}/Willy_Selke_Tondo_sampling_noise_renorm_bdry.ply      ${path_of_raw}/Willy_Selke_Tondo_sampling_noise_renorm_bdry_correct_sno.ply       ${path_of_opath}/Willy_Selke_Tondo_sampling_noise_renorm_bdry_correct_sno.ply    
${myexe} ${path_of_disturbed}/Xenophora_noise_renorm_bdry.ply                       ${path_of_raw}/Xenophora_noise_renorm_bdry_correct_sno.ply                        ${path_of_opath}/Xenophora_noise_renorm_bdry_correct_sno.ply


                  

      
# myexe="/media/i9/gamma/workspace/P03_fdo_cpp/build/fdo_cpp --fun ipsr_modify "
# path_of_disturbed="--ipath_of_disturbed /media/i9/phi/experiment_nc/2_accuracy_performance/ThreeDScans_noise_bdry/Raw/bdry"
# path_of_raw="--ipath_of_raw /media/i9/phi/experiment_nc/2_accuracy_performance/stanford_noise_bdry/Raw_noise_bdry/bdry/results/5_dpgo/origin"
# path_of_opath="--opath_of_correct /media/i9/phi/experiment_nc/2_accuracy_performance/ThreeDScans_noise_bdry/Raw/bdry/results/3_dipole"

# ${myexe} ${path_of_disturbed}/Alfred_Jacquemart_noise_renorm_bdry.ply               ${path_of_raw}/Alfred_Jacquemart_noise_renorm_bdry_correct_dipole.ply                ${path_of_opath}/Alfred_Jacquemart_noise_renorm_bdry_correct_dipole.ply             
# ${myexe} ${path_of_disturbed}/Blue_Sea_Star_sampling_noise_renorm_bdry.ply          ${path_of_raw}/Blue_Sea_Star_sampling_noise_renorm_bdry_correct_dipole.ply           ${path_of_opath}/Blue_Sea_Star_sampling_noise_renorm_bdry_correct_dipole.ply        
# ${myexe} ${path_of_disturbed}/Dark_Finger_Reef_Crab_sampling_noise_renorm_bdry.ply  ${path_of_raw}/Dark_Finger_Reef_Crab_sampling_noise_renorm_bdry_correct_dipole.ply   ${path_of_opath}/Dark_Finger_Reef_Crab_sampling_noise_renorm_bdry_correct_dipole.ply
# ${myexe} ${path_of_disturbed}/Eagle_sampling_noise_renorm_bdry.ply                  ${path_of_raw}/Eagle_sampling_noise_renorm_bdry_correct_dipole.ply                   ${path_of_opath}/Eagle_sampling_noise_renorm_bdry_correct_dipole.ply                
# ${myexe} ${path_of_disturbed}/Ghost_Crab_noise_renorm_bdry.ply                      ${path_of_raw}/Ghost_Crab_noise_renorm_bdry_correct_dipole.ply                       ${path_of_opath}/Ghost_Crab_noise_renorm_bdry_correct_dipole.ply                    
# ${myexe} ${path_of_disturbed}/Henri_IV_Enfant_noise_renorm_bdry.ply                 ${path_of_raw}/Henri_IV_Enfant_noise_renorm_bdry_correct_dipole.ply                  ${path_of_opath}/Henri_IV_Enfant_noise_renorm_bdry_correct_dipole.ply               
# ${myexe} ${path_of_disturbed}/Hunde_Paar_noise_renorm_bdry.ply                      ${path_of_raw}/Hunde_Paar_noise_renorm_bdry_correct_dipole.ply                       ${path_of_opath}/Hunde_Paar_noise_renorm_bdry_correct_dipole.ply                    
# ${myexe} ${path_of_disturbed}/Murex_Romosus_sampling_noise_renorm_bdry.ply          ${path_of_raw}/Murex_Romosus_sampling_noise_renorm_bdry_correct_dipole.ply           ${path_of_opath}/Murex_Romosus_sampling_noise_renorm_bdry_correct_dipole.ply        
# ${myexe} ${path_of_disturbed}/Puck_on_Toadstool_sampling_noise_renorm_bdry.ply      ${path_of_raw}/Puck_on_Toadstool_sampling_noise_renorm_bdry_correct_dipole.ply       ${path_of_opath}/Puck_on_Toadstool_sampling_noise_renorm_bdry_correct_dipole.ply    
# ${myexe} ${path_of_disturbed}/Scallop_noise_renorm_bdry.ply                         ${path_of_raw}/Scallop_noise_renorm_bdry_correct_dipole.ply                          ${path_of_opath}/Scallop_noise_renorm_bdry_correct_dipole.ply                       
# ${myexe} ${path_of_disturbed}/Willy_Selke_Tondo_sampling_noise_renorm_bdry.ply      ${path_of_raw}/Willy_Selke_Tondo_sampling_noise_renorm_bdry_correct_dipole.ply       ${path_of_opath}/Willy_Selke_Tondo_sampling_noise_renorm_bdry_correct_dipole.ply    
# ${myexe} ${path_of_disturbed}/Xenophora_noise_renorm_bdry.ply                       ${path_of_raw}/Xenophora_noise_renorm_bdry_correct_dipole.ply                        ${path_of_opath}/Xenophora_noise_renorm_bdry_correct_dipole.ply                     


