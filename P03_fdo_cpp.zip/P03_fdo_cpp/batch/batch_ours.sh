myexe="/media/i9/gamma/workspace/P03_fdo_cpp/build/fdo_cpp "
mypyexe="python /media/i9/gamma/workspace/P03_fdo_python/ST01_forceatlas2_gpu_main_cluster_args.py"


ipath_of_disturbed="/media/i9/Lei/experiment_nc/1_special_cases/2_varying_point_density/disturbed/bulbasaur_flower_pot_merge_disturbed.ply"
opath="/media/i9/Lei/experiment_nc/1_special_cases/2_varying_point_density/disturbed/9_ours"
${myexe} --fun narrow_band_establishment --ipath_of_raw ${ipath_of_disturbed}/${model}.ply
${mypyexe} --cloud_name ${model} --output_prefix ${opath}
${myexe} --fun normal_correction --ipath_of_disturbed   ${ipath_of_disturbed} --ipath_of_positive    ${opath}/${model}_positive.ply --opath_of_corrected   ${opath}/${model}_ours.ply 


