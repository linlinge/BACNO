#include "ComputeMST.h"
vector<vector<int>> GetConnectedComponents(pcl::PointCloud<PointType>::Ptr cloud)
{
    pcl::search::KdTree<PointType>::Ptr mykdtree(new pcl::search::KdTree<PointType>);
    mykdtree->setInputCloud(cloud);

    // create graph
    BoostGraph g;
    int K=10;
    for(int i=0; i<cloud->points.size(); i++){
        vector<int> idx;
        vector<float> dist;
        mykdtree->nearestKSearch(i, K, idx, dist);

        for(int j=1; j<K; j++){
            add_edge(idx[0], idx[j], g);
        }
    }

    // This vector will hold the component index for each vertex
    std::vector<int> component(num_vertices(g));

    // The total number of components
    int num = boost::connected_components(g, &component[0]);

    // Map from component number to its vertices
    std::map<int, std::vector<int>> component_map;

    for (size_t i = 0; i != component.size(); ++i) {
        component_map[component[i]].push_back(i);
    }

    // Convert map to vector<vector<int>>
    std::vector<std::vector<int>> components(num);
    for (const auto& pair : component_map) {
        components[pair.first] = pair.second;
    }

    //cout<<components.size()<<endl;
    return components;
}