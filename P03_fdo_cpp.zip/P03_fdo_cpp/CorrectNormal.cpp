#include <CorrectNormal.h>

CorrectNormal::CorrectNormal()
{
    cloud_zero_equipotential_= pcl::PointCloud<PointType>::Ptr(new pcl::PointCloud<PointType>);
    // kdtree_zero_equipotential_->setInputCloud(cloud_zero_equipotential_);
}

void CorrectNormal::SetDisturbedCloud(string ipath_of_disturbed)
{
    cloud_disturbed_=pcl::PointCloud<PointType>::Ptr(new pcl::PointCloud<PointType>);
    pcl::io::loadPLYFile(ipath_of_disturbed, *cloud_disturbed_);
    kdtree_disturbed_ = pcl::search::KdTree<PointType>::Ptr(new  pcl::search::KdTree<PointType>);
    kdtree_disturbed_->setInputCloud(cloud_disturbed_);
}

void CorrectNormal::SetPositiveCloud(string ipath_of_positive)
{
    cloud_positive_=pcl::PointCloud<PointType>::Ptr(new pcl::PointCloud<PointType>);
    pcl::io::loadPLYFile(ipath_of_positive, *cloud_positive_);
    kdtree_positive_ = pcl::search::KdTree<PointType>::Ptr(new  pcl::search::KdTree<PointType>);
    kdtree_positive_->setInputCloud(cloud_positive_);
    vector<int> idx;
    vector<float> dist;
    kdtree_positive_->nearestKSearch(cloud_positive_->points[0], 2, idx, dist);
    spacing_ = sqrt(dist[1]);
}

void CorrectNormal::SetNegtiveCloud(string ipath_of_negtive)
{
    cloud_negtive_=pcl::PointCloud<PointType>::Ptr(new pcl::PointCloud<PointType>);
    pcl::io::loadPLYFile(ipath_of_negtive, *cloud_negtive_);
    kdtree_negtive_ = pcl::search::KdTree<PointType>::Ptr(new  pcl::search::KdTree<PointType>);
    kdtree_negtive_->setInputCloud(cloud_negtive_);
}


void CorrectNormal::SetInputCloud(string ipath_of_disturbed, string ipath_of_positive)
{
    /* step 01: load positive point cloud */
    cm_positive_.SetInputCloud(ipath_of_positive);  
    cloud_positive_=cm_positive_.cloud_;
    mean_dist_of_positive_ = cm_positive_.GetMeanDistance();
    max_dist_of_positive_ = cm_positive_.GetMaximumDistance();
    kdtree_positive_=pcl::search::KdTree<PointType>::Ptr(new pcl::search::KdTree<PointType>());
    kdtree_positive_->setInputCloud(cloud_positive_);

    /* step 02: load disturbed point cloud*/
    cm_disturbed_.SetInputCloud(ipath_of_disturbed);
    cloud_disturbed_=cm_disturbed_.cloud_;
    mean_dist_of_disturbed_=cm_disturbed_.GetMeanDistance();
    max_dist_of_disturbed_=cm_disturbed_.GetMaximumDistance();
    kdtree_disturbed_=pcl::search::KdTree<PointType>::Ptr(new pcl::search::KdTree<PointType>());
    kdtree_disturbed_->setInputCloud(cloud_disturbed_);
}


void CorrectNormal::SetCloudOn(string ipath_of_cloud_on)
{
    cloud_on_ = pcl::PointCloud<PointType>::Ptr(new pcl::PointCloud<PointType>);
    pcl::io::loadPLYFile(ipath_of_cloud_on, *cloud_on_);
    kdtree_on_ = pcl::search::KdTree<PointType>::Ptr(new  pcl::search::KdTree<PointType>);
    kdtree_on_->setInputCloud(cloud_on_);
}

pcl::PointCloud<PointType>::Ptr CorrectNormal::Smooth_by_MLS(pcl::PointCloud<PointType>::Ptr icloud)
{
    cout<<icloud->points.size()<<endl;
    CloudProperties cp;
    cp.SetInputCloud(icloud);

    float max_ngbr_dist = cp.GetMaximumDistance();
    
    // 创建一个 KD-Tree
    pcl::search::KdTree<PointType>::Ptr tree(new pcl::search::KdTree<PointType>);

    // 输出点云
    pcl::PointCloud<PointType>::Ptr mls_points(new pcl::PointCloud<PointType>);

    // 初始化移动最小二乘对象
    pcl::MovingLeastSquares<PointType, PointType> mls;
    mls.setComputeNormals(true); // 计算法线

    // 设置参数
    mls.setInputCloud(icloud);
    mls.setPolynomialOrder(2);
    mls.setSearchMethod(tree);
    mls.setSearchRadius(3*max_ngbr_dist); // 设置搜索半径

    // 开始处理
    mls.process(*mls_points);

    return mls_points;
}

double ComputeWassteinDistance(V3 pt, pcl::PointCloud<PointType>::Ptr cloud)
{
    double dist=0;
    for(int i=0; i<cloud->points.size(); i++)
    {
        double dtmp=pow(pt.x-cloud->points[i].x,2) + 
                    pow(pt.y-cloud->points[i].y,2) +
                    pow(pt.z-cloud->points[i].z,2);
        dist+=dtmp;
    }
    dist=sqrt(dist/cloud->points.size());
    return dist;
}

void CorrectNormal::Correct_by_WassteinDistance(string opath_of_corrected)
{
    /** step 01: rough phase 
    * cloud_disturbed_
    * cloud_positive_
    **/
    #pragma omp parallel for
    for(int i=0; i<cloud_disturbed_->points.size(); i++){
        vector<int> idx_positive;
        vector<float> dist_positive; 
        kdtree_positive_->nearestKSearch(cloud_disturbed_->points[i], 3, idx_positive, dist_positive);
        pcl::PointCloud<PointType>::Ptr lcloud(new pcl::PointCloud<PointType>);
        pcl::copyPointCloud(*cloud_positive_, idx_positive, *lcloud);

        
        
        /* get Pa and Pb*/
        V3 Po(cloud_disturbed_->points[i].x, 
              cloud_disturbed_->points[i].y,
              cloud_disturbed_->points[i].z);
        
       

        V3 nrm_of_Po(cloud_disturbed_->points[i].normal_x,
                     cloud_disturbed_->points[i].normal_y,
                     cloud_disturbed_->points[i].normal_z);
        nrm_of_Po.Normalize();

        V3 Pa=Po+ 0.5*dist_positive[0]*nrm_of_Po;
        V3 Pb=Po- 0.5*dist_positive[0]*nrm_of_Po;

        /* get distance */
        double dist_to_Pa=ComputeWassteinDistance(Pa, lcloud);
        double dist_to_Pb=ComputeWassteinDistance(Pb, lcloud);
        if(dist_to_Pa>dist_to_Pb)
        {
            cloud_disturbed_->points[i].normal_x=-cloud_disturbed_->points[i].normal_x;
            cloud_disturbed_->points[i].normal_y=-cloud_disturbed_->points[i].normal_y;
            cloud_disturbed_->points[i].normal_z=-cloud_disturbed_->points[i].normal_z;
        }
    }


    /** step 02: refinement by majority voting
     * cloud_disturbed_
    */
    int k2=40;
    #pragma omp parallel for
    for(int i=0; i<cloud_disturbed_->points.size(); i++){
        /* step 03-1: get local cloud */    
        vector<int> idx_disturbed;
        vector<float> dist_disturbed;
        kdtree_disturbed_->nearestKSearch(cloud_disturbed_->points[i], k2, idx_disturbed, dist_disturbed);
 
        /* step 03-2: majority voting */  
        vector<int> voting(idx_disturbed.size()-1);
        V3 Po(cloud_disturbed_->points[i].x, cloud_disturbed_->points[i].y, cloud_disturbed_->points[i].z);
        V3 Po_nrm(cloud_disturbed_->points[i].normal_x, cloud_disturbed_->points[i].normal_y, cloud_disturbed_->points[i].normal_z);
        V3 Pe_of_o=Po+Po_nrm;
        for(int j=1; j<idx_disturbed.size(); j++){
            int itmp=idx_disturbed[j];
            V3 ngbr(cloud_disturbed_->points[itmp].x, cloud_disturbed_->points[itmp].y, cloud_disturbed_->points[itmp].z);
            V3 ngbr_nrm(cloud_disturbed_->points[itmp].normal_x, cloud_disturbed_->points[itmp].normal_y, cloud_disturbed_->points[itmp].normal_z);
            float arc=Po_nrm.Dot(ngbr_nrm);
            if(arc<0)
                voting[j-1]= -1;
            else
                voting[j-1]= 1;
        }
        int cnt_neg=0;
        int cnt_pos=0;
        for(int j=0; j<voting.size(); j++){
            if(voting[j]==-1)
                cnt_neg++;
            else 
                cnt_pos++;
        }
        if(cnt_neg>cnt_pos){
            cloud_disturbed_->points[i].normal_x=-cloud_disturbed_->points[i].normal_x;
            cloud_disturbed_->points[i].normal_y=-cloud_disturbed_->points[i].normal_y;
            cloud_disturbed_->points[i].normal_z=-cloud_disturbed_->points[i].normal_z;
        }
    }

    pcl::io::savePLYFileBinary(opath_of_corrected, *cloud_disturbed_);
}

void CorrectNormal::CalculateNormal(pcl::PointCloud<PointType>::Ptr icloud, int K)
{
    // 创建法向量估计对象  
    pcl::NormalEstimation<PointType, pcl::Normal> ne;  
    ne.setInputCloud(icloud);  
        
    // 创建一个Kd树对象，用于最近邻搜索  
    pcl::search::KdTree<PointType>::Ptr tree(new pcl::search::KdTree<PointType>);  
    ne.setSearchMethod(tree);  
    
    // 设置搜索邻域的大小  
    ne.setKSearch(K);  
    
    // 计算法向量  
    pcl::PointCloud<pcl::Normal>::Ptr cloud_normals(new pcl::PointCloud<pcl::Normal>);  
    ne.compute(*cloud_normals);

    for(int i=0; i<cloud_normals->points.size(); i++){
        icloud->points[i].normal_x = cloud_normals->points[i].normal_x;
        icloud->points[i].normal_y = cloud_normals->points[i].normal_y;
        icloud->points[i].normal_z = cloud_normals->points[i].normal_z;
    }
}


void CorrectNormal::Correct_by_WassteinDistance_Pro(string opath_of_corrected)
{
    string path_of_cloud_disturbed = ReadStringFromFilename("Cache/path_of_disturbed");
    SetDisturbedCloud(path_of_cloud_disturbed);

    string path_of_cloud_positive = ReadStringFromFilename("Cache/path_of_cloud_positive");
    SetPositiveCloud(path_of_cloud_positive);

    string path_of_cloud_on = ReadStringFromFilename("Cache/path_of_cloud_on");
    SetCloudOn(path_of_cloud_on);

    float semi_spacing = spacing_/2.0;
    cout<<"spacing:"<<semi_spacing<<endl;

    /* get smooth cloud on */
    auto mls_cloud_on = Smooth_by_MLS(cloud_on_);
   
    /* correct orientation by cloud positive */
    Correct_by_UDF(mls_cloud_on, cloud_positive_);

    string path_of_mls_cloud_on = ReadStringFromFilename("Cache/opath") + "/" + ReadStringFromFilename("Cache/model_name") + "_cloud_on_mls.ply";
    pcl::io::savePLYFileBinary(path_of_mls_cloud_on, *mls_cloud_on);


    /* correct by cloud_on_ */
    kdtree_on_->setInputCloud(mls_cloud_on);

    #pragma omp parallel for
    for(int i=0; i < cloud_disturbed_->points.size(); i++){
        vector<int> idx;
        vector<float> dist;
        kdtree_on_->nearestKSearch(cloud_disturbed_->points[i], 1, idx, dist);
        V3 current_result_pt(mls_cloud_on->points[idx[0]].normal_x, mls_cloud_on->points[idx[0]].normal_y, mls_cloud_on->points[idx[0]].normal_z);
        V3 current_disturbed_pt(cloud_disturbed_->points[i].normal_x, cloud_disturbed_->points[i].normal_y, cloud_disturbed_->points[i].normal_z);
        float arc = current_result_pt.Dot(current_disturbed_pt);
        if(arc<0){
            cloud_disturbed_->points[i].normal_x=-cloud_disturbed_->points[i].normal_x;
            cloud_disturbed_->points[i].normal_y=-cloud_disturbed_->points[i].normal_y;
            cloud_disturbed_->points[i].normal_z=-cloud_disturbed_->points[i].normal_z;
        }
    }

    pcl::io::savePLYFileBinary(opath_of_corrected, *cloud_disturbed_);
}


void CorrectNormal::Correct_by_UDF_Pro()
{
    /* load disturbed cloud */    
    SetDisturbedCloud(ReadStringFromFilename("Cache/path_of_disturbed"));

    /* load cloud positive*/
    SetPositiveCloud(ReadStringFromFilename("Cache/path_of_cloud_positive"));


    /* compute the udf from raw cloud to positive cloud */
    VectorExtend<float> udf_to_cloud_positive;
    udf_to_cloud_positive.Resize(cloud_disturbed_->points.size());
    for(int i=0; i<udf_to_cloud_positive.size(); i++){
        udf_to_cloud_positive[i] = CalculateUDF_by_WassteinDistance(cloud_positive_, kdtree_positive_, cloud_disturbed_->points[i], 3);
    }

    /* get the indices of low and high confident cloud */
    float threshold_of_low_confidence = udf_to_cloud_positive.Quantile(0.1);
    vector<int> indices_of_high_confidence, indices_of_low_confidence;
    for(int i=0; i<udf_to_cloud_positive.size(); i++){
        if(udf_to_cloud_positive[i] > threshold_of_low_confidence)
            indices_of_high_confidence.push_back(i);
        else
            indices_of_low_confidence.push_back(i);
    }

    /* correct normal with high confident */
    for(int i=0; i<indices_of_high_confidence.size(); i++){
        int current_i = indices_of_high_confidence[i];
        vector<int> idx_positive;
        vector<float> dist_positive; 
        kdtree_positive_->nearestKSearch(cloud_disturbed_->points[current_i], 50, idx_positive, dist_positive);
        pcl::PointCloud<PointType>::Ptr lcloud(new pcl::PointCloud<PointType>);
        pcl::copyPointCloud(*cloud_positive_, idx_positive, *lcloud);

        /* get Pa and Pb*/
        V3 Po(cloud_disturbed_->points[current_i].x, cloud_disturbed_->points[current_i].y, cloud_disturbed_->points[current_i].z);
        V3 nrm_of_Po(cloud_disturbed_->points[current_i].normal_x, cloud_disturbed_->points[current_i].normal_y, cloud_disturbed_->points[current_i].normal_z);
        nrm_of_Po.Normalize();
        V3 Pa=Po + 0.5*sqrt(dist_positive[0])*nrm_of_Po;
        V3 Pb=Po - 0.5*sqrt(dist_positive[0])*nrm_of_Po;

        /* get distance */
        double dist_to_Pa=ComputeWassteinDistance(Pa, lcloud);
        double dist_to_Pb=ComputeWassteinDistance(Pb, lcloud);
        if(dist_to_Pa>dist_to_Pb){
            cloud_disturbed_->points[current_i].normal_x=-cloud_disturbed_->points[current_i].normal_x;
            cloud_disturbed_->points[current_i].normal_y=-cloud_disturbed_->points[current_i].normal_y;
            cloud_disturbed_->points[current_i].normal_z=-cloud_disturbed_->points[current_i].normal_z;
        }
    }

    string path_of_ours = ReadStringFromFilename("Cache/path_of_ours");
    pcl::io::savePLYFileBinary(path_of_ours, *cloud_disturbed_);

    /* get cloud with low and high confident */
    pcl::PointCloud<PointType>::Ptr cloud_high_confident(new pcl::PointCloud<PointType>);
    pcl::copyPointCloud(*cloud_disturbed_, indices_of_high_confidence, *cloud_high_confident);
    pcl::search::KdTree<PointType>::Ptr kdtree_high_confident(new pcl::search::KdTree<PointType>);
    kdtree_high_confident->setInputCloud(cloud_high_confident);
    int K=200;
    for(int i=0; i < indices_of_low_confidence.size(); i++){
        int current_i = indices_of_low_confidence[i];
        vector<int> idx;
        vector<float> dist;
        kdtree_high_confident->nearestKSearch(cloud_disturbed_->points[current_i], K, idx, dist);

        V3 nrm_of_Po(cloud_disturbed_->points[current_i].normal_x, cloud_disturbed_->points[current_i].normal_y, cloud_disturbed_->points[current_i].normal_z);
        vector<int> flag(K);
        for(int j=0; j<K; j++){
            int ngbr_j = indices_of_high_confidence[idx[j]]; 
            V3 nrm_of_Pa(cloud_disturbed_->points[ngbr_j].normal_x, cloud_disturbed_->points[ngbr_j].normal_y, cloud_disturbed_->points[ngbr_j].normal_z);
            float arc =nrm_of_Po.Dot(nrm_of_Pa);
            if(arc<0)
                flag[j]=-1;
            else
                flag[j]=1;
        }
        int sum = std::accumulate(flag.begin(), flag.end(), 0);
        if(sum < 0){
            cloud_disturbed_->points[current_i].normal_x=-cloud_disturbed_->points[current_i].normal_x;
            cloud_disturbed_->points[current_i].normal_y=-cloud_disturbed_->points[current_i].normal_y;
            cloud_disturbed_->points[current_i].normal_z=-cloud_disturbed_->points[current_i].normal_z;
        }
    }

    path_of_ours = ReadStringFromFilename("Cache/path_of_ours");
    pcl::io::savePLYFileBinary(path_of_ours, *cloud_disturbed_);
}

/**
 * correct normal orientation by unsigned distance field
 * @param: the cloud whose normal orientation required to determine
 * @param: the cloud which offer the points to correct normal orientation
*/
void CorrectNormal::Correct_by_UDF(pcl::PointCloud<PointType>::Ptr icloud, pcl::PointCloud<PointType>::Ptr cloud_positive)
{
    pcl::search::KdTree<PointType>::Ptr kdtree_disturbed(new pcl::search::KdTree<PointType>);
    kdtree_disturbed->setInputCloud(icloud);
    pcl::search::KdTree<PointType>::Ptr kdtree_positive(new pcl::search::KdTree<PointType>);
    kdtree_positive->setInputCloud(cloud_positive);

    #pragma omp parallel for
    for(int i=0; i<icloud->points.size(); i++){
        vector<int> idx_positive;
        vector<float> dist_positive; 
        kdtree_positive->nearestKSearch(icloud->points[i], 3, idx_positive, dist_positive);
        pcl::PointCloud<PointType>::Ptr lcloud(new pcl::PointCloud<PointType>);
        pcl::copyPointCloud(*cloud_positive, idx_positive, *lcloud);
        
        /* get Pa and Pb */
        V3 Po(icloud->points[i].x, 
              icloud->points[i].y,
              icloud->points[i].z);
        
       

        V3 nrm_of_Po(icloud->points[i].normal_x,
                     icloud->points[i].normal_y,
                     icloud->points[i].normal_z);
        nrm_of_Po.Normalize();

        V3 Pa=Po+ 0.5*dist_positive[0]*nrm_of_Po;
        V3 Pb=Po- 0.5*dist_positive[0]*nrm_of_Po;

        /* get distance */
        double dist_to_Pa=ComputeWassteinDistance(Pa, lcloud);
        double dist_to_Pb=ComputeWassteinDistance(Pb, lcloud);
        if(dist_to_Pa>dist_to_Pb)
        {
            icloud->points[i].normal_x=-icloud->points[i].normal_x;
            icloud->points[i].normal_y=-icloud->points[i].normal_y;
            icloud->points[i].normal_z=-icloud->points[i].normal_z;
        }
    }
}


/**
 * cloud normal orientation by majority voting algorithm
 * @param icloud: the cloud that required to correct normal orientation
 * @param K: the k nearest cloud that used to perform majority voting
*/
void CorrectNormal::Correct_by_MajorityVoting(pcl::PointCloud<PointType>::Ptr icloud, int K)
{
    pcl::search::KdTree<PointType>::Ptr kdtree(new pcl::search::KdTree<PointType>);
    kdtree->setInputCloud(icloud);

    #pragma omp parallel for
    for(int i=0; i<icloud->points.size(); i++){
        /* step 03-1: get local cloud */    
        vector<int> idx_disturbed;
        vector<float> dist_disturbed;
        kdtree_disturbed_->nearestKSearch(icloud->points[i], K, idx_disturbed, dist_disturbed);
 
        /* step 03-2: majority voting */  
        vector<int> voting(idx_disturbed.size()-1);
        V3 Po(icloud->points[i].x, icloud->points[i].y, icloud->points[i].z);
        V3 Po_nrm(icloud->points[i].normal_x, icloud->points[i].normal_y, icloud->points[i].normal_z);
        V3 Pe_of_o=Po+Po_nrm;
        for(int j=1; j<idx_disturbed.size(); j++){
            int itmp=idx_disturbed[j];
            V3 ngbr(icloud->points[itmp].x, icloud->points[itmp].y, icloud->points[itmp].z);
            V3 ngbr_nrm(icloud->points[itmp].normal_x, icloud->points[itmp].normal_y, icloud->points[itmp].normal_z);
            float arc=Po_nrm.Dot(ngbr_nrm);
            if(arc<0)
                voting[j-1]= -1;
            else
                voting[j-1]= 1;
        }
        int cnt_neg=0;
        int cnt_pos=0;
        for(int j=0; j<voting.size(); j++){
            if(voting[j]==-1)
                cnt_neg++;
            else 
                cnt_pos++;
        }
        if(cnt_neg>cnt_pos){
            icloud->points[i].normal_x=-icloud->points[i].normal_x;
            icloud->points[i].normal_y=-icloud->points[i].normal_y;
            icloud->points[i].normal_z=-icloud->points[i].normal_z;
        }
    }
}

void CorrectNormal::LoadDisturbedCloud(string ipath_of_disturbed)
{
    cloud_disturbed_ = pcl::PointCloud<PointType>::Ptr(new pcl::PointCloud<PointType>);
    pcl::io::loadPLYFile(ipath_of_disturbed, *cloud_disturbed_);
    kdtree_disturbed_= pcl::search::KdTree<PointType>::Ptr(new pcl::search::KdTree<PointType>);
    kdtree_disturbed_->setInputCloud(cloud_disturbed_);
}

void CorrectNormal::Correct_by_ZeroEquipotentialSurface(string ipath_of_cloud_zero_equipotential, string ipath_of_cloud_positive)
{
    pcl::io::loadPLYFile(ipath_of_cloud_zero_equipotential, *cloud_zero_equipotential_);
    kdtree_zero_equipotential_ = pcl::search::KdTree<PointType>::Ptr(new pcl::search::KdTree<PointType>);
    kdtree_zero_equipotential_->setInputCloud(cloud_zero_equipotential_);

    cloud_positive_= pcl::PointCloud<PointType>::Ptr(new pcl::PointCloud<PointType>);
    pcl::io::loadPLYFile(ipath_of_cloud_positive, *cloud_positive_);

    /* Step 01: calculate the normal of the cloud_zero_equipotential */
    pcl::NormalEstimation<PointType, pcl::Normal> ne;  
    ne.setInputCloud(cloud_zero_equipotential_);    
    pcl::search::KdTree<PointType>::Ptr tree(new pcl::search::KdTree<PointType>);  
    ne.setSearchMethod(tree);    
    ne.setKSearch(20);
    pcl::PointCloud<pcl::Normal>::Ptr cloud_normals(new pcl::PointCloud<pcl::Normal>);  
    ne.compute(*cloud_normals);
    for(int i=0; i < cloud_zero_equipotential_->points.size(); i++){
        cloud_zero_equipotential_->points[i].normal_x = cloud_normals->points[i].normal_x;
        cloud_zero_equipotential_->points[i].normal_y = cloud_normals->points[i].normal_y;
        cloud_zero_equipotential_->points[i].normal_z = cloud_normals->points[i].normal_z;
    }

    /* Step 02: correct all the normal orientation of cloud_zero_equipotential */
    if(cloud_positive_==NULL)
        cloud_positive_ = pcl::PointCloud<PointType>::Ptr(new pcl::PointCloud<PointType>);
    pcl::io::loadPLYFile(ipath_of_cloud_positive, *cloud_positive_);

    Correct_by_UDF(cloud_zero_equipotential_, cloud_positive_);

    /* Step 03: use cloud_zero_equipotential_ to correct disturbed cloud */    
    for(int i=0; i < cloud_disturbed_->points.size(); i++){
        vector<int> idx;
        vector<float> dist;
        kdtree_zero_equipotential_->nearestKSearch(cloud_disturbed_->points[i], 1, idx, dist);
        V3 current_result_pt(cloud_zero_equipotential_->points[idx[0]].normal_x, 
                             cloud_zero_equipotential_->points[idx[0]].normal_y, 
                             cloud_zero_equipotential_->points[idx[0]].normal_z);

        V3 current_disturbed_pt(cloud_disturbed_->points[i].normal_x, 
                                cloud_disturbed_->points[i].normal_y, 
                                cloud_disturbed_->points[i].normal_z);

        float arc = current_result_pt.Dot(current_disturbed_pt);
        if(arc<0){
            cloud_disturbed_->points[i].normal_x=-cloud_disturbed_->points[i].normal_x;
            cloud_disturbed_->points[i].normal_y=-cloud_disturbed_->points[i].normal_y;
            cloud_disturbed_->points[i].normal_z=-cloud_disturbed_->points[i].normal_z;
        }
    }
}
void CorrectNormal::ExtractResult(string opath)
{
    pcl::io::savePLYFileBinary(opath, *cloud_disturbed_);
}

void CorrectNormal::Correct_by_Nearest(string oprefix)
{
    for(int i=0; i<cloud_disturbed_->points.size(); i++){
        /* current pt */
        V3 Po(cloud_disturbed_->points[i].x, cloud_disturbed_->points[i].y,  cloud_disturbed_->points[i].z);
        V3 nrm_of_Po(cloud_disturbed_->points[i].normal_x, 
                     cloud_disturbed_->points[i].normal_y, 
                     cloud_disturbed_->points[i].normal_z);
        PointType& pcl_current_pt= cloud_disturbed_->points[i];

        /* get its nearest positive point */
        vector<int> idx_positive;
        vector<float> dist_positive; 
        kdtree_positive_->nearestKSearch(cloud_disturbed_->points[i], 1, idx_positive, dist_positive);
        V3 Pa(cloud_positive_->points[idx_positive[0]].x, 
              cloud_positive_->points[idx_positive[0]].y, 
              cloud_positive_->points[idx_positive[0]].z);
        V3 o2a=(Pa-Po).Normalize();

        /*  */
        double arc=nrm_of_Po.Dot(o2a);
        if(arc<0){
            cloud_disturbed_->points[i].normal_x=-cloud_disturbed_->points[i].normal_x;
            cloud_disturbed_->points[i].normal_y=-cloud_disturbed_->points[i].normal_y;
            cloud_disturbed_->points[i].normal_z=-cloud_disturbed_->points[i].normal_z;
        }
    }


     /* step 04: second time correct normal */
    int k2=20;
    #pragma omp parallel for
    for(int i=0; i<cloud_disturbed_->points.size(); i++){
        /* step 03-1: get local cloud */    
        vector<int> idx_disturbed;
        vector<float> dist_disturbed;
        kdtree_disturbed_->nearestKSearch(cloud_disturbed_->points[i], k2, idx_disturbed, dist_disturbed);

        /* step 03-2: majority voting */  
        vector<int> voting(idx_disturbed.size()-1);
        V3 Po(cloud_disturbed_->points[i].x, cloud_disturbed_->points[i].y, cloud_disturbed_->points[i].z);
        V3 Po_nrm(cloud_disturbed_->points[i].normal_x, cloud_disturbed_->points[i].normal_y, cloud_disturbed_->points[i].normal_z);
        V3 Pe_of_o=Po+Po_nrm;
        for(int j=1; j<idx_disturbed.size(); j++){
            int itmp=idx_disturbed[j];
            V3 ngbr(cloud_disturbed_->points[itmp].x, cloud_disturbed_->points[itmp].y, cloud_disturbed_->points[itmp].z);
            V3 ngbr_nrm(cloud_disturbed_->points[itmp].normal_x, cloud_disturbed_->points[itmp].normal_y, cloud_disturbed_->points[itmp].normal_z);
            float arc=Po_nrm.Dot(ngbr_nrm);
            if(arc<0)
                voting[j-1]= -1;
            else
                voting[j-1]= 1;
        }
        int cnt_neg=0;
        int cnt_pos=0;
        for(int j=0; j<voting.size(); j++){
            if(voting[j]==-1)
                cnt_neg++;
            else 
                cnt_pos++;
        }
        double ratio=abs(cnt_neg*1.0/k2-0.5);
        if(ratio<0.4){
            cloud_disturbed_->points[i].r=255;
            cloud_disturbed_->points[i].g=0;
            cloud_disturbed_->points[i].b=0;
        }
        else{
            cloud_disturbed_->points[i].r=0;
            cloud_disturbed_->points[i].g=150;
            cloud_disturbed_->points[i].b=0;
        }
    }
    pcl::io::savePLYFileBinary(oprefix+"_correct_ours.ply", *cloud_disturbed_);
}

void CorrectNormal::Correct(string output_prefix)
{
    int debug;
    V3 test_point(-17.747736, 70.159767, 72.614555);
    PointType pcl_test_point((float)test_point.x, (float)test_point.y, (float)test_point.z);
    
    cout<<cloud_disturbed_->points.size()<<endl;
    /* step 03:  */
    flag_is_determined_.resize(cloud_disturbed_->points.size(), 0);
    vector<int> side_of_determined(cloud_disturbed_->points.size(), 0);
    debug=0; 
    // #pragma omp parallel for
    for(int i=0; i<cloud_disturbed_->points.size(); i++){

        V3 Po(cloud_disturbed_->points[i].x, cloud_disturbed_->points[i].y,  cloud_disturbed_->points[i].z);

        double dtmp=Po.EuclideanDistance(test_point);
        if(dtmp<0.1){
            cout<<dtmp<<endl;
            debug=1;
            ofstream fout(output_prefix+"/test_point.xyz");
            fout<<test_point.x<<" "<<test_point.y<<" "<<test_point.z<<endl;
            fout.close();
        }
            
        /* step 03-1: get local cloud */    
        vector<int> idx_positive;
        vector<float> dist_positive; 
        kdtree_positive_->nearestKSearch(cloud_disturbed_->points[i], 5, idx_positive, dist_positive);
        dist_positive[0]=sqrt(dist_positive[0]);

        vector<int> idx;
        vector<float> dist;
        // kdtree_disturbed_->radiusSearch(i, max_dist_of_disturbed_, idx, dist);

        kdtree_disturbed_->nearestKSearch(i, 20, idx, dist);

        pcl::PointCloud<PointType>::Ptr lcloud(new pcl::PointCloud<PointType>);
        pcl::copyPointCloud(*cloud_disturbed_, idx, *lcloud);
        if(debug==1){
            pcl::io::savePLYFileBinary(output_prefix+"/lcloud.ply", *lcloud);
        }


        Poly22Fitting pf;
        pf.SetInputCloud(GetXYZ(lcloud));
        pf.Fit_BestFittingPlane();

        if(debug==1){
            V3 foot=pf.GetFoot(Po);

            ofstream fout;
            fout.open(output_prefix+"/foot.xyz");
            fout<<foot<<endl;
            fout.close();

            fout.open(output_prefix + "/Po.xyz");
            fout<<Po<<endl;
            fout.close();

            pf.GetMesh(output_prefix+"/lmesh.obj");

            cout<<"wokaka"<<endl;
        }

        /* Get side of Pa */
        vector<int> side_of_Pa(idx_positive.size());
        vector<V3> Pa_set;
        for(int j=0; j<idx_positive.size(); j++){
            V3 Pa(cloud_positive_->points[idx_positive[j]].x, 
                    cloud_positive_->points[idx_positive[j]].y,
                    cloud_positive_->points[idx_positive[j]].z);
            
            Pa_set.push_back(Pa);
            side_of_Pa[j]=pf.WhichSide(Pa);
        }

        /* Is side of Pa right? */
        bool is_right=true;
        for(int j=1; j<side_of_Pa.size(); j++){
            if(side_of_Pa[j-1]!=side_of_Pa[j]){
                is_right=false;
                break;
            }                    
        }

        if(is_right==false){
            continue;
        }
        else{

            flag_is_determined_[i]=1;
            V3 nrm_of_Po(cloud_disturbed_->points[i].normal_x,
                            cloud_disturbed_->points[i].normal_y,
                            cloud_disturbed_->points[i].normal_z);

            V3 Pb=Po+ mean_dist_of_disturbed_ *nrm_of_Po;
            int side_of_Pb=pf.WhichSide(Pb);
            side_of_determined[i]=side_of_Pb;
                        
            if(debug==1){
                ofstream fout;

                for(int j=0; j<idx_positive.size(); j++){
                    fout.open(output_prefix+ "/Pa_"+to_string(j)+".xyz");
                    fout<<Pa_set[j]<<endl;
                    fout.close();
                }

                fout.open(output_prefix+"/Pb.xyz");
                fout<<Pb<<endl;
                fout.close();
              
                cout<<"wokaka"<<endl;
            }
            
            if(side_of_Pa[0]!=side_of_Pb){
                cloud_disturbed_->points[i].normal_x=-cloud_disturbed_->points[i].normal_x;
                cloud_disturbed_->points[i].normal_y=-cloud_disturbed_->points[i].normal_y;
                cloud_disturbed_->points[i].normal_z=-cloud_disturbed_->points[i].normal_z;
                
                cloud_disturbed_->points[i].r=0;
                cloud_disturbed_->points[i].g=0;
                cloud_disturbed_->points[i].b=255;
            }
        }

           

    
    }
    pcl::io::savePLYFileBinary(output_prefix+"_correct_ours.ply", *cloud_disturbed_);
    
    // /* iterative get remaining normal */
    // vector<int> idx_of_undetermined=FindElement(flag_is_determined_, 0);
    // int previous_num_of_undetermined=0;

    // int num_of_ngbrs=20;
    // while(idx_of_undetermined.size()!=previous_num_of_undetermined){
        
    //     /* get seed */
    //     auto [seed_i, idx_of_determined_ngbrs]=GetFirstSeed(idx_of_undetermined, num_of_ngbrs);

    //     /* propagate from seed */
    //     while(seed_i!=-1){
    //         /* if it has determined neighbours, this determined neighbours are used to determine the status of itself*/
    //             /* what is the side of current node ? */               
    //             pcl::PointCloud<PointType>::Ptr lcloud_determined(new pcl::PointCloud<PointType>);
    //             pcl::copyPointCloud(*cloud_disturbed_, idx_of_determined_ngbrs, *lcloud_determined);
    //             Poly22Fitting pf;
    //             pf.SetInputCloud(GetXYZ(lcloud_determined));
    //             pf.Fit_BestFittingPlane();

    //             /* side of current pt */
    //             V3 current_pt(cloud_disturbed_->points[seed_i].x,
    //                           cloud_disturbed_->points[seed_i].y,
    //                           cloud_disturbed_->points[seed_i].z);

               

    //             V3 nrm_of_current_pt(cloud_disturbed_->points[seed_i].normal_x,
    //                                  cloud_disturbed_->points[seed_i].normal_y,
    //                                  cloud_disturbed_->points[seed_i].normal_z);
    //             V3 Pa=current_pt+ 0.5*nrm_of_current_pt;
    //             int side_of_Pa=pf.WhichSide(Pa);


    //             /* side of its neighbours */
    //             vector<int> side_of_ngbrs(idx_of_determined_ngbrs.size(),0);
    //             vector<V3> Pb_set;
    //             for(int j=0; j<idx_of_determined_ngbrs.size(); j++)
    //             {
    //                 V3 ngbr(cloud_disturbed_->points[idx_of_determined_ngbrs[j]].x,
    //                         cloud_disturbed_->points[idx_of_determined_ngbrs[j]].y,
    //                         cloud_disturbed_->points[idx_of_determined_ngbrs[j]].z);
                    
    //                 V3 nrm_of_ngbr(cloud_disturbed_->points[idx_of_determined_ngbrs[j]].normal_x,
    //                                cloud_disturbed_->points[idx_of_determined_ngbrs[j]].normal_y,
    //                                cloud_disturbed_->points[idx_of_determined_ngbrs[j]].normal_z);
    //                 V3 Pb=ngbr+ 0.5*nrm_of_ngbr;
    //                 Pb_set.push_back(Pb);
    //                 side_of_ngbrs[j]=pf.WhichSide(Pb);
    //             }

    //             if(debug==1){
    //                 if(current_pt.EuclideanDistance(test_point)<0.01){
    //                     pf.GetMesh("/home/i9/experiment_nc/DTU/Result/lmesh.obj");
    //                     pcl::io::savePLYFileBinary("/home/i9/experiment_nc/DTU/Result/lcloud_determined.ply", *lcloud_determined);

    //                     ofstream fout;
    //                     fout.open("/home/i9/experiment_nc/DTU/Result/Pa.xyz");        
    //                     fout<<Pa<<endl;
    //                     fout.close();

    //                     fout.open("/home/i9/experiment_nc/DTU/Result/current_pt.xyz");
    //                     fout<<current_pt<<endl;
    //                     fout.close();

                        

    //                     for(int j=0; j<Pb_set.size(); j++){
    //                         fout.open(output_prefix+"_Pb_"+to_string(j)+".xyz");
    //                         fout<<Pb_set[j]<<endl;
    //                         fout.close();
    //                     }   

    //                     cout<<"wokaka"<<endl;
    //                 }
    //             }
                
    //             int cnt_negtive=0;                
    //             int cnt_positive=0;
    //             for(int j=0; j<side_of_ngbrs.size(); j++){
    //                 if(side_of_ngbrs[j]==side_of_Pa)
    //                     cnt_positive++;                    
    //                 else 
    //                     cnt_negtive++;
    //             }

    //             if(cnt_negtive> cnt_positive){
    //                 cloud_disturbed_->points[seed_i].normal_x=-cloud_disturbed_->points[seed_i].normal_x;
    //                 cloud_disturbed_->points[seed_i].normal_y=-cloud_disturbed_->points[seed_i].normal_y;
    //                 cloud_disturbed_->points[seed_i].normal_z=-cloud_disturbed_->points[seed_i].normal_z;
    //             }      
    //             flag_is_determined_[seed_i]=1;    

    //             tie(seed_i, idx_of_determined_ngbrs)=GetFirstSeed(idx_of_undetermined, num_of_ngbrs);
    //     }

    //     previous_num_of_undetermined=idx_of_undetermined.size();
    //     idx_of_undetermined=FindElement(flag_is_determined_, 0);    
    // }

    // idx_of_undetermined=FindElement(flag_is_determined_, 0);  
    // cout<<endl<<"num of undetermined "<< idx_of_undetermined.size()<<endl;
    // for(int i=0; i<idx_of_undetermined.size(); i++){
    //     int current_i=idx_of_undetermined[i];
    //     cloud_disturbed_->points[current_i].r=0;
    //     cloud_disturbed_->points[current_i].g=255;
    //     cloud_disturbed_->points[current_i].b=0;
    // }
    // pcl::PointCloud<PointType>::Ptr cloud_undetermined(new pcl::PointCloud<PointType>);
    // pcl::copyPointCloud(*cloud_disturbed_, idx_of_undetermined, *cloud_undetermined);
    // pcl::io::savePLYFileBinary(output_prefix+"_undetermined.ply",*cloud_undetermined);
    // pcl::io::savePLYFileBinary(output_prefix+"_correct_ours.ply", *cloud_disturbed_);
}

tuple<bool, vector<int>> CorrectNormal::IsSeed(int test_idx, int num_of_ngbrs)
{   
    vector<int> idx_of_determined;
    /* get its neighbours */
    vector<int> idx;
    vector<float> dist;
    kdtree_disturbed_->nearestKSearch(test_idx, num_of_ngbrs, idx, dist);

    /* count the number of determined neighbours */
    int num_of_determined_ngbrs=0;
    for(int j=1; j<idx.size(); j++){
        if(flag_is_determined_[idx[j]]==1){
            num_of_determined_ngbrs++;
            idx_of_determined.push_back(idx[j]);
        }            
    }

    /* can it be regarded as the seed */
    if(num_of_determined_ngbrs> (num_of_ngbrs/3.0))
        return make_tuple(true, idx_of_determined);
    else 
        return make_tuple(false, idx_of_determined);
}

tuple<int, vector<int>> CorrectNormal::GetFirstSeed(vector<int>& idx, int num_of_ngbrs)
{
    /* find seed point */
    for(int i=0; i<idx.size(); i++){
        auto [is_seed, idx_of_determined_ngbrs]= IsSeed(idx[i], num_of_ngbrs);
        if(is_seed==true){
            return make_tuple(idx[i], idx_of_determined_ngbrs);
            break;
        }            
    }
    vector<int> out;
    return make_tuple(-1,out);
}
