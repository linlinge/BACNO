#include <iostream>
#include <LocalMeshGenerator.h>
#include <CloudProperties.h>
#include <KDTree.h>
#include <Clustering.h>
#include <GraphManagement.h>
#include <PCLExtend.h>
#include <queue>
#include <CorrectNormal.h>
#include <EvaluationMetric.h>
#include <HybridMethod.h>
#include <BoundaryDetection.h>
#include <stdio.h>
#include <omp.h>
#include <GridManager.h>
#include <filesystem>  
#include <Upsampling.h>
#include <Eigen/Core>
#include <ComputeMST.h>
#include <GraphExtend.h>
#include <ctime> 
#include <CloudBorderDetection.h>
using namespace std;
namespace fs = std::filesystem;
using namespace boost;


// 最近邻插值函数实现
pcl::PointCloud<PointType>::Ptr nearestNeighborInterpolation(pcl::PointCloud<PointType>::Ptr inputCloud) 
{
    // 创建KdTree对象进行最近邻搜索
    pcl::search::KdTree<PointType>::Ptr kdtree(new pcl::search::KdTree<PointType>);    
    kdtree->setInputCloud(inputCloud);

    // 新点云，用于存储插值后的点
    pcl::PointCloud<PointType>::Ptr outputCloud(new pcl::PointCloud<PointType>);

    // 对每个点进行最近邻搜索并插值
    for (size_t i = 0; i < inputCloud->points.size(); ++i) {
        std::vector<int> pointIdxNKNSearch(1);
        std::vector<float> pointNKNSquaredDistance(1);

        // 寻找最近邻点
        if (kdtree->nearestKSearch(inputCloud->points[i], 2, pointIdxNKNSearch, pointNKNSquaredDistance) > 0) {
            // 在原始点和其最近邻点之间插入一个点
            PointType newPoint;
            newPoint.x = (inputCloud->points[i].x + inputCloud->points[pointIdxNKNSearch[1]].x) / 2.0;
            newPoint.y = (inputCloud->points[i].y + inputCloud->points[pointIdxNKNSearch[1]].y) / 2.0;
            newPoint.z = (inputCloud->points[i].z + inputCloud->points[pointIdxNKNSearch[1]].z) / 2.0;
            outputCloud->push_back(newPoint);
        }
    }

    return outputCloud;
}


void EdgeRefine()
{
    pcl::PointCloud<PointType>::Ptr cloud_edge(new pcl::PointCloud<PointType>());
    pcl::io::loadPLYFile("/home/i9/experiment_nc/DTU/Result/stl001_total_OR_mls_cca_edge.ply", *cloud_edge);
    pcl::search::KdTree<PointType>::Ptr kdtree_edge(new pcl::search::KdTree<PointType>);
    kdtree_edge->setInputCloud(cloud_edge);

    pcl::PointCloud<PointType>::Ptr cloud_voxel(new pcl::PointCloud<PointType>());
    pcl::io::loadPLYFile("/home/i9/experiment_nc/DTU/Result/stl001_total_OR_mls_cca_voxel.obj", *cloud_voxel);
    pcl::search::KdTree<PointType>::Ptr kdtree_voxel(new pcl::search::KdTree<PointType>);
    kdtree_voxel->setInputCloud(cloud_voxel);

    float r=1.7*5;
    vector<int> idx_out;
    for(int i=0; i<cloud_voxel->points.size(); i++){
        vector<int> idx;
        vector<float> dist;
        kdtree_edge->radiusSearch(cloud_voxel->points[i], r, idx, dist);
        if(idx.size()>0)
            idx_out.push_back(i);
    }

    /* cloud out */
    pcl::PointCloud<PointType>::Ptr cloud_out(new pcl::PointCloud<PointType>());
    pcl::copyPointCloud(*cloud_voxel, idx_out, *cloud_out);
    pcl::io::savePLYFileBinary("/home/i9/experiment_nc/DTU/Result/stl001_total_OR_mls_cca_voxel_out.ply", *cloud_out);

    vector<int> idx_yes;
    for(int i=0; i<cloud_out->points.size(); i++)
    {
        cout<<i<<endl;
        vector<int> idx;
        vector<float> dist;
        kdtree_edge->nearestKSearch(cloud_out->points[i], 30, idx, dist);
        pcl::PointCloud<PointType>::Ptr ctmp(new pcl::PointCloud<PointType>());
        pcl::copyPointCloud(*cloud_edge, idx, *ctmp);

        pcl::NormalEstimation<PointType, pcl::Normal> ne;
        ne.setInputCloud(ctmp);
        pcl::search::KdTree<PointType>::Ptr tree(new pcl::search::KdTree<PointType>());
        tree->setInputCloud(ctmp);
        ne.setSearchMethod(tree);
        ne.setKSearch(20);
        pcl::PointCloud<pcl::Normal>::Ptr cloud_normals(new pcl::PointCloud<pcl::Normal>);
        ne.compute(*cloud_normals);

        // pcl::io::savePLYFileBinary("/home/i9/experiment_nc/DTU/Result/ctmp.ply", *ctmp);

        CloudProperties cp;
        cp.SetInputCloud(ctmp);

        Poly22Fitting pf;
        pf.SetInputCloud(cp.GetCloudXYZ());
        pf.Fit_BestFittingPlane();

        V3 pt(cloud_out->points[i].x, cloud_out->points[i].y, cloud_out->points[i].z);
        
        // ofstream fout("/home/i9/experiment_nc/DTU/Result/Pa.xyz");
        // fout<<cloud_out->points[i].x<<" "<< cloud_out->points[i].y<<" "<<cloud_out->points[i].z<<endl;
        // fout.close();

        bool is_within=pf.IsWithinRange(pt,0.1);

        if(is_within==false){
            idx_yes.push_back(i);
        }
    }

    pcl::PointCloud<PointType>::Ptr cloud_yes(new pcl::PointCloud<PointType>());
    pcl::copyPointCloud(*cloud_out, idx_yes, *cloud_yes);
    pcl::io::savePLYFileBinary("/home/i9/experiment_nc/DTU/Result/stl001_total_OR_mls_cca_voxel_yes.ply", *cloud_yes);

}

int IsCorrect(PointType& ptmp, pcl::PointCloud<PointType>::Ptr local_cloud)
{
    // ofstream fout("/home/i9/experiment_nc/DTU/Result/Po.xyz");
    // fout<<ptmp.x<<" "<<ptmp.y<<" "<<ptmp.z<<endl;
    // fout.close();

    // pcl::io::savePLYFileBinary("/home/i9/experiment_nc/DTU/Result/local_cloud.ply",*local_cloud);

    V3 Po(ptmp.x, ptmp.y, ptmp.z);
    V3 nrm(ptmp.normal_x, ptmp.normal_y, ptmp.normal_z);
    Line line(Po, nrm, point_with_direction);

    /* min dist */
    int min_i=0;
    float min_dist=INT32_MAX;    
    for(int i=0; i<local_cloud->points.size(); i++){
        V3 Pa_tmp(local_cloud->points[i].x, local_cloud->points[i].y, local_cloud->points[i].z);
        float current_dist= line.GetDistTo(Pa_tmp);
        if(current_dist<min_dist){
            min_dist=current_dist;
            min_i=i;
        }
    }    
    V3 Pa(local_cloud->points[min_i].x, local_cloud->points[min_i].y, local_cloud->points[min_i].z);
    
    // ofstream fout2("/home/i9/experiment_nc/DTU/Result/Pa.xyz");
    // fout2<<Pa.x<<" "<<Pa.y<<" "<<Pa.z<<endl;
    // fout2.close();

    V3 P_o2a=(Pa-Po).Normalize();
    float arc=P_o2a.Dot(nrm);
    if(arc<0)
        return -1;
    else 
        return 1;
}


void OldCorrectNormal(string ipath_of_disturbed, string ipath_of_positive, string output_prefix)
{
    int debug=0;
     /* step 01: load positive point cloud */    
    pcl::PointCloud<PointType>::Ptr cloud_positive(new pcl::PointCloud<PointType>());
    pcl::io::loadPLYFile(ipath_of_positive, *cloud_positive);    
    // pcl::io::loadPCDFile(ipath_of_positive, *cloud_positive);

    pcl::search::KdTree<PointType>::Ptr kdtree_positive(new pcl::search::KdTree<PointType>());
    kdtree_positive->setInputCloud(cloud_positive);

    /* step 02: load disturbed point cloud*/
    // CloudProperties cm_disturbed(ipath_of_disturbed);
    // pcl::PointCloud<PointType>::Ptr cloud_disturbed=cm_disturbed.cloud_;
    pcl::PointCloud<PointType>::Ptr cloud_disturbed(new pcl::PointCloud<PointType>());
    pcl::io::loadPLYFile(ipath_of_disturbed, *cloud_disturbed);
    pcl::search::KdTree<PointType>::Ptr kdtree_disturbed(new pcl::search::KdTree<PointType>());
    kdtree_disturbed->setInputCloud(cloud_disturbed);

    V3 test_point(0.035732, 0.089261, -0.016491);


    /* step 03: first time correct normal */
    debug=0;
    #pragma omp parallel for
    for(int i=0; i<cloud_disturbed->points.size(); i++){
        // V3 current_pts(cloud_disturbed->points[i].x, cloud_disturbed->points[i].y, cloud_disturbed->points[i].z);
        // if(current_pts.EuclideanDistance(test_point)<0.1){
        //     debug=1;
        //     ofstream fout(output_prefix+"_test_point.xyz");
        //     fout<<test_point.x<<" "<<test_point.y<<" "<<test_point.z<<endl;
        //     fout.close();
        // }
            

        /* step 03-1: get local cloud */    
        vector<int> idx_positive;
        vector<float> dist_positive; 
        kdtree_positive->nearestKSearch(cloud_disturbed->points[i], 8, idx_positive, dist_positive);
        pcl::PointCloud<PointType>::Ptr local_cloud_positive(new pcl::PointCloud<PointType>);
        pcl::copyPointCloud(*cloud_positive, idx_positive, *local_cloud_positive);
        if(debug==1){
            pcl::io::savePLYFileBinary(output_prefix+"_local.ply", *local_cloud_positive);
        }

        int is_correct=IsCorrect(cloud_disturbed->points[i], local_cloud_positive);
        if(is_correct==-1){
            cloud_disturbed->points[i].normal_x=-cloud_disturbed->points[i].normal_x;
            cloud_disturbed->points[i].normal_y=-cloud_disturbed->points[i].normal_y;
            cloud_disturbed->points[i].normal_z=-cloud_disturbed->points[i].normal_z;
        }
    }
    
    pcl::io::savePLYFileBinary(output_prefix+"_correct_ours.ply", *cloud_disturbed);
    
    /* step 04: second time correct normal */
    int k2=30;
    #pragma omp parallel for
    for(int i=0; i<cloud_disturbed->points.size(); i++){
        /* step 03-1: get local cloud */    
        vector<int> idx_disturbed;
        vector<float> dist_disturbed;
        kdtree_disturbed->nearestKSearch(cloud_disturbed->points[i], k2, idx_disturbed, dist_disturbed);
 
        /* step 03-2: majority voting */  
        vector<int> voting(idx_disturbed.size()-1);
        V3 Po(cloud_disturbed->points[i].x, cloud_disturbed->points[i].y, cloud_disturbed->points[i].z);
        V3 Po_nrm(cloud_disturbed->points[i].normal_x, cloud_disturbed->points[i].normal_y, cloud_disturbed->points[i].normal_z);
        V3 Pe_of_o=Po+Po_nrm;
        for(int j=1; j<idx_disturbed.size(); j++){
            int itmp=idx_disturbed[j];
            V3 ngbr(cloud_disturbed->points[itmp].x, cloud_disturbed->points[itmp].y, cloud_disturbed->points[itmp].z);
            V3 ngbr_nrm(cloud_disturbed->points[itmp].normal_x, cloud_disturbed->points[itmp].normal_y, cloud_disturbed->points[itmp].normal_z);
            float arc=Po_nrm.Dot(ngbr_nrm);
            if(arc<0)
                voting[j-1]= -1;
            else
                voting[j-1]= 1;
        }
        int cnt_neg=0;
        int cnt_pos=0;
        for(int j=0; j<voting.size(); j++){
            if(voting[j]==-1)
                cnt_neg++;
            else 
                cnt_pos++;
        }
        float ratio=abs(cnt_neg*1.0/k2-0.5);
        if(ratio<0.4){
            cloud_disturbed->points[i].r=255;
            cloud_disturbed->points[i].g=0;
            cloud_disturbed->points[i].b=0;
        }
        else{
            cloud_disturbed->points[i].r=0;
            cloud_disturbed->points[i].g=150;
            cloud_disturbed->points[i].b=0;
        }

        // if(cnt_neg>cnt_pos){
        //     cloud_disturbed->points[i].normal_x=-cloud_disturbed->points[i].normal_x;
        //     cloud_disturbed->points[i].normal_y=-cloud_disturbed->points[i].normal_y;
        //     cloud_disturbed->points[i].normal_z=-cloud_disturbed->points[i].normal_z;
        // }
    }

    pcl::io::savePLYFileBinary(output_prefix+"_correct_ours.ply", *cloud_disturbed);
}






vector<vector<int>> GetMappingOfTwoClouds(pcl::PointCloud<PointType>::Ptr cloud_01, pcl::PointCloud<PointType>::Ptr cloud_02)
{
    vector<vector<int>> c2c(cloud_01->points.size());
    pcl::search::KdTree<PointType>::Ptr kdtree_01(new pcl::search::KdTree<PointType>);
    kdtree_01->setInputCloud(cloud_01);
    for(int i=0; i<cloud_02->points.size(); i++){
        vector<int> idx;
        vector<float> dist;
        kdtree_01->nearestKSearch(cloud_02->points[i], 10, idx, dist);

        pcl::PointCloud<PointType>::Ptr local_cloud(new pcl::PointCloud<PointType>);
        pcl::copyPointCloud(*cloud_01, idx, *local_cloud);
        Poly22Fitting pf;
        pf.SetInputCloud(GetXYZ(local_cloud));
        pf.Fit_BestFittingPlane();
        bool is_within= pf.IsWithinRange(V3(cloud_02->points[i].x, cloud_02->points[i].y, cloud_02->points[i].z),0);
        if(is_within==true)
            c2c[idx[0]].push_back(i);
    }
    return c2c;
}


void TestOrientation(pcl::PointCloud<PointType>::Ptr cloud, int s, int t)
{
    // create empty graph
    typedef boost::adjacency_list<boost::vecS, boost::vecS, boost::undirectedS, boost::no_property, boost::no_property> MyGraphType;
    MyGraphType G(cloud->points.size());
    pcl::search::KdTree<PointType>::Ptr kdtree(new pcl::search::KdTree<PointType>);
    kdtree->setInputCloud(cloud);
    int k=5;
    // for(int i=0; i<cloud->points.size(); i++){
    //     vector<int> idx;
    //     vector<float> dist;
    //     kdtree->nearestKSearch(i, k, idx, dist);
    //     for(int j=1; j< idx.size(); j++)
    //         add_edge(vertices(G)[idx[0]],vertices(G)[idx[j]], G);
    // }


    // create vertex and edge
    
    auto v1 = add_vertex(G);
    auto v2 = add_vertex(G);
    auto e = add_edge(v1, v2, G);

    /* traverse vertices */
    auto vpair = vertices(G);
    for(auto iter=vpair.first; iter!=vpair.second; iter++) {
        std::cout << "vertex " << *iter << std::endl;
    }

    /* traverse edges */
    auto epair = edges(G);
    for(auto iter=epair.first; iter!=epair.second; iter++) {
        std::cout << "edge " << source(*iter, G) << " - " << target(*iter, G) << std::endl;
    }
}

void GetLowDensity(pcl::PointCloud<PointType>::Ptr cloud)
{
    CloudProperties cm;
    cm.SetInputCloud(cloud);
    float max_dist=cm.GetMaximumDistance();

    pcl::search::KdTree<PointType>::Ptr kdtree(new pcl::search::KdTree<PointType>);
    kdtree->setInputCloud(cloud);
    VectorExtend<float> dsty;
    dsty.Resize(cloud->points.size());
    for(int i=0; i<cloud->points.size(); i++){
        vector<int> idx;
        vector<float> dist;
        kdtree->nearestKSearch(i, 150, idx, dist);
        // float mean=0;
        // for(int j=0; j<dist.size(); j++)
        //     mean+=sqrt(dist[j]);
        // mean=mean/dist.size();
        // dsty[i]=1.0/mean;
        dsty[i]=1.0/sqrt(dist[dist.size()-1]);
    }
    // auto [thresh, idx_out]=dsty.TukeyFence("<", 5);
    // pcl::PointCloud<PointType>::Ptr cloud_out(new pcl::PointCloud<PointType>);
    // pcl::copyPointCloud(*cloud, idx_out, *cloud_out);
    // dsty.Zscore();

    auto [thresh, idx_out]=dsty.TukeyFence("<", 1);
    
    // dsty.Tanh();
    dsty.Normalize();
    auto colors=dsty.GetColors();
    for(int i=0; i<cloud->points.size(); i++){
        cloud->points[i].r=colors[i].r;
        cloud->points[i].g=colors[i].g;
        cloud->points[i].b=colors[i].b;
    }
    pcl::io::savePLYFileBinary("/home/i9/experiment_nc/ThreeDScan/raw/watertight/1.ply", *cloud);
    

    pcl::PointCloud<PointType>::Ptr cloud_out(new pcl::PointCloud<PointType>);
    pcl::copyPointCloud(*cloud, idx_out, *cloud_out);

    pcl::search::KdTree<PointType>::Ptr kdtree_out(new pcl::search::KdTree<PointType>);
    kdtree_out->setInputCloud(cloud_out);

    ofstream fout("/home/i9/experiment_nc/ThreeDScan/raw/watertight/a.xyz");
    float numerital=10.0;
    for(int i=0; i<cloud_out->points.size(); i++){
        vector<int> idx;
        vector<float> dist;
        kdtree_out->radiusSearch(cloud_out->points[i], max_dist, idx, dist);

        pcl::PointCloud<PointType>::Ptr lcloud(new pcl::PointCloud<PointType>);
        pcl::copyPointCloud(*cloud_out, idx, *lcloud);

        Delaunay2D dy(lcloud);
        auto triagular=dy.Recon();

        // V3 current_pt(cloud_out->points[i].x, cloud_out->points[i].y, cloud_out->points[i].z);
        // for(int j=1; j<idx.size(); j++){
        //     V3 ngbr_pt(cloud_out->points[idx[j]].x, cloud_out->points[idx[j]].y, cloud_out->points[idx[j]].z);
        //     // V3 mid_pt=(current_pt + ngbr_pt)/2.0;

        //     for(int k=0; k<numerital; k++){
        //         V3 pt=current_pt + (ngbr_pt - current_pt)*k/numerital;
        //         fout<<pt<<endl;
        //     } 
        // }
    }
    fout.close();


    // pcl::io::savePLYFileBinary("/home/i9/experiment_nc/ThreeDScan/raw/watertight/refine.ply",*cloud);
    pcl::io::savePLYFileBinary("/home/i9/experiment_nc/ThreeDScan/raw/watertight/ldsty.ply",*cloud_out);
}

/**
 * Description: 
 * @param  cloud_ref  
 * @param  cloud_req  point cloud requires to be adjustment
 * 
 * **/
pcl::PointCloud<PointType>::Ptr ModifyGroundGruth(pcl::PointCloud<PointType>::Ptr cloud_ref, pcl::PointCloud<PointType>::Ptr cloud_req)
{
    pcl::search::KdTree<PointType>::Ptr kdtree_old_raw(new pcl::search::KdTree<PointType>);
    kdtree_old_raw->setInputCloud(cloud_ref);

    /*  */
    for(int i=0; i<cloud_req->points.size(); i++){
        vector<int> idx;
        vector<float> dist;
        kdtree_old_raw->nearestKSearch(cloud_req->points[i], 1, idx, dist);

        V3 Vnew(cloud_req->points[i].normal_x,
                cloud_req->points[i].normal_y,
                cloud_req->points[i].normal_z);
        
        V3 Vold(cloud_ref->points[idx[0]].normal_x,
                cloud_ref->points[idx[0]].normal_y,
                cloud_ref->points[idx[0]].normal_z);
        float arc=Vnew.Dot(Vold);
        if(arc<0){
            cloud_req->points[i].normal_x=-cloud_req->points[i].normal_x;
            cloud_req->points[i].normal_y=-cloud_req->points[i].normal_y;
            cloud_req->points[i].normal_z=-cloud_req->points[i].normal_z;
        }
    }

    pcl::search::KdTree<PointType>::Ptr kdtree_new_raw(new pcl::search::KdTree<PointType>);
    kdtree_new_raw->setInputCloud(cloud_req);
    int k=20;
    for(int i=0; i<cloud_req->points.size(); i++){
        vector<int> idx;
        vector<float> dist;
        kdtree_new_raw->nearestKSearch(cloud_req->points[i], k, idx, dist);

        V3 Po(cloud_req->points[i].normal_x,
              cloud_req->points[i].normal_y,
              cloud_req->points[i].normal_z);
        
        int cnt_pos,cnt_neg;
        cnt_pos=cnt_neg=0;
        for(int j=1; j<idx.size(); j++){
            V3 Pb(cloud_req->points[idx[j]].normal_x,cloud_req->points[idx[j]].normal_y,cloud_req->points[idx[j]].normal_z);
            if(Po.Dot(Pb)<0)
                cnt_neg++;
            else 
                cnt_pos++;
        }
        if(cnt_neg>cnt_pos){
            cloud_req->points[i].normal_x=-cloud_req->points[i].normal_x;
            cloud_req->points[i].normal_y=-cloud_req->points[i].normal_y;
            cloud_req->points[i].normal_z=-cloud_req->points[i].normal_z;
        }
    }
    return cloud_req;
}


using namespace std;
// using namespace cv;
int main(int argc, char* argv[])
{   
    pcl::console::setVerbosityLevel(pcl::console::L_ERROR); 
    /* Initialization */
    createFolderIfNotExists("Cache");

    string ipath_of_ref, ipath_of_raw, ipath_of_disturbed, ipath_of_correct;
    string ipath_of_positive, ipath_of_negtive, ipath_of_required, ipath_of_trim, opath_of_correct, output_prefix;
    string ipath_of_cloud_ref, ipath_of_cloud_req, opath_of_out, ipath_of_vx;
    string ipath_of_bdry, ipath_of_gt, ipath_of_noise;
    string func;
    string opath_of_mapping_from_bdry_to_gt;
    string opath_of_corrected;
    string opath;
    string opath_of_ply, opath_of_txt;
    string whether_compute_boundary;
    string whether_use_upsampling;
    int grid_depth;

    for(int i=0; i<argc; i++){
        string str=argv[i];
        if(str=="--fun"){
            func=argv[i+1];
        }
        else if(str=="--whether_compute_boundary"){
            whether_compute_boundary = argv[i+1];
        }
        else if(str=="--whether_use_upsampling"){
            whether_use_upsampling = argv[i+1];
        }
        else if(str=="--ipath_of_ref"){
            ipath_of_ref=argv[i+1];            
        }
        else if(str=="--ipath_of_raw"){
            ipath_of_raw=argv[i+1];
        }
        else if(str=="--ipath_of_correct"){
            ipath_of_correct=argv[i+1];
        }
        else if(str=="--ipath_of_disturbed"){
            ipath_of_disturbed=argv[i+1];
            WriteStringToFilename("Cache/path_of_disturbed", ipath_of_disturbed);
            string model_name = StrSplit(GetFileName(ipath_of_disturbed), "_disturbed")[0] ;
            WriteStringToFilename("Cache/model_name", model_name);
        }
        else if(str=="--ipath_of_positive"){
            ipath_of_positive=argv[i+1];
            WriteStringToFilename("Cache/ipath_of_positive", ipath_of_positive);
        }
        else if(str=="--ipath_of_negtive"){
            ipath_of_negtive=argv[i+1];
            WriteStringToFilename("Cache/ipath_of_negtive", ipath_of_negtive);
        }
        else if(str=="--opath_of_corrected"){
            opath_of_corrected=argv[i+1];
        }
        else if(str=="--ipath_of_cloud_ref"){
            ipath_of_cloud_ref=argv[i+1];
        }
        else if(str=="--ipath_of_cloud_req"){
            ipath_of_cloud_req=argv[i+1];
        }
        else if(str=="--opath_of_out"){
            opath_of_out=argv[i+1];
        }
        else if(str=="--ipath_of_vx"){
            ipath_of_vx=argv[i+1];
        }
        else if(str=="--ipath_of_trim"){
            ipath_of_trim=argv[i+1];
        }
        else if(str=="--ipath_of_required"){
            ipath_of_required=argv[i+1];
        }
        else if(str=="--ipath_of_bdry"){
            ipath_of_bdry=argv[i+1];
        }
        else if(str=="--ipath_of_gt"){
            ipath_of_gt=argv[i+1];
        }
        else if(str=="--opath_of_mapping_from_bdry_to_gt"){
            opath_of_mapping_from_bdry_to_gt=argv[i+1];
        }
        else if(str=="--ipath_of_noise"){
            ipath_of_noise=argv[i+1];
        }
        else if(str=="--opath"){
            opath = argv[i+1];
            WriteStringToFilename("Cache/opath", opath);
        }
        else if(str=="--opath_of_correct"){
            opath_of_correct = argv[i+1];
        }
        else if(str=="--grid_depth"){
            grid_depth = atoi(argv[i+1]);
        }
        else if(str=="--opath_of_ply"){
            opath_of_ply = argv[i+1];
        }
        else if(str=="--opath_of_txt"){
            opath_of_txt = argv[i+1];
        }
    }

    if(ReadStringFromFilename("Cache/opath")!="null"){
        string model_name = ReadStringFromFilename("Cache/model_name");

        string path_of_cloud_on = ReadStringFromFilename("Cache/opath") + "/" + ReadStringFromFilename("Cache/model_name") + "_cloud_on.ply";
        WriteStringToFilename("Cache/path_of_cloud_on", path_of_cloud_on);

        string path_of_cloud_off = ReadStringFromFilename("Cache/opath") + "/" + ReadStringFromFilename("Cache/model_name") + "_cloud_off.ply";
        WriteStringToFilename("Cache/path_of_cloud_off", path_of_cloud_off);

        string path_of_cloud_positive = ReadStringFromFilename("Cache/opath") + "/" + ReadStringFromFilename("Cache/model_name") + "_positive.ply";
        WriteStringToFilename("Cache/path_of_cloud_positive", path_of_cloud_positive);

        string path_of_cloud_negtive = ReadStringFromFilename("Cache/opath") + "/" + ReadStringFromFilename("Cache/model_name") + "_negtive.ply";
        WriteStringToFilename("Cache/path_of_cloud_negtive", path_of_cloud_negtive);

        string path_of_ours = ReadStringFromFilename("Cache/opath") + "/" + ReadStringFromFilename("Cache/model_name") + "_ours.ply";
        WriteStringToFilename("Cache/path_of_ours", path_of_ours);
    }


    if(func=="compute_accuracy"){
        cout<<ipath_of_gt<<endl;
        cout<<ipath_of_correct<<endl;
        CaclulateAccuracy_by_distance(ipath_of_gt, ipath_of_correct);
    }
    /***
     * icloud 1: the cloud requires to detect edge
    */
    else if(func=="boundary_detection"){
        EdgeDetection ed;        
        ed.SetCloudProperties(ipath_of_disturbed);        
        // ed.ComputeDensity();
        ed.Apply(3.0, 180);
        ed.ExtractEdgeCloud(opath_of_out);
    }
    /***
     * icloud 1: the cloud used to establish grid. I means raw cloud or downsampling version. Actually, I always use downsampling version.
     * icloud 2: the edge cloud
     * 
    */
    else if(func=="narrow_band_establishment"){
        /* upsampling */
        string cloud_to_processing;
        if(whether_use_upsampling == "yes"){
            cout<<"* Upsampling"<<endl;
            float start_time = omp_get_wtime();  
            Upsampling us;
            us.SetInputCloud(ReadStringFromFilename("Cache/path_of_disturbed"));
            us.ApplyMLS();
            string path_of_mls = ReadStringFromFilename("Cache/opath") + "/" + ReadStringFromFilename("Cache/model_name") + "_mls.ply";
            us.ExtractCloud(path_of_mls);
            float end_time = omp_get_wtime(); 
            float elapse= end_time - start_time;
            WriteStringToFilename("Cache/path_of_mls", path_of_mls);
            
            cloud_to_processing = ReadStringFromFilename("Cache/path_of_mls");
            HybridMethod hm(ReadStringFromFilename("Cache/path_of_mls"));
            hm.LoOP("0", 30, 0.9);
            hm.ExtractResult(ReadStringFromFilename("Cache/path_of_mls"));
            printf("  * Elapse: %.2f s\n", elapse);
        }
        else{
            WriteStringToFilename("Cache/path_of_mls", "null");
            cloud_to_processing = ReadStringFromFilename("Cache/path_of_disturbed");
        }

        /* boundary detection */
        if(whether_compute_boundary=="yes"){
            cout<<"* Edge detetion"<<endl;
            float start_time = omp_get_wtime();  
            EdgeDetection ed;        
            ed.SetCloudProperties(cloud_to_processing);                    
            ed.Apply(3.5, 200);
            float end_time = omp_get_wtime(); 
            float elapse= end_time - start_time;
            printf("  * Elapse: %.2f s\n", elapse);
            string path_of_edge = opath + "/" + ReadStringFromFilename("Cache/model_name") + "_edges.ply";            
            ed.ExtractEdgeCloud(path_of_edge);
            WriteStringToFilename("Cache/path_of_edge", path_of_edge);
        }
        else{
            WriteStringToFilename("Cache/path_of_edge","null");
        }
               
        cout<<"*  Narrow bandwidth voxel establish."<<endl;
        NarrowBandVoxels obj;
        if(whether_use_upsampling=="yes")
            obj.SetInputCloud(ReadStringFromFilename("Cache/path_of_mls"));
        else
            obj.SetInputCloud(ReadStringFromFilename("Cache/path_of_disturbed"));
        
        obj.SetEdgeCloud(ReadStringFromFilename("Cache/path_of_edge"));
        obj.SetOpath(opath);
        float start_time = omp_get_wtime();
        obj.InitNarrowBandVoxels(grid_depth);
        float end_time = omp_get_wtime();
        float elapse= end_time - start_time;
        printf("* Elapse: %.2f s\n", elapse);

        /* extract voxels */
        obj.ExtractBorderAwareNarrowBandVoxels_BorderVoxels();
        obj.ExtractBorderAwareNarrowBandVoxels_RegularVoxels();
        obj.ExtractCloud_BorderVoxels();
        obj.ExtractCloud_RegularVoxels();
        cout<<"Finish!"<<endl;
    }
    else if(func=="normal_correct"){
        CorrectNormal cn;
        cn.SetInputCloud(ipath_of_disturbed,  ipath_of_positive);
        float start_time = omp_get_wtime();
        cn.Correct_by_WassteinDistance(opath_of_corrected);
        float end_time = omp_get_wtime();
        float elapse= end_time - start_time;
        printf("Elapse: %.2f s\n", elapse);
        
        string path_of_ours = ReadStringFromFilename("Cache/opath") + "/" + ReadStringFromFilename("Cache/model_name") + "_ours.ply";

        CaclulateAccuracy_by_distance("/media/i9/phi/experiment_nc/1_special_cases/1_anti_noise_test/ratio_1d00_mag_0d005/0_Raw/bunny_noise.ply", path_of_ours);
    }
    else if(func=="normal_correct_2"){                
        // string path_of_cloud_on = ReadStringFromFilename("Cache/opath")+"/"+ ReadStringFromFilename("Cache/model_name") + "_cloud_on2.ply";
        CorrectNormal cn;
        cn.LoadDisturbedCloud("/media/i9/phi/experiment_nc/1_special_cases/1_anti_noise_test/ratio_0d75_mag_0d005/4_disturbed/dragon_sampling_disturbed.ply");
        cn.Correct_by_ZeroEquipotentialSurface(
            "/media/i9/phi/experiment_nc/1_special_cases/1_anti_noise_test/ratio_0d75_mag_0d005/4_disturbed/9_ours/dragon_sampling_cloud_on.ply",
            "/media/i9/phi/experiment_nc/1_special_cases/1_anti_noise_test/ratio_0d75_mag_0d005/4_disturbed/9_ours/dragon_sampling_positive.ply");        
        cn.ExtractResult("/media/i9/phi/experiment_nc/1_special_cases/1_anti_noise_test/ratio_0d75_mag_0d005/4_disturbed/9_ours/dragon_sampling_ours.ply");
    }
    else if(func=="normal_correct_3"){ // correct normal with the help of cloud_on
        cout<<"* Normal correction"<<endl;
        CorrectNormal cn;        
        string path_of_ours = ReadStringFromFilename("Cache/opath") + "/" + ReadStringFromFilename("Cache/model_name") + "_ours.ply";
        float start_time = omp_get_wtime();
        cn.Correct_by_WassteinDistance_Pro(path_of_ours);
        float end_time = omp_get_wtime();
        float elapse= end_time - start_time;
        printf("  * Elapse: %.2f s\n", elapse);        
        CaclulateAccuracy_by_distance(ipath_of_gt, path_of_ours);
    }
    else if(func=="normal_correct_by_considering_confidence"){
        string path_of_ours = ReadStringFromFilename("Cache/opath") + "/" + ReadStringFromFilename("Cache/model_name") + "_ours.ply";
        CorrectNormal cn;
        cn.Correct_by_UDF_Pro();
        CaclulateAccuracy_by_distance(ipath_of_gt, path_of_ours);
    }
    else if(func=="find_nearest"){
        pcl::PointCloud<PointType>::Ptr cloud_required(new pcl::PointCloud<PointType>);
        pcl::io::loadPLYFile(ipath_of_raw, *cloud_required);
        pcl::PointCloud<PointType>::Ptr cloud_trim(new pcl::PointCloud<PointType>);
        pcl::io::loadPLYFile(ipath_of_trim, *cloud_trim);

        pcl::search::KdTree<PointType>::Ptr kdtree_required(new pcl::search::KdTree<PointType>);
        kdtree_required->setInputCloud(cloud_required);
        vector<int> idx_out;
        for(int i=0; i< cloud_trim->points.size(); i++){
            vector<int> idx;
            vector<float> dist;
            kdtree_required->nearestKSearch(cloud_trim->points[i], 1, idx, dist);
            idx_out.push_back(idx[0]);
        }

        pcl::PointCloud<PointType>::Ptr cloud_out(new pcl::PointCloud<PointType>);
        pcl::copyPointCloud(*cloud_required, idx_out, *cloud_out);
        opath_of_out=opath_of_out+"/"+GetFileName(ipath_of_raw);
        pcl::io::savePLYFileBinary(opath_of_out, *cloud_out);
    }   
    else if(func=="max_dist"){
        pcl::PointCloud<PointType>::Ptr cloud(new pcl::PointCloud<PointType>);
        pcl::io::loadPLYFile(ipath_of_raw, *cloud);
        CloudProperties cp;
        cp.SetInputCloud(cloud);
        float max_dist=cp.GetMaximumDistance();
        cout<<max_dist<<endl;
    }
    else if(func=="reestimated_normal_adjustment"){
        pcl::PointCloud<PointType>::Ptr cloud_ref(new pcl::PointCloud<PointType>);
        pcl::io::loadPLYFile(ipath_of_cloud_ref, *cloud_ref);

        pcl::PointCloud<PointType>::Ptr cloud_req(new pcl::PointCloud<PointType>);
        pcl::io::loadPLYFile(ipath_of_cloud_req, *cloud_req);

        auto cloud_out=ModifyGroundGruth(cloud_ref, cloud_req);  
        cout<<cloud_out->points[0].normal_x<<" "<<cloud_out->points[0].normal_y<<" "<<cloud_out->points[0].normal_z<<endl;
        pcl::io::savePLYFileBinary(opath_of_out, *cloud_out);
    }
    else if(func=="outlier_removal"){
        pcl::PointCloud<PointType>::Ptr cloud_raw(new pcl::PointCloud<PointType>);
        pcl::io::loadPLYFile(ipath_of_raw, *cloud_raw);
        
        HybridMethod hm(cloud_raw);
        hm.LNGD("0", 40, 15);
        hm.RegionGrowth_kIQR("1", 9, 60.0);
        hm.ExtractResult();
        pcl::io::savePLYFileBinary(opath_of_out, *hm.cloud_out_regular_);
        // pcl::io::savePLYFileBinary(opath_of_out, *hm.cloud_);
    }    
    else if(func=="resampling"){
        Upsampling us;
        us.SetInputCloud("/media/i9/sumsung1t/experiment_nc/3_runtime_performance/raw_ply/disturbed/horse_1k_disturbed.ply");
        us.ApplyMLS();
        us.ExtractCloud("/media/i9/gamma/workspace/P03_fdo_cpp/tmp/horse_1k_upsampling.ply");
    }
    else if(func=="weighted_distance_2"){
        int K=2;
        CloudProperties cp_query, cp_search;
        cp_query.SetInputCloud("/media/i9/gamma/workspace/P03_fdo_cpp/tmp/query_pts.ply");
        cp_search.SetInputCloud("/media/i9/gamma/workspace/P03_fdo_cpp/tmp/search_pts.ply");        
        vector<float> dsty_search=cp_search.GetDensityViaK(5);

        /*  */
        pcl::search::KdTree<PointType>::Ptr kdtree_search(new pcl::search::KdTree<PointType>);
        kdtree_search->setInputCloud(cp_search.cloud_);
        vector<float> d_was(cp_query.cloud_->points.size());
        vector<float> omega(cp_query.cloud_->points.size());
        float sigma =1;
        for(int i=0; i<cp_query.cloud_->points.size(); i++){
            vector<int> idx;
            vector<float> dist;
            kdtree_search->nearestKSearch(cp_query.cloud_->points[i], K, idx, dist);

            // calculate wasserstein distance
            float current_d_was=0;
            for(int j=0; j<K; j++){
                current_d_was += dist[j];
            }
            current_d_was = sqrt(current_d_was/K);
            d_was[i] = current_d_was;

            // calculate weight
            float current_dsty = (dsty_search[idx[0]] + dsty_search[idx[1]])/2.0;
            omega[i]= exp(- current_dsty/ (2*sigma*sigma));
        }

        float min_omega = * std::min_element(omega.begin(), omega.end());
        float max_omega = * std::max_element(omega.begin(), omega.end());
        for(int i=0; i<cp_query.cloud_->points.size(); i++){
            omega[i] = (omega[i] - min_omega)/(max_omega - min_omega);
        }

        float sum_omega = std::accumulate(omega.begin(), omega.end(), 0);
        for(int i=0; i<cp_query.cloud_->points.size(); i++){
            omega[i] = omega[i]/ sum_omega;
            // cout<<omega[i]<<" "<<d_was[i]<<" "<< omega[i] * d_was[i]<<endl;            
            d_was[i] = omega[i] * d_was[i];
        }


        ofstream fout("tmp/weighted_distance_2_k_2.txt");
        for(int i=0; i<d_was.size(); i++){
            fout<<d_was[i]<<endl;
        }
        fout.close();
    }
    else if(func=="weighted_distance"){
        int K=2;
        CloudProperties cp_query, cp_search;
        cp_query.SetInputCloud("/media/i9/gamma/workspace/P03_fdo_cpp/tmp/query_pts.ply");
        cp_search.SetInputCloud("/media/i9/gamma/workspace/P03_fdo_cpp/tmp/search_pts.ply");

        /*  */
        pcl::search::KdTree<PointType>::Ptr kdtree_search(new pcl::search::KdTree<PointType>);
        kdtree_search->setInputCloud(cp_search.cloud_);

        vector<float> dw(cp_query.cloud_->points.size());

        for(int i=0; i<cp_query.cloud_->points.size(); i++){
            vector<int> idx;
            vector<float> dist;
            kdtree_search->nearestKSearch(cp_query.cloud_->points[i], K, idx, dist);

            // calculate sigma
            float sigma=0;
            for(int j=0; j<K; j++){
                sigma+= sqrt(dist[j]);
            }
            sigma = 1.0* sigma / K;

            // 
            float di=0;
            for(int j=0; j<K; j++){
                float omega = exp(- dist[j]/(2*sigma*sigma));
                di+= omega*sqrt(dist[j]);
            }
            dw[i]=di;
        }



        ofstream fout("tmp/weighted_distance_k_2_s_1.txt");
        for(int i=0; i<dw.size(); i++){
            fout<<dw[i]<<endl;
        }
        fout.close();
    }
    else if(func=="wasserstein_distance"){
        int K=2;
        CloudProperties cp_query, cp_search;
        cp_query.SetInputCloud("/media/i9/gamma/workspace/P03_fdo_cpp/tmp/query_pts.ply");
        cp_search.SetInputCloud("/media/i9/gamma/workspace/P03_fdo_cpp/tmp/search_pts.ply");

        /*  */
        pcl::search::KdTree<PointType>::Ptr kdtree_search(new pcl::search::KdTree<PointType>);
        kdtree_search->setInputCloud(cp_search.cloud_);

        vector<float> dw(cp_query.cloud_->points.size());

        for(int i=0; i<cp_query.cloud_->points.size(); i++){
            vector<int> idx;
            vector<float> dist;
            kdtree_search->nearestKSearch(cp_query.cloud_->points[i], K, idx, dist);

            // calculate sigma
            float sum=0;
            for(int j=0; j<K; j++){
                sum+=dist[j];
            }
            sum= sqrt(sum /K);
            
            dw[i]=sum;
        }

        ofstream fout("tmp/wassertein_distance_k_2.txt");
        for(int i=0; i<dw.size(); i++){
            fout<<dw[i]<<endl;
        }
        fout.close();
    }
    else if(func=="mahalanobis_distance"){
        int K=2;
        CloudProperties cp_query, cp_search;
        cp_query.SetInputCloud("/media/i9/gamma/workspace/P03_fdo_cpp/tmp/query_pts.ply");
        cp_search.SetInputCloud("/media/i9/gamma/workspace/P03_fdo_cpp/tmp/search_pts.ply");

        /*  */
        pcl::search::KdTree<PointType>::Ptr kdtree_search(new pcl::search::KdTree<PointType>);
        kdtree_search->setInputCloud(cp_search.cloud_);

        vector<float> dw(cp_query.cloud_->points.size());

        for(int i=0; i<cp_query.cloud_->points.size(); i++){
            vector<int> idx;
            vector<float> dist;
            kdtree_search->nearestKSearch(cp_query.cloud_->points[i], K, idx, dist);

            
            Eigen::Vector2f mu(0,0);
            for(int j=0; j<K; j++){
                mu = mu + Eigen::Vector2f(cp_search.cloud_->points[idx[j]].x, cp_search.cloud_->points[idx[j]].y);                
            }
            mu = mu/K;
            Eigen::Vector2f x(cp_query.cloud_->points[i].x, cp_query.cloud_->points[i].y);
            
            // covariance 

            Eigen::MatrixXf S = 1/(K-1) * (x-mu) *(x-mu).transpose();
            cout<<mu<<endl;
            cout<<(x-mu)<<endl;
            cout<<S<<endl;
            cout<<S.inverse()<<endl;
            cout<<"wokaka"<<endl;
            // dw[i]=sum;
        }

        ofstream fout("tmp/wassertein_distance_k_2.txt");
        for(int i=0; i<dw.size(); i++){
            fout<<dw[i]<<endl;
        }
        fout.close();
    }
    else if(func=="compute_accuracy_of_bdry"){        
        pcl::PointCloud<PointType>::Ptr cloud_bdry(new pcl::PointCloud<PointType>);
        pcl::PointCloud<PointType>::Ptr cloud_raw(new pcl::PointCloud<PointType>);
        pcl::PointCloud<PointType>::Ptr cloud_gt(new pcl::PointCloud<PointType>);
        pcl::io::loadPLYFile(ipath_of_bdry, *cloud_bdry);
        pcl::io::loadPLYFile(ipath_of_raw, *cloud_raw);
        pcl::io::loadPLYFile(ipath_of_gt, *cloud_gt);
        if(cloud_raw->points.size() != cloud_gt->points.size())
            cout<<"error!"<<endl;

        vector<int> flag_idx_neg, flag_idx_pos;
        vector<int> mapping_from_bdry_to_gt(cloud_bdry->points.size());

        // find mapping from bdry to raw point cloud. Note that the raw point cloud and 
        // ground truth point cloud has one to one correspondance in order. Hence, the mapping from
        // bdry to ground truth is also obtained.
        pcl::search::KdTree<PointType>::Ptr kdtree_raw(new pcl::search::KdTree<PointType>);
        kdtree_raw->setInputCloud(cloud_raw);
        for(int i=0; i<cloud_bdry->points.size(); i++){
            vector<int> idx;
            vector<float> dist;
            kdtree_raw->nearestKSearch(cloud_bdry->points[i], 1, idx, dist);
            mapping_from_bdry_to_gt[i]= idx[0];
        }
        
        int num_of_correct=0;
        for(int i=0; i<cloud_bdry->points.size(); i++){
            V3 nrm_1(cloud_bdry->points[i].normal_x, cloud_bdry->points[i].normal_y, cloud_bdry->points[i].normal_z);
            
            int itmp= mapping_from_bdry_to_gt[i];
            V3 nrm_2(cloud_gt->points[itmp].normal_x, cloud_gt->points[itmp].normal_y, cloud_gt->points[itmp].normal_z);

            float arc= nrm_1.Dot(nrm_2);
            if(arc>0){
                flag_idx_pos.push_back(i);
                num_of_correct++;
            }
            else{
                flag_idx_neg.push_back(i);
            }                
        }

        float ratio= num_of_correct*1.0/cloud_bdry->points.size();
        if(ratio<0.5){
            num_of_correct=cloud_bdry->points.size() - num_of_correct;
            // ratio=1-ratio;
        }
        // cout<<"num_of_errors: "<<(cloud_bdry->points.size() - num_of_correct)<<endl;
        // cout<<"Accuracy: "<< abs(2*ratio-1)<<endl;

        int num_of_errors= cloud_bdry->points.size() - num_of_correct;
        printf("Errors:\t %d \t Accuracy: %.4f\n", num_of_errors, abs(2*ratio-1));


        pcl::PointCloud<PointType>::Ptr cloud_flag_pos(new pcl::PointCloud<PointType>);
        pcl::PointCloud<PointType>::Ptr cloud_flag_neg(new pcl::PointCloud<PointType>);
        if(flag_idx_pos.size()>0){
            pcl::copyPointCloud(*cloud_bdry, flag_idx_pos, *cloud_flag_pos);
            pcl::io::savePLYFileBinary(StrSplit(ipath_of_bdry,".")[0]+"_flag_pos.ply",*cloud_flag_pos);
        }
        
        if(flag_idx_neg.size()>0){
            pcl::copyPointCloud(*cloud_bdry, flag_idx_neg, *cloud_flag_neg);
            pcl::io::savePLYFileBinary(StrSplit(ipath_of_bdry,".")[0]+"_flag_neg.ply",*cloud_flag_neg);
        }
    }
    else if(func=="compute_accuracy_of_fdo"){
        /**************************************************
         *  normal orientation
        ***************************************************/
        CorrectNormal cn;
        cn.SetInputCloud(ipath_of_raw,  ipath_of_positive);
        float Tstart=clock();
        cn.Correct_by_WassteinDistance(opath_of_corrected);
        cout<<"Elapsed: "<<(clock()-Tstart)/CLOCKS_PER_SEC<<endl;

        /****************************************************
         * 
        ***************************************************/
        pcl::PointCloud<PointType>::Ptr cloud_bdry(new pcl::PointCloud<PointType>);
        pcl::PointCloud<PointType>::Ptr cloud_noise(new pcl::PointCloud<PointType>);
        pcl::PointCloud<PointType>::Ptr cloud_gt(new pcl::PointCloud<PointType>);
        pcl::io::loadPLYFile(opath_of_corrected, *cloud_bdry);
        pcl::io::loadPLYFile(ipath_of_noise, *cloud_noise);
        pcl::io::loadPLYFile(ipath_of_gt, *cloud_gt);

        if(cloud_noise->points.size() != cloud_gt->points.size()){
            cout<<"number of raw cloud: "<<cloud_noise->points.size()<<endl;
            cout<<"number of gt cloud: "<<cloud_gt->points.size()<<endl;
            cout<<"error!"<<endl;
        }            

        vector<int> mapping_from_bdry_to_gt(cloud_bdry->points.size());

        // find mapping from bdry to raw point cloud. Note that the raw point cloud and 
        // ground truth point cloud has one to one correspondance in order. Hence, the mapping from
        // bdry to ground truth is also obtained.
        pcl::search::KdTree<PointType>::Ptr kdtree_raw(new pcl::search::KdTree<PointType>);
        kdtree_raw->setInputCloud(cloud_noise);
        for(int i=0; i<cloud_bdry->points.size(); i++){
            vector<int> idx;
            vector<float> dist;
            kdtree_raw->nearestKSearch(cloud_bdry->points[i], 1, idx, dist);
            mapping_from_bdry_to_gt[i]= idx[0];
        }
        
        int num_of_correct=0;
        for(int i=0; i<cloud_bdry->points.size(); i++){
            V3 nrm_1(cloud_bdry->points[i].normal_x, cloud_bdry->points[i].normal_y, cloud_bdry->points[i].normal_z);
            
            int itmp= mapping_from_bdry_to_gt[i];
            V3 nrm_2(cloud_gt->points[itmp].normal_x, cloud_gt->points[itmp].normal_y, cloud_gt->points[itmp].normal_z);

            float arc= nrm_1.Dot(nrm_2);
            if(arc>0)
                num_of_correct++;
        }

        float ratio= num_of_correct*1.0/cloud_bdry->points.size();
        if(ratio<0.5){
            num_of_correct=cloud_bdry->points.size() - num_of_correct;
        }
        int num_of_errors= cloud_bdry->points.size() - num_of_correct;
        printf("Errors:\t %d \t Accuracy: %.4f\n", num_of_errors, abs(2*ratio-1));
    }
    else if(func=="compute_for_mst"){
        pcl::PointCloud<PointType>::Ptr cloud(new pcl::PointCloud<PointType>);
        pcl::io::loadPLYFile(ipath_of_raw, *cloud);
        auto components = GetConnectedComponents(cloud);                
        cout<<components.size()<<endl;
    }
    else if(func=="test_for_time"){
        pcl::PointCloud<PointType>::Ptr cloud(new pcl::PointCloud<PointType>);
        pcl::io::loadPLYFile(ipath_of_raw, *cloud);
        int numOfPts=cloud->points.size();


        
        float start_time = omp_get_wtime(); 
        pcl::search::KdTree<PointType>::Ptr kdtree1(new pcl::search::KdTree<PointType>);
        for(int i=0; i<1000; i++){
            kdtree1->setInputCloud(cloud);
        }
        float end_time = omp_get_wtime(); 
        float elapse= end_time - start_time;
        printf("Elapse: %.2f s\n", elapse);

        start_time = omp_get_wtime(); 
        for(int i=0; i<1000; i++){
           pcl::search::KdTree<PointType>::Ptr kdtree2(new pcl::search::KdTree<PointType>);
           kdtree2->setInputCloud(cloud);
        }
        end_time = omp_get_wtime(); 
        elapse= end_time - start_time;
        printf("Elapse: %.2f s\n", elapse);
    }
    else if(func=="test_for_equal"){
        LineSegment ls_1(V3(-45.814163,42.340290,1.256090), V3(-46.611145,42.340065,1.255732));
        for(int i=0; i<8; i++){
            cout<<ls_1.GetQuantile(i/8.0)<<endl;
        }
        cout<<"wokaka"<<endl;
    }
    else if(func=="upsampling"){
        // pcl::PointCloud<PointType>::Ptr icloud(new pcl::PointCloud<PointType>);
        // pcl::io::loadPLYFile("/media/i9/Lei/experiment_nc/1_special_cases/2_varying_point_density/disturbed/bulbasaur_flower_pot_merge_disturbed.ply", *icloud);
        // pcl::PointCloud<PointType>::Ptr ocloud = nearestNeighborInterpolation(icloud);
        // pcl::io::savePLYFileBinary("/media/i9/Lei/experiment_nc/1_special_cases/2_varying_point_density/disturbed/bulbasaur_flower_pot_merge_ocloud.ply", *ocloud);

        Upsampling us;
        us.SetInputCloud(ipath_of_raw);
        us.ApplyMLS();
        us.ExtractCloud(opath_of_out);
    }
    else if(func=="fold"){
        /* read edge file */
        vector<vector<int>> edges;
        vector<float> weights;
        ifstream fin("/media/i9/Lei/experiment_nc/1_special_cases/2_varying_point_density/disturbed/9_ours/bulbasaur_flower_pot_merge_edges_old.csv");
        if (fin.is_open()) { // 检查文件是否成功打开  
            std::string line;  
            std::getline(fin, line); // jump over this head line
            while(std::getline(fin, line)){
                auto ss=StrSplit(line, ",");
                edges.push_back({std::stoi(ss[0]), std::stoi(ss[1])});
                weights.push_back(std::stof(ss[3]));
            }
        }

        GraphExtend inst_g;
        inst_g.Create(edges, weights);
        inst_g.ApplyFold(0.6);
        cout<<"Finish!"<<endl;
    }
    else if(func=="ipsr_modify"){
        pcl::PointCloud<PointType>::Ptr cloud_disturbed(new pcl::PointCloud<PointType>);
        pcl::PointCloud<PointType>::Ptr cloud_result(new pcl::PointCloud<PointType>);
        pcl::io::loadPLYFile(ipath_of_disturbed, *cloud_disturbed);
        pcl::io::loadPLYFile(ipath_of_raw, *cloud_result);
        pcl::search::KdTree<PointType>::Ptr kdtree(new pcl::search::KdTree<PointType>);
        kdtree->setInputCloud(cloud_result);
        for(int i=0; i < cloud_disturbed->points.size(); i++){
            vector<int> idx;
            vector<float> dist;
            kdtree->nearestKSearch(cloud_disturbed->points[i], 1, idx, dist);
            V3 current_result_pt(cloud_result->points[idx[0]].normal_x, cloud_result->points[idx[0]].normal_y, cloud_result->points[idx[0]].normal_z);
            V3 current_disturbed_pt(cloud_disturbed->points[i].normal_x, cloud_disturbed->points[i].normal_y, cloud_disturbed->points[i].normal_z);
            float arc = current_result_pt.Dot(current_disturbed_pt);
            if(arc<0){
                cloud_disturbed->points[i].normal_x=-cloud_disturbed->points[i].normal_x;
                cloud_disturbed->points[i].normal_y=-cloud_disturbed->points[i].normal_y;
                cloud_disturbed->points[i].normal_z=-cloud_disturbed->points[i].normal_z;
            }
        }
        pcl::io::savePLYFileBinary(opath_of_correct, *cloud_disturbed);
    }
    else if(func=="order_result"){
        struct order_data{
            int id_;
            float data_;
            int order_;
        };
        ifstream fin("/media/i9/phi/1.txt");
        string line;
        while(getline(fin, line)){
            auto ss=StrSplit(line,",");
            vector<order_data> dat;
            for(int i=0; i<ss.size(); i++){
                dat.push_back({i, (float)atof(ss[i].c_str())});
            }
            sort(dat.begin(), dat.end(), [](order_data& e1, order_data& e2){return e1.data_< e2.data_;});

            dat[0].order_=1;
            int previous_error_num = dat[0].data_;
            int order = 1;
            for(int i=1; i<dat.size(); i++){
                if(previous_error_num == dat[i].data_)
                    dat[i].order_=order;
                else{
                    dat[i].order_=(++order);
                    previous_error_num = dat[i].data_;
                }                    
            }
            sort(dat.begin(), dat.end(), [](order_data& e1, order_data& e2){return e1.id_< e2.id_;});

            for(int i=0; i<dat.size(); i++){
                cout<<dat[i].order_<<",";
            }
            cout<<endl;            
        }
        fin.close();
    }
    else if(func=="region_growth"){
        pcl::PointCloud<PointType>::Ptr cloud(new pcl::PointCloud<PointType>);        
        pcl::PointCloud<pcl::Normal>::Ptr normals(new pcl::PointCloud<pcl::Normal>);
        pcl::search::Search<PointType>::Ptr tree = pcl::search::KdTree<PointType>::Ptr(new pcl::search::KdTree<PointType>);

        pcl::io::loadPLYFile(ipath_of_raw, *cloud);                
        for (size_t i = 0; i < cloud->points.size(); ++i)
        {
            pcl::Normal normal;
            normal.normal_x = cloud->points[i].normal_x;
            normal.normal_y = cloud->points[i].normal_y;
            normal.normal_z = cloud->points[i].normal_z;
            normals->points.push_back(normal);
        }

        // 初始化区域增长分割器
        pcl::RegionGrowing<PointType, pcl::Normal> reg;
        reg.setMinClusterSize(1);
        // reg.setMaxClusterSize(1000000);        
        reg.setSearchMethod(tree);
        reg.setNumberOfNeighbours(5);
        reg.setInputCloud(cloud);
        reg.setInputNormals(normals); // 使用提取的法向信息
        reg.setSmoothnessThreshold(12.0 / 180.0 * M_PI);
        reg.setCurvatureThreshold(1.0);

        // 执行分割
        std::vector<pcl::PointIndices> clusters;
        reg.extract(clusters);

        // 可视化
        int j = 0;
        for (std::vector<pcl::PointIndices>::const_iterator it = clusters.begin(); it != clusters.end(); ++it)
        {
            int r = rand() %256;
            int g = rand() %256;
            int b = rand() %256;

            pcl::PointCloud<PointType>::Ptr cloud_cluster(new pcl::PointCloud<PointType>);
            for (std::vector<int>::const_iterator pit = it->indices.begin(); pit != it->indices.end(); ++pit){
                cloud->points[*pit].r = r;
                cloud->points[*pit].g = g;
                cloud->points[*pit].b = b;
            }
        }
        pcl::io::savePLYFileBinary("/media/i9/gamma/Exp_nc/demo/color.ply", *cloud);

        
    }
    else if(func=="plot_narrow_band_grid"){
        pcl::PointCloud<PointType>::Ptr cloud(new pcl::PointCloud<PointType>);        
        pcl::search::Search<PointType>::Ptr tree = pcl::search::KdTree<PointType>::Ptr(new pcl::search::KdTree<PointType>);
        pcl::io::loadPLYFile(ipath_of_raw, *cloud);

        NarrowBandVoxels obj;
        obj.SetInputCloud(ipath_of_raw);
        obj.InitNarrowBandVoxels(7);
        obj.ExtractAdjacent(opath_of_out+"_adjacent_7.obj");
        obj.ExtractNarrowBandVoxels(opath_of_out+"_voxels_7.obj");
        // obj.WriteVoxels(opath_of_out);
    }
    else if(func=="AC_boundary_detection"){        
        /*输入点云和法线*/
        pcl::PointCloud<PointType>::Ptr cloud(new pcl::PointCloud<PointType>);
        pcl::PointCloud<pcl::Normal>::Ptr normal(new pcl::PointCloud<pcl::Normal>);
        pcl::PLYReader reader;
        reader.read(ipath_of_raw, *cloud);
        reader.read(ipath_of_raw, *normal);
		
        /*pcl计算边界*/
        pcl::PointCloud<pcl::Boundary>::Ptr boundaries(new pcl::PointCloud<pcl::Boundary>); //声明一个boundary类指针，作为返回值
        boundaries->resize(cloud->size()); //初始化大小
        pcl::BoundaryEstimation<PointType, pcl::Normal, pcl::Boundary> boundary_estimation; //声明一个BoundaryEstimation类
        boundary_estimation.setInputCloud(cloud); //设置输入点云
        boundary_estimation.setInputNormals(normal); //设置输入法线
        pcl::search::KdTree<PointType>::Ptr kdtree_ptr(new pcl::search::KdTree<PointType>); 
        boundary_estimation.setSearchMethod(kdtree_ptr); //设置搜寻k近邻的方式
        boundary_estimation.setKSearch(30); //设置k近邻数量
        boundary_estimation.setAngleThreshold(M_PI * 0.6); //设置角度阈值，大于阈值为边界
        boundary_estimation.compute(*boundaries); //计算点云边界，结果保存在boundaries中

        ofstream fout(opath_of_txt);
        int count_of_edge_pts=0;
        vector<int> indices_of_edges;
        for(int i=0; i<cloud->points.size(); i++){
            if(boundaries->points[i].boundary_point!=0){
                cloud->points[i].r=255;
                cloud->points[i].g=0;
                cloud->points[i].b=0;
                fout<<"1"<<endl;
                count_of_edge_pts++;
                indices_of_edges.push_back(i);
            }
            else{
                fout<<"0"<<endl;
            }
        }
        fout.close();

        cout<<"number of edge points: "<<count_of_edge_pts<<endl;

        pcl::PointCloud<PointType>::Ptr cloud_edges(new pcl::PointCloud<PointType>);
        pcl::copyPointCloud(*cloud, indices_of_edges, *cloud_edges);
        pcl::io::savePLYFileBinary(opath_of_ply, *cloud_edges);
    }
    else if(func=="HDC_boundary_detection"){
        /*输入点云和法线*/
        pcl::PointCloud<PointType>::Ptr cloud(new pcl::PointCloud<PointType>);
        pcl::PLYReader reader;
        reader.read(ipath_of_raw, *cloud);

        applyHalfdiscCriterion(cloud, 1.5, 10, "/media/i9/gamma/Exp_nc/5_boundary_detection/Raw/cube_uniform100k_noise_white_1_HDC.ply");
        
    }
    return 0; 
}