#include <GraphExtend.h>
void GraphExtend::Create(vector<vector<int>> edge_list, vector<float> weight)
{
    /* step 01: create edges and set their corresponding weight */
    int num_of_edges = weight.size();
    add_edge(edge_list[0][0], edge_list[0][1], EdgeProperty({weight[0]}), g_); 

    for(int i=1; i < num_of_edges; i++){   
        int snode = edge_list[i][0];
        int tnode = edge_list[i][1];
        GraphType::edge_descriptor edge;
        bool exists;
        boost::tie(edge, exists) = boost::edge(snode, tnode, g_);  
        if(exists==false)   /* make sure no duplicate edges */
            add_edge(edge_list[i][0], edge_list[i][1], EdgeProperty({weight[i]}), g_);        
    } 

    /* record all edges */     
    for (auto edgeIt = boost::edges(g_); edgeIt.first != edgeIt.second; ++edgeIt.first) {  
        edges_.push_back(*edgeIt.first);  
    }  
    num_of_edges_ = boost::num_edges(g_);

    /* nodes */
    num_of_nodes_ = boost::num_vertices(g_);
}

void GraphExtend::SetEdgeWeight(int snode, int tnode, float weight)
{
    auto weight_map = get(&EdgeProperty::weight_, g_);          
    GraphType::edge_descriptor edge;
    bool exists;
    boost::tie(edge, exists) = boost::edge(snode, tnode, g_);    // 获取边(1, 2)  
    if(exists){
       weight_map[edge]=weight;   
    }
    else{
        cout<<"Warning: This edge not found!"<<endl;
    }
}

float GraphExtend::GetEdgeWeight(int snode, int tnode)
{
    auto weight_map = get(&EdgeProperty::weight_, g_);          
    GraphType::edge_descriptor edge;
    bool exists;
    boost::tie(edge, exists) = boost::edge(snode, tnode, g_);    // 获取边(1, 2) 
    return weight_map[edge];
}

std::unordered_map<int, std::vector<int>> order_clusters_by_vector_size(const std::unordered_map<int, std::vector<int>>& clusters) 
{    
    // Create a vector of pairs to sort the clusters based on vector size
    std::vector<std::pair<int, std::vector<int>>> sorted_clusters(clusters.begin(), clusters.end());
    
    // Sort the pairs based on the size of the vector in descending order
    std::sort(sorted_clusters.begin(), sorted_clusters.end(), 
              [](const std::pair<int, std::vector<int>>& a, const std::pair<int, std::vector<int>>& b){
                  return a.second.size() > b.second.size();
              });

    // Create an unordered_map from the sorted pairs
    std::unordered_map<int, std::vector<int>> ordered_clusters;
    for(std::vector<std::pair<int, std::vector<int>>>::reverse_iterator it=sorted_clusters.rbegin(); it!=sorted_clusters.rend(); it++){
        ordered_clusters[it->first].insert(ordered_clusters[it->first].end(), it->second.begin(), it->second.end());
    }

    return ordered_clusters;
}

void GraphExtend::ApplyFold(float weight_threshold)
{
    ofstream fout;
    /* create new graph */
    vector<GraphType::edge_descriptor> edges_with_low_confidence;
   
    set<int> immature_fold_nodes, remaining_nodes;
    for(int i=0; i < num_of_edges_; i++){
        int current_snode = boost::source(edges_[i], g_);
        int current_tnode = boost::target(edges_[i], g_);
        // if(current_snode==9 && current_tnode==217)
        //     cout<<"tmp"<<endl;

        if(g_[edges_[i]].weight_ <= weight_threshold){           
            remaining_nodes.insert(current_snode);
            remaining_nodes.insert(current_tnode);
            edges_with_low_confidence.push_back(edges_[i]);           
        }
        else{
            immature_fold_nodes.insert(current_snode);
            immature_fold_nodes.insert(current_tnode);
        }
    }

    std::set<int> fold_nodes;  
    std::set_difference(immature_fold_nodes.begin(), immature_fold_nodes.end(), 
                        remaining_nodes.begin(), remaining_nodes.end(),
                        std::inserter(fold_nodes, fold_nodes.begin()));

    // fout.open("/media/i9/Lei/experiment_nc/1_special_cases/2_varying_point_density/disturbed/9_ours/remaining_nodes.txt");
    // for(auto& e:remaining_nodes){
    //     fout<<e<<endl;
    // }
    // fout.close();

    // fout.open("/media/i9/Lei/experiment_nc/1_special_cases/2_varying_point_density/disturbed/9_ours/fold_nodes.txt");
    // for(auto& e:fold_nodes){
    //     fout<<e<<endl;
    // }
    // fout.close();


    /* get correspondance from remaining node to new node*/
    int fold_graph_nodes_cnt=0;
    for(set<int>::iterator it=remaining_nodes.begin(); it!=remaining_nodes.end(); it++){
        mapping_of_old_2_new_[*it] = fold_graph_nodes_cnt++;
    }

    /* construct temporary graph */
    GraphType temporary_graph;
    for(int i=0; i < num_of_edges_; i++){
        if(g_[edges_[i]].weight_>weight_threshold){
            int current_snode = boost::source(edges_[i], g_);
            int current_tnode = boost::target(edges_[i], g_);            
            if(fold_nodes.count(current_snode)==0 || fold_nodes.count(current_tnode)==0) // if this edge 
                boost::add_edge(current_snode, current_tnode, EdgeProperty({g_[edges_[i]].weight_}), temporary_graph);
        }
    }

    /* get connected components */
    std::vector<int> component(num_vertices(temporary_graph));
    int num_components = connected_components(temporary_graph, &component[0]);
    markSingleAndReorder(component); // note: this function update four variables

    /* cluster id -> location indices */        
    std::unordered_map<int, vector<int>> clusters;
    for(int i=0; i < component.size(); i++){
        if(component[i]!=-1){
            clusters[component[i]].push_back(i);
        }
    }

    /* sort clusters order with cluster size */
    std::unordered_map<int, std::vector<int>>  clusters_ordered_by_size = order_clusters_by_vector_size(clusters);   

    /* reorder cluster id */    
    std::map<int, vector<int>> clusters_reordered;
    for(auto it=clusters_ordered_by_size.begin(); it!=clusters_ordered_by_size.end(); it++){
        int current_cluster_id = fold_graph_nodes_cnt++;
        clusters_reordered[current_cluster_id] = it->second;

        /* traverse */
        for(int i=0; i < it->second.size(); i++){
            mapping_of_new_2_old_[it->second[i]] = current_cluster_id;
        }
    }    
    
    /* create fold graph */
    GraphType fold_graph;
    // first edge
    auto current_edge = edges_with_low_confidence[0];
    int old_snode = boost::source(current_edge, g_);
    int old_tnode = boost::target(current_edge, g_);
    int new_snode = mapping_of_old_2_new_[old_snode];
    int new_tnode = mapping_of_old_2_new_[old_tnode];
    float current_weight = g_[edges_[0]].weight_;
    boost::add_edge(new_snode, new_tnode, EdgeProperty({current_weight}), fold_graph); 
    
    // other edges
    for(int i=0; i < edges_with_low_confidence.size(); i++){
        auto current_edge = edges_with_low_confidence[i];
        int old_snode = boost::source(current_edge, g_);
        int old_tnode = boost::target(current_edge, g_);
        int new_snode = mapping_of_old_2_new_[old_snode];
        int new_tnode = mapping_of_old_2_new_[old_tnode];
        float current_weight = g_[edges_[i]].weight_;

        auto weight_map = get(&EdgeProperty::weight_, fold_graph);
        GraphType::edge_descriptor edge;
        bool exists;  
        boost::tie(edge, exists) = boost::edge(new_snode, new_tnode, fold_graph);  
        if (exists) {  
            double weight = weight_map[edge];                  // read edge weight  
            double min_weight = weight < current_weight ? weight: current_weight;
            boost::add_edge(new_snode, new_tnode, EdgeProperty({min_weight}), fold_graph); 
        }
        else
            boost::add_edge(new_snode, new_tnode, EdgeProperty({current_weight}), fold_graph); 
    }

    fout.open("/media/i9/Lei/experiment_nc/1_special_cases/2_varying_point_density/disturbed/9_ours/bulbasaur_flower_pot_merge_edges_new.csv");
    GraphType::edge_iterator it, end;  
    auto weight_map = get(&EdgeProperty::weight_, fold_graph);
    for (boost::tie(it, end) = boost::edges(fold_graph); it != end; ++it) {  
        fout << boost::source(*it, fold_graph) << "," << boost::target(*it, fold_graph) << ","<< weight_map[*it]<<endl;
    }  
    fout.close();

    fout.open("/media/i9/Lei/experiment_nc/1_special_cases/2_varying_point_density/disturbed/9_ours/bulbasaur_flower_pot_merge_nodes_new.csv");
    for (auto vertex : boost::make_iterator_range(boost::vertices(fold_graph))) {  
        fout<<vertex<<endl;  
    }  
    fout.close();

    cout<<"wokaka"<<endl;    
}

void GraphExtend::markSingleAndReorder(std::vector<int>& dat)
{
    // Step 1: Count frequency
    std::unordered_map<int, int> freq;
    for(int i=0; i<dat.size(); i++){
        freq[dat[i]]++;
        old_2_corresponding_pos_[dat[i]].push_back(i);
    }

    // Step 2: Mark single occurrences
    for(int i=0; i<dat.size(); i++){
        if (freq[dat[i]] == 1){
            dat[i] = -1;
        }
    }

    // Step 3: reorder    
    for(int i=0; i<dat.size(); i++){
        if(dat[i]!=-1){
            if(mapping_of_old_2_new_.count(dat[i])==0){ // if this element not exist
                mapping_of_old_2_new_[dat[i]]=0;
            }
        }   
    }

    int reorder_cnt=0;    
    for(auto &pair: mapping_of_old_2_new_){
        mapping_of_new_2_old_[reorder_cnt] = pair.second;
        pair.second = reorder_cnt++;
    }

    // Step 4: 
    for(int i=0; i< dat.size(); i++){
        if(dat[i]!=-1){
            int current_value = dat[i];
            int update_value = mapping_of_old_2_new_[current_value];
            dat[i]= update_value;            
            new_2_corresponding_pos_[dat[i]].push_back(i);
        }
    }    
}


set<int> GraphExtend::SetRemaining(set<int>& dat)
{
    set<int> all_dat;
    int maximum_in_dat = *std::max_element(dat.begin(), dat.end());
    for(int i=0; i<maximum_in_dat; i++){
        all_dat.insert(i);
    }

    set<int> remaining_dat;
    set_difference(all_dat.begin(), all_dat.end(), dat.begin(), dat.end(), std::inserter(remaining_dat, remaining_dat.end()));
    return remaining_dat;
}