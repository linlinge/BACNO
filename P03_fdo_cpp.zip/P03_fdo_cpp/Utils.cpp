#include <Utils.h>
void ply_2_xyznxnynz(string ipath_of_raw, string opath_of_out)
{
    pcl::PointCloud<PointType>::Ptr cloud_raw(new pcl::PointCloud<PointType>);
    pcl::io::loadPLYFile(ipath_of_raw, *cloud_raw);
    ofstream fout(opath_of_out);
    for(int i=0; i<cloud_raw->points.size(); i++){
        fout<<cloud_raw->points[i].x<<" "<<cloud_raw->points[i].y<<" "<<cloud_raw->points[i].z<<" "
            <<cloud_raw->points[i].normal_x<<" "<<cloud_raw->points[i].normal_y<<" "<<cloud_raw->points[i].normal_z<<endl;
    }
    fout.close();
}

void pcpnet_modify(string ipath_of_disturbed, string ipath_of_correct, string opath_of_out)
{
    pcl::PointCloud<PointType>::Ptr cloud_disturbed(new pcl::PointCloud<PointType>);
    pcl::PointCloud<PointType>::Ptr cloud_pcpnet_out(new pcl::PointCloud<PointType>);
    pcl::io::loadPLYFile(ipath_of_disturbed, *cloud_disturbed);
    pcl::io::loadPLYFile(ipath_of_correct, *cloud_pcpnet_out);
    pcl::search::KdTree<PointType>::Ptr kdtree_correct(new pcl::search::KdTree<PointType>);
    kdtree_correct->setInputCloud(cloud_pcpnet_out);
    for(int i=0; i<cloud_disturbed->points.size(); i++){
        vector<int> idx;
        vector<float> dist;
        kdtree_correct->nearestKSearch(cloud_disturbed->points[i], 1, idx, dist);
        V3 current_disturbed(cloud_disturbed->points[i].normal_x, 
                                cloud_disturbed->points[i].normal_y,
                                cloud_disturbed->points[i].normal_z);

        V3 current_correct(cloud_pcpnet_out->points[idx[0]].normal_x, 
                            cloud_pcpnet_out->points[idx[0]].normal_y,
                            cloud_pcpnet_out->points[idx[0]].normal_z);
        
        float arc=current_disturbed.Dot(current_correct);
        if(arc<0){
            cloud_disturbed->points[i].normal_x=-cloud_disturbed->points[i].normal_x;
            cloud_disturbed->points[i].normal_y=-cloud_disturbed->points[i].normal_y;
            cloud_disturbed->points[i].normal_z=-cloud_disturbed->points[i].normal_z;
        }
    }

    pcl::io::savePLYFileBinary(opath_of_out, *cloud_disturbed);
}

void normal_modify(string ipath_of_ref, string ipath_of_required, string opath_of_out)
{
    pcl::PointCloud<PointType>::Ptr cloud_ref(new pcl::PointCloud<PointType>);
    pcl::PointCloud<PointType>::Ptr cloud_required(new pcl::PointCloud<PointType>);
    pcl::io::loadPLYFile(ipath_of_ref, *cloud_ref);
    pcl::io::loadPLYFile(ipath_of_required, *cloud_required);

    pcl::search::KdTree<PointType>::Ptr kdtree_raw(new pcl::search::KdTree<PointType>);
    kdtree_raw->setInputCloud(cloud_ref);
    for(int i=0; i<cloud_required->points.size(); i++){
        vector<int> idx;
        vector<float> dist;
        kdtree_raw->nearestKSearch(cloud_required->points[i], 1, idx, dist);

        V3 nrm_of_required(cloud_required->points[i].normal_x, cloud_required->points[i].normal_y, cloud_required->points[i].normal_z);
        V3 nrm_of_raw(cloud_ref->points[idx[0]].normal_x, cloud_ref->points[idx[0]].normal_y, cloud_ref->points[idx[0]].normal_z);
        
        float arc=nrm_of_raw.Normalize().Dot(nrm_of_required.Normalize());
        if(arc<0){
            cloud_required->points[i].normal_x=-cloud_ref->points[idx[0]].normal_x;
            cloud_required->points[i].normal_y=-cloud_ref->points[idx[0]].normal_y;
            cloud_required->points[i].normal_z=-cloud_ref->points[idx[0]].normal_z;
        }
        else{
            cloud_required->points[i].normal_x=cloud_ref->points[idx[0]].normal_x;
            cloud_required->points[i].normal_y=cloud_ref->points[idx[0]].normal_y;
            cloud_required->points[i].normal_z=cloud_ref->points[idx[0]].normal_z;
        }
    }
    pcl::io::savePLYFileBinary(opath_of_out, *cloud_required);
}

void get_index_mapping_from_bdry_to_gt(string ipath_of_bdry, string ipath_of_raw, string opath_of_mapping_from_bdry_to_gt)
{
    pcl::PointCloud<PointType>::Ptr cloud_bdry(new pcl::PointCloud<PointType>);
    pcl::PointCloud<PointType>::Ptr cloud_raw(new pcl::PointCloud<PointType>);
    pcl::io::loadPLYFile(ipath_of_bdry, *cloud_bdry);
    pcl::io::loadPLYFile(ipath_of_raw, *cloud_raw);
    pcl::search::KdTree<PointType>::Ptr kdtree_raw(new pcl::search::KdTree<PointType>);
    kdtree_raw->setInputCloud(cloud_raw);
    ofstream fout(opath_of_mapping_from_bdry_to_gt);
    for(int i=0; i<cloud_bdry->points.size(); i++){
        vector<int> idx;
        vector<float> dist;
        kdtree_raw->nearestKSearch(cloud_bdry->points[i], 1, idx, dist);
        fout<<idx[0]<<endl;
    }
    fout.close();
}



tuple<pcl::PointCloud<PointType>::Ptr, pcl::PointCloud<PointType>::Ptr, vector<vector<int>>> ReadVx(string path)
{
    pcl::PointCloud<PointType>::Ptr cloud_centre(new pcl::PointCloud<PointType>);
    pcl::PointCloud<PointType>::Ptr cloud_corners(new pcl::PointCloud<PointType>);
    
    vector<vector<int>> cells;
    ifstream fin(path);
    while(!fin.eof()){
        string line;
        getline(fin, line);
        if(line!=""){
            auto ss=StrSplit(line," ");
            if(ss[0]=="vtx"){
                PointType ptmp((float)atof(ss[1].c_str()), (float) atof(ss[2].c_str()), (float) atof(ss[3].c_str()));
                cloud_corners->points.push_back(ptmp);
            }
            else if(ss[0]=="cell"){
                cells.push_back({atoi(ss[1].c_str()), atoi(ss[2].c_str()), atoi(ss[3].c_str()),atoi(ss[4].c_str()),
                                 atoi(ss[5].c_str()), atoi(ss[6].c_str()), atoi(ss[7].c_str()),atoi(ss[8].c_str())});

                int cell_min=cells[cells.size()-1][0];
                int cell_max=cells[cells.size()-1][6];
                V3 vmin(cloud_corners->points[cell_min].x, cloud_corners->points[cell_min].y, cloud_corners->points[cell_min].z);
                V3 vmax(cloud_corners->points[cell_max].x, cloud_corners->points[cell_max].y, cloud_corners->points[cell_max].z);
                V3 current_vx=(vmin+vmax)/2.0;
                cloud_centre->points.push_back(PointType((float)current_vx.x, (float)current_vx.y, (float)current_vx.z));
            }
        }        
    }

    return make_tuple(cloud_centre, cloud_corners, cells);
}

void extract_voxels(string ipath_of_raw, string ipath_of_vx)
{
    pcl::PointCloud<PointType>::Ptr cloud_raw(new pcl::PointCloud<PointType>);
    pcl::io::loadPLYFile(ipath_of_raw, *cloud_raw);

    auto [cloud_centre, cloud_corners, cells]=ReadVx(ipath_of_vx);
    pcl::search::KdTree<PointType>::Ptr kdtree_centre(new pcl::search::KdTree<PointType>);
    pcl::search::KdTree<PointType>::Ptr kdtree_corners(new pcl::search::KdTree<PointType>);
    pcl::search::KdTree<PointType>::Ptr kdtree_raw(new pcl::search::KdTree<PointType>);
    kdtree_centre->setInputCloud(cloud_centre);
    kdtree_corners->setInputCloud(cloud_corners);
    kdtree_raw->setInputCloud(cloud_raw);

    // pcl::io::savePLYFileBinary("/home/i9/experiment_nc/ThreeDScan2/ours/Murex_Romosus_holes_noise_centre.ply",*cloud_centre);
    /* extract corners corresponding to raw point cloud */
    vector<int> contained_corners;
    for(int i=0; i<cloud_raw->points.size(); i++){
        vector<int> idx;
        vector<float> dist;
        kdtree_centre->nearestKSearch(cloud_raw->points[i], 1, idx, dist);

        int itmp=idx[0];
        contained_corners.insert(contained_corners.end(), cells[itmp].begin(), cells[itmp].end());            
    }

    
    VecUnique(contained_corners);
    pcl::PointCloud<PointType>::Ptr cloud_related_corners(new pcl::PointCloud<PointType>);
    pcl::copyPointCloud(*cloud_corners, contained_corners, *cloud_related_corners);

    // pcl::io::savePLYFileBinary("/home/i9/experiment_nc/ThreeDScan2/ours/related_corners.ply",*cloud_centre);
    pcl::search::KdTree<PointType>::Ptr kdtree_related_corners(new pcl::search::KdTree<PointType>);
    kdtree_related_corners->setInputCloud(cloud_related_corners);

    /* extract voxels */
    ofstream fout(StrSplit(ipath_of_raw,".")[0] + ".obj");
    
    /* extract used corners */
    for(int i=0; i<cloud_related_corners->points.size(); i++){
        fout<<"v "<<cloud_related_corners->points[i].x<<" "<<cloud_related_corners->points[i].y<<" "<<cloud_related_corners->points[i].z<<endl;
    }

    /* extract lines */
    for(int i=0; i<cloud_raw->points.size(); i++){            
        vector<int> idx;
        vector<float> dist;
        kdtree_centre->nearestKSearch(cloud_raw->points[i], 1, idx, dist);

        
        vector<int> corner_id_of_vx;
        for(int j=0; j<cells[idx[0]].size(); j++){
            PointType ptmp=cloud_corners->points[cells[idx[0]][j]];
            vector<int> idx_corners;
            vector<float> dist_corners;
            kdtree_related_corners->nearestKSearch(ptmp,1,idx_corners, dist_corners);
            corner_id_of_vx.push_back(idx_corners[0]);
        }

        fout<<"l "<<corner_id_of_vx[0]+1<<" "<<corner_id_of_vx[1]+1<<endl;
        fout<<"l "<<corner_id_of_vx[1]+1<<" "<<corner_id_of_vx[2]+1<<endl;
        fout<<"l "<<corner_id_of_vx[2]+1<<" "<<corner_id_of_vx[3]+1<<endl;
        fout<<"l "<<corner_id_of_vx[3]+1<<" "<<corner_id_of_vx[0]+1<<endl;
        fout<<"l "<<corner_id_of_vx[0]+1<<" "<<corner_id_of_vx[4]+1<<endl;
        fout<<"l "<<corner_id_of_vx[1]+1<<" "<<corner_id_of_vx[5]+1<<endl;
        fout<<"l "<<corner_id_of_vx[2]+1<<" "<<corner_id_of_vx[6]+1<<endl;
        fout<<"l "<<corner_id_of_vx[3]+1<<" "<<corner_id_of_vx[7]+1<<endl;
        fout<<"l "<<corner_id_of_vx[4]+1<<" "<<corner_id_of_vx[5]+1<<endl;
        fout<<"l "<<corner_id_of_vx[5]+1<<" "<<corner_id_of_vx[6]+1<<endl;
        fout<<"l "<<corner_id_of_vx[6]+1<<" "<<corner_id_of_vx[7]+1<<endl;
        fout<<"l "<<corner_id_of_vx[7]+1<<" "<<corner_id_of_vx[4]+1<<endl;

    }
    fout.close();
}