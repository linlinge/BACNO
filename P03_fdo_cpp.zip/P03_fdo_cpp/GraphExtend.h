#pragma once 
#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/connected_components.hpp>
#include <boost/graph/graphviz.hpp>
#include <boost/graph/properties.hpp>
#include <boost/property_map/property_map.hpp>
#include <boost/graph/named_function_params.hpp>
#include <unordered_map>
#include <iostream>
using namespace boost;
using namespace std;

struct VertexProperty{
	int id_;
	vector<int> id_of_fold_nodes_;
};
struct EdgeProperty{
	double weight_;
};
typedef adjacency_list<vecS, vecS, undirectedS, VertexProperty, EdgeProperty> GraphType;

class GraphExtend
{
	/* variables */
	private:
		std::map<int, int> mapping_of_old_2_new_;
		std::unordered_map<int, vector<int>> old_2_corresponding_pos_;
		std::map<int, int> mapping_of_new_2_old_;
    	std::unordered_map<int, vector<int>> new_2_corresponding_pos_;

	public:
		std::vector<GraphType::edge_descriptor> edges_;  
		GraphType g_;
		int num_of_edges_, num_of_nodes_;


	/* functions */
    public:        
        
        void Create(vector<vector<int>> edge_list, vector<float> weight);
		
		/* Set */		
		void SetEdgeWeight(int snode, int tnode, float weight);

		/* Get */
		float GetEdgeWeight(int snode, int tnode);

		/* Apply */
		void ApplyFold(float weight_threshold);

	private:
		void markSingleAndReorder(std::vector<int>& dat);
		set<int> SetRemaining(set<int>& dat);
};

