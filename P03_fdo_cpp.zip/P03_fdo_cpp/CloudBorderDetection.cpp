#include <CloudBorderDetection.h>
void applyHalfdiscCriterion(pcl::PointCloud<PointType>::Ptr cloud, float radius, float angle_threshold, string path_to_edges) 
{
    vector<int> indices_of_edges;
    pcl::KdTreeFLANN<PointType> kdtree;
    kdtree.setInputCloud(cloud);

    for(size_t i = 0; i < cloud->points.size(); ++i){
        PointType searchPoint = cloud->points[i];
        std::vector<int> idx;
        std::vector<float> dist;

        if (kdtree.radiusSearch(searchPoint, radius, idx, dist) > 0){
            int halfdisc_count = 0;
            for (size_t j = 0; j < idx.size(); ++j) {
                float angle = std::atan2(cloud->points[idx[j]].y - searchPoint.y, cloud->points[idx[j]].x - searchPoint.x);
                if (std::fabs(angle) <= angle_threshold) {
                    ++halfdisc_count;
                }
            }

            if(halfdisc_count < (idx.size() / 2)){
                indices_of_edges.push_back(i);
            }
        }
    }

    if(indices_of_edges.size()>0){
        pcl::PointCloud<PointType>::Ptr cloud_edges(new pcl::PointCloud<PointType>());
        pcl::copyPointCloud(*cloud, indices_of_edges, *cloud_edges);
        pcl::io::savePLYFileBinary(path_to_edges, *cloud_edges);
    }
    else{
        cout<<"No border points found!"<<endl;
    }
}

void applyShapeCriterion(pcl::PointCloud<PointType>::Ptr cloud, pcl::PointCloud<pcl::Normal>::Ptr cloud_normals, float radius, pcl::PointCloud<pcl::PointXYZ>::Ptr boundary_points) 
{
    vector<int> indices_of_edges;
    pcl::KdTreeFLANN<PointType> kdtree;
    kdtree.setInputCloud(cloud);

    for (size_t i = 0; i < cloud->points.size(); ++i) {
        pcl::Normal searchNormal = cloud_normals->points[i];
        PointType searchPoint = cloud->points[i];
        std::vector<int> pointIdxRadiusSearch;
        std::vector<float> pointRadiusSquaredDistance;

        // if (kdtree.radiusSearch(searchPoint, radius, pointIdxRadiusSearch, pointRadiusSquaredDistance) > 0) {
        //     int shape_count = 0;
        //     for (size_t j = 0; j < pointIdxRadiusSearch.size(); ++j) {
        //         if (pcl::getAngle3D(searchNormal, cloud_normals->points[pointIdxRadiusSearch[j]], true) > 45) {
        //             ++shape_count;
        //         }
        //     }

        //     if (shape_count > (pointIdxRadiusSearch.size() / 2)) {
        //         boundary_points->points.push_back(searchPoint);
        //     }
        // }
    }
}