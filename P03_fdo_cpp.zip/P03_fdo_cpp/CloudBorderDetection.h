#pragma once
#include <pcl/point_types.h>
#include <pcl/io/pcd_io.h>
#include <pcl/io/ply_io.h>
#include <pcl/kdtree/kdtree_flann.h>
#include <pcl/features/normal_3d.h>
#include <pcl/common/common.h>
#include <vector>
#include <PCLExtend.h>
using namespace std;
void applyHalfdiscCriterion(pcl::PointCloud<PointType>::Ptr cloud, float radius, float angle_threshold, string path_to_edges);
void applyShapeCriterion(pcl::PointCloud<PointType>::Ptr cloud, pcl::PointCloud<pcl::Normal>::Ptr cloud_normals, float radius, string path_to_edges);