#pragma once 
#include <string>
#include <PCLExtend.h>
#include <LocalMeshGenerator.h>
#include <CloudProperties.h>
#include <FileExtend.h>
using namespace std;
class CorrectNormal
{
    public:
        void SetInputCloud(string ipath_of_disturbed, string ipath_of_positive);
        void SetDisturbedCloud(string ipath_of_disturbed);
        void SetPositiveCloud(string ipath_of_positive);
        void SetNegtiveCloud(string ipath_of_negtive);
        void SetCloudOn(string ipath_of_cloud_on);

        /* Init */
        CorrectNormal();
        void LoadDisturbedCloud(string ipath_of_disturbed);

        /* correct */
        void Correct(string output_prefix);        
        void Correct_by_WassteinDistance(string oprefix); // poor effect when face with noise
        void Correct_by_WassteinDistance_Pro(string oprefix);        
        void Correct_by_UDF_Pro();
        void Correct_by_ZeroEquipotentialSurface(string ipath_of_cloud_on, string ipath_of_cloud_positive);   
        
        tuple<int,  vector<int>> GetFirstSeed(vector<int>& idx, int num_of_ngbrs);
        tuple<bool, vector<int>> IsSeed(int test_idx, int num_of_ngbrs);

        /* Calculate */
        void CalculateNormal(pcl::PointCloud<PointType>::Ptr icloud, int K);


        /* Apply */
        pcl::PointCloud<PointType>::Ptr Smooth_by_MLS(pcl::PointCloud<PointType>::Ptr icloud);

        /* Extract */
        // void PrintResultAccuracy(string );
        void ExtractResult(string opath);
    
    private:
        vector<int> flag_is_determined_;
        pcl::search::KdTree<PointType>::Ptr kdtree_on_;
        pcl::search::KdTree<PointType>::Ptr kdtree_disturbed_;
        pcl::search::KdTree<PointType>::Ptr kdtree_positive_;
        pcl::search::KdTree<PointType>::Ptr kdtree_negtive_;
        pcl::search::KdTree<PointType>::Ptr kdtree_zero_equipotential_;
        pcl::PointCloud<PointType>::Ptr cloud_on_;
        pcl::PointCloud<PointType>::Ptr cloud_positive_;
        pcl::PointCloud<PointType>::Ptr cloud_negtive_;
        pcl::PointCloud<PointType>::Ptr cloud_disturbed_;
        pcl::PointCloud<PointType>::Ptr cloud_zero_equipotential_;

        double mean_dist_of_positive_, max_dist_of_positive_;
        double mean_dist_of_disturbed_, max_dist_of_disturbed_;
        CloudProperties cm_positive_, cm_disturbed_;
        float spacing_;

    private:
        void Correct_by_Nearest(string oprefix); // poor effect
        void Correct_by_UDF(pcl::PointCloud<PointType>::Ptr cloud_disturbed, pcl::PointCloud<PointType>::Ptr cloud_positive);
        void Correct_by_MajorityVoting(pcl::PointCloud<PointType>::Ptr icloud, int K);
};
