#include "EvaluationMetric.h"
void CaclulateAccuracy(string path_of_raw, string output_prefix)
{
    pcl::PointCloud<PointType>::Ptr cloud_correct(new pcl::PointCloud<PointType>);
    pcl::io::loadPLYFile(path_of_raw, *cloud_correct);
    pcl::PointCloud<PointType>::Ptr cloud_ground_true(new pcl::PointCloud<PointType>);
    pcl::io::loadPLYFile(output_prefix+"_correct_ours.ply", *cloud_ground_true);
    int cnt=0;
    for(int i=0; i<cloud_correct->points.size(); i++){
        V3 nrm_gt(cloud_ground_true->points[i].normal_x, cloud_ground_true->points[i].normal_y, cloud_ground_true->points[i].normal_z);
        V3 nrm_correct(cloud_correct->points[i].normal_x, cloud_correct->points[i].normal_y, cloud_correct->points[i].normal_z);
        float arc=nrm_gt.Dot(nrm_correct);
        if(arc<0){
            cloud_correct->points[i].r=255;
            cloud_correct->points[i].g=0;
            cloud_correct->points[i].b=0;
            cnt++;
        }
        else{
            cloud_correct->points[i].r=0;
            cloud_correct->points[i].g=255;
            cloud_correct->points[i].b=0;
        }
    }
    double ratio=(cloud_correct->points.size()-cnt)*100.0/cloud_correct->points.size();
    if(ratio>50){
        cout<<cnt<<endl;
        cout<<"Accuracy:    "<<ratio<<" %"<<endl;
    }
    else {
        cout<<"total :"<<cloud_correct->points.size()<<endl;
        cout<<cloud_correct->points.size()-cnt<<endl;
        cout<<"Accuracy:    "<<100-ratio<<" %"<<endl;
    }
   
    pcl::io::savePLYFileBinary(output_prefix+"_correct_flag.ply", *cloud_correct);
}


void CaclulateAccuracy_by_distance(string path_of_raw, string path_of_correct)
{
    pcl::PointCloud<PointType>::Ptr cloud_correct(new pcl::PointCloud<PointType>);
    pcl::io::loadPLYFile(path_of_correct, *cloud_correct);
    pcl::PointCloud<PointType>::Ptr cloud_ground_true(new pcl::PointCloud<PointType>);
    pcl::io::loadPLYFile(path_of_raw, *cloud_ground_true);
    pcl::search::KdTree<PointType>::Ptr kdtree_gt(new pcl::search::KdTree<PointType>);
    kdtree_gt->setInputCloud(cloud_ground_true);

    int cnt=0;
    vector<int> flag_idx_pos, flag_idx_neg;
    for(int i=0; i<cloud_correct->points.size(); i++){
        vector<int> idx;
        vector<float> dist;
        kdtree_gt->nearestKSearch(cloud_correct->points[i], 1, idx, dist);

        V3 nrm_gt(cloud_ground_true->points[idx[0]].normal_x, 
                  cloud_ground_true->points[idx[0]].normal_y, 
                  cloud_ground_true->points[idx[0]].normal_z);
        V3 nrm_correct(cloud_correct->points[i].normal_x, cloud_correct->points[i].normal_y, cloud_correct->points[i].normal_z);
        float arc=nrm_gt.Dot(nrm_correct);
        if(arc<0){
            // cloud_correct->points[i].r=255;
            // cloud_correct->points[i].g=0;
            // cloud_correct->points[i].b=0;

            flag_idx_neg.push_back(i);
            cnt++;
        }
        else{
            flag_idx_pos.push_back(i);
            // cloud_correct->points[i].r=0;
            // cloud_correct->points[i].g=255;
            // cloud_correct->points[i].b=0;
        }
    }
    double ratio=(cloud_correct->points.size()-cnt)*100.0/cloud_correct->points.size();
    cout<<"total :"<<cloud_correct->points.size()<<endl;
    ofstream fout;
    fout.open("Cache/accuracy.txt", ios::out| ios::app);

    auto ss=StrSplit(path_of_correct, "/");
    if(ratio>50){
        cout<<cnt<<endl;        
        printf("Accyracy: \t %.4f \% \n", ratio);
        fout<< cnt<<"\t"<<ratio<<"\t\t\t"<<ss[ss.size()-1]<<endl;
    }
    else {        
        cout<<cloud_correct->points.size()-cnt<<endl;        
        printf("Accyracy: \t %.4f \% \n", 100-ratio);
        fout<< cnt<<"\t"<<100-ratio<<"\t\t\t"<<ss[ss.size()-1]<<endl;
    }
    fout.close();

    pcl::PointCloud<PointType>::Ptr cloud_flag_pos(new pcl::PointCloud<PointType>);
    pcl::PointCloud<PointType>::Ptr cloud_flag_neg(new pcl::PointCloud<PointType>);
    if(flag_idx_pos.size()>0){
        pcl::copyPointCloud(*cloud_correct, flag_idx_pos, *cloud_flag_pos);
        pcl::io::savePLYFileBinary(StrSplit(path_of_correct,".")[0]+"_flag_pos.ply",*cloud_flag_pos);
    }
    
    if(flag_idx_neg.size()>0){
        pcl::copyPointCloud(*cloud_correct, flag_idx_neg, *cloud_flag_neg);
        pcl::io::savePLYFileBinary(StrSplit(path_of_correct,".")[0]+"_flag_neg.ply",*cloud_flag_neg);
    }
}