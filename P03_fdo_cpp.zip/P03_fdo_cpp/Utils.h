#pragma once 
#include <VectorExtend.h>
#include <PCLExtend.h>
#include <V3.hpp>
#include <StringExtend.h>
/**
 * Convert ply file to xyznxnynz file 
 * */
void ply_2_xyznxnynz(string ipath_of_raw, string opath_of_out);

/*
 * After using pcpnet, the normals of input point cloud have changed.
 * Hence, this function modify the result to make the result only change the orientation
 */
void pcpnet_modify(string ipath_of_disturbed, string ipath_of_correct, string opath_of_out);

/**
 * use reference point cloud (normal) to modify required point cloud
*/
void normal_modify(string ipath_of_ref, string ipath_of_required, string opath_of_out);

/**
 * get the index mapping from point cloud 1 (boundary) to point cloud 2 (ground truth)
*/
void get_index_mapping_from_bdry_to_gt(string ipath_of_bdry, string ipath_of_raw, string opath_of_mapping_from_bdry_to_gt);

/**
 * extract voxels
*/
tuple<pcl::PointCloud<PointType>::Ptr, pcl::PointCloud<PointType>::Ptr, vector<vector<int>>> ReadVx(string path);
void extract_voxels(string ipath_of_raw, string ipath_of_vx);