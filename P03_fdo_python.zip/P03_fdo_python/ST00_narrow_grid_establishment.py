import sys 
import os 
# import subprocess  

myexe = "/media/i9/gamma/workspace/P03_fdo_cpp/build/fdo_cpp"  

'''
    edge detection
'''
ipath_of_raw = "/media/i9/sumsung1t/experiment_nc/3_runtime_performance/raw_ply/disturbed/horse_1k_disturbed.ply"
os.system("%s --fun boundary_detection --ipath_of_raw %s" % (myexe, ipath_of_raw))  