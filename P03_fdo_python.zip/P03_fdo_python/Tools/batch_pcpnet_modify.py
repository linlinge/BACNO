import pandas as pd
import numpy as np
import open3d as o3d
import sys 
import os
def list_all_files(rootdir, pattern="", is_contain_pattern=True, is_recurse=True):
    import os
    _files = []

    #列出文件夹下所有的目录与文件
    list_file = os.listdir(rootdir)
    
    for i in range(0,len(list_file)):
        # 构造路径
        path = os.path.join(rootdir,list_file[i])

        # 判断路径是否是一个文件目录或者文件
        # 如果是文件目录，继续递归        
        if is_recurse==True and os.path.isdir(path):
            _files.extend(list_all_files(path))
        if os.path.isfile(path):
            if pattern=="":
                _files.append(path)
            else:
                if is_contain_pattern==True: 		# 假如想匹配包含该字符串的所有文件
                    if path.find(pattern)!=-1:
                        _files.append(path)
                else:
                    if path.find(pattern)==-1:	# 假如想匹配不包含该字符串的所有文件
                        _files.append(path)
                
    return _files

path_disturbed="/home/i9/experiment_nc/ThreeDScans_noise/Disturbed"
path_of_out="/home/i9/experiment_nc/ThreeDScans_noise/Results/pcpnet"
fs=list_all_files(path_disturbed, pattern=".ply", is_recurse=False)
for f in fs:
    ply_disturbed=o3d.io.read_point_cloud(f)
    ply_disturbed_nrm=np.asarray(ply_disturbed.normals)
    ply_out=o3d.io.read_point_cloud("{}/{}_correct_pcpnet.ply".format(path_of_out,os.path.basename(f).split("_disturbed")[0]))
    ply_out_nrm=np.asarray(ply_out.normals)
    for i in range(len(ply_disturbed_nrm)):
        arc=np.dot(ply_disturbed_nrm[i,:], ply_out_nrm[i,:])
        if arc<0:
            ply_disturbed_nrm[i,:]=-ply_disturbed_nrm[i,:]
    ply_disturbed.normals=o3d.utility.Vector3dVector(ply_disturbed_nrm)
    o3d.io.write_point_cloud("{}/final/{}_correct_pcpnet.ply".format(path_of_out,os.path.basename(f).split("_disturbed")[0]), ply_disturbed)

