import cv2
import numpy as np

# 读取图片
img = cv2.imread('/home/i9/Pictures/force_directed_solver_and_k_means/kmeans.png')

# 定义白色的BGR值
white = [255, 255, 255]

# 创建一个新的带Alpha通道的图像
# 初始化为完全不透明
h, w = img.shape[:2]
result = np.dstack([img, np.ones((h, w), dtype=np.uint8) * 255])

# 遍历图片中的每个像素
for y in range(h):
    for x in range(w):
        # 如果像素是白色，则将其Alpha值设为0（透明）
        if np.array_equal(img[y, x], white):
            result[y, x, 3] = 0

# 保存修改后的图片为PNG格式，以支持透明度
cv2.imwrite('/home/i9/Pictures/force_directed_solver_and_k_means/kmeans_transparent.png', result)






# import cv2
# import numpy as np

# # 读取图片
# img = cv2.imread('/home/i9/Pictures/force_directed_solver_and_k_means/up.png')

# # 定义白色的BGR值
# white = [255, 255, 255]

# # 创建一个新的带Alpha通道的图像
# # 初始化为完全不透明
# h, w = img.shape[:2]
# result = np.dstack([img, np.ones((h, w), dtype=np.uint8) * 255])

# # 遍历图片中的每个像素
# for y in range(h):
#     for x in range(w):
#         # 如果像素是白色，则将其Alpha值设为0（透明）
#         if np.array_equal(img[y, x], white):
#             pass
#         else:
#             result[y, x, 0] = 0
#             result[y, x, 1] = 255
#             result[y, x, 2] = 0

# # 保存修改后的图片为PNG格式，以支持透明度
# cv2.imwrite('/home/i9/Pictures/force_directed_solver_and_k_means/up_green.png', result)

