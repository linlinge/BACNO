import networkx as nx
import pandas as pd 
import numpy as np

path_of_nodes_csv = "/media/i9/Lei/experiment_nc/1_special_cases/2_varying_point_density/disturbed/9_ours/bulbasaur_flower_pot_merge_nodes.csv"
path_of_edges_csv = "/media/i9/Lei/experiment_nc/1_special_cases/2_varying_point_density/disturbed/9_ours/bulbasaur_flower_pot_merge_edges.csv"

nxG = nx.Graph()
# load nodes
df_nodes=pd.read_csv(path_of_nodes_csv, sep=",")
nodes=np.int32(np.asarray(df_nodes.values[:,0]))
for node in nodes:
    nxG.add_node(node)

# load edges
df_edges=pd.read_csv(path_of_edges_csv, sep=",")
source=np.int32(np.asarray(df_edges.values[:,0]))
target=np.int32(np.asarray(df_edges.values[:,1]))
weights=np.float32(np.asarray(df_edges.values[:,3]))
for i in range(len(source)):
    nxG.add_edge(source[i], target[i], weight=weights[i]) 

# 创建一个新的图，只包含权重大于0.5的边
H = nx.Graph((u, v, d) for u, v, d in nxG.edges(data=True) if d['weight'] > 0.8)

# 找出所有连通组件
connected_components = list(nx.connected_components(H))

# 打印连通组件的数量
print("连通组件的数量：", len(connected_components))

# 打印每个连通组件的节点数
for i, component in enumerate(connected_components):
    print("连通组件 {} 的节点数：{}".format(i + 1, len(component)))