import sys 
sys.path.append(".")
from ultis import *
import os
import open3d as o3d
import numpy as np 

path_of_disturbed = "/media/i9/phi/experiment_nc/1_special_cases/3_data_sparsity/disturbed"
path_of_tf = "/media/i9/phi/experiment_nc/1_special_cases/3_data_sparsity/disturbed/8_sno/tf"
path_of_out = "/media/i9/phi/experiment_nc/1_special_cases/3_data_sparsity/disturbed/8_sno"
fs = list_all_files(path_of_disturbed, pattern="disturbed.ply")
for f in fs:
    froot = os.path.dirname(f)    
    model_name = f.split("/")[-1].split("_disturbed")[0]

    
    cloud_disturbed = o3d.io.read_point_cloud(f)
    cloud_disturbed_xyz = np.asarray(cloud_disturbed.points)
    cloud_disturbed_nrm = np.asarray(cloud_disturbed.normals)

    cloud_tf = o3d.io.read_point_cloud("{}/{}_sno_tf.ply".format(path_of_tf, model_name))
    cloud_tf_xyz = np.asarray(cloud_tf.points)
    cloud_tf_nrm = np.asarray(cloud_tf.normals)


    from sklearn.neighbors import NearestNeighbors
    nn = NearestNeighbors(n_neighbors=1, algorithm='kd_tree').fit(cloud_tf_xyz)
    distances, neighbors = nn.kneighbors(cloud_disturbed_xyz)

    for i, ngbrs in enumerate(neighbors):
        current_disturbed_nrm = cloud_disturbed_nrm[i,:]
        current_tf_nrm = cloud_tf_nrm[ngbrs[0],:]

        arc = np.dot(current_disturbed_nrm, current_tf_nrm)
        if arc<0:
            cloud_disturbed_nrm[i,:] = -cloud_disturbed_nrm[i,:]
    
    save_ply_in_compatibility_mode("{}/{}_correct_sno.ply".format(path_of_out, model_name), cloud_disturbed_xyz, cloud_disturbed_nrm)