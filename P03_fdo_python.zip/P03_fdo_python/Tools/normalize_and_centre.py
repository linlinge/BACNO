import open3d as o3d  
import numpy as np  
  
def center_and_normalize_ply(points):  
    # 计算点云的中心  
    center = points.mean(axis=0)  
  
    # 将点云居中  
    centered_points = points - center  
  
    # 计算点云的最大范围  
    max_range = np.abs(centered_points).max()  
  
    # 将点云归一化  
    normalized_points = centered_points / max_range  
  
    return normalized_points  

# 读取PLY文件  
icloud = o3d.io.read_point_cloud("/media/i9/phi/experiment_nc/New/Einstein_pts.ply")  
  
# 获取点云数据  
icloud_xyz = np.asarray(icloud.points)  
icloud_nrm = np.asarray(icloud.normals)  
icloud_rgb = np.asarray(icloud.colors)  
  
icloud_xyz_normalized = center_and_normalize_ply(icloud_xyz)
  
# 创建新的点云对象  
ocloud = o3d.geometry.PointCloud()  
ocloud.points = o3d.utility.Vector3dVector(icloud_xyz_normalized)  
ocloud.normals = o3d.utility.Vector3dVector(icloud_nrm)  
ocloud.colors = o3d.utility.Vector3dVector(icloud_rgb)  
  
# 可选：可视化归一化后的点云  
o3d.io.write_point_cloud("/media/i9/phi/experiment_nc/New/Einstein_pts_centre.ply", ocloud)