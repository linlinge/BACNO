# import numpy as np
# import open3d as o3d 
# import random
# import math
# import sys 
# sys.path.append(".")
# from ultis import *

# fs=list_all_files("/media/i9/phi/experiment_nc/New", pattern=".ply")
# noise_ratio = 0.600
# noise_magnitude = 0.01

# for f in fs:
#     ply=o3d.io.read_point_cloud(f)
#     ply_xyz=np.asarray(ply.points)
#     ply_nrm=np.asarray(ply.normals)

#     num_of_pts = len(ply_xyz)
#     num_of_noise =  noise_ratio * num_of_pts

#     ply_out_xyz = add_gaussian_noise(ply_xyz, noise_ratio, noise_magnitude)

#     ply_out = o3d.geometry.PointCloud()
#     ply_out.points=o3d.utility.Vector3dVector(ply_out_xyz)
#     ply_out.normals=o3d.utility.Vector3dVector(ply_nrm)
#     # o3d.io.write_point_cloud(f.split(".")[0]+"_noise.ply", ply_out)
#     save_ply_in_compatibility_mode(f.split(".")[0]+"_noise.ply", ply_out_xyz, ply_nrm)



import numpy as np

initial_mean = 392.15
initial_std = np.sqrt(10) 

# Generate a sample
sample = np.random.normal(loc=initial_mean, scale=initial_std, size=5)

# Verify the results
mean_of_sample = np.mean(sample)
variance_of_sample = np.var(sample)

print("%.2f %.2f %.2f %.2f %.2f" %(sample[0], sample[1], sample[2], sample[3],sample[4]))