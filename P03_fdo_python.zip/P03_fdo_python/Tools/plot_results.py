import pandas as pd 
import matplotlib.pyplot as plt
df=pd.read_csv("/home/i9/Documents/1.txt",sep="\t", header=None)
dat = df.values

plt.plot(dat[0,:], dat[1,:],"-^")
plt.plot(dat[0,:], dat[2,:],"-^")
plt.plot(dat[0,:], dat[3,:],"-^")
plt.plot(dat[0,:], dat[4,:],"-^")
plt.plot(dat[0,:], dat[5,:],"-^")
plt.xticks(dat[0,:], ['6', '7', '8', '9', '10'])
plt.xlabel("Grid Depth $D$")
plt.ylabel("$F_{1}$(%)")
plt.grid("on")
plt.savefig("1.png")
