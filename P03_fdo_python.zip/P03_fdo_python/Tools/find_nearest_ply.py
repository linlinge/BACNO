# import open3d as o3d 
# import numpy as np


# ply_raw  = o3d.io.read_point_cloud("/home/i9/experiment_nc/stanford/Results_trim/dipole/statuette_sampling_correct_dipole.ply")
# ply_raw_xyz=np.asarray(ply_raw.points)
# ply_raw_nrm=np.asarray(ply_raw.normals)

# ply_trim = o3d.io.read_point_cloud("/home/i9/experiment_nc/stanford_bdry/Raw/statuette_sampling_bdry.ply")
# ply_trim_xyz = np.asarray(ply_trim.points)


# # 建立KD树
# ply_tree = o3d.geometry.KDTreeFlann(ply_raw)
# idx_out=[]
# for i in range(len(ply_trim_xyz)):
#     [nn, idx, _] = ply_tree.search_knn_vector_3d(ply_trim.points[0], 1)  # 返回邻域点的个数和索引
#     idx_out.append(idx[0])


# ply_out=o3d.geometry.PointCloud()
# ply_out.points=o3d.utility.Vector3dVector(ply_raw_xyz[idx_out])
# ply_out.normals=o3d.utility.Vector3dVector(ply_raw_nrm[idx_out])
# o3d.io.write_point_cloud("/home/i9/experiment_nc/stanford/Results_trim/dipole/statuette_sampling_correct_dipole.ply",ply_out)


import open3d as o3d
import numpy as np

pcd = o3d.io.read_point_cloud("/home/i9/experiment_nc/stanford/Results_trim/dipole/statuette_sampling_correct_dipole.ply")
# 建立KD树
pcd_tree = o3d.geometry.KDTreeFlann(pcd)
# 使用K近邻，将第1500个点最近的100个点设置为蓝色
k = 100  # 设置K的大小
[nn_k, idx_k, _] = pcd_tree.search_knn_vector_3d(pcd.points[1500], k)  # 返回邻域点的个数和索引

print(nn_k)