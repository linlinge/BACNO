import open3d as o3d 
import numpy as np
import sys
import math

path_of_raw=""
path_of_corrected=""
for i in range(len(sys.argv)):
    if sys.argv[i]=="--path_of_raw":
        path_of_raw=sys.argv[i+1]
    elif sys.argv[i]=="--path_of_corrected":
        path_of_corrected=sys.argv[i+1]


cloud_raw=o3d.io.read_point_cloud(path_of_raw)
cloud_raw_xyz=np.asarray(cloud_raw.points)
cloud_raw_nrm=np.asarray(cloud_raw.normals)
cloud_corrected=o3d.io.read_point_cloud(path_of_corrected)
cloud_corrected_nrm=np.asarray(cloud_corrected.normals)

kdtree_raw = o3d.geometry.KDTreeFlann(cloud_raw)
cnt_yes=0
cnt_no=0
for i, xyz in enumerate(cloud_raw_xyz):
    [_, idx,dist]=kdtree_raw.search_knn_vector_3d(xyz, 1)
    # get normals
    arc=cloud_raw_nrm[i,:].dot(cloud_corrected_nrm[i,:])
    if arc>0:
        cnt_yes=cnt_yes+1
    else:
        cnt_no=cnt_no+1

ratio=cnt_yes/len(cloud_raw_xyz)
if ratio>0.5:    
    out_ratio=ratio*100
    out_ratio_integer= math.floor(out_ratio)
    out_ratio_decimal= math.floor((out_ratio-out_ratio_integer)*100)
    print("%s %d %d.%d%%" % (path_of_raw.split("/")[-1], cnt_no, out_ratio_integer, out_ratio_decimal))
else:
    out_ratio=(1-ratio)*100
    out_ratio_integer= math.floor(out_ratio)
    out_ratio_decimal= math.floor((out_ratio-out_ratio_integer)*100)
    print("%s %d %d.%d%%" % (path_of_raw.split("/")[-1], cnt_yes, out_ratio_integer, out_ratio_decimal))