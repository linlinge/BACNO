import cv2
import numpy as np
import argparse

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="A simple example script.")
    parser.add_argument('--input', type=str, help='input image')
    parser.add_argument('--output', type=str, help='output image')
    
    # 解析命令行参数
    args = parser.parse_args()


    # 读取图片
    img = cv2.imread(args.input)

    # 获取图片的宽度和高度
    height, width = img.shape[:2]

    # 定义蓝色和绿色的RGB值
    target = [0, 255, 0]  # OpenCV使用BGR格式
    green = [255, 255, 255]

    # 遍历图片中的每个像素
    for y in range(height):
        for x in range(width):
            # 如果像素是蓝色，则将其修改为绿色
            # if np.array_equal(img[y, x], target):
            if img[y, x][1] == img[y, x][2] and img[y, x][0]==255:
                img[y, x] = green

    # 保存修改后的图片
    cv2.imwrite(args.output, img)

    # 显示图片（可选）
    # cv2.imshow('Modified Image', img)
    # cv2.waitKey(0)
    # cv2.destroyAllWindows()
