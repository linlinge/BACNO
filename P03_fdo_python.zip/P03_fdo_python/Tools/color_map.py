import cv2 
import open3d as o3d
import numpy as np

def GetColor(min, max, confidence):
    rst_r=0
    rst_g=0
    rst_b=0
    n=4.0
    step=(max-min)/n
    c=confidence-min
    if c<step:
        rst_r=0
        rst_g=c/step*255
        rst_b=255
    elif c<2*step:
        rst_r=0
        rst_g=255
        rst_b=255-(c-step)/step*255
    elif c<3*step:
        rst_r=(c-2*step)/step*255
        rst_g=255
        rst_b=0        
    else:
        rst_r=255
        rst_g=255-(c-3*step)/step*255
        rst_b=0

    return  rst_b, rst_g, rst_r


def GetColor_Gray(min, max, confidence):
    rst_r=0
    rst_g=0
    rst_b=0
    c=256-(confidence-min)*256/max
    rst_r=int(c)
    rst_g=int(c)
    rst_b=int(c)
    return  rst_b, rst_g, rst_r

def GetColors(idata, mode="gray"):
    vmin=np.min(idata)
    vmax=np.max(idata)
    colors=[]

    if mode=="color":
        for i in range(len(idata)):
            colors.append(GetColor(vmin, vmax, idata[i]))
    elif mode=="gray":
        for i in range(len(idata)):
            colors.append(GetColor_Gray(vmin, vmax, idata[i]))
    else:
        print("Mode Error!")
    return colors

def Zscore(idata):
    vmean=np.mean(idata)
    vvar=np.var(idata)
    idata=(idata-vmean)/vvar 
    return idata

def Normalize(idata):
    vmin=np.min(idata)
    vmax=np.max(idata)
    idata=(idata-vmin)/(vmax-vmin)
    return idata 

img=cv2.imread("/home/i9/Pictures/F02/F02.png")
print(img.shape)
seed=[35,31,32]
# seed=[129,64,152]
thresh=1

loc_pos=[]
loc_neg=[]
for i in range(img.shape[0]):
    for j in range(img.shape[1]):
        pixel_b, pixel_g, pixel_r = img[i][j]
        # if abs(pixel_r-seed[0])==0 and (pixel_g-seed[1])==0 and (pixel_b-seed[2])==0:
        if abs(pixel_r-255)!=0 and (pixel_g-255)!=0 and (pixel_b-255)!=0:
            loc_pos.append([i,j,0])
            # loc_neg.append([i,j,0])
        elif abs(pixel_r-35)==0 and (pixel_g-31)==0 and (pixel_b-32)==0:
            loc_pos.append([i,j,0])
        else:
            loc_neg.append([i,j,0])


pcd = o3d.geometry.PointCloud()
pcd.points = o3d.utility.Vector3dVector(loc_pos)
pcd_tree = o3d.geometry.KDTreeFlann(pcd)

k=50
colors=[]
for i in range(len(loc_neg)):
    pt=np.asarray(loc_neg[i]).reshape(3,-1)
    [nn_k, idx_k, dist_k] = pcd_tree.search_knn_vector_3d(pt, k)
    mean_dist = np.log10(np.sqrt(np.mean(np.power(dist_k,2)))) 
    colors.append(mean_dist)
    # colors.append(pt[0,0]-loc_pos[idx_k[0],0])


colors=Normalize(colors)
# colors=colors*6
# colors=np.tanh(colors)
# colors=Normalize(colors)

colors=GetColors(colors)

for i in range(len(loc_neg)):
    lx, ly, _=loc_neg[i]
    img[lx, ly]=colors[i]

cv2.imwrite("/home/i9/Pictures/F02/F02_out.png", img)