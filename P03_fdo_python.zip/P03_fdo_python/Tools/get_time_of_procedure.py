import psutil
import time

def find_process_by_name(process_name):
    """根据进程名查找进程"""
    for proc in psutil.process_iter(['pid', 'name']):
        if proc.info['name'] == process_name:
            return proc.info['pid']
    return None

def wait_for_process_to_start(process_name):
    """等待指定名字的进程开始"""
    pid = None
    while not pid:
        pid = find_process_by_name(process_name)
        time.sleep(1)  # 每秒检查一次
    return pid

def monitor_process(process_name):
    try:
        # 等待进程启动并获取其PID
        pid = wait_for_process_to_start(process_name)
        print(f"检测到名为'{process_name}'的进程已启动，PID为{pid}。")

        # 获取进程对象
        process = psutil.Process(pid)

        # 获取进程的启动时间
        start_time = process.create_time()

        # 持续检查进程是否还在运行
        while process.is_running():
            time.sleep(1)

        # 计算进程的总运行时间
        end_time = time.time()
        running_time = end_time - start_time
        print(f"进程已运行：{running_time:.2f}秒")

    except psutil.NoSuchProcess:
        print(f"没有找到名为'{process_name}'的进程。")
    except Exception as e:
        print(f"发生错误：{e}")

# 替换为你的进程名
process_name = "potree"  # 示例进程名
monitor_process(process_name)
