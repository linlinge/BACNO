import numpy as np
import open3d as o3d 
import trimesh
import random
import math
import sys 
sys.path.append(".")
from ultis import *

fs=list_all_files("/media/i9/sumsung1t/experiment_nc/1_robustness_test/1_anti_noise_test/ratio_1d00_mag_0d005/1_noise_gt", pattern=".ply")

for f in fs:
    print(f)
    fname = f.split("/")[-1].split(".")[0]
    froot = f[0:len(f)-len(fname)-4]
    icloud=o3d.io.read_point_cloud(f)    
    icloud.estimate_normals(search_param=o3d.geometry.KDTreeSearchParamKNN(knn=20))
    # o3d.io.write_point_cloud("{}/{}_renormed.ply".format(froot, fname), icloud)

    
    # # In case you need to convert to float32 explicitly
    # ocloud = o3d.geometry.PointCloud()
    # ocloud.points = o3d.utility.Vector3dVector(np.asarray(icloud.points).astype(np.float32))
    # ocloud.normals = o3d.utility.Vector3dVector(np.asarray(icloud.normals).astype(np.float32))

    # # Save the point cloud with normals
    # o3d.io.write_point_cloud("{}/{}_renormed.ply".format(froot, fname), ocloud, write_ascii=True)

    mesh = trimesh.Trimesh(vertices=np.asarray(icloud.points), vertex_normals=np.asarray(icloud.normals))  
    mesh.export("{}/{}_renormed.ply".format(froot, fname.split("_normalized")[0]), file_type="ply")  