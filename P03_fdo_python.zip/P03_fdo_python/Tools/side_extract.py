import trimesh
import numpy as np
from sklearn.neighbors import NearestNeighbors
import pandas as pd

cloud=trimesh.load("/home/i9/experiment_nc/DTU/Result/stl014_total_OR_mls_cca_cloud_off.ply")
cloud_xyz=np.asarray(cloud.vertices)
nn = NearestNeighbors(n_neighbors=1, algorithm='kd_tree').fit(cloud_xyz)

# onside 
cloud_one_side=trimesh.load("/home/i9/experiment_nc/DTU/Result/one_side.ply")
cloud_xyz_one_side=np.asarray(cloud_one_side.vertices)
distances, neighbors = nn.kneighbors(cloud_xyz_one_side)
with open("/home/i9/experiment_nc/DTU/Result/onside.csv", "w") as f:
    for ngbr in neighbors:
        f.write("159070, {}, undirected,1\n".format(ngbr[0]))


# another side
cloud_another_side=trimesh.load("/home/i9/experiment_nc/DTU/Result/another_side.ply")
cloud_xyz_another_side=np.asarray(cloud_another_side.vertices)
distances, neighbors = nn.kneighbors(cloud_xyz_another_side)
with open("/home/i9/experiment_nc/DTU/Result/another.csv", "w") as f:
    for ngbr in neighbors:
        f.write("159071, {}, undirected,1\n".format(ngbr[0]))