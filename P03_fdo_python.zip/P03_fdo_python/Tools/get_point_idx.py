import numpy as np
import open3d as o3d


cloud = o3d.io.read_point_cloud("/media/i9/phi/experiment_nc/1_special_cases/1_anti_noise_test/ratio_0d00_mag_0d005/1_Disturbed/9_ours/stl001_octree.ply")
cloud_xyz = np.asarray(cloud.points)
test_pts= np.array([[0.006261259, -0.2773438, 0.2505989]])

# test_pts= np.array([[0.0566958785, 0.0439882874, -0.309801698]])

from sklearn.neighbors import NearestNeighbors
nn = NearestNeighbors(n_neighbors=1, algorithm='kd_tree').fit(cloud_xyz)
distances, neighbors = nn.kneighbors(test_pts)

print(neighbors)
print(distances)