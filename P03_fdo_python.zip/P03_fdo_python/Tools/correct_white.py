import cv2 as cv
import numpy as np

img=cv.imread("/home/i9/Pictures/Screenshot from 2022-06-21 09-24-51.png")
white_pixels = np.where(
    (img[:, :, 0] > 253) & 
    (img[:, :, 1] > 253) & 
    (img[:, :, 2] > 253)
)

img[white_pixels] = [255, 255, 255]
cv.imwrite("2.png",img)