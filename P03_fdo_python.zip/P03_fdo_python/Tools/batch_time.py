with open("Tools/time.txt",'r') as f:
    line=f.readline()
    line=line.split("\n")[0]
    while line!="":
        ss=line.split(":")
        if len(ss)==1:
            print(int(float(ss[0])))
        elif len(ss)==2:
            print(int(float(ss[0]))*60+int(float(ss[1])))
        elif len(ss)==3:
            print(int(float(ss[0]))*3600+int(float(ss[1]))*60+int(float(ss[0])))
        line=f.readline()
    