import open3d as o3d 
import numpy as np 
import sys 
sys.path.append(".")
from ultis import *

# def list_all_files(rootdir, pattern="", is_recurse=False):
#     import os
#     _files = []
#     pattern=pattern if pattern=="" else pattern.split("&")
#     words_contained=[x for x in pattern if x.find("~")==-1]
#     words_not_contained=[w[1:] for w in pattern if w.find("~")!=-1]

#     #列出文件夹下所有的目录与文件
#     list_file = os.listdir(rootdir)
    
#     for i in range(0,len(list_file)):
#         # 构造路径
#         path = os.path.join(rootdir,list_file[i])

#         # 判断路径是否是一个文件目录或者文件
#         # 如果是文件目录，继续递归        
#         if is_recurse==True and os.path.isdir(path):
#             _files.extend(list_all_files(path))
#         if os.path.isfile(path):
#             if pattern=="":
#                 _files.append(path)
#             else:                
#                 is_contained=True if len([1 for w in words_contained if path.find(w)!=-1])==len(words_contained) else False
#                 is_not_contained=True if len([1 for w in words_not_contained if path.find(w)!=-1])!=0 else False
#                 if is_contained==True and is_not_contained==False:
#                     _files.append(path)                
#     return _files


files=list_all_files("/media/i9/gamma/Exp_nc/video_demo/New",pattern=".ply",is_recurse=False)
for f in files:
    cloud=o3d.io.read_point_cloud(f)
    cloud_nrm=np.asarray(cloud.normals)    
    cloud_num=len(cloud_nrm)

    # idx
    ratio=0.2
    num=int(ratio*len(cloud_nrm))
    idx=set()
    for i in range(num):
        idx.add(np.random.randint(cloud_num))
    idx=list(idx)

    flags = np.zeros(cloud_num)
    flags[idx] = np.ones(len(idx))
    # revert normals
    for i in range(len(idx)):
        cloud_nrm[idx[i],:]=-cloud_nrm[idx[i],:]
    
    # normal
    cloud.normals=o3d.utility.Vector3dVector(cloud_nrm)

    # save point cloud
    save_path="{}_disturbed.ply".format(f.split(".")[0])
    # o3d.io.write_point_cloud(save_path,cloud)
    save_ply_in_compatibility_mode(save_path, cloud.points, cloud.normals, cloud.colors)

    np.savetxt("{}_disturbed_flag.txt".format(f.split(".")[0]), flags, fmt="%d" )


