import open3d as o3d
import sys 
sys.path.append(".")
from ultis import *
import os 
import numpy as np

fs = list_all_files("/media/i9/phi/experiment_nc/2_accuracy_performance/DTU/Disturbed/8_sno/origin", pattern="_sno.ply")
for f in fs:    
    model_name = f.split("/")[-1].split("_sno.")[0]
    root_path = os.path.dirname(f)

    path_of_R = "{}/{}_R.txt".format(root_path, model_name)
    R = np.loadtxt(path_of_R)

    path_of_T = "{}/{}_T.txt".format(root_path, model_name)
    T = np.loadtxt(path_of_T).reshape((3,-1))

    cloud = o3d.io.read_point_cloud(f)
    cloud_xyz = np.asarray(cloud.points)
    cloud_nrm = np.asarray(cloud.normals)

    cloud_xyz_invR = np.dot(np.linalg.inv(R), cloud_xyz.T) 
    cloud_xyz_invT = (cloud_xyz_invR + T).T

    
    path_of_out = "{}/{}_tf.ply".format(root_path, model_name)    
    save_ply_in_compatibility_mode(path_of_out, cloud_xyz_invT, cloud_nrm)
