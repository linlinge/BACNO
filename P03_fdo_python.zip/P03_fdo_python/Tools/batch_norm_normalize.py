import open3d as o3d 
import numpy as np 

def list_all_files(rootdir, pattern="", is_recurse=False):
    import os
    _files = []
    pattern=pattern if pattern=="" else pattern.split("&")
    words_contained=[x for x in pattern if x.find("~")==-1]
    words_not_contained=[w[1:] for w in pattern if w.find("~")!=-1]

    #列出文件夹下所有的目录与文件
    list_file = os.listdir(rootdir)
    
    for i in range(0,len(list_file)):
        # 构造路径
        path = os.path.join(rootdir,list_file[i])

        # 判断路径是否是一个文件目录或者文件
        # 如果是文件目录，继续递归        
        if is_recurse==True and os.path.isdir(path):
            _files.extend(list_all_files(path))
        if os.path.isfile(path):
            if pattern=="":
                _files.append(path)
            else:                
                is_contained=True if len([1 for w in words_contained if path.find(w)!=-1])==len(words_contained) else False
                is_not_contained=True if len([1 for w in words_not_contained if path.find(w)!=-1])!=0 else False
                if is_contained==True and is_not_contained==False:
                    _files.append(path)                
    return _files


files=list_all_files("/home/i9/experiment_nc/stanford/Disturbed/New",pattern=".ply",is_recurse=False)
cnt=0
for f in files:
    cnt=cnt+1
    ply=o3d.io.read_point_cloud(f)
    ply_xyz=np.asarray(ply.points)
    ply_nrm=np.asarray(ply.normals)
    for i in range(len(ply_nrm)):
        ply_nrm[i,:]=ply_nrm[i,:]/np.linalg.norm(ply_nrm[i,:])
    ply.normals=o3d.utility.Vector3dVector(ply_nrm)
    o3d.io.write_point_cloud(f,ply)
    print("{}/{}".format(cnt,len(files)))
