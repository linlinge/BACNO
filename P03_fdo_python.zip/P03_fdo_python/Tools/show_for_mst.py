import open3d as o3d
import numpy as np
import networkx as nx
from scipy.spatial import KDTree
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

def create_knn_graph(point_cloud, k):
    # Convert Open3D point cloud to numpy array
    points = np.asarray(point_cloud.points)
    
    # Build a KDTree for efficient nearest neighbor search
    tree = KDTree(points)
    
    # Create a graph
    G = nx.Graph()
    
    # Add nodes and edges based on k nearest neighbors
    for i in range(len(points)):
        distances, indices = tree.query(points[i], k=k+1)  # k+1 because the point itself is included
        for j in range(1, k+1):  # Skip the first one (itself)
            G.add_edge(i, indices[j], weight=distances[j])

    return G

def find_mst(graph):
    # Compute the minimum spanning tree
    return nx.minimum_spanning_tree(graph)

def plot_3d_graph(graph, pos_3d):
    # Create a 3D plot
    fig = plt.figure(figsize=(8, 6))
    ax = fig.add_subplot(111, projection='3d')

    # Extract the x, y, z coordinates of each node
    xs, ys, zs = zip(*[pos_3d[node] for node in graph.nodes()])

    # Plot the nodes
    ax.scatter(xs, ys, zs)

    # Plot the edges
    for edge in graph.edges():
        x_coords, y_coords, z_coords = zip(*(pos_3d[edge[0]], pos_3d[edge[1]]))
        ax.plot(x_coords, y_coords, z_coords, color='blue')

    # Set labels and show plot
    ax.set_xlabel('X axis')
    ax.set_ylabel('Y axis')
    ax.set_zlabel('Z axis')
    
    plt.axis("equal")
    plt.show()
    # plt.savefig("1.png")

# Load point cloud
pcd = o3d.io.read_point_cloud("/media/i9/alpha/experiment_nc/1_special_cases/1.ply") # Adjust the file path

# Create the kNN graph (choose your k)
k = 5  # For example, k=5
knn_graph = create_knn_graph(pcd, k)

# num_subgraphs = nx.number_connected_components(knn_graph)
# print(num_subgraphs)

# # Find the minimum spanning tree
mst = find_mst(knn_graph)
subgraphs = list(nx.connected_components(knn_graph))

# Extract positions from the 3D point cloud
pos_3d = {i: pos for i, pos in enumerate(np.asarray(pcd.points))}

# Plot the 3D graph of the minimum spanning tree
plot_3d_graph(mst, pos_3d)
