import open3d as o3d 
import numpy as np
import math
from glb import *

GPath=GlobalManager()

cloud_raw=o3d.io.read_point_cloud("/home/i9/experiment_nc/DTU/MLS/stl001_total_OR_mls_cca_nrm.ply")
cloud_raw_xyz=np.asarray(cloud_raw.points)
cloud_raw_nrm=np.asarray(cloud_raw.normals)

cloud_force=o3d.io.read_point_cloud("/home/i9/experiment_nc/DTU/Result/stl001_total_OR_mls_cca_adj_positive.ply")
cloud_force_xyz=np.asarray(cloud_force.points)


cloud_out_nrm=np.zeros((len(cloud_raw_xyz),3))
colors=np.zeros((len(cloud_raw_xyz),3))
pcd_tree = o3d.geometry.KDTreeFlann(cloud_force)
for i, pt1 in enumerate(cloud_raw_xyz):
    [k, idx, dist]=pcd_tree.search_knn_vector_3d(pt1, 1)
    pt2=cloud_force_xyz[idx[0],:]

    current_nrm=cloud_raw_nrm[i,:]
    # print(current_nrm)
    
    vec_pt1_to_pt2=pt2-pt1
    vec_pt1_to_pt2=vec_pt1_to_pt2/np.linalg.norm(vec_pt1_to_pt2)

    arc= np.dot(current_nrm, vec_pt1_to_pt2)
    if arc<0:
        cloud_out_nrm[i,:]=-cloud_raw_nrm[i,:]
        colors[i,0]=1
    else:
        cloud_out_nrm[i,:]=cloud_raw_nrm[i,:]


cloud_out=o3d.geometry.PointCloud()
cloud_out.points=o3d.utility.Vector3dVector(cloud_raw_xyz)
cloud_out.normals=o3d.utility.Vector3dVector(cloud_out_nrm)
cloud_out.colors=o3d.utility.Vector3dVector(colors)
o3d.io.write_point_cloud("/home/i9/experiment_nc/DTU/MLS/stl001_total_OR_mls_cca_correct.ply", cloud_out)