import open3d as o3d 
import numpy as np

cloud = o3d.io.read_point_cloud("/media/i9/sumsung1t/experiment_nc/3_runtime_performance/raw_ply/disturbed/horse_1k_disturbed.ply")
cloud_xyz = np.asarray(cloud.points)

radii = [0.04, 0.03, 0.05, 0.08]
rec_mesh = o3d.geometry.TriangleMesh.create_from_point_cloud_ball_pivoting(cloud, o3d.utility.DoubleVector(radii))
o3d.visualization.draw_geometries([cloud, rec_mesh])


# import open3d as o3d  
# from scipy.stats import wasserstein_distance  
# import numpy as np  
# import matplotlib.pyplot as plt  
  
# def visualize_wasserstein_distance_field(point_cloud_file, voxel_size=0.1):  
#     # Step 1: Load point cloud  
#     pcd = o3d.io.read_point_cloud(point_cloud_file)  
  
#     # Step 2: Compute AABB bounding box  
#     aabb = pcd.get_axis_aligned_bounding_box()  
#     aabb.color = (1, 0, 0)  # Set color of AABB to red  
  
#     # Step 3: Get min and max coordinates of AABB  
#     min_point = aabb.get_min_bound()  
#     max_point = aabb.get_max_bound()  
  
#     # Step 4: Create voxel grid  
#     voxel_grid = o3d.geometry.VoxelGrid.create_from_point_cloud(pcd, voxel_size)  
  
#     # Step 5: Create empty distance field array  
#     distance_field = np.zeros(voxel_grid.get_voxels().shape[0])  
  
#     # Step 6: Calculate Wasserstein distance for each voxel  
#     for i, voxel in enumerate(voxel_grid.get_voxels()):  
#         voxel_center = voxel_grid.get_voxel_center(i)  
#         distance_field[i] = wasserstein_distance(voxel_center, pcd.points)  
  
#     # Step 7: Normalize distance values to range 0-1  
#     normalized_distances = (distance_field - np.min(distance_field)) / (np.max(distance_field) - np.min(distance_field))  
  
#     # Step 8: Map distance values to colors  
#     colors = plt.cm.jet(normalized_distances)  
  
#     # Step 9: Create VoxelGrid object with distance field and colors  
#     distance_voxel_grid = o3d.geometry.VoxelGrid()  
#     distance_voxel_grid.voxels = voxel_grid.get_voxels()  
#     distance_voxel_grid.colors = o3d.utility.Vector3dVector(colors[:, :3])  
  
#     # Step 10: Create Visualizer and add voxel grid  
#     visualizer = o3d.visualization.Visualizer()  
#     visualizer.create_window()  
#     visualizer.add_geometry(distance_voxel_grid)  
  
#     # Step 11: Visualize voxel grid and distance field  
#     visualizer.run()  
#     visualizer.destroy_window()  


# visualize_wasserstein_distance_field("/media/i9/sumsung1t/experiment_nc/3_runtime_performance/raw_ply/disturbed/horse_1k_disturbed.ply", voxel_size=0.1)