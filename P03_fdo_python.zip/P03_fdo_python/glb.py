import pandas as pd
import numpy as np

config_path="/home/i9/experiment_nc/config.csv"

class GlobalManager:
    device='cpu'
    learning_rate=0.01
    depth_of_voxel= 6
    path_of_features=""
    path_of_disturbed=""
    path_to_pred_labels=""
    path_to_gt_labels=      ""
    path_of_nodes_csv=      ""
    path_of_edges_csv=       ""
    path_to_out_cloud=      ""    
    path_of_raw=""
    path_of_out=""
    path_of_adj_2_obj=""    
    path_of_voxel_2_obj=""
    path_of_cloud_off=""
    path_of_positive=""
    path_of_negtive=""
    input_prefix=""
    output_prefix=""

    def __init__(self):
        df=pd.read_csv(config_path, header=None, sep=" ")
        config=np.asarray(df.values)
        for name, value in config:
            if name=="path_of_raw":
                self.path_of_raw=value
            elif name=="path_of_disturbed":
                self.path_of_disturbed=value
            elif name=="path_of_features":
                self.path_of_features=value
            elif name=="path_to_pred_labels":
                self.path_to_pred_labels=value
            elif name=="path_to_gt_labels":
                self.path_to_gt_labels=value
            elif name=="path_of_nodes_csv":
                self.path_of_nodes_csv=value
            elif name=="path_of_edges_csv":
                self.path_of_edges_csv=value
            elif name=="path_to_out_cloud":
                self.path_to_out_cloud=value            
            elif name=="path_of_out":
                self.path_of_out=value
            elif name=="path_of_adj_2_obj":
                self.path_of_adj_2_obj=value
            elif name=="input_prefix":
                self.input_prefix=value
            elif name=="output_prefix":
                self.output_prefix=value
            elif name=="path_of_voxel_2_obj":
                self.path_of_voxel_2_obj=value
            elif name=="path_of_cloud_off":
                self.path_of_cloud_off=value
            elif name=="path_of_negtive":
                self.path_of_negtive=value
            
    def Write(self):
        with open(config_path,"w") as f:
            f.write("path_of_raw {}\n".format(self.path_of_raw))
            f.write("path_of_disturbed {}\n".format(self.path_of_disturbed))
            f.write("path_of_out {}\n".format(self.path_of_out))
            f.write("path_of_nodes_csv {}\n".format(self.path_of_nodes_csv))
            f.write("path_of_edges_csv {}\n".format(self.path_of_edges_csv))            
            f.write("path_of_adj_2_obj {}\n".format(self.path_of_adj_2_obj))
            f.write("path_of_voxel_2_obj {}\n".format(self.path_of_voxel_2_obj))
            f.write("path_of_cloud_off {}\n".format(self.path_of_cloud_off))
            f.write("path_of_positive {}\n".format(self.path_of_positive))
            f.write("path_of_negtive\n".format(self.path_of_negtive))
            f.write("input_prefix {}\n".format(self.input_prefix))
            f.write("output_prefix {}\n".format(self.output_prefix))
            f.write("path_of_features {}\n".format(self.path_of_features))
            
