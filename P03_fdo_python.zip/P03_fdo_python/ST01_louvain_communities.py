import networkx as nx  
import argparse
import community
import numpy as np
import pandas as pd
  
#####################################################################################################
# input 1: nodes.csv
# input 2: edges.csv
# input 3: cloud_off.ply
# input 4: cloud_raw.ply
# output: opath
#####################################################################################################
parser = argparse.ArgumentParser()
parser.add_argument('--ipath_of_raw', type=str, default="/media/i9/Lei/experiment_nc/1_special_cases/2_varying_point_density/disturbed/bulbasaur_flower_pot_merge_disturbed.ply", help='training run name')
parser.add_argument('--opath', type=str, default='/media/i9/Lei/experiment_nc/1_special_cases/2_varying_point_density/disturbed/9_ours', help='training run name')
args=parser.parse_args()


###################################################################################################
model_name = args.ipath_of_raw.split("/")[-1].split("_disturbed")[0]
path_of_nodes_csv = "{}/{}_nodes_old.csv".format(args.opath, model_name)
path_of_edges_csv = "{}/{}_edges_old.csv".format(args.opath, model_name)
path_of_cloud_off = "{}/{}_cloud_off.ply".format(args.opath, model_name)

################################## Step 00: Load Data  ############################################
nxG = nx.Graph()
# load nodes
df_nodes=pd.read_csv(path_of_nodes_csv, sep=",")
nodes=np.int32(np.asarray(df_nodes.values[:,0]))
for node in nodes:
    nxG.add_node(node)

# load edges
df_edges=pd.read_csv(path_of_edges_csv, sep=",")
source=np.int32(np.asarray(df_edges.values[:,0]))
target=np.int32(np.asarray(df_edges.values[:,1]))
for i in range(len(source)):
    nxG.add_edge(source[i], target[i]) 



  
# 使用 Louvain 方法检测社区  
# communities = nx.community.greedy_modularity_communities(nxG)  
component=community.best_partition(nxG)
  
clusters={}
for i,c in enumerate(component):
    if c in clusters:
        clusters[c].append(i)
    else:
        clusters[c]=[i]


print(len(clusters))