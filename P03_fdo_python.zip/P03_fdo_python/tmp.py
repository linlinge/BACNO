# import networkx as nx
# import matplotlib.pyplot as plt
# import itertools

# # def fold_graph_based_on_weight(G, weight_threshold):
# #     H = nx.Graph((u, v, d) for u, v, d in G.edges(data=True) if d.get('weight', 0) > weight_threshold)
# #     connected_components = list(nx.connected_components(H))
# #     folded_graph = G.copy()

# #     for component in connected_components:
# #         if len(component) > 1:
# #             rep_node = next(iter(component))
# #             for node in component:
# #                 if node != rep_node:
# #                     for neighbor, attrs in G[node].items():
# #                         if neighbor not in component:
# #                             if folded_graph.has_edge(rep_node, neighbor):
# #                                 max_weight = max(attrs['weight'], folded_graph[rep_node][neighbor]['weight'])
# #                                 folded_graph[rep_node][neighbor]['weight'] = max_weight
# #                             else:
# #                                 folded_graph.add_edge(rep_node, neighbor, **attrs)
# #                     folded_graph.remove_node(node)
# #     return folded_graph


# def find_a_class_subgraphs(G, alpha):
#     a_class_subgraphs = []
    
#     # 遍历所有可能的边组合
#     for subgraph_edges in itertools.combinations(G.edges(data=True), r=2):
#         subgraph = nx.Graph()
#         add_all = True
#         for edge in subgraph_edges:
#             if edge[2]['weight'] > alpha:
#                 subgraph.add_edge(edge[0], edge[1], weight=edge[2]['weight'])
#             else:
#                 add_all = False
#                 break
#         if add_all and len(subgraph.edges) > 0:
#             a_class_subgraphs.append(subgraph)
    
#     return a_class_subgraphs

# def fold_graph_based_on_weight(G, weight_threshold):
#     # Step 1: Identify all subgraphs where all edge weights are greater than weight_threshold
#     # subgraphs = []
#     # for community in nx.algorithms.community.kernighan_lin_bisection(G):
#     #     subgraph = G.subgraph(community)
#     #     if all(subgraph[u][v]['weight'] > weight_threshold for u, v in subgraph.edges()):
#     #         subgraphs.append(subgraph)

    
#     subgraphs = find_a_class_subgraphs(G, weight_threshold)
    
#     # list all nodes of subgraphs
#     subgraph_nodes = [list(subgraph.nodes()) for subgraph in subgraphs]
#     # print subgraph_nodes
#     print(subgraph_nodes)

#     print(len(subgraphs))

#     # nx.draw(subgraphs[0], with_labels=True)  
#     # plt.show() 

#     # Step 2: Create a new graph
#     new_graph = nx.Graph()

#     # Mapping of original nodes to new nodes
#     node_mapping = {}

#     # Step 3: Replace each subgraph with a new node
#     for i, subgraph in enumerate(subgraphs):
#         new_node = f'new_node_{i}'
#         new_graph.add_node(new_node)

#         # Remember the mapping of nodes in the subgraph to the new node
#         for node in subgraph:
#             node_mapping[node] = new_node

#     # Step 4: Inherit the neighborhood connections
#     for (u, v, weight) in G.edges(data='weight'):
#         if u in node_mapping:
#             u = node_mapping[u]
#         if v in node_mapping:
#             v = node_mapping[v]
#         new_graph.add_edge(u, v, weight=weight)

#     # Return the new graph
#     return new_graph




# def get_neighbors_of_subgraph(G, nodes_in_S):
#   """
#   Returns a list of the neighbors of each node in the subgraph defined by the input nodes,
#   but without including the nodes in the input subgraph.
  
#   Parameters:
#   G (NetworkX graph): the input graph
#   nodes_in_S (list): a list of nodes in the subgraph
  
#   Returns:
#   list: a list of lists, where each sublist contains the neighbors of a node in the subgraph,
#   but without including the nodes in the input subgraph
#   """
#   # Get the neighbors of each node in the subgraph
#   neighbors = [G.neighbors(n) for n in nodes_in_S]
  
#   # Flatten the list of neighbors
#   flat_neighbors = [n for sublist in neighbors for n in sublist]
  
#   # Remove duplicates
#   unique_neighbors = list(set(flat_neighbors) - set(nodes_in_S))
  
#   return unique_neighbors


# # 创建一个示例图
# G = nx.Graph()
# G.add_edge('A', 'B', weight=0.4)
# G.add_edge('B', 'C', weight=0.6)
# G.add_edge('C', 'D', weight=0.7)
# G.add_edge('D', 'E', weight=0.3)
# G.add_edge('E', 'F', weight=0.9)
# G.add_edge('F', 'G', weight=0.2)
# G.add_edge('A', 'G', weight=0.5)

# print(get_neighbors_of_subgraph(G, ['A', 'B', 'C']))


# # 应用函数折叠图
# folded_G = fold_graph_based_on_weight(G, 0.5)

# # 可视化原始图和折叠后的图
# plt.figure(figsize=(15, 7))

# # 绘制原始图
# plt.subplot(1, 2, 1)
# pos = nx.spring_layout(G)  # 定义一个布局
# nx.draw(G, pos, with_labels=True, node_color='lightblue', font_weight='bold')
# edge_labels = nx.get_edge_attributes(G, 'weight')
# nx.draw_networkx_edge_labels(G, pos, edge_labels=edge_labels)
# plt.title("Original Graph")


# # 绘制折叠后的图
# plt.subplot(1, 2, 2)
# pos_folded = nx.spring_layout(folded_G)  # 定义一个布局
# nx.draw(folded_G, pos_folded, with_labels=True, node_color='lightgreen', font_weight='bold')
# edge_labels_folded = nx.get_edge_attributes(folded_G, 'weight')
# nx.draw_networkx_edge_labels(folded_G, pos_folded, edge_labels=edge_labels_folded)
# plt.title("Folded Graph")
# plt.show()


import numpy as np
dat=np.load("/media/i9/phi/experiment_ad/SemiREST_results/SemiREST_results/bagel/contamination/009.png.npy")
print(dat.shape)