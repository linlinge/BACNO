import cudf
import cugraph
from cuml import DBSCAN as cumlDBSCAN
from cuml import KMeans as cumlKmeans
from cuml import AgglomerativeClustering as cumlAgg
import matplotlib.pyplot as plt
import numpy as np
import time
from glb import *
import networkx as nx
import trimesh
from sklearn.cluster import KMeans, SpectralClustering, OPTICS, MeanShift
import open3d as o3d
import trimesh
from sklearn.neighbors import NearestNeighbors


GPath=GlobalManager()
palette=np.array([[0.5, 0, 0],                 
                  [0, 0.5, 0],
                  [0, 1, 0],
                  [0, 0, 1],
                  [0, 0, 0.5],
                  [0, 1, 1],
                  [0, 0.5, 0.5],
                  [1, 1, 0],
                  [0.5, 0.5, 0],
                  [1, 0, 1],
                  [0.5, 0, 0.5],
                  [1, 0, 0],
                  ])
debug=0
param={}
################################## Step 00: Load Data  ############################################
nxG = nx.Graph()
# load nodes
df_nodes=pd.read_csv(GPath.path_of_nodes_csv, sep=",")
nodes=np.int32(np.asarray(df_nodes.values[:,0]))
for node in nodes:
    nxG.add_node(node)

# load edges
df_edges=pd.read_csv(GPath.path_of_edges_csv, sep=",")
source=np.int32(np.asarray(df_edges.values[:,0]))
target=np.int32(np.asarray(df_edges.values[:,1]))
for i in range(len(source)):
    nxG.add_edge(source[i], target[i]) 

# load cloud_off
cloud_off=o3d.io.read_point_cloud(GPath.path_of_cloud_off)
cloud_off_xyz=np.asarray(cloud_off.points)
kdtree_off=o3d.geometry.KDTreeFlann(cloud_off)

# load cloud_disturbed
cloud_disturbed=o3d.io.read_point_cloud(GPath.path_of_raw)
cloud_disturbed_xyz=np.asarray(cloud_disturbed.points)
kdtree_disturbed= o3d.geometry.KDTreeFlann(cloud_disturbed)

################################## Step 01: Remove small components ############################################
# Step 01-1: Get connected clusters
connected_cluters=[]
for c in nx.connected_components(nxG):
    connected_cluters.append(np.asarray(list(c)))
connected_cluters.sort(key=lambda e: len(e), reverse=True)
connected_cluters=np.asarray(connected_cluters)

for c in connected_cluters:
    print("{} ".format(len(c)),end=' ')

if debug==1:
    cloud_rgb=np.repeat(np.array([[0,1,0]]),len(cloud_off_xyz), axis=0)
    cloud_rgb[connected_cluters[0], :]= np.repeat(np.array([[1.0,0.0,0.0]]), len(connected_cluters[0]), axis=0)
    cloud_off_colors=o3d.geometry.PointCloud()
    cloud_off_colors.points=o3d.utility.Vector3dVector(cloud_off_xyz)
    cloud_off_colors.colors=o3d.utility.Vector3dVector(cloud_rgb)
    o3d.io.write_point_cloud(GPath.output_prefix+"_cloud_off_colors.ply",cloud_off_colors)

# Step 01-2: Obtain the nodes for forceatlas2
idx_of_main_nodes=[]    # indices of nodes that are used for forceatlas2
num_of_main_clusters=0  # how many connected clusters are used for forceatlas2
if len(connected_cluters[0]) > 4* len(connected_cluters[1]):
    idx_of_main_nodes.extend(connected_cluters[0])
    num_of_main_clusters=1
    print("use first cluster.")
else:
    idx_of_main_nodes.extend(connected_cluters[0])
    idx_of_main_nodes.extend(connected_cluters[1])
    num_of_main_clusters=2
    print("use first two clusters")
idx_of_main_nodes=np.asarray(idx_of_main_nodes)


################################### Step 02: ForceAtlas2 ######################################################
loc_of_main_nodes=[]

if debug==0:
    # Define the parameters 
    heyITERATIONS=500
    THETA=1.0
    OPTIMIZE=True

    # read data into a cuDF DataFrame using read_csv
    gdf = cudf.read_csv(GPath.path_of_edges_csv, names=["source", "target", "type", "weight"], dtype=["int32", "int32","string","int32"])

    # We now have data as edge pairs
    # create a Graph using the source (src) and destination (dst) vertex pairs
    G = cugraph.Graph()
    G.from_cudf_edgelist(gdf, source='source', destination='target')
    start=time.perf_counter()
    pos_gdf = cugraph.layout.force_atlas2(G,
                                    max_iter=10000,
                                    pos_list=None,
                                    outbound_attraction_distribution=False,
                                    lin_log_mode=False,
                                    edge_weight_influence=1,
                                    jitter_tolerance=100.0,
                                    barnes_hut_optimize=OPTIMIZE,
                                    barnes_hut_theta=1,
                                    scaling_ratio=0.2,
                                    strong_gravity_mode=False,
                                    gravity=1,
                                    verbose=False,
                                    callback=None)
    print(time.perf_counter()-start)
    x_y_idx=pos_gdf.to_numpy()

    # establish dictionary for idx -> location (idx is the local indices of main nodes)
    set_of_loc={}
    for x,y,idx in x_y_idx:
        idx=int(idx)
        set_of_loc[idx]=np.array([x,y])

    # get global indices of main nodes
    # idx_of_main_nodes: local indices of main nodes -> global indices of main nodes

    for idx in idx_of_main_nodes:
        loc_of_main_nodes.append(set_of_loc[idx])
    loc_of_main_nodes=np.asarray(loc_of_main_nodes)
    param["loc_of_main_nodes"]=loc_of_main_nodes
    np.save("param.npy", param)
else:
    param=np.load("param.npy",allow_pickle='TRUE')
    loc_of_main_nodes=param.item()["loc_of_main_nodes"]

########################################  Step 03: clustering #####################################################
from sklearn.cluster import DBSCAN
import open3d as o3d

def label_2_cluster(labels):
    max_label=np.max(labels)
    clusters=[[] for i in range((max_label+1))]
    for i, label in enumerate(labels):
        clusters[label].append(i)
    
    clusters.sort(key=lambda e: len(e), reverse=True)
    return clusters


def max_dist(cloud_xyz):
    nn = NearestNeighbors(n_neighbors=2, algorithm='kd_tree').fit(cloud_xyz)
    distances, neighbors = nn.kneighbors(cloud_xyz)
    return np.max(distances[:,1])


# db = cumlKmeans(n_clusters=2).fit(loc_of_main_nodes)
# km_clusters=label_2_cluster(db.labels_)

# res=KMeans(n_clusters=2, random_state=0).fit_predict(loc_of_main_nodes)
# res=OPTICS(min_samples=1).fit_predict(loc_of_main_nodes)
res=cumlKmeans(n_clusters=2).fit(loc_of_main_nodes).labels_

km_clusters=label_2_cluster(res)

############################################## Test Connection of different clusters ################################
def TestOrientation(cloud_xyz, cloud_nrm, S, T):
    lcloud=o3d.geometry.PointCloud()
    lcloud.points=o3d.utility.Vector3dVector(cloud_xyz)
    kdtree_local= o3d.geometry.KDTreeFlann(lcloud)
    
    # get local idx of S
    [_, idx, dist]=kdtree_local.search_knn_vector_3d(S, 1)
    local_idx_of_S=idx[0]

    # get local idx of T
    [_, idx, dist]=kdtree_local.search_knn_vector_3d(T, 1)
    local_idx_of_T=idx[0]

    # establish knn graph
    k=4
    G=nx.Graph()
    for i in range(len(cloud_xyz)):
        [_, idx, dist]=kdtree_local.search_knn_vector_3d(cloud_xyz[i], k)
    
        for i in range(1,len(idx)):
            G.add_edge(idx[0], idx[i])
    path=nx.shortest_path(G, local_idx_of_S, local_idx_of_T)
    print(path)

if debug==1:
    # traverse all connected clusters except clusters have been used for forceatlas2
    for i in range(num_of_main_clusters, len(connected_cluters)):
        # only the contained nodes in connected clusters are large enough, they will re-consider whether they are positve clusters
        if len(connected_cluters[i])>5:
            # get the cloud of another connected cluster
            cloud_off_xyz_another=cloud_off_xyz[connected_cluters[i]]

            # get idx of S
            Pa_dot=cloud_off_xyz_another[0,:]        
            [_, idx_of_S, _]=kdtree_disturbed.search_knn_vector_3d(Pa_dot, 1)        

            # get S and T        
            S=cloud_disturbed_xyz[idx_of_S[0]]
            [_, idx_of_Pb_dot, _]=kdtree_off.search_knn_vector_3d(S, 1)
            Pb_dot=cloud_off_xyz[idx_of_Pb_dot[0],:]
            [_, idx_of_T, _]=kdtree_disturbed.search_knn_vector_3d(Pb_dot, 1)
            T=cloud_disturbed_xyz[idx_of_T[0]]
            
            # get local cloud
            dist_of_S_and_T=np.linalg.norm(S-T) 
            [_, indices_of_lcloud,_]=kdtree_disturbed.search_radius_vector_3d(S, 1.5*dist_of_S_and_T)
            lcloud_xyz= cloud_disturbed_xyz[indices_of_lcloud,:]
            lcloud_nrm= cloud_disturbed_xyz[indices_of_lcloud,:]

            # get path
            TestOrientation(lcloud_xyz, lcloud_nrm, S, T)

            print("wokaka")


############################################## Result Extraction ######################################################
plt.figure()
plt.plot(loc_of_main_nodes[km_clusters[0],0], loc_of_main_nodes[km_clusters[0],1],'r.', markersize=1)
plt.plot(loc_of_main_nodes[km_clusters[1],0], loc_of_main_nodes[km_clusters[1],1],'g.', markersize=1)
plt.savefig("2.png")


ply_colors=np.zeros((len(cloud_off_xyz),3))
png_colors=np.zeros((len(x_y_idx),3))
for i, cluster in enumerate(km_clusters):
    if i<12:
        for idx in cluster:            
            ply_colors[idx_of_main_nodes[idx], :]=palette[i,:]
            png_colors[idx,:]=palette[i,:]

# get positive point cloud
cloud_xyz_positive=cloud_off_xyz[idx_of_main_nodes[km_clusters[0]],:]
cloud_positive=o3d.geometry.PointCloud()
cloud_positive.points=o3d.utility.Vector3dVector(cloud_xyz_positive)
cloud_positive.colors=o3d.utility.Vector3dVector(ply_colors[idx_of_main_nodes[km_clusters[0]],:])
GPath.path_of_positive="{}_positive.ply".format(GPath.output_prefix)
o3d.io.write_point_cloud(GPath.path_of_positive, cloud_positive, write_ascii=True)

cloud_negtive=o3d.geometry.PointCloud()
cloud_negtive.points=o3d.utility.Vector3dVector(cloud_off_xyz[idx_of_main_nodes[km_clusters[1]],:])
cloud_negtive.colors=o3d.utility.Vector3dVector(ply_colors[idx_of_main_nodes[km_clusters[1]],:])
GPath.path_of_negtive="{}_negtive.ply".format(GPath.output_prefix)
o3d.io.write_point_cloud(GPath.path_of_negtive, cloud_negtive, write_ascii=True)

GPath.Write()