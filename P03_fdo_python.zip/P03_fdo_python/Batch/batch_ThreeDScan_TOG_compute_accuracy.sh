#!/bin/bash
myexe=/home/i9/workspace/P04_normal_consistency/Tools/compute_accuracy.py
path_of_gt="--path_of_raw /home/i9/experiment_nc/ThreeDScan/raw/not_close"
path_of_corrected="--path_of_corrected /home/i9/experiment_nc/ThreeDScan/Result/TOG2021/not_close"
python ${myexe} ${path_of_gt}/"Eagle_custom_Normals.ply"     ${path_of_corrected}/"Eagle_custom_Normals_ratio_0d6_corrected_tog2021.ply"
python ${myexe} ${path_of_gt}/"Horned_Helmet.ply"            ${path_of_corrected}/"Horned_Helmet_ratio_0d6_corrected_tog2021.ply"
python ${myexe} ${path_of_gt}/"Saxilby_Memorial_Helmet.ply"  ${path_of_corrected}/"Saxilby_Memorial_Helmet_ratio_0d6_corrected_tog2021.ply"


path_of_gt="--path_of_raw /home/i9/experiment_nc/ThreeDScan/raw/watertight"
path_of_corrected="--path_of_corrected /home/i9/experiment_nc/ThreeDScan/Result/TOG2021/watertight"
python ${myexe} ${path_of_gt}/"Blue_Sea_Star.ply"            ${path_of_corrected}/"Blue_Sea_Star_ratio_0d6_corrected_tog2021.ply"
python ${myexe} ${path_of_gt}/"Dark_Finger_Reef_Crab.ply"    ${path_of_corrected}/"Dark_Finger_Reef_Crab_ratio_0d6_corrected_tog2021.ply"
python ${myexe} ${path_of_gt}/"Ghost_Crab.ply"               ${path_of_corrected}/"Ghost_Crab_ratio_0d6_corrected_tog2021.ply"
python ${myexe} ${path_of_gt}/"Henri_IV_Enfant.ply"          ${path_of_corrected}/"Henri_IV_Enfant_ratio_0d6_corrected_tog2021.ply"
python ${myexe} ${path_of_gt}/"Hunde_Paar.ply"               ${path_of_corrected}/"Hunde_Paar_ratio_0d6_corrected_tog2021.ply"
python ${myexe} ${path_of_gt}/"Willy_Selke_Tondo.ply"        ${path_of_corrected}/"Willy_Selke_Tondo_ratio_0d6_corrected_tog2021.ply"