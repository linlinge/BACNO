#!/bin/bash
myexe=/media/i9/gamma/workspace/P03_fdo_python/Tools/compute_accuracy.py
path_of_gt="--path_of_raw /media/i9/Lei/experiment_nc/1_special_cases/2_varying_point_density"
path_of_corrected="--path_of_corrected /media/i9/Lei/experiment_nc/1_special_cases/2_varying_point_density/disturbed/1_hoppe"
python ${myexe} ${path_of_gt}/"cocacola_varying.ply" ${path_of_corrected}/"cocacola_varying_hoppe.ply"
python ${myexe} ${path_of_gt}/"mandarine_varying.ply" ${path_of_corrected}/"mandarine_varying_hoppe.ply"
