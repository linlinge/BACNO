#!/bin/bash
myexe=/home/i9/workspace/P04_normal_consistency/Tools/compute_accuracy.py
path_of_gt="--path_of_raw /home/i9/experiment_nc/stanford/Raw/not_close"
path_of_corrected="--path_of_corrected /home/i9/experiment_nc/stanford/Result/TOG2021/not_close"
python ${myexe} ${path_of_gt}/"bunny.ply"   ${path_of_corrected}/"bunny_pts_ratio_0d6_corrected_tog2021.ply"
python ${myexe} ${path_of_gt}/"horse.ply"   ${path_of_corrected}/"horse_pts_ratio_0.6_corrected_tog2021.ply"
# python ${myexe} ${path_of_gt}/"lucy.ply"    ${path_of_corrected}/"lucy_ratio_0d6_corrected_MST.ply"


path_of_gt="--path_of_raw /home/i9/experiment_nc/stanford/Raw/watertight"
path_of_corrected="--path_of_corrected /home/i9/experiment_nc/stanford/Result/TOG2021/watertight"
python ${myexe} ${path_of_gt}/"Armadillo_pts.ply"   ${path_of_corrected}/"Armadillo_pts_ratio_0d6_corrected_tog2021.ply"
# python ${myexe} ${path_of_gt}/"dragon.ply"          ${path_of_corrected}/"dragon_ratio_0d6_corrected_MST.ply"
python ${myexe} ${path_of_gt}/"hand_pts.ply"        ${path_of_corrected}/"hand_pts_ratio_0d6_corrected_tog2021.ply"
# python ${myexe} ${path_of_gt}/"happy_vrip.ply"      ${path_of_corrected}/"happy_vrip_0d6_corrected_MST.ply"
# python ${myexe} ${path_of_gt}/"statuette.ply"       ${path_of_corrected}/"statuette_0d6_corrected_MST.ply"