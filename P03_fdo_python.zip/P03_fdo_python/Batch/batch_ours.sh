my_nb_exe="/media/i9/gamma/workspace/P03_fdo_cpp/build/fdo_cpp --fun narrow_band_establishment"
my_py_exe=/media/i9/gamma/workspace/P03_fdo_python/ST01_forceatlas2_gpu_main_cluster_args.py
my_nc_exe="/media/i9/gamma/workspace/P03_fdo_cpp/build/fdo_cpp --fun normal_correct_by_considering_confidence"


path_to_disturbed="--ipath_of_disturbed /media/i9/gamma/Exp_nc/4_ablation_study/happy_vrip_noise_renorm.ply"
path_to_gt="--ipath_of_gt /media/i9/gamma/Exp_nc/4_ablation_study/gt/happy_noise.ply"

# echo "####################################################################################################################"
# opath="--opath /media/i9/gamma/Exp_nc/4_ablation_study/ours_D_6"
# grid_size=" --grid_depth 6 "
# boudary=" --whether_compute_boundary yes"
# upsampling=" --whether_use_upsampling no"
# ${my_nb_exe} ${grid_size} ${path_to_disturbed} ${opath} ${boudary} ${upsampling}
# python ${my_py_exe} ${path_to_disturbed} ${opath}
# ${my_nc_exe} ${path_to_gt}

# echo "####################################################################################################################"
# opath="--opath /media/i9/gamma/Exp_nc/4_ablation_study/ours_D_7"
# grid_size=" --grid_depth 7 "
# boudary="--whether_compute_boundary yes"
# upsampling="--whether_use_upsampling no"
# ${my_nb_exe} ${grid_size} ${path_to_disturbed} ${opath} ${boudary} ${upsampling}
# python ${my_py_exe} ${path_to_disturbed} ${opath}
# ${my_nc_exe} ${path_to_gt}

# echo "####################################################################################################################"
# opath="--opath /media/i9/gamma/Exp_nc/4_ablation_study/ours_D_8"
# grid_size=" --grid_depth 8 "
# boudary="--whether_compute_boundary yes"
# upsampling="--whether_use_upsampling no"
# ${my_nb_exe} ${grid_size} ${path_to_disturbed} ${opath} ${boudary} ${upsampling}
# python ${my_py_exe} ${path_to_disturbed} ${opath}
# ${my_nc_exe} ${path_to_gt}

# echo "####################################################################################################################"
# opath="--opath /media/i9/gamma/Exp_nc/4_ablation_study/ours_D_9"
# grid_size=" --grid_depth 9 "
# boudary="--whether_compute_boundary yes"
# upsampling="--whether_use_upsampling no"
# ${my_nb_exe} ${grid_size} ${path_to_disturbed} ${opath} ${boudary} ${upsampling}
# python ${my_py_exe} ${path_to_disturbed} ${opath}
# ${my_nc_exe} ${path_to_gt}

echo "####################################################################################################################"
opath="--opath /media/i9/gamma/Exp_nc/4_ablation_study/ours_D_10"
grid_size=" --grid_depth 10 "
boudary="--whether_compute_boundary yes"
upsampling="--whether_use_upsampling no"
${my_nb_exe} ${grid_size} ${path_to_disturbed} ${opath} ${boudary} ${upsampling}
python ${my_py_exe} ${path_to_disturbed} ${opath}
${my_nc_exe} ${path_to_gt}