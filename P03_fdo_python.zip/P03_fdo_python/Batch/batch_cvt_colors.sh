myexe=Tools/convert_colorA_2_colorB.py
root=/media/i9/gamma/Exp_nc/demo_video/mrt_03_narrow_band_without_border_voxels
python ${myexe} --input ${root}/snapshot16_replace.png   --output ${root}/tmp/snapshot16_replace.png
python ${myexe} --input ${root}/snapshot17_replace.png   --output ${root}/tmp/snapshot17_replace.png
python ${myexe} --input ${root}/snapshot18_replace.png   --output ${root}/tmp/snapshot18_replace.png
python ${myexe} --input ${root}/snapshot19_replace.png   --output ${root}/tmp/snapshot19_replace.png
python ${myexe} --input ${root}/snapshot20_replace.png   --output ${root}/tmp/snapshot20_replace.png
python ${myexe} --input ${root}/snapshot21_replace.png   --output ${root}/tmp/snapshot21_replace.png
python ${myexe} --input ${root}/snapshot22_replace.png   --output ${root}/tmp/snapshot22_replace.png
python ${myexe} --input ${root}/snapshot23_replace.png   --output ${root}/tmp/snapshot23_replace.png
python ${myexe} --input ${root}/snapshot24_replace.png   --output ${root}/tmp/snapshot24_replace.png
python ${myexe} --input ${root}/snapshot25_replace.png   --output ${root}/tmp/snapshot25_replace.png
python ${myexe} --input ${root}/snapshot26_replace.png   --output ${root}/tmp/snapshot26_replace.png
python ${myexe} --input ${root}/snapshot27_replace.png   --output ${root}/tmp/snapshot27_replace.png
python ${myexe} --input ${root}/snapshot28_replace.png   --output ${root}/tmp/snapshot28_replace.png
python ${myexe} --input ${root}/snapshot29_replace.png   --output ${root}/tmp/snapshot29_replace.png
python ${myexe} --input ${root}/snapshot30_replace.png   --output ${root}/tmp/snapshot30_replace.png
python ${myexe} --input ${root}/snapshot31_replace.png   --output ${root}/tmp/snapshot31_replace.png
python ${myexe} --input ${root}/snapshot32_replace.png   --output ${root}/tmp/snapshot32_replace.png
python ${myexe} --input ${root}/snapshot33_replace.png   --output ${root}/tmp/snapshot33_replace.png
python ${myexe} --input ${root}/snapshot34_replace.png   --output ${root}/tmp/snapshot34_replace.png
python ${myexe} --input ${root}/snapshot35_replace.png   --output ${root}/tmp/snapshot35_replace.png
python ${myexe} --input ${root}/snapshot36_replace.png   --output ${root}/tmp/snapshot36_replace.png
python ${myexe} --input ${root}/snapshot37_replace.png   --output ${root}/tmp/snapshot37_replace.png
python ${myexe} --input ${root}/snapshot38_replace.png   --output ${root}/tmp/snapshot38_replace.png
python ${myexe} --input ${root}/snapshot39_replace.png   --output ${root}/tmp/snapshot39_replace.png
python ${myexe} --input ${root}/snapshot40_replace.png   --output ${root}/tmp/snapshot40_replace.png
python ${myexe} --input ${root}/snapshot41_replace.png   --output ${root}/tmp/snapshot41_replace.png
python ${myexe} --input ${root}/snapshot42_replace.png   --output ${root}/tmp/snapshot42_replace.png
python ${myexe} --input ${root}/snapshot43_replace.png   --output ${root}/tmp/snapshot43_replace.png
python ${myexe} --input ${root}/snapshot44_replace.png   --output ${root}/tmp/snapshot44_replace.png
python ${myexe} --input ${root}/snapshot45_replace.png   --output ${root}/tmp/snapshot45_replace.png
python ${myexe} --input ${root}/snapshot46_replace.png   --output ${root}/tmp/snapshot46_replace.png
python ${myexe} --input ${root}/snapshot47_replace.png   --output ${root}/tmp/snapshot47_replace.png
python ${myexe} --input ${root}/snapshot48_replace.png   --output ${root}/tmp/snapshot48_replace.png
python ${myexe} --input ${root}/snapshot49_replace.png   --output ${root}/tmp/snapshot49_replace.png
python ${myexe} --input ${root}/snapshot50_replace.png   --output ${root}/tmp/snapshot50_replace.png
python ${myexe} --input ${root}/snapshot51_replace.png   --output ${root}/tmp/snapshot51_replace.png
python ${myexe} --input ${root}/snapshot52_replace.png   --output ${root}/tmp/snapshot52_replace.png
python ${myexe} --input ${root}/snapshot53_replace.png   --output ${root}/tmp/snapshot53_replace.png
python ${myexe} --input ${root}/snapshot54_replace.png   --output ${root}/tmp/snapshot54_replace.png
python ${myexe} --input ${root}/snapshot55_replace.png   --output ${root}/tmp/snapshot55_replace.png


