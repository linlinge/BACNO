import numpy as np
from sklearn.neighbors import NearestNeighbors

def gaussian_weight(distance, sigma=1.0):
    return np.exp(-distance**2 / (2 * sigma**2))

def weighted_nearest_neighbor_distances(query_pts, search_pts, k=10, sigma=1.0):
    nn = NearestNeighbors(n_neighbors=k+1, algorithm='kd_tree').fit(search_pts)
    distances, ngbrs = nn.kneighbors(query_pts)

    # distance
    
    
    # 计算高斯权重
    weights = gaussian_weight(distances, sigma=sigma)
    
    # 计算加权平均距离
    weighted_distance = np.sum(weights * distances) / np.sum(weights)
    
    return weighted_distance


# from scipy.spatial import cKDTree

# def gaussian_weight(distance, sigma=1.0):
#     return np.exp(-distance**2 / (2 * sigma**2))

# def weighted_nearest_neighbor_distances(query_points, point_cloud, k=10, sigma=1.0):
#     # 创建KDTree以便高效搜索
#     tree = cKDTree(point_cloud)
#     distances_list = []

#     for query_point in query_points:
#         # 找到最近的k个邻居以及它们的距离
#         distances, indexes = tree.query(query_point, k=k)
        
#         # 如果只找到一个邻居，我们把它变成一个列表以便一致处理
#         if k == 1:
#             distances = [distances]
        
#         # 计算高斯权重
#         weights = gaussian_weight(np.array(distances), sigma=sigma)
        
#         # 计算加权平均距离并添加到列表中
#         weighted_distance = np.sum(weights * distances) / np.sum(weights)
#         distances_list.append(weighted_distance)

#     # 将距离列表转换为n×1的NumPy数组
#     return np.array(distances_list).reshape(-1, 1)