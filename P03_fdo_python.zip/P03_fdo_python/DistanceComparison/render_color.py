import cv2
import numpy as np

def GetColor(min, max, confidence):
    rst_r=0
    rst_g=0
    rst_b=0
    n=4.0
    step=(max-min)/n
    c=confidence-min
    if c<step:
        rst_r=0
        rst_g=c/step*255
        rst_b=255
    elif c<2*step:
        rst_r=0
        rst_g=255
        rst_b=255-(c-step)/step*255
    elif c<3*step:
        rst_r=(c-2*step)/step*255
        rst_g=255
        rst_b=0        
    else:
        rst_r=255
        rst_g=255-(c-3*step)/step*255
        rst_b=0

    return  rst_b, rst_g, rst_r


def GetColor_Gray(min, max, confidence):
    rst_r=0
    rst_g=0
    rst_b=0
    c=256-(confidence-min)*256/max
    rst_r=int(c)
    rst_g=int(c)
    rst_b=int(c)
    return  rst_b, rst_g, rst_r

def GetColors(idata, mode="gray"):
    vmin=np.min(idata)
    vmax=np.max(idata)
    colors=[]

    if mode=="color":
        for i in range(len(idata)):
            colors.append(GetColor(vmin, vmax, idata[i]))
    elif mode=="gray":
        for i in range(len(idata)):
            colors.append(GetColor_Gray(vmin, vmax, idata[i]))
    else:
        print("Mode Error!")
    return colors

# 加载图像
image_path = 'DistanceComparison/test_image/1.png'
image = cv2.imread(image_path, cv2.IMREAD_COLOR)

# 
weighted_distance=np.loadtxt("/media/i9/gamma/workspace/P03_fdo_cpp/tmp/weighted_distance_2_k_2.txt")


query_loc = np.loadtxt("/media/i9/gamma/workspace/P03_fdo_cpp/tmp/query_loc.txt").astype(np.int32)

colors=GetColors(weighted_distance, mode="color")
colors= np.asarray(colors)

height, width, _ = image.shape  

i=0
for loc in query_loc: 
    # 获取当前像素的值  
    pixel = image[loc[0], loc[1]]  
        
    # 示例：将像素的红色通道值设置为255（即完全红色）  
    pixel[2] = colors[i,0]  # 设置红色通道值  
    pixel[1] = colors[i,1]   # 设置绿色通道值  
    pixel[0] = colors[i,2]    # 设置蓝色通道值  

    i=i+1

cv2.imwrite("/media/i9/gamma/workspace/P03_fdo_python/DistanceComparison/out_image/weighted_distance_2_k_2.png", image)