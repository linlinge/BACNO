import cv2
import numpy as np
import sys 
sys.path.append(".")
from DistanceComparison.distances import *

# 加载图像
image_path = 'DistanceComparison/test_image/1.png'
image = cv2.imread(image_path, cv2.IMREAD_COLOR)

# 将图像转换为灰度
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# 应用霍夫变换进行圆检测
circles = cv2.HoughCircles(gray,cv2.HOUGH_GRADIENT, dp=1, minDist=40, param1=40, param2=3,  minRadius=12, maxRadius=20)

# 如果找到了圆，输出圆的信息
if circles is not None:
    circles = np.uint16(np.around(circles))
    for i in circles[0, :]:
        # 绘制圆心
        cv2.circle(image, (i[0], i[1]), 1, (0, 100, 100), 3)
        # 绘制圆轮廓
        cv2.circle(image, (i[0], i[1]), i[2], (255, 0, 255), 2)

cv2.imwrite("DistanceComparison/out_image/1.png", image)


# 
search_pts = np.asarray([ np.array([x[0], x[1], 0]) for x in circles[0, :]])
query_pts = []
query_loc = []
height, width, channels = image.shape  
for y in range(height):  
    for x in range(width):  
        # 获取像素值  
        b, g, r = image[y, x]  
        if r==255 and g==255 and b==255:
            query_pts.append(np.array([x,y,0]))
            query_loc.append(np.array([y , x]))

query_pts = np.asarray(query_pts)


np.savetxt("/media/i9/gamma/workspace/P03_fdo_cpp/tmp/query_pts.xyz", query_pts, fmt="%f %f %f")
np.savetxt("/media/i9/gamma/workspace/P03_fdo_cpp/tmp/query_loc.txt", query_loc, "%d %d")
np.savetxt("/media/i9/gamma/workspace/P03_fdo_cpp/tmp/search_pts.xyz", search_pts, fmt="%f %f %f")

