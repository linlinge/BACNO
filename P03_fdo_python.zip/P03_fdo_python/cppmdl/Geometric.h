#pragma once
#include "V3.hpp"
#include <iostream>
#include <eigen3/Eigen/Dense>
#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Geometry>
#include <fstream>
#include <stack>
#include <OBJManager.h>
using namespace std;
using namespace Eigen;
#define IS_BETWEEN(DAT, A,B)   ((DAT>=A)&&(DAT<=B))
#define MIN2(A,B) (A<B ? A:B)
#define MAX2(A,B) (A>B ? A:B)

enum LineInitType{point_with_direction,point_to_point};
enum ProjectionType{XY,XZ,YZ};
class Plane;
class AABB;
class Triangle;
class PointN;
class OBJManager;

/************************************************************* 
 * N-dimension Point
**************************************************************/
class PointN
{
    public:
        int id_;
        vector<float> dat_;

		PointN(int i, float idata){
			id_=i;
			dat_.push_back(idata);
		}

		PointN(float idata){
			dat_.push_back(idata);
		}

        PointN(vector<float> dat){
            dat_=dat;
        }
        PointN(int id, vector<float> dat){
            dat_=dat;
            id_=id;
        }
        float DistTo(PointN& b){
            float r=0;
            for(int i=0; i<dat_.size(); i++){
                r+=pow(dat_[i]-b.dat_[i],2);
            }
            return sqrt(r);
        }
};


/************************************************************* 
 * Pointwise Equation:
       (x-x1)/d.x=(y-y1)/d.y=(z-z1)/d.z
**************************************************************/
class Ray
{
	public:
		// represent by parameter	
		V3 origin_,direction_;
		
		// convert point-direction equation to parameter equation
		Ray(V3 dat1, V3 dat2, LineInitType mode);    

		// is intersect
		V3 IsIntersect(Plane& dat);
		tuple<bool, float>        IsIntersect(AABB obj);
		tuple<int,vector<float>> IsIntersect(Triangle ob);

		// transform
		V3    GetProjectionVector(ProjectionType mode);
		float GetProjectionArc(ProjectionType mode);
		V3 TransformTo(ProjectionType mode);
		Ray operator=(Ray obj);
};

/************************************************************* 
 * Line Segments
**************************************************************/
class LineSegment
{
	public:
		// variables
		V3 origin_, end_;
		V3 direction_;
		float t_o2e_;

		// function
		LineSegment(V3 origin, V3 end);
		tuple<bool, float>        IsIntersect(AABB* obj);
		tuple<bool,vector<float>> IsIntersect(Triangle ob);
		tuple<bool,int> IsIntersect(vector<vector<float>> pts, vector<vector<int>> fid);
};

/************************************************************* 
 * AABB
**************************************************************/
class AABB{
public:
    V3 bmin_, bmax_;	
	vector<vector<float>> corners_;	
    AABB(V3 bmin, V3 bmax);
	AABB(){};
	AABB(vector<vector<float>> pts);
	V3 GetCentre();
	bool IsWithin(V3 pt);
	bool IsWithin(float x, float y, float z);
	vector<vector<float>> GenerateEightCorners();
	vector<vector<int>> GenerateSelfLines();
	friend AABB* UnionAABB(AABB* idata1, AABB* idata2);
	
};

/************************************************************* 
 * Plane
**************************************************************/
class Plane
{
public:
	float A_, B_, C_, D_;
	Plane(V3 P1, V3 P2, V3 P3);
	Plane(V3 pt_on_plane, V3 normal);
	Plane(vector<vector<float>> pts);
	V3 IsIntersect(Ray& dat);
	float Apply(float x, float y);
};

/************************************************************* 
 * Angle
**************************************************************/
class Angle
{
public:
	float arc_, angle_;	
	Angle(V3& mid,V3& left,V3& right);
};

/************************************************************* 
 * Triangle
**************************************************************/
class Triangle
{
	public:
		V3 vtx_[3];
		Triangle(V3 v0, V3 v1, V3 v2);
		Triangle(vector<vector<float>> pts);
		tuple<int,vector<float>> IsIntersect(Ray ry);
		tuple<bool,vector<float>> IsIntersect(LineSegment ry);
		Triangle operator=(Triangle dat);
};


/************************************************************* 
 * KDTree
**************************************************************/
class BinaryNode
{
    public:
        int axis_;
        float pivot_;
        int id_of_pt_=-INT16_MAX;       //  store the indice of point
        int num_of_pts_=0;
        bool is_leaf=false;
		int is_visited_=0;
        BinaryNode* lchild_=NULL;
        BinaryNode* rchild_=NULL;
        BinaryNode* parent_=NULL;
};

class KDTreeN
{
    public:
        vector<PointN*> dat_;
        BinaryNode* root_;
        int dim_;
		vector<int> order_to_id_;
		vector<int> id_to_order_;

        KDTreeN(vector<vector<float>> idata){
            // make sure dat has values
            if(idata.size()==0){
                cout<<"Error: the input data is empty!"<<endl;
            }

            // init dimension
            dim_=idata[0].size();

            for(int i=0;i< idata.size(); i++){
                dat_.push_back(new PointN(i, idata[i]));    
            }
            // Init cloud
            root_=new BinaryNode();

			//
			id_to_order_.resize(idata.size());

            // create binary tree
			CreateTree(root_,dat_);

			// update
			UpdateDFSOrder();			
        }

		~KDTreeN(){
			delete root_;
		}

        vector<vector<float>> SearchKNearest(vector<float> input, int k){
			PointN idata(input);
            // Init 
			          
            if(dat_.size()==0){
                cout<<"KDTree search error: data is empty !"<<endl;
            }

            // find nearest point
			BinaryNode* current=root_;
			while(current->is_leaf==false){
				if(input[current->axis_]<current->pivot_){
					current=current->lchild_;
				}
				else{
					current=current->rchild_;
				}
			}

			int idx_in_order=id_to_order_[current->id_of_pt_];
			int min_idx_in_order= (idx_in_order-k)> 0 ? (idx_in_order-k):0;
			int max_idx_in_order= (idx_in_order+k)< id_to_order_.size() ? (idx_in_order+k): id_to_order_.size();
			
			vector<vector<float>> rst(max_idx_in_order-min_idx_in_order+1,vector<float>(2));  
			for(int i=min_idx_in_order; i<= max_idx_in_order; i++){
				int itmp=order_to_id_[i];
				rst[i-min_idx_in_order][0]=itmp;
				rst[i-min_idx_in_order][1]=dat_[itmp]->DistTo(idata);
			}

			sort(rst.begin(), rst.end(), [](vector<float>& e1, vector<float>& e2){ return e1[1]<e2[1];});
			if(rst.size()>k)
				rst.erase(rst.begin()+k,rst.end());
			
            //
            return rst;
        }

    private:
        float DistanceOf(PointN& d1, PointN& d2){
            float rst=0;
            for(int i=0; i< d1.dat_.size(); i++){
                rst+=pow(d1.dat_[i]-d2.dat_[i],2);
            }
            return sqrt(rst);
        }

        /* binary tree manager */
        void CreateTree(BinaryNode* parent, vector<PointN*>& pts)
        {   
			// stop recursive
			if(pts.size()==1){
				parent->is_leaf=true;
				parent->id_of_pt_=pts[0]->id_;
				return;
			}
				

			// establish new node
			// obtain split dim 
			int split_axis=GetSplitDim(pts);
			parent->axis_=split_axis;

			// obtain split data
			vector<PointN*> left, right;
			float split_val=SplitData(pts, split_axis, left, right);
			parent->pivot_=split_val;
			
			if(left.size()>0){	
				BinaryNode* new_node=new BinaryNode();	
				parent->lchild_=new_node;
				CreateTree(new_node, left);
			}

			if(right.size()>0){
				BinaryNode* new_node=new BinaryNode();
				parent->rchild_=new_node;
				CreateTree(new_node, right);
			}
        }

		int GetSplitDim(vector<PointN*>& pts){
			vector<float> pts_mean(dim_,0);
			vector<float> pts_variance(dim_,0);
			for(int j=0; j<dim_; j++){
				for(int i=0; i<pts.size(); i++){
					pts_mean[j]+=pts[i]->dat_[j];
				}
				pts_mean[j]/=pts.size();
			}

			for(int j=0; j<dim_; j++){
				for(int i=0; i<pts.size(); i++){
					pts_variance[j]+=pow(pts[i]->dat_[j]-pts_mean[j],2);
				}
				pts_variance[j]/=pts.size();
			}

			float max_variance=pts_variance[0];
			float max_i=0;
			for(int i=1; i<pts_variance.size(); i++){
				if(max_variance< pts_variance[i]){
					max_i=i;
					max_variance=pts_variance[i];
				}
			}
			return max_i;
		}


		float SplitData(vector<PointN*> pts, int split_dim, vector<PointN*>& left, vector<PointN*>& right){
			class CMP{
				public:
					CMP(int select_dim):select_dim_(select_dim){}
				
					bool operator()(PointN* e1, PointN* e2){ 
						return e1->dat_[select_dim_]<e2->dat_[select_dim_];
					}
				private:
					int select_dim_;
			};
				

			sort(pts.begin(), pts.end(), CMP(split_dim));
			int split_num=pts.size()/2;
			left.insert(left.end(), pts.begin(), pts.begin() + split_num);
			right.insert(right.end(), pts.begin()+split_num, pts.end());

			float split_val= (pts[split_num-1]->dat_[split_dim] + pts[split_num]->dat_[split_dim])/2.0;
			return split_val;
		}

		void UpdateDFSOrder(){
			BinaryNode* current=NULL;;
			stack<BinaryNode*> stk;
			stk.push(root_);

			stk.top()->is_visited_+=1;
			current=stk.top();

			while(stk.size()!=0){				
				if(current->is_leaf==true){
					order_to_id_.push_back(current->id_of_pt_);					
					stk.pop();					
				}
				else if(current->is_visited_==2){
					stk.pop();
				}
				else{
					if(current->rchild_!=NULL && current->rchild_->is_visited_!=1){
						stk.push(current->rchild_);
					}					
					if(current->lchild_!=NULL && current->lchild_->is_visited_!=1){
						stk.push(current->lchild_);
					}						
				}
				stk.top()->is_visited_+=1;
				current=stk.top();
			}

			// update id_to_order_
			if(order_to_id_.size()!=id_to_order_.size())
				cout<<"update error!"<<endl;
			else{
				for(int i=0; i<order_to_id_.size(); i++){
					int itmp=order_to_id_[i];
					id_to_order_[itmp]=i;
				}
			}			
		}
};

/**************************************************************
 * 
 **************************************************************/
tuple<int, float, float> Poly2Solve(float a, float b, float c);


/************************************************************* 
 * Surface Fitting
**************************************************************/
class SurfaceFitting
{
    public:
        vector<vector<float>> pts_;
};

class Poly33Fitting: public SurfaceFitting
{
    public:
        float p00, p10, p01, p20, p11, p02, p30, p21, p12, p03;        
        void Fit(vector<vector<float>> pts);
		int IsIntersect(Ray ry);
};

class Poly22Fitting: public SurfaceFitting
{
	public:
		float p00, p10, p01, p20, p11, p02;
		vector<AABB*> range_;
		AABB* bb_;
		Quaterniond trans_;
		MatrixXd T_;

		Poly22Fitting(vector<AABB*> range);

		// x-y surface (naive)
		void Fit(vector<vector<float>> pts);	
		float Apply(float x, float y);
		void GenerateMesh(string path);

		// Auto	
		void AutoFit(vector<vector<float>> pts);		
		tuple<int, float, float> AutoApply(float x, float y);
		void GenerateAutoMesh(string path);

		// 
		int IsIntersect(Ray ry);
		bool IsWithin(float x, float y, float z);		
};

class OBJManagerGeometricEx: public OBJManager{
	public:		
		OBJManagerGeometricEx(){};	        
		OBJManagerGeometricEx(Triangle tri);
        OBJManagerGeometricEx(Ray ry);
        OBJManagerGeometricEx(LineSegment ry);
		void AddMesh(Triangle& tri);
		void AddMesh(vector<vector<float>> pts, vector<vector<int>> faces);		
		void AddBox(AABB* bb);
		void AddLineSegment(LineSegment lg);
		void AddPlane(Plane pl, AABB* bb);
		void AddRay(Ray ry);
};