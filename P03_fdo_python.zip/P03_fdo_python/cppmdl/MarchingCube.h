#pragma once
#include <vector>
#include <iostream>
extern int edgeTable[256];
extern int triTable[256][16];
extern int e2c[12][2];

using namespace std;
// tuple<int, vector<vector<int>>> SearchTriangulatedID(int encoding);
vector<vector<int>> SearchTriangulatedID(int encoding, vector<int> global_indices, int& is_succeed);