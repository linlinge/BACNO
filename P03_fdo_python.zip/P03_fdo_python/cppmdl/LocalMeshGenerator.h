#pragma once
#include <pcl/surface/poisson.h>
#include <PCLExtend.h>
#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>
#include <CGAL/Delaunay_triangulation_2.h>
#include <CGAL/Triangulation_vertex_base_with_info_2.h>
#include <CGAL/Triangulation_vertex_base_with_info_3.h>
#include <CGAL/Triangulation_cell_base_with_info_3.h>
#include <CGAL/Delaunay_triangulation_3.h>
#include <vector>
#include <V3.hpp>
#include <Geometric.h>
#include <Clustering.h>
using namespace std;
typedef CGAL::Exact_predicates_inexact_constructions_kernel            Kernel;
typedef CGAL::Triangulation_vertex_base_with_info_2<unsigned int, Kernel> Vb_2;
typedef CGAL::Triangulation_data_structure_2<Vb_2>                       Tds;
typedef CGAL::Delaunay_triangulation_2<Kernel, Tds>                    delaunay_2;
typedef Kernel::Point_2                                                point_2;
typedef CGAL::Triangulation_vertex_base_with_info_3<unsigned int, Kernel> Vb_3;
typedef CGAL::Triangulation_cell_base_3<Kernel> Cb;
typedef CGAL::Triangulation_cell_base_with_info_3<int, Kernel, Cb> CbI;
typedef CGAL::Triangulation_data_structure_3<Vb_3, CbI> cdTds;
typedef CGAL::Delaunay_triangulation_3<Kernel, cdTds> delaunay_3;
typedef delaunay_3::Point_3 point_3;
using namespace std;

class BaseRecon
{
    public:
        vector<vector<float>> pts_; // points
        vector<vector<int>> fid_;  // local faces indices
        virtual void Recon()=0;
};

class PoissonRecon: public BaseRecon
{
    public:
        PoissonRecon(vector<vector<float>>& pts);
        void Recon();
};

class Delaunay2D: public BaseRecon
{
    public:
        int debug;
        Delaunay2D(vector<vector<float>>& pts);
        void EnableDebug();
        void DisableDebug();
        void Recon();
        int IsIntersect(Ray ry);
};

class Delaunay3D: public BaseRecon
{
    public:
        Delaunay3D(vector<vector<float>>& pts);
        void Recon();
};

