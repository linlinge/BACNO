#pragma once 
#include <GridManager.h>
class ChartFlow
{
    public:
        NarrowBandVoxels* obj_;
        ChartFlow(string filepath);
        void PlotNarrowBandVoxels();
        void PlotOnOffNarrowBandVoxels();
        void PlotIntersectVoxels(int i);
};