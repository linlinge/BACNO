#include <Delaunay2D.h>

vector<vector<int>> Delaunay2D(vector<vector<float>>& pts, vector<int>& pts_id)
{
    vector<pair<Point,unsigned> > points;
    vector<vector<int>> faces_id;
    for(int i=0; i<pts.size(); i++){
        // points.push_back(std::make_pair( Point(pts[i][0],pts[i][1]), pts_id[i] ));
        points.push_back(std::make_pair( Point(pts[i][0],pts[i][1]), i ));
    }

    Delaunay triangulation;
    triangulation.insert(points.begin(),points.end());

    for(Delaunay::Finite_faces_iterator fit = triangulation.finite_faces_begin(); fit != triangulation.finite_faces_end(); ++fit) {
        Delaunay::Face_handle face = fit;        
        faces_id.push_back(V3(face->vertex(0)->info(), face->vertex(1)->info(), face->vertex(2)->info()).ToInt());
    }
    return faces_id;
}