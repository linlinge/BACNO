#include <Geometric.h>

/*****************************************************************
 Ray
******************************************************************/
Ray::Ray(V3 dat1, V3 dat2, LineInitType mode=point_with_direction)
{
	switch(mode)
	{
		case point_with_direction: // represent line with point and direction
			origin_=dat1;
			direction_=dat2;
			direction_.Normalize();
			break;
			
		case point_to_point: // represent line with two points
			origin_=dat1;
			direction_=dat2-dat1;
			direction_.Normalize();
			break;
	} 
}

V3 Ray::IsIntersect(Plane& dat)
{
	float t = -(dat.A_*origin_.x + dat.B_*origin_.y + dat.C_*origin_.z + dat.D_) / (dat.A_*direction_.x + dat.B_*direction_.y + dat.C_*direction_.z);
	return V3(direction_.x * t + origin_.x, direction_.y * t + origin_.y, direction_.z * t + origin_.z);
}

/**
 * @brief 
 * 
 * @param a 
 * @return (bool) whether intersect, (float) distance to AABB
 */
tuple<bool, float> Ray::IsIntersect(AABB a)
{
    float tmin = 0.0f;
	float tmax = 1000000.0f;
 
	//The plane perpendicular to x-axie
	if(abs(direction_.x) < 0.000001f) //If the ray parallel to the plane
	{
		//If the ray is not within AABB box, then not intersecting
		if(origin_.x < a.bmin_.x || origin_.x > a.bmax_.x)			
			return make_tuple(false, INT_MAX);
	}
	else
	{
		//Compute the distance of ray to the near plane and far plane
		float ood = 1.0f / direction_.x;
		float t1 = (a.bmin_.x - origin_.x) * ood;
		float t2 = (a.bmax_.x - origin_.x) * ood;
 
		//Make t1 be intersecting with the near plane, t2 with the far plane
		if(t1 > t2)
		{
			float temp = t1;
			t1 = t2;
			t2 = temp;
		}
 
		//Compute the intersection of slab intersection intervals
		if(t1 > tmin) tmin = t1;
		if(t2 < tmax) tmax = t2;
 
		//Exit with no collision as soon as slab intersection becomes empty
		if(tmin > tmax) return make_tuple(false,INT_MAX);
	}// end for perpendicular to x-axie
 
	//The plane perpendicular to y-axie
	if(abs(direction_.y) < 0.000001f) //If the ray parallel to the plane
	{
		//If the ray is not within AABB box, then not intersecting
		if(origin_.y < a.bmin_.y || origin_.y > a.bmax_.y)
			return make_tuple(false, INT_MAX);
	}
	else
	{
		//Compute the distance of ray to the near plane and far plane
		float ood = 1.0f / direction_.y;
		float t1 = (a.bmin_.y - origin_.y) * ood;
		float t2 = (a.bmax_.y - origin_.y) * ood;
 
		//Make t1 be intersecting with the near plane, t2 with the far plane
		if(t1 > t2)
		{
			float temp = t1;
			t1 = t2;
			t2 = temp;
		}
 
		//Compute the intersection of slab intersection intervals
		if(t1 > tmin) tmin = t1;
		if(t2 < tmax) tmax = t2;
 
		//Exit with no collision as soon as slab intersection becomes empty
		if(tmin > tmax) return make_tuple(false, INT_MAX);
	}// end for perpendicular to y-axie
 
	//The plane perpendicular to z-axie
	if(abs(direction_.z) < 0.000001f) //If the ray parallel to the plane
	{
		//If the ray is not within AABB box, then not intersecting
		if(origin_.z < a.bmin_.z || origin_.z > a.bmax_.z)
			return make_tuple(false, INT_MAX);
	}
	else
	{
		//Compute the distance of ray to the near plane and far plane
		float ood = 1.0f / direction_.z;
		float t1 = (a.bmin_.z - origin_.z) * ood;
		float t2 = (a.bmax_.z - origin_.z) * ood;
 
		//Make t1 be intersecting with the near plane, t2 with the far plane
		if(t1 > t2)
		{
			float temp = t1;
			t1 = t2;
			t2 = temp;
		}
 
		//Compute the intersection of slab intersection intervals
		if(t1 > tmin) tmin = t1;
		if(t2 < tmax) tmax = t2;
 
		//Exit with no collision as soon as slab intersection becomes empty
		if(tmin > tmax) return make_tuple(false, INT_MAX);
	}
	// end for perpendicular to z-axie
    
    V3 vcHit;
	if(IS_BETWEEN(origin_.x,a.bmin_.x,a.bmax_.x) && IS_BETWEEN(origin_.y,a.bmin_.y,a.bmax_.y) && IS_BETWEEN(origin_.z,a.bmin_.z,a.bmax_.z)){
		vcHit.x = origin_.x + tmax * direction_.x;
		vcHit.y = origin_.y + tmax * direction_.y;
		vcHit.z = origin_.z + tmax * direction_.z;
		return make_tuple(true, tmax);
	}
	else{
		vcHit.x = origin_.x + tmin * direction_.x;
		vcHit.y = origin_.y + tmin * direction_.y;
		vcHit.z = origin_.z + tmin * direction_.z;
		return make_tuple(true, tmin);
	}	
	// return true;
}

tuple<int,vector<float>> Ray::IsIntersect(Triangle obj)
{
	auto [num_of_itsc, itsc]=obj.IsIntersect(*this);
	return make_tuple(num_of_itsc,itsc);
}

V3 Ray::GetProjectionVector(ProjectionType mode)
{
	if(mode==XY)
	{
		return V3(direction_.x, direction_.y, 0);
	}
	else if(mode==XZ)
	{
		return V3(direction_.x, 0, direction_.z);
	}
	else if(mode==YZ)
	{
		return V3(0, direction_.y, direction_.z);
	}
}

float Ray::GetProjectionArc(ProjectionType mode)
{
	if(mode==XY)
	{
		return atan(direction_.z/sqrt(pow(direction_.x,2)+pow(direction_.y,2)));
	}
	else if(mode==XZ)
	{
		return atan(direction_.y/sqrt(pow(direction_.x,2)+pow(direction_.z,2)));
	}
	else if(mode==YZ)
	{
		return atan(direction_.x/sqrt(pow(direction_.y,2)+pow(direction_.z,2)));
	}
}

V3 Ray::TransformTo(ProjectionType mode)
{
	if(mode==XY)
	{
		return GetProjectionVector(XY).Normalize()*direction_.GetLength() + origin_;
	} 
	else if(mode == YZ)
	{
		return GetProjectionVector(YZ).Normalize()*direction_.GetLength() + origin_;
	}
	else if(mode == XZ)
	{
		return GetProjectionVector(XZ).Normalize()*direction_.GetLength() + origin_;
	}
}

Ray Ray::operator=(Ray obj){
	origin_=obj.origin_;
	direction_=obj.direction_;
	return *this;
}

/******************************************************************
 *  Line Segment
 *******************************************************************/
LineSegment::LineSegment(V3 origin, V3 end)
{
	origin_=origin;
	end_=end;
	direction_=(end_-origin_).Normalize();
	t_o2e_=(end_-origin_).GetLength();
}

/**
 * @brief 
 * 
 * @param a 
 * @return (bool) whether intersect, (float) distance to AABB
 */
tuple<bool, float> LineSegment::IsIntersect(AABB* idata)
{
    float tmin = 0.0f;
	float tmax = 1000000.0f;
 
	//The plane perpendicular to x-axie
	if(abs(direction_.x) < 0.000001f) //If the ray parallel to the plane
	{
		//If the ray is not within AABB box, then not intersecting
		if(origin_.x < idata->bmin_.x || origin_.x > idata->bmax_.x)			
			return make_tuple(false, INT_MAX);
	}
	else
	{
		//Compute the distance of ray to the near plane and far plane
		float ood = 1.0f / direction_.x;
		float t1 = (idata->bmin_.x - origin_.x) * ood;
		float t2 = (idata->bmax_.x - origin_.x) * ood;
 
		//Make t1 be intersecting with the near plane, t2 with the far plane
		if(t1 > t2)
		{
			float temp = t1;
			t1 = t2;
			t2 = temp;
		}
 
		//Compute the intersection of slab intersection intervals
		if(t1 > tmin) tmin = t1;
		if(t2 < tmax) tmax = t2;
 
		//Exit with no collision as soon as slab intersection becomes empty
		if(tmin > tmax) return make_tuple(false,INT_MAX);
	}// end for perpendicular to x-axie
 
	//The plane perpendicular to y-axie
	if(abs(direction_.y) < 0.000001f) //If the ray parallel to the plane
	{
		//If the ray is not within AABB box, then not intersecting
		if(origin_.y < idata->bmin_.y || origin_.y > idata->bmax_.y)
			return make_tuple(false, INT_MAX);
	}
	else
	{
		//Compute the distance of ray to the near plane and far plane
		float ood = 1.0f / direction_.y;
		float t1 = (idata->bmin_.y - origin_.y) * ood;
		float t2 = (idata->bmax_.y - origin_.y) * ood;
 
		//Make t1 be intersecting with the near plane, t2 with the far plane
		if(t1 > t2)
		{
			float temp = t1;
			t1 = t2;
			t2 = temp;
		}
 
		//Compute the intersection of slab intersection intervals
		if(t1 > tmin) tmin = t1;
		if(t2 < tmax) tmax = t2;
 
		//Exit with no collision as soon as slab intersection becomes empty
		if(tmin > tmax) return make_tuple(false, INT_MAX);
	}// end for perpendicular to y-axie
 
	//The plane perpendicular to z-axie
	if(abs(direction_.z) < 0.000001f) //If the ray parallel to the plane
	{
		//If the ray is not within AABB box, then not intersecting
		if(origin_.z < idata->bmin_.z || origin_.z > idata->bmax_.z)
			return make_tuple(false, INT_MAX);
	}
	else
	{
		//Compute the distance of ray to the near plane and far plane
		float ood = 1.0f / direction_.z;
		float t1 = (idata->bmin_.z - origin_.z) * ood;
		float t2 = (idata->bmax_.z - origin_.z) * ood;
 
		//Make t1 be intersecting with the near plane, t2 with the far plane
		if(t1 > t2)
		{
			float temp = t1;
			t1 = t2;
			t2 = temp;
		}
 
		//Compute the intersection of slab intersection intervals
		if(t1 > tmin) tmin = t1;
		if(t2 < tmax) tmax = t2;
 
		//Exit with no collision as soon as slab intersection becomes empty
		if(tmin > tmax) return make_tuple(false, INT_MAX);
	}
	// end for perpendicular to z-axie
    
    V3 vcHit;
	if(IS_BETWEEN(origin_.x,idata->bmin_.x,idata->bmax_.x) && 
	   IS_BETWEEN(origin_.y,idata->bmin_.y,idata->bmax_.y) && 
	   IS_BETWEEN(origin_.z,idata->bmin_.z,idata->bmax_.z)){
		vcHit.x = origin_.x + tmax * direction_.x;
		vcHit.y = origin_.y + tmax * direction_.y;
		vcHit.z = origin_.z + tmax * direction_.z;
		
		if(tmax<=t_o2e_)
			return make_tuple(true, tmax);
		else 
			return make_tuple(false, INT_MAX);
	}
	else{
		vcHit.x = origin_.x + tmin * direction_.x;
		vcHit.y = origin_.y + tmin * direction_.y;
		vcHit.z = origin_.z + tmin * direction_.z;

		if(tmin<=t_o2e_)
			return make_tuple(true, tmin);
		else 	
			return make_tuple(false,INT_MAX);
	}	
	// return true;
}

/******************************************************************
 *  Axis-aligned bounding box
 *******************************************************************/
AABB::AABB(V3 bmin, V3 bmax){
	bmin_=bmin;
	bmax_=bmax;
}

AABB::AABB(vector<vector<float>> pts)
{
	bmin_=V3(INT_MAX, INT_MAX, INT_MAX);
	bmax_=V3(-INT_MAX, -INT_MAX, -INT_MAX);

	for(int i=0; i< pts.size(); i++){
		bmin_.x= bmin_.x < pts[i][0] ? bmin_.x : pts[i][0];
		bmin_.y= bmin_.y < pts[i][1] ? bmin_.y : pts[i][1];
		bmin_.z= bmin_.z < pts[i][2] ? bmin_.z : pts[i][2];

		bmax_.x= bmax_.x > pts[i][0] ? bmax_.x : pts[i][0];
		bmax_.y= bmax_.y > pts[i][1] ? bmax_.y : pts[i][1];
		bmax_.z= bmax_.z > pts[i][2] ? bmax_.z : pts[i][2];
	}
}

V3 AABB::GetCentre()
{
	return V3((bmin_.x+bmax_.x)/2.0, (bmin_.y+bmax_.y)/2.0, (bmin_.z+bmax_.z)/2.0);
}

bool AABB::IsWithin(V3 pt)
{
    if((pt.x> bmin_.x) && (pt.x< bmax_.x) &&
       (pt.y> bmin_.y) && (pt.y< bmax_.y) && 
       (pt.z> bmin_.z) && (pt.z< bmax_.z)){
        return true;
    }
    else 
        return false;
}

bool AABB::IsWithin(float x, float y, float z)
{
	int count=0;
	if(IS_BETWEEN(x, bmin_.x, bmax_.x)) count++;
	if(IS_BETWEEN(y, bmin_.y, bmax_.y)) count++;
	if(IS_BETWEEN(z, bmin_.z, bmax_.z)) count++;

	if(count==3)
		return true;
	else 
		return false;
}

vector<vector<float>> AABB::GenerateEightCorners(){    
    if(corners_.size()==0){
        corners_.resize(8); 
        corners_[0].push_back(bmin_.x);
        corners_[0].push_back(bmin_.y);
        corners_[0].push_back(bmin_.z);

        corners_[1].push_back(bmin_.x);
        corners_[1].push_back(bmax_.y);
        corners_[1].push_back(bmin_.z);

        corners_[2].push_back(bmax_.x);
        corners_[2].push_back(bmax_.y);
        corners_[2].push_back(bmin_.z);

        corners_[3].push_back(bmax_.x);
        corners_[3].push_back(bmin_.y);
        corners_[3].push_back(bmin_.z);

        corners_[4].push_back(bmin_.x);
        corners_[4].push_back(bmin_.y);
        corners_[4].push_back(bmax_.z);

        corners_[5].push_back(bmin_.x);
        corners_[5].push_back(bmax_.y);
        corners_[5].push_back(bmax_.z);

        corners_[6].push_back(bmax_.x);
        corners_[6].push_back(bmax_.y);
        corners_[6].push_back(bmax_.z);

        corners_[7].push_back(bmax_.x);
        corners_[7].push_back(bmin_.y);
        corners_[7].push_back(bmax_.z);
    }       
    return corners_;   
}


vector<vector<int>> AABB::GenerateSelfLines()
{
	vector<vector<int>> lines_by_self_id;

	lines_by_self_id.resize(12);
	// line 0
	lines_by_self_id[0].push_back(0);
	lines_by_self_id[0].push_back(1);
	// line 1
	lines_by_self_id[1].push_back(1);
	lines_by_self_id[1].push_back(2);
	// line 2
	lines_by_self_id[2].push_back(2);
	lines_by_self_id[2].push_back(3);
	// line 3
	lines_by_self_id[3].push_back(3);
	lines_by_self_id[3].push_back(0);
	// line 4
	lines_by_self_id[4].push_back(4);
	lines_by_self_id[4].push_back(5);
	// line 5
	lines_by_self_id[5].push_back(5);
	lines_by_self_id[5].push_back(6);
	// line 6
	lines_by_self_id[6].push_back(6);
	lines_by_self_id[6].push_back(7);
	// line 7
	lines_by_self_id[7].push_back(7);
	lines_by_self_id[7].push_back(4);
	// line 8
	lines_by_self_id[8].push_back(4);
	lines_by_self_id[8].push_back(0);
	// line 9
	lines_by_self_id[9].push_back(5);
	lines_by_self_id[9].push_back(1);
	// line 10
	lines_by_self_id[10].push_back(6);
	lines_by_self_id[10].push_back(2);
	// line 11
	lines_by_self_id[11].push_back(7);
	lines_by_self_id[11].push_back(3);  

    return lines_by_self_id;    
}

AABB* UnionAABB(AABB* idata1, AABB* idata2)
{
	AABB* odata= new AABB();
	odata->bmin_.x= idata1->bmin_.x < idata2->bmin_.x ? idata1->bmin_.x : idata2->bmin_.x;
	odata->bmin_.y= idata1->bmin_.y < idata2->bmin_.y ? idata1->bmin_.y : idata2->bmin_.y;
	odata->bmin_.z= idata1->bmin_.z < idata2->bmin_.z ? idata1->bmin_.z : idata2->bmin_.z;

	odata->bmax_.x= idata1->bmax_.x > idata2->bmax_.x ? idata1->bmax_.x : idata2->bmax_.x;
	odata->bmax_.y= idata1->bmax_.y > idata2->bmax_.y ? idata1->bmax_.y : idata2->bmax_.y;
	odata->bmax_.z= idata1->bmax_.z > idata2->bmax_.z ? idata1->bmax_.z : idata2->bmax_.z;
	return odata;
}




/*****************************************************************
 * Plane
******************************************************************/
Plane::Plane(V3 P1, V3 P2, V3 P3)
{
	A_ = (P2.y - P1.y)*(P3.z - P1.z) - (P3.y - P1.y)*(P2.z - P1.z);
	B_ = (P2.z - P1.z)*(P3.x - P1.x) - (P3.z - P1.z)*(P2.x - P1.x);
	C_ = (P2.x - P1.x)*(P3.y - P1.y) - (P3.x - P1.x)*(P2.y - P1.y);
	D_ = -A_ * P1.x - B_ * P1.y - C_ * P1.z;
}

Plane::Plane(V3 pt_on_plane, V3 normal)
{
	normal.Normalize();
	A_=normal.x;
	B_=normal.y;
	C_=normal.z;
	D_=-(A_*pt_on_plane.x+B_*pt_on_plane.y+C_*pt_on_plane.z);
}

Plane::Plane(vector<vector<float>> pts)
{		
	MatrixXf P(3,3);
	MatrixXf b(3,1);
	for(int i=0; i<pts.size(); i++){
		P(0,0)=P(0,0)+pts[i][0]*pts[i][0];
		P(0,1)=P(0,1)+pts[i][0]*pts[i][1];
		P(0,2)=P(0,2)+pts[i][0];
		P(1,0)=P(0,1);
		P(1,1)=P(1,1)+pts[i][1]*pts[i][1];
		P(1,2)=P(1,2)+pts[i][1];
		P(2,0) = P(0,2);
		P(2,1) = P(1,2);
		P(2,2) = pts.size();

		b(0,0)=b(0,0)+pts[i][0]*pts[i][2];
    	b(1,0)=b(1,0)+pts[i][1]*pts[i][2];
    	b(2,0)=b(2,0)+pts[i][2];
	} 

	MatrixXf X=P.inverse()*b;
	A_=X(0,0);
	B_=X(1,0);
	C_=-1;
	D_=X(2,0);

	// float nrm=sqrt(A_*A_+B_*B_+C_*C_);
	// A_=A_/nrm;
	// B_=B_/nrm;
	// C_=C_/nrm;
	// D_=D_/nrm;
}

V3 Plane::IsIntersect(Ray& dat)
{
	float t = -(A_*dat.origin_.x + B_ * dat.origin_.y + C_ * dat.origin_.z + D_) / (A_*dat.direction_.x + B_ * dat.direction_.y + C_ * dat.direction_.z);
	return V3(dat.direction_.x * t + dat.origin_.x, dat.direction_.y * t + dat.origin_.y, dat.direction_.z * t + dat.origin_.z);
}

float Plane::Apply(float x, float y)
{
	return (A_*x+B_*y+D_)/(-C_);
}

tuple<int,vector<float>> Triangle::IsIntersect(Ray ry)
{
	float kEpsilon=0.0000000001;
	float t;
	V3 itsc;

	// compute plane's normal
    V3 v0_1 = vtx_[1] - vtx_[0]; 
    V3 v0_2 = vtx_[2] - vtx_[0]; 

    // no need to normalize
    V3 N = v0_1.Cross(v0_2);  //N 
    float area2 = N.GetLength(); 
 
    /*********************************************************** 
	 * Step 1: finding P 
	 * *********************************************************/
    // check if ray and plane are parallel ?
    float NdotRayDirection = N.Dot(ry.direction_); 
    if (fabs(NdotRayDirection) < kEpsilon)  //almost 0 
		return make_tuple(0,itsc.ToFloat());  //they are parallel so they don't intersect !         
 
    // compute d parameter using equation 2
    float d = -N.Dot(vtx_[0]); 
 
    // compute t (equation 3)
    t = -(N.Dot(ry.origin_) + d) / NdotRayDirection; 
	itsc=ry.origin_+t*ry.direction_;

 
    // check if the triangle is in behind the ray
    if (t < 0) return make_tuple(0, itsc.ToFloat());  //the triangle is behind 
 
    // compute the intersection point using equation 1
    V3 P = ry.origin_ + t * ry.direction_; 
 

    /*************************************************************
	 *  Step 2: inside-outside test
	 * ***********************************************************/
    V3 C;  //vector perpendicular to triangle's plane 
 
    // edge 0
    V3 edge0 = vtx_[1] - vtx_[0]; 
    V3 vp0 = P - vtx_[0]; 
    C = edge0.Cross(vp0); 
    if (N.Dot(C) < 0) return make_tuple(0, itsc.ToFloat());  //P is on the right side 
 
    // edge 1
    V3 edge1 = vtx_[2] - vtx_[1]; 
    V3 vp1 = P - vtx_[1]; 
    C = edge1.Cross(vp1); 
    if (N.Dot(C) < 0)  return make_tuple(0, itsc.ToFloat());  //P is on the right side 
 
    // edge 2
    V3 edge2 = vtx_[0] - vtx_[2]; 
    V3 vp2 = P - vtx_[2]; 
    C = edge2.Cross(vp2); 
    if (N.Dot(C) < 0) return make_tuple(0, itsc.ToFloat());  //P is on the right side; 
 
    return make_tuple(1, itsc.ToFloat());  //this ray hits the triangle 
}

tuple<bool,vector<float>> LineSegment::IsIntersect(Triangle ob)
{
	auto [whether, itsc]=ob.IsIntersect(*this);
	return make_tuple(whether, itsc);
}


/************************************************************************************
 * 							Triangle
 ************************************************************************************/
Triangle::Triangle(V3 v0, V3 v1, V3 v2){
	vtx_[0]=v0;
	vtx_[1]=v1;
	vtx_[2]=v2;
}
Triangle::Triangle(vector<vector<float>> pts){
	vtx_[0]=V3(pts[0]);
	vtx_[1]=V3(pts[1]);
	vtx_[2]=V3(pts[2]);
}
Triangle Triangle::operator=(Triangle dat){
	vtx_[0]=dat.vtx_[0];
	vtx_[1]=dat.vtx_[1];
	vtx_[2]=dat.vtx_[2];
	return *this;
}
tuple<bool,vector<float>> Triangle::IsIntersect(LineSegment lseg)
{
	float kEpsilon=0.0000000001;
	float t;
	bool whether_intersect;
	V3 itsc;

	// compute plane's normal
    V3 v0_1 = vtx_[1] - vtx_[0]; 
    V3 v0_2 = vtx_[2] - vtx_[0]; 

    // no need to normalize
    V3 N = v0_1.Cross(v0_2);  //N 
    float area2 = N.GetLength(); 
 
    /*********************************************************** 
	 * Step 1: finding P 
	 * *********************************************************/
    // check if ray and plane are parallel ?
    float NdotRayDirection = N.Dot(lseg.direction_); 
    if (fabs(NdotRayDirection) < kEpsilon)  //almost 0 
		return make_tuple(false,itsc.ToFloat());  //they are parallel so they don't intersect !         
 
    // compute d parameter using equation 2
    float d = -N.Dot(vtx_[0]); 
 
    // compute t (equation 3)
    t = -(N.Dot(lseg.origin_) + d) / NdotRayDirection; 
	itsc=lseg.origin_+t*lseg.direction_;

	// check if the triangle is out of range
	if(t> lseg.t_o2e_)
		return make_tuple(false, itsc.ToFloat());

    // check if the triangle is in behind the ray
    if (t < 0) return make_tuple(false, itsc.ToFloat());  //the triangle is behind 
 
    // compute the intersection point using equation 1
    V3 P = lseg.origin_ + t * lseg.direction_; 
 

    /*************************************************************
	 *  Step 2: inside-outside test
	 * ***********************************************************/
    V3 C;  //vector perpendicular to triangle's plane 
 
    // edge 0
    V3 edge0 = vtx_[1] - vtx_[0]; 
    V3 vp0 = P - vtx_[0]; 
    C = edge0.Cross(vp0); 
	if(N.Dot(C)< 0){
		return make_tuple(false, itsc.ToFloat());  //P is on the right side 
	} 
 
    // edge 1
    V3 edge1 = vtx_[2] - vtx_[1]; 
    V3 vp1 = P - vtx_[1]; 
    C = edge1.Cross(vp1); 
    if(N.Dot(C)< 0){
		 return make_tuple(false, itsc.ToFloat());  //P is on the right side 
	}
 
    // edge 2
    V3 edge2 = vtx_[0] - vtx_[2]; 
    V3 vp2 = P - vtx_[2]; 
    C = edge2.Cross(vp2); 
    if(N.Dot(C)< 0){
		return make_tuple(false, itsc.ToFloat());  //P is on the right side; 
	}
 
    return make_tuple(true, itsc.ToFloat());  //this ray hits the triangle 
}

/**
 * @brief 
 * 
 * @param pts 
 * @param fid 
 * @return （bool) is intersect, (int) number of intersect points
 */
tuple<bool,int> LineSegment::IsIntersect(vector<vector<float>> pts, vector<vector<int>> fid)
{
	int count=0;
	vector<Triangle> tri;
	for(int i=0;i<fid.size(); i++){
		V3 v1=V3(pts[fid[i][0]][0],pts[fid[i][0]][1],pts[fid[i][0]][2]);
		V3 v2=V3(pts[fid[i][1]][0],pts[fid[i][1]][1],pts[fid[i][1]][2]);
		V3 v3=V3(pts[fid[i][2]][0],pts[fid[i][2]][1],pts[fid[i][2]][2]);
		Triangle tri_tmp(v1,v2,v3);

		// OBJManager scene_tri;
		// scene_tri.AddMesh(tri_tmp);
		// scene_tri.SaveOBJ("/home/i9/experiment_nc/scene_tri.obj");

		// ofstream fout("/home/i9/experiment_nc/scene_tri.obj");
		// fout<<"v "<<v1.x<<" "<< v1.y<<" "<< v1.z<<endl;
		// fout<<"v "<<v2.x<<" "<< v2.y<<" "<< v2.z<<endl;
		// fout<<"v "<<v3.x<<" "<< v3.y<<" "<< v3.z<<endl;
		// fout<<"f 1 2 3"<<endl;
		// fout.close();

		auto [whether, itsc]=this->IsIntersect(tri_tmp);
		if(whether==true)
			count++;
		tri.push_back(tri_tmp);
	}

	if(count==0)
		return make_tuple(false, count);
	else 
		return make_tuple(true, count);
}


/*******************************************************************************************
 * XOY Polynomial fitting
 * *****************************************************************************************/
void Poly33Fitting::Fit(vector<vector<float>> pts)
{
    pts_=pts;
    Eigen::MatrixXd dat(pts.size(), pts[0].size());
    Eigen::MatrixXd b(pts.size(),1);
    Eigen::MatrixXd A(pts.size(),10);
    for(int i=0; i<pts.size(); i++){
        float x=pts[i][0];
        float y=pts[i][1];
        float z=pts[i][2];
        for(int j=0; j< pts[i].size(); j++){
            dat(i,j)=pts[i][j];
        }
        b(i,0)=pts[i][2];

        A(i,0)=1;
        A(i,1)=x;
        A(i,2)=y;
        A(i,3)=x*x;
        A(i,4)=x*y;
        A(i,5)=y*y;
        A(i,6)=x*x*x;
        A(i,7)=x*x*y;
        A(i,8)=x*y*y;
        A(i,9)=y*y*y;
    }
    
    Eigen::MatrixXd P= (A.transpose()*A).inverse()*A.transpose()*b;
    p00=P(0,0);
	p10=P(1,0);
	p01=P(2,0);
	p20=P(3,0);
	p11=P(4,0);
	p02=P(5,0);
	p30=P(6,0);
	p21=P(7,0);
	p12=P(8,0);
	p03=P(9,0);
}

int Poly33Fitting::IsIntersect(Ray ry)
{
	float xo=ry.origin_.x;
	float yo=ry.origin_.y;
	float zo=ry.origin_.z;
	float xd=ry.direction_.x;
	float yd=ry.direction_.y;
	float zd=ry.direction_.z;
	
	float a=p30*pow(xd,3) + p21*pow(xd,2)*yd  + p12*xd*pow(yd,2)   + p03*pow(yd,3);
	float b=3*p30*xo*pow(xd,2) + 2*p21*xo*xd*yd  + p12*xo*pow(yd,2) + p21*yo*pow(xd,2) + 2*p12*yo*xd*yd  + 3*p03*yo*pow(yd,2) + p20*pow(xd,2) + p11*xd*yd + p02*pow(yd,2);
	float c=3*p30*pow(xo,2)*xd + p21*pow(xo,2)*yd + 2*p21*xo*yo*xd + 2*p12*xo*yo*yd  + 2*p20*xo*xd+ p11*xo*yd+ p12*pow(yo,2)*xd + 3*p03*pow(yo,2)*yd 
			+ p11*yo*xd+ 2*p02*yo*yd+ p10*xd+ p01*yd -zd;
	float d=p30*pow(xo,3) + p21*pow(xo,2)*yo + p20*pow(xo,2) + p12*xo*pow(yo,2) + p11*xo*yo+ p10*xo + p03*pow(yo,3)+ p02*pow(yo,2)+ p01*yo+ p00 -zo;
	
	float A=pow(b,2)-3*a*c;
	float B=b*c-9*a*d;
	float C=pow(c,2)-3*b*d;
	float delta=B*B-4*A*C;

	if(A==B && A==0)
		return 3;
	else if(delta>0)
		return 1;
	else if(delta==0)
		return 3;
	else if(delta<0)
		return 3;
}


/*******************************************************************************************
 * Poly22 Fitting
 * *****************************************************************************************/

Poly22Fitting::Poly22Fitting(vector<AABB*> range)
{
	range_=range;

	bb_=new AABB(V3(INT_MAX,INT_MAX,INT_MAX),V3(-INT_MAX, -INT_MAX, -INT_MAX));
	for(int i=0; i< range.size(); i++)
		bb_=UnionAABB(bb_, range[i]); 
}

void Poly22Fitting::Fit(vector<vector<float>> pts)
{
	pts_=pts;
	
	/* obtain the rotation matrix from normal to z-axis */
	MatrixXd D(pts.size(), 3);
	for(int i=0; i< pts.size(); i++){
		D(i,0)=pts[i][0];
		D(i,1)=pts[i][1];
		D(i,2)=pts[i][2];
	}

	/* obtain coffes */
    Eigen::MatrixXd dat(pts.size(), pts[0].size());
    Eigen::MatrixXd b(pts.size(),1);
    Eigen::MatrixXd A(pts.size(),6);
    for(int i=0; i<pts.size(); i++){
        float x=D(i,0);
        float y=D(i,1);
        float z=D(i,2);
        for(int j=0; j< pts[i].size(); j++){
            dat(i,j)=pts[i][j];
        }
        b(i,0)=pts[i][2];

        A(i,0)=1;
        A(i,1)=x;
        A(i,2)=y;
        A(i,3)=x*x;
        A(i,4)=x*y;
        A(i,5)=y*y;
    }
    Eigen::MatrixXd P= (A.transpose()*A).inverse()*A.transpose()*b;
    p00=P(0,0);
	p10=P(1,0);
	p01=P(2,0);
	p20=P(3,0);
	p11=P(4,0);
	p02=P(5,0);
}

void Poly22Fitting::AutoFit(vector<vector<float>> pts)
{
	pts_=pts; // nx3
	
	/* obtain the rotation matrix from normal to z-axis */
	MatrixXd D(pts.size(), 3);
	for(int i=0; i< pts.size(); i++){
		D(i,0)=pts[i][0];
		D(i,1)=pts[i][1];
		D(i,2)=pts[i][2];
	}
	// 重心坐标 (nx3)
	MatrixXd D_bar_repeat_n=MatrixXd::Ones(pts.size(), pts.size())*D;
	D_bar_repeat_n=D_bar_repeat_n/pts.size();
	// C协方差矩阵
	MatrixXd C=(D-D_bar_repeat_n).transpose()*(D-D_bar_repeat_n);
	// 求协方差矩阵的特征值和特征向量
	Eigen::EigenSolver<Eigen::MatrixXd> eigen_solver(C);
	// eigen_solver.eigenvectors().real().col(2) 是最小特征值对应的特征向量，Vector3d(0,0,1) z轴方向
	trans_=Quaterniond::FromTwoVectors(eigen_solver.eigenvectors().real().col(2), Vector3d(0,0,1));
	MatrixXd D_tranpose=D.transpose();	
	MatrixXd D_trans=trans_.toRotationMatrix()*D_tranpose;
	MatrixXd D_trans_transpose=D_trans.transpose();

	/* obtain coffes */
    Eigen::MatrixXd dat(pts.size(), pts[0].size());
    Eigen::MatrixXd b(pts.size(),1);
    Eigen::MatrixXd A(pts.size(),6);
    for(int i=0; i<pts.size(); i++){
        float x=D_trans_transpose(i,0);
        float y=D_trans_transpose(i,1);
        float z=D_trans_transpose(i,2);
        for(int j=0; j< pts[i].size(); j++){
            dat(i,j)=pts[i][j];
        }
        b(i,0)=pts[i][2];

        A(i,0)=1;
        A(i,1)=x;
        A(i,2)=y;
        A(i,3)=x*x;
        A(i,4)=x*y;
        A(i,5)=y*y;
    }
    Eigen::MatrixXd P= (A.transpose()*A).inverse()*A.transpose()*b;
    p00=P(0,0);
	p10=P(1,0);
	p01=P(2,0);
	p20=P(3,0);
	p11=P(4,0);
	p02=P(5,0);

	T_=trans_.toRotationMatrix();
}

int Poly22Fitting::IsIntersect(Ray ry)
{
	/* tansform origin and direction */
	Vector3d o=Vector3d(ry.origin_.x, ry.origin_.y, ry.origin_.z);
	Vector3d d= Vector3d(ry.direction_.x, ry.direction_.y, ry.direction_.z);
	Vector3d e= o+d;
	Vector3d o_trans= trans_.toRotationMatrix() * o;
	Vector3d e_trans= trans_.toRotationMatrix() * e;
	Vector3d d_trans= (e_trans-o_trans).normalized();


	float xo=o_trans(0);
	float yo=o_trans(1);
	float zo=o_trans(2);
	float xd=d_trans(0);
	float yd=d_trans(1);
	float zd=d_trans(2);




	float a=p20*pow(xd,2) + p11*xd*yd + p02*pow(yd,2);
	float b=2*p20*xd*xo + p11*xd*yo + p10*xd + p11*xo*yd + 2*p02*yd*yo + p01*yd - zd;
	float c=p20*pow(xo,2) + p11*xo*yo + p10*xo + p02*pow(yo,2) + p01*yo + p00 - zo;
	float delta= b*b-4*a*c;
	if(delta<=0)
		return 0;
	
	float t1=(sqrt(delta)-b)/(2*a);
	float t2=(-sqrt(delta)-b)/(2*a);

	float itsc1_x=xo+t1*xd;
	float itsc1_y=yo+t1*yd;
	float itsc1_z=zo+t1*zd;
	Vector3d itsc1_invert_trans= trans_.conjugate().toRotationMatrix()*Vector3d(itsc1_x, itsc1_y, itsc1_z);
	bool is_in_bb_1=IsWithin(itsc1_invert_trans(0), itsc1_invert_trans(1), itsc1_invert_trans(2));

	float itsc2_x=xo+t2*xd;
	float itsc2_y=yo+t2*yd;
	float itsc2_z=zo+t2*zd;
	Vector3d itsc2_invert_trans= trans_.conjugate().toRotationMatrix()* Vector3d(itsc2_x, itsc2_y, itsc2_z);
	bool is_in_bb_2=IsWithin(itsc2_invert_trans(0), itsc2_invert_trans(1), itsc2_invert_trans(2));

	
	if(t1>0 && t2>0){
		if(is_in_bb_1==true && is_in_bb_2==true)
			return 2;
		else if(is_in_bb_1==false && is_in_bb_2==false)
			return 0;
		else 
			return 1;
	}		
	else if(t1>0 && t2<0){
		if(is_in_bb_1==true)
			return 1;
		else 
			return 0;
	}		
	else if(t1<0 && t2>0){
		if(is_in_bb_2==true)
			return 1;
		else 
			return 0;
	}
	else 
		return 0;
}

bool Poly22Fitting::IsWithin(float x, float y, float z)
{
	int count=0;
	for(int i=0; i<range_.size(); i++){
		if(range_[i]->IsWithin(x,y,z)==true){
			count++;
		}
	}

	if(count==1)
		return true;
	else if(count==0)
		return false;
	else{
		cout<<"Error: more than one!"<<endl;
		return true;
	}
}

tuple<int, float, float> Poly2Solve(float a, float b, float c)
{
	int num_of_real_root=0;
	float root1,root2;
	float delta=b*b -4*a*c;
	if(delta<0){
		num_of_real_root=0;
	}
	else if(delta==0){
		num_of_real_root=1;
		root1=root2= - b/(2*a);		
	}
	else{
		num_of_real_root=2;
		float sqrt_delta=sqrt(delta);
		root1=(-b-sqrt_delta)/(2*a);
		root2=(-b+sqrt_delta)/(2*a);
	}
	return make_tuple(num_of_real_root, root1, root2);
}

void Poly22Fitting::GenerateMesh(string path)
{
	// step 02: obtain span in xyz axis
	float num=30;
	float xspan=(bb_->bmax_.x -bb_->bmin_.x)/num;
	float yspan=(bb_->bmax_.y -bb_->bmin_.y)/num;
	float zspan=(bb_->bmax_.z -bb_->bmin_.z)/num;

	// step 03: obtain some points on the surfaces
	vector<float> xi,yi;
	float start_x=bb_->bmin_.x-(3*xspan);
	float start_y=bb_->bmin_.y-(3*yspan);
	for(int i=0; start_x + i*xspan < bb_->bmax_.x+3*xspan; i++){
		xi.push_back(start_x + i*xspan);
		yi.push_back(start_y + i*yspan);
	}
	vector<vector<float>> zi(xi.size(), vector<float>(xi.size()));
	vector<vector<float>> new_pts;
	for(int i=0;i<xi.size(); i++){
		for(int j=0; j< yi.size(); j++){
			vector<float> pts_tmp(3);
			zi[i][j]=Apply(xi[i],yi[j]);
			pts_tmp[0]=xi[i];
			pts_tmp[1]=yi[j];
			pts_tmp[2]=zi[i][j];
			new_pts.push_back(pts_tmp);
		}
	}

	OBJManager scene_surface;
	scene_surface.AddPoints(new_pts);
	scene_surface.SaveOBJ(path);
}

void Poly22Fitting::GenerateAutoMesh(string path)
{
	// step 02: obtain span in xyz axis
	float num=30;
	float xspan=(bb_->bmax_.x -bb_->bmin_.x)/num;
	float yspan=(bb_->bmax_.y -bb_->bmin_.y)/num;
	float zspan=(bb_->bmax_.z -bb_->bmin_.z)/num;

	// step 03: obtain some points on the surfaces
	vector<float> xi,yi;
	float start_x=bb_->bmin_.x-(3*xspan);
	float start_y=bb_->bmin_.y-(3*yspan);
	for(int i=0; start_x + i*xspan < bb_->bmax_.x+3*xspan; i++){
		xi.push_back(start_x + i*xspan);
		yi.push_back(start_y + i*yspan);
	}
	vector<vector<float>> zi(xi.size(), vector<float>(xi.size()));
	vector<vector<float>> new_pts;
	for(int i=0;i<xi.size(); i++){
		for(int j=0; j< yi.size(); j++){
			vector<float> pts_tmp;
			auto [num_of_root, root1, root2]=AutoApply(xi[i],yi[j]);

			if(num_of_root==1){
				pts_tmp.push_back(xi[i]);
				pts_tmp.push_back(yi[j]);
				pts_tmp.push_back(root1);
				new_pts.push_back(pts_tmp);
			}
			else if(num_of_root==2){
				pts_tmp.push_back(xi[i]);
				pts_tmp.push_back(yi[j]);
				pts_tmp.push_back(root1);

				pts_tmp.push_back(xi[i]);
				pts_tmp.push_back(yi[j]);
				pts_tmp.push_back(root2);

				new_pts.push_back(pts_tmp);
			}			
		}
	}

	OBJManager scene_surface;
	scene_surface.AddPoints(new_pts);
	scene_surface.SaveOBJ(path);
}

float Poly22Fitting::Apply(float x, float y)
{
	return (p00 + p10*x + p01*y + p20*x*x + p02*y*y +p11*x*y);
}

tuple<int, float, float> Poly22Fitting::AutoApply(float x, float y)
{
	float a= p20*T_(0,2)*T_(0,2) + p11* T_(0,2)* T_(1,2) + p02*T_(1,2)*T_(1,2);
	float b= p10*T_(0,2) + p01*T_(1,2) + 2* p20*T_(0,2)*(T_(0,0)*x+T_(0,1)*y) 
			 + p11*((T_(0,0)*x+T_(0,1)*y)*T_(1,2)+(T_(1,0)*x+T_(1,1)*y)*T_(0,2)) + 2*p02*T_(1,2)*(T_(1,0)*x+T_(1,1)*y) -T_(2,2);

	float c=p00 + p10*(T_(0,0)*x+T_(0,1)*y) + p01*(T_(1,0)*x+T_(1,1)*y) + p20*(T_(0,0)*x+T_(0,1)*y)*(T_(0,0)*x+T_(0,1)*y) +
			p11*(T_(0,0)*x+T_(0,1)*y)*(T_(1,0)*x+T_(1,1)*y) + p02*(T_(1,0)*x + T_(1,1)*y)*(T_(1,0)*x + T_(1,1)*y) - (T_(2,0)*x+T_(2,1)*y);
	
	auto [num_of_root, root1, root2]= Poly2Solve(a,b,c);
	return make_tuple(num_of_root, root1, root2);
}


/****************************************************************************
 * 	OBJManager Geometric Extend
 * **************************************************************************/
OBJManagerGeometricEx::OBJManagerGeometricEx(Triangle tri)
{
    vector<int> face;

    vtx_.push_back(tri.vtx_[0].ToFloat());
    face.push_back(vtx_.size()-1);

    vtx_.push_back(tri.vtx_[1].ToFloat());
    face.push_back(vtx_.size()-1);

    vtx_.push_back(tri.vtx_[2].ToFloat());
    face.push_back(vtx_.size()-1);

    faces_.push_back(face);
}

OBJManagerGeometricEx::OBJManagerGeometricEx(Ray ry)
{
    vector<int> line;
    vtx_.push_back(ry.origin_.ToFloat());
    line.push_back(vtx_.size()-1);

    vtx_.push_back((ry.origin_+ry.direction_).ToFloat());
    line.push_back(vtx_.size()-1); 

    lines_.push_back(line);
}

OBJManagerGeometricEx::OBJManagerGeometricEx(LineSegment lsg)
{
    vector<int> line;
    vtx_.push_back(lsg.origin_.ToFloat());
    line.push_back(vtx_.size()-1);

    vtx_.push_back(lsg.end_.ToFloat());
    line.push_back(vtx_.size()-1); 

    lines_.push_back(line);
}

void OBJManagerGeometricEx::AddMesh(Triangle& tri)
{
    vector<int> f;
    vtx_.push_back(tri.vtx_[0].ToFloat());
    f.push_back(vtx_.size()-1);
    vtx_.push_back(tri.vtx_[1].ToFloat());
    f.push_back(vtx_.size()-1);
    vtx_.push_back(tri.vtx_[2].ToFloat());
    f.push_back(vtx_.size()-1);
    faces_.push_back(f);
}

void OBJManagerGeometricEx::AddMesh(vector<vector<float>> pts, vector<vector<int>> faces)
{
	for(int i=0; i<faces.size(); i++){
		for(int j=0; j<faces[i].size(); j++){
			faces[i][j]+=vtx_.size();
		}
	}

	vtx_.insert(vtx_.end(), pts.begin(), pts.end());
	faces_.insert(faces_.end(), faces.begin(), faces.end());
}

void OBJManagerGeometricEx::AddLineSegment(LineSegment lg)
{
    vector<int> line;
    vtx_.push_back(lg.origin_.ToFloat());
    line.push_back(vtx_.size()-1);
    vtx_.push_back(lg.end_.ToFloat());
    line.push_back(vtx_.size()-1);
    lines_.push_back(line);
}

void OBJManagerGeometricEx::AddBox(AABB* bb)
{
	vector<vector<float>> corners=bb->GenerateEightCorners();
	vector<vector<int>>   line_by_self_id=bb->GenerateSelfLines();
	int base=vtx_.size();
	for(int i=0; i<line_by_self_id.size(); i++){
		for(int j=0; j<line_by_self_id[i].size(); j++){
			line_by_self_id[i][j]+=base;
		}
	}
	AddPoints(corners);
	AddLines(line_by_self_id);
}

void OBJManagerGeometricEx::AddPlane(Plane pl, AABB* bb)
{
	// step 02: obtain span in xyz axis
	float num=30;
	float xspan=(bb->bmax_.x -bb->bmin_.x)/num;
	float yspan=(bb->bmax_.y -bb->bmin_.y)/num;
	float zspan=(bb->bmax_.z -bb->bmin_.z)/num;

	// step 03: obtain some points on the surfaces
	vector<float> xi,yi;
	float start_x=bb->bmin_.x-(3*xspan);
	float start_y=bb->bmin_.y-(3*yspan);
	for(int i=0; start_x + i*xspan < bb->bmax_.x+3*xspan; i++){
		xi.push_back(start_x + i*xspan);
		yi.push_back(start_y + i*yspan);
	}

	vector<vector<float>> out_pts;
	for(int i=0; i<xi.size(); i++){
		for(int j=0; j<yi.size(); j++){
			float z=pl.Apply(xi[i],yi[j]);

			vector<float> ptmp;
			ptmp.push_back(xi[i]);
			ptmp.push_back(yi[j]);
			ptmp.push_back(z);

			out_pts.push_back(ptmp);
		}
	}
	AddPoints(out_pts);
}

void OBJManagerGeometricEx::AddRay(Ray ry)
{
	AddPoints(ry.origin_.ToFloat2D());
	AddPoints((ry.origin_+2*ry.direction_).ToFloat2D());
	vector<int> tmp(2);
	tmp[0]=vtx_.size()-2;
	tmp[1]=vtx_.size()-1;
	lines_.push_back(tmp);
}