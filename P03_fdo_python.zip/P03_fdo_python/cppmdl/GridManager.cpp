#include "GridManager.h"
int global_cnt=0;

VoxelInfo::VoxelInfo(V3& bmin, V3& bmax, int level){
    bmin_=bmin;
    bmax_=bmax;
    centre_=(bmin_+bmax_)/2.0;
    flag_=UNFLAG;
    level_=level;
    pParent_=NULL;

    // Init Eight corners
    GenerateEightCorners();
}

void VoxelInfo::operator =(VoxelInfo& dat){
    bmin_=dat.bmin_;
    bmax_=dat.bmax_;
    centre_=dat.centre_;
    corners_=dat.corners_;
    id_of_corners_=dat.id_of_corners_;
    lines_by_id_=dat.lines_by_id_;
    faces_by_id_=dat.faces_by_id_;
    pts_idx_=dat.pts_idx_;
    flag_=dat.flag_;
    child_=dat.child_;
    level_=dat.level_;
}


vector<vector<int>> VoxelInfo::GenerateLines(){
    if(id_of_corners_.size()>0){
        lines_by_id_.resize(12);
        // line 0
        lines_by_id_[0].push_back(id_of_corners_[0]);
        lines_by_id_[0].push_back(id_of_corners_[1]);
        // line 1
        lines_by_id_[1].push_back(id_of_corners_[1]);
        lines_by_id_[1].push_back(id_of_corners_[2]);
        // line 2
        lines_by_id_[2].push_back(id_of_corners_[2]);
        lines_by_id_[2].push_back(id_of_corners_[3]);
        // line 3
        lines_by_id_[3].push_back(id_of_corners_[3]);
        lines_by_id_[3].push_back(id_of_corners_[0]);
        // line 4
        lines_by_id_[4].push_back(id_of_corners_[4]);
        lines_by_id_[4].push_back(id_of_corners_[5]);
        // line 5
        lines_by_id_[5].push_back(id_of_corners_[5]);
        lines_by_id_[5].push_back(id_of_corners_[6]);
        // line 6
        lines_by_id_[6].push_back(id_of_corners_[6]);
        lines_by_id_[6].push_back(id_of_corners_[7]);
        // line 7
        lines_by_id_[7].push_back(id_of_corners_[7]);
        lines_by_id_[7].push_back(id_of_corners_[4]);
        // line 8
        lines_by_id_[8].push_back(id_of_corners_[4]);
        lines_by_id_[8].push_back(id_of_corners_[0]);
        // line 9
        lines_by_id_[9].push_back(id_of_corners_[5]);
        lines_by_id_[9].push_back(id_of_corners_[1]);
        // line 10
        lines_by_id_[10].push_back(id_of_corners_[6]);
        lines_by_id_[10].push_back(id_of_corners_[2]);
        // line 11
        lines_by_id_[11].push_back(id_of_corners_[7]);
        lines_by_id_[11].push_back(id_of_corners_[3]);
    }
    else
        cout<<"Error: you should get id of corners at first, please call GenerateEightCorners()!"<<endl;  

    return lines_by_id_;    
}

vector<vector<int>> VoxelInfo::GenerateFaces(){
    if(id_of_corners_.size()>0){
        faces_by_id_.resize(12);
        // triangle 0
        faces_by_id_[0].push_back(id_of_corners_[0]);
        faces_by_id_[0].push_back(id_of_corners_[1]);
        faces_by_id_[0].push_back(id_of_corners_[5]);
        // triangle 1
        faces_by_id_[1].push_back(id_of_corners_[0]);
        faces_by_id_[1].push_back(id_of_corners_[5]);
        faces_by_id_[1].push_back(id_of_corners_[4]);
        // triangle 2
        faces_by_id_[2].push_back(id_of_corners_[0]);
        faces_by_id_[2].push_back(id_of_corners_[1]);
        faces_by_id_[2].push_back(id_of_corners_[3]);
        // triangle 3
        faces_by_id_[3].push_back(id_of_corners_[0]);
        faces_by_id_[3].push_back(id_of_corners_[3]);
        faces_by_id_[3].push_back(id_of_corners_[2]);
        // triangle 4
        faces_by_id_[4].push_back(id_of_corners_[5]);
        faces_by_id_[4].push_back(id_of_corners_[1]);
        faces_by_id_[4].push_back(id_of_corners_[3]);
        // triangle 5
        faces_by_id_[5].push_back(id_of_corners_[5]);
        faces_by_id_[5].push_back(id_of_corners_[3]);
        faces_by_id_[5].push_back(id_of_corners_[7]);
        // triangle 6
        faces_by_id_[6].push_back(id_of_corners_[4]);
        faces_by_id_[6].push_back(id_of_corners_[5]);
        faces_by_id_[6].push_back(id_of_corners_[7]);
        // triangle 7
        faces_by_id_[7].push_back(id_of_corners_[4]);
        faces_by_id_[7].push_back(id_of_corners_[7]);
        faces_by_id_[7].push_back(id_of_corners_[6]);
        // triangle 8
        faces_by_id_[8].push_back(id_of_corners_[4]);
        faces_by_id_[8].push_back(id_of_corners_[0]);
        faces_by_id_[8].push_back(id_of_corners_[2]);
        // triangle 9
        faces_by_id_[9].push_back(id_of_corners_[4]);
        faces_by_id_[9].push_back(id_of_corners_[2]);
        faces_by_id_[9].push_back(id_of_corners_[6]);
            // triangle 10
        faces_by_id_[10].push_back(id_of_corners_[6]);
        faces_by_id_[10].push_back(id_of_corners_[7]);
        faces_by_id_[10].push_back(id_of_corners_[3]);
        // triangle 11
        faces_by_id_[11].push_back(id_of_corners_[6]);
        faces_by_id_[11].push_back(id_of_corners_[3]);
        faces_by_id_[11].push_back(id_of_corners_[2]);
    }
    else
        cout<<"Error: you should get id of corners at first, please call GenerateEightCorners()!"<<endl;     

    return faces_by_id_;   
}




vector<vector<float>> VoxelInfo::GenerateTwelveMiddlePoints()
{
    int map[12][2]={{0,1},{1,2},{2,3},{0,3},{4,5},{5,6},{6,7},{4,7},{0,4},{1,5},{2,6},{3,7}};
    vector<vector<float>> e(12, vector<float>(3));
    for(int i=0; i < e.size(); i++){
        e[i][0]=(corners_[map[i][0]][0] + corners_[map[i][1]][0])/2.0;
        e[i][1]=(corners_[map[i][0]][1] + corners_[map[i][1]][1])/2.0;
        e[i][2]=(corners_[map[i][0]][2] + corners_[map[i][1]][2])/2.0;
    }
    return e;
}

VoxelInfo* UnionVoxel(VoxelInfo* idata1, VoxelInfo* idata2)
{
    VoxelInfo* odata= new VoxelInfo();
    odata->bmax_.x= idata1->bmax_.x > idata2->bmax_.x ? idata1->bmax_.x : idata2->bmax_.x;
    odata->bmax_.y= idata1->bmax_.y > idata2->bmax_.y ? idata1->bmax_.y : idata2->bmax_.y;
    odata->bmax_.z= idata1->bmax_.z > idata2->bmax_.z ? idata1->bmax_.z : idata2->bmax_.z;

    odata->bmin_.x= idata1->bmin_.x < idata2->bmin_.x ? idata1->bmin_.x : idata2->bmin_.x;
    odata->bmin_.y= idata1->bmin_.y < idata2->bmin_.y ? idata1->bmin_.y : idata2->bmin_.y;
    odata->bmin_.z= idata1->bmin_.z < idata2->bmin_.z ? idata1->bmin_.z : idata2->bmin_.z;
    return odata;
}


std::tuple<vector<float>, vector<float>, vector<float>> BaseVoxelsManager::GetCell(int level, int idx){
    vector<float> bmin(3),bmax(3), centre(3);
    if(level< depth_){
        bmin[0]=dat_[level][idx]->bmin_.x;
        bmin[1]=dat_[level][idx]->bmin_.y;
        bmin[2]=dat_[level][idx]->bmin_.z;

        bmax[0]=dat_[level][idx]->bmax_.x;
        bmax[1]=dat_[level][idx]->bmax_.y;
        bmax[2]=dat_[level][idx]->bmax_.z;

        centre[0]=dat_[level][idx]->centre_.x;
        centre[1]=dat_[level][idx]->centre_.y;
        centre[2]=dat_[level][idx]->centre_.z;
    }
    else{
        cout<<"Level out of range!"<<endl;
    }
    return std::make_tuple(bmin,bmax,centre);
}

void BaseVoxelsManager::CorrectBoxMinMax(V3& dmin, V3& dmax){
    float tmp=0;
    if(dmin.x>dmax.x){
        tmp=dmin.x;
        dmin.x=dmax.x;
        dmax.x=tmp;
    }
    if(dmin.y>dmax.y){
        tmp=dmin.y;
        dmin.y=dmax.y;
        dmax.y=tmp;
    }
    if(dmin.z>dmax.z){
        tmp=dmin.z;
        dmin.z=dmax.z;
        dmax.z=tmp;
    }
}

void BaseVoxelsManager::CreateRepCloud(){
    
    // create cloud for cells
    cloud_on_and_off_ = pcl::PointCloud<PointType>::Ptr(new pcl::PointCloud<PointType>());

    // make sure cells have been established
    if(dat_.size()>0){                  
        for(int i=0;i<dat_[depth_-1].size();i++){
            cloud_on_and_off_->points.push_back(PointType(dat_[depth_-1][i]->centre_.x, dat_[depth_-1][i]->centre_.y, dat_[depth_-1][i]->centre_.z));
        }               
    }
    else 
        cout<<"Error: cells should be established at first, please call Create() function."<<endl;   

    kdtree_on_and_off_=pcl::search::KdTree<PointType>::Ptr(new pcl::search::KdTree<PointType>);        
    kdtree_on_and_off_->setInputCloud(cloud_on_and_off_);
}

void BaseVoxelsManager::CreateCloudOnAndOff()
{
    // make sure cells have been established
    if(dat_.size()==0){ 
        cout<<"Error: cells should be established at first, please call Create() function."<<endl;  
         return;
    }
    if(cloud_on_==NULL){
        cloud_on_ = pcl::PointCloud<PointType>::Ptr(new pcl::PointCloud<PointType>());
        kdtree_on_=pcl::search::KdTree<PointType>::Ptr(new pcl::search::KdTree<PointType>);
        for(int i=0;i<dat_[depth_-1].size();i++){
            if(dat_[depth_-1][i]->pts_idx_.size()>0){
                cloud_on_->points.push_back(PointType(dat_[depth_-1][i]->centre_.x,dat_[depth_-1][i]->centre_.y,dat_[depth_-1][i]->centre_.z));
            }
        }        
        kdtree_on_->setInputCloud(cloud_on_);
    }

    if(cloud_off_==NULL){
        cloud_off_ = pcl::PointCloud<PointType>::Ptr(new pcl::PointCloud<PointType>());            
        kdtree_off_=pcl::search::KdTree<PointType>::Ptr(new pcl::search::KdTree<PointType>);
        for(int i=0;i<dat_[depth_-1].size();i++){
            if(dat_[depth_-1][i]->pts_idx_.size()==0){
                cloud_off_->points.push_back(PointType(dat_[depth_-1][i]->centre_.x,dat_[depth_-1][i]->centre_.y,dat_[depth_-1][i]->centre_.z));
            }
        }        
        kdtree_off_->setInputCloud(cloud_off_);   
    } 
    if(cloud_on_and_off_==NULL){
        cloud_on_and_off_=pcl::PointCloud<PointType>::Ptr(new pcl::PointCloud<PointType>());
        kdtree_on_and_off_=pcl::search::KdTree<PointType>::Ptr(new pcl::search::KdTree<PointType>);
        for(int i=0; i<dat_[depth_-1].size(); i++){
            cloud_on_and_off_->points.push_back(PointType(dat_[depth_-1][i]->centre_.x,dat_[depth_-1][i]->centre_.y,dat_[depth_-1][i]->centre_.z));
        }
    }
}

void NaiveVoxels::InitNaiveGrids(vector<float> bmin, vector<float> bmax, int depth)
{
    flag_are_cells_labelled_=0;
    bmin_=V3(bmin);
    bmax_=V3(bmax);

    depth_=depth;
    dat_.resize(depth_);
    CreateNaiveCell(V3(bmin), V3(bmax), 0);    
    CreateRepCloud();
}

std::tuple< vector<vector<float>>,vector<vector<int>>> NaiveVoxels::GetCornersOfNaiveGrids()
{        
    if(x_sequence_.size()>0){
        // generate cloud for all corners
        pcl::PointCloud<PointType>::Ptr cloud(new pcl::PointCloud<PointType>);
        corners_.resize(pow(pow(2,depth_-1)+1,3));
        int a=0;
        for(int k=0;k<z_sequence_.size();k++){
            for(int j=0;j<y_sequence_.size();j++){
                for(int i=0;i<x_sequence_.size();i++){
                    corners_[a].push_back(x_sequence_[i]);
                    corners_[a].push_back(y_sequence_[j]);
                    corners_[a].push_back(z_sequence_[k]);
                    cloud->points.push_back(PointType(x_sequence_[i],y_sequence_[j],z_sequence_[k]));
                    a++;
                }
            }
        }
        
        // update cell corner indices to cellinfo        
        pcl::search::KdTree<PointType>::Ptr kdtree(new pcl::search::KdTree<PointType>());
        kdtree->setInputCloud(cloud);
        for(int i=0;i<dat_[depth_-1].size();i++){
            for(int j=0;j<8;j++){ // eight corners
                vector<int> idx;
                vector<float> dist;
                kdtree->nearestKSearch(PointType(dat_[depth_-1][i]->corners_[j][0],
                                                 dat_[depth_-1][i]->corners_[j][1],
                                                 dat_[depth_-1][i]->corners_[j][2]), 1, idx, dist);
                dat_[depth_-1][i]->id_of_corners_.push_back(idx[0]);
            }
        }
        
        // update lines information in cell       
        vector<vector<int>> lines;
        for(int i=0;i<dat_[depth_-1].size();i++){            
            vector<vector<int>> line_tmp=dat_[depth_-1][i]->GenerateLines();
            lines.insert(lines.end(), line_tmp.begin(), line_tmp.end());
        }

        return std::make_tuple(corners_,lines);
    }
    else
        cout<<"Error: please update sequence first, call ExpandBoundingBox."<<endl;       
}    

void NaiveVoxels::CreateNaiveCell(V3 bmin, V3 bmax, int level){
    // make sure bmin is the minimum corner, and bmax is the maximum corner
    CorrectBoxMinMax(bmin,bmax);

    // new a cell
    VoxelInfo* new_cell=new VoxelInfo(bmin,bmax, level);

    // continue or return
    if(level<depth_){
        dat_[level].push_back(new_cell);            
    }
    else if(level==depth_){
        return;
    }
    else{
        cout<<"Error: level out of range!"<<endl;
    }

    // cells in sub-level
    CreateNaiveCell(new_cell->corners_[0], new_cell->centre_, level+1);
    CreateNaiveCell(new_cell->corners_[1], new_cell->centre_, level+1);
    CreateNaiveCell(new_cell->corners_[2], new_cell->centre_, level+1);
    CreateNaiveCell(new_cell->corners_[3], new_cell->centre_, level+1);
    CreateNaiveCell(new_cell->corners_[4], new_cell->centre_, level+1);
    CreateNaiveCell(new_cell->corners_[5], new_cell->centre_, level+1);
    CreateNaiveCell(new_cell->corners_[6], new_cell->centre_, level+1);
    CreateNaiveCell(new_cell->corners_[7], new_cell->centre_, level+1);
}

void NaiveVoxels::ExpandBoundingBox(PointType minPt, PointType maxPt)
{
    // get length in each axis
    float x_length=maxPt.x-minPt.x;
    float y_length=maxPt.y-minPt.y;
    float z_length=maxPt.z-minPt.z;

    // get spacing in each axis
    float x_spacing_=x_length/pow(2,depth_-1);
    float y_spacing_=y_length/pow(2,depth_-1);
    float z_spacing_=z_length/pow(2,depth_-1);

    // update bounding box
    bmin_.x=minPt.x-5*x_spacing_;
    bmin_.y=minPt.y-5*y_spacing_;
    bmin_.z=minPt.z-5*z_spacing_;

    bmax_.x=maxPt.x+5*x_spacing_;
    bmax_.y=maxPt.y+5*y_spacing_;
    bmax_.z=maxPt.z+5*z_spacing_;

    // re-update length in each axis
    x_length=bmax_.x-bmin_.x;
    y_length=bmax_.y-bmin_.y;
    z_length=bmax_.z-bmin_.z;

    // update sequence
    for(int i=0; (bmin_.x+ i*x_spacing_) <= bmax_.x; i++ ){
        x_sequence_.push_back(bmin_.x+ i*x_spacing_);
        y_sequence_.push_back(bmin_.y+ i*y_spacing_);
        z_sequence_.push_back(bmin_.z+ i*z_spacing_);
    }
}

/******************************
 *  Narrow Band Grid
 ******************************/
void NarrowBandVoxels::InitNarrowBandVoxels(vector<vector<float>> pyCloud_xyz, int depth, vector<vector<float>> pyCloud_nrm){    
    depth_=depth;

    // cloud xyz
    cloud_xyz_=pyCloud_xyz;

    // Establish cloud (PCL) from python
    cloud_=pcl::PointCloud<PointType>::Ptr(new pcl::PointCloud<PointType>);
    if(pyCloud_nrm.size()==0){
        for(int i=0;i<pyCloud_xyz.size();i++){
            cloud_->points.push_back(PointType(pyCloud_xyz[i][0],pyCloud_xyz[i][1],pyCloud_xyz[i][2]));
        }
    }
    else{
        for(int i=0;i<pyCloud_xyz.size();i++){
            cloud_->points.push_back(PointType(pyCloud_xyz[i][0],pyCloud_xyz[i][1],pyCloud_xyz[i][2],0,0,0, 
                                            pyCloud_nrm[i][0],pyCloud_nrm[i][1],pyCloud_nrm[i][2]));
        }
    }
    
    kdtree_=pcl::search::KdTree<PointType>::Ptr(new pcl::search::KdTree<PointType>);
    kdtree_->setInputCloud(cloud_);

    // Expand bounding box
    PointType minPt, maxPt;
    pcl::getMinMax3D(*cloud_, minPt, maxPt);
    ExpandBoundingBox(minPt,maxPt);

    // Init depth
    depth_=depth;
    dat_.resize(depth_);
    dat_on_surface_.resize(depth_);

    // Create cells
    CreateNarrowBandGrid(bmin_,bmax_, 0);    

    // Create corners of each cell       
    CreateCornersOfNarrowBandGrid();

    // Create the point indices in each cell              
    CreatePointIdx();  

    // create lines of voxel
    CreateLinesOfNarrowBandGrid();      
    // 
    CreateIdxOnAndOff();
    //
    CreateZeroBandGrid();

    // 
    CreateCloudOnAndOff();

    // connected graph
    CreateConnectedGraph();    

    //
    GenerateMarchingCubeEdgePoints();

    // set labels
    gt_labels_.resize(idx_off_.size());

    // debug
    debug=0;

    // direction
    drct_.push_back(V3(1,1,1));
    drct_.push_back(V3(1,1,-1));
    drct_.push_back(V3(0,1,0));
    drct_.push_back(V3(0,-1,0));
    drct_.push_back(V3(-1,0,0));
    drct_.push_back(V3(1,0,0));

    // voxel size
    voxel_size_=GetGridSize();
}

vector<vector<float>> NarrowBandVoxels::GetPredictNormal(vector<int> flgCell, string save_path){
    vector<vector<float>> pred_nrm;
    cout<<"flgcell size:"<<flgCell.size()<<endl;
    cout<<"idx_off size:"<<idx_off_.size()<<endl;
    if(flgCell.size()==idx_off_.size()){
        // get inner cells representation cloud
        pcl::PointCloud<PointType>::Ptr cloud_one(new pcl::PointCloud<PointType>);
        pcl::PointCloud<PointType>::Ptr cloud_theother(new pcl::PointCloud<PointType>);        
        for(int i=0;i< flgCell.size();i++){
            V3& centre_tmp=dat_[depth_-1][idx_off_[i]]->centre_;
            if(flgCell[i]==OneSide)                
                cloud_one->points.push_back(PointType(centre_tmp.x, centre_tmp.y, centre_tmp.z));
            else
                cloud_theother->points.push_back(PointType(centre_tmp.x, centre_tmp.y, centre_tmp.z));
        }

        pcl::PointCloud<PointType>::Ptr cloud_inner(new pcl::PointCloud<PointType>);
        pcl::search::KdTree<PointType>::Ptr kdtree_inner(new pcl::search::KdTree<PointType>);
        if(cloud_one->points.size()<cloud_theother->points.size())
            cloud_inner=cloud_one;
        else 
            cloud_inner=cloud_theother;
            
        kdtree_inner->setInputCloud(cloud_inner);

        // boundary cell 
        for(int i=0;i<cloud_->points.size();i++){
            vector<int> idx;
            vector<float> dist;
            kdtree_inner->nearestKSearch(cloud_->points[i], 1, idx, dist);

            // position vector
            V3 Pa= V3(cloud_inner->points[idx[0]].x, cloud_inner->points[idx[0]].y, cloud_inner->points[idx[0]].z);
            V3 Pb= V3(cloud_->points[i].x, cloud_->points[i].y, cloud_->points[i].z);
            V3 Pab= Pb-Pa;
            float sign=Pab.Dot(V3(cloud_->points[i].normal_x, cloud_->points[i].normal_y, cloud_->points[i].normal_z));
            if(sign<0){
                cloud_->points[i].normal_x=-cloud_->points[i].normal_x;
                cloud_->points[i].normal_y=-cloud_->points[i].normal_y;
                cloud_->points[i].normal_z=-cloud_->points[i].normal_z;                    
            }
            vector<float> nrm_tmp;
            nrm_tmp.push_back(cloud_->points[i].normal_x);
            nrm_tmp.push_back(cloud_->points[i].normal_y);
            nrm_tmp.push_back(cloud_->points[i].normal_z);
            pred_nrm.push_back(nrm_tmp);
        }
        pcl::io::savePLYFileBinary(save_path, *cloud_);
    }
    else{
        cout<<"Error: the dimension of labels is not consistent with cloud"<<endl;
    }
    return pred_nrm;
}

vector<vector<float>> NarrowBandVoxels::GetOffCloud()
{
    vector<vector<float>> off_pts;
    for(int i=0; i<cloud_off_->points.size(); i++){
        vector<float> ptmp;
        ptmp.push_back(cloud_off_->points[i].x);
        ptmp.push_back(cloud_off_->points[i].y);
        ptmp.push_back(cloud_off_->points[i].z);
        off_pts.push_back(ptmp);
    }
    return off_pts;
}

tuple<int,vector<int>> NarrowBandVoxels::IsTheVoxelInside(int idx)
{
    VoxelInfo* current_cell=dat_[depth_-1][idx];

    // six direction
    int count=0;
    vector<int> nItsc;
    for(int i=0; i< drct_.size(); i++){
        int num_of_itsc = QueryIntersectVoxelWithRay_Fast(Ray(current_cell->centre_, drct_[i], point_with_direction));
        nItsc.push_back(num_of_itsc);
        if(num_of_itsc%2==1){
            count++;
        }
    }

    if(debug==1){
        for(int i=0; i< nItsc.size(); i++)
            cout<<nItsc[i]<<" ";
        cout<<endl;
    }
  
    // if(count>=5)
    //     return OneSide;
    // else if(count<=2)
    //     return TheOtherSide;    
    // else 
    //     return UNDETERMINED;
    

    if(count==6)
        return make_tuple(OneSide,nItsc);
    else if(count==0)
        return make_tuple(TheOtherSide,nItsc);    
    else 
        return make_tuple(UNDETERMINED,nItsc);
}

vector<int> NarrowBandVoxels::GetFeatures(string path_to_gt_labels, string path_to_pred_labels, string path_to_features)
{
    LabelCellsByGTNormal();
    vector<vector<float>> pts;
    vector<vector<float>> colors;
    vector<int> pred_labels_(gt_labels_.size());
    int count_pred_I=0;
    int count_pred_I_true=0;
    int count_pred_O=0;
    int count_pred_O_true=0;
    int count_undetermined=0;
    vector<vector<int>> features;
    features.resize(idx_off_.size());

    for(int i=0; i< idx_off_.size(); i++){
        if(i==29717)
            debug=1;
        else 
            debug=0;

        auto [in_or_out,nitsc]=IsTheVoxelInside(idx_off_[i]);
        pts.push_back(dat_[depth_-1][idx_off_[i]]->centre_.ToFloat());
        features[i].insert(features[i].end(), nitsc.begin(), nitsc.end());

        if(in_or_out==OneSide){
            pred_labels_[i]=OneSide;
            count_pred_I++;
            if(pred_labels_[i]==gt_labels_[i]){
                count_pred_I_true++;
            }
            else{
                cout<<"inside error idx: "<<i<<endl;
            }
            colors.push_back(V3(255,0,0).ToFloat());
        }       
        else if(in_or_out==TheOtherSide){
            pred_labels_[i]=TheOtherSide;
            count_pred_O++;
            if(pred_labels_[i]==gt_labels_[i]){
                count_pred_O_true++;
            }
            else{
                cout<<"outside error idx: "<<i<<endl;
            }
            colors.push_back(V3(0,255,0).ToFloat());
        }
        else{
            colors.push_back(V3(0,0,255).ToFloat());
            pred_labels_[i]=UNDETERMINED;
            count_undetermined++;
        }
    }

    cout<<"inside accuracy: "<<count_pred_I_true*1.0/count_pred_I*100<<" %"<<endl;
    cout<<"outside accuracy: "<<count_pred_O_true*1.0/count_pred_O*100<<" %"<<endl;
    cout<<"undetermined:"<< count_undetermined<<endl;
    
    OBJManager scene_io;
    scene_io.AddPoints(pts, colors);
    scene_io.SaveOBJ("/home/i9/experiment_nc/cylinder100k/rst_color.obj");
    fout.close();


    ofstream fout_pred_label(path_to_pred_labels);
    ofstream fout_gt_label(path_to_gt_labels);
    ofstream fout_features(path_to_features);
    for(int i=0; i<pred_labels_.size(); i++){
        fout_pred_label<<pred_labels_[i]<<endl;
        fout_gt_label<<gt_labels_[i]<<endl;

        for(int j=0; j< features[i].size(); j++){
            if(j==0)
                fout_features<<(features[i][j]%2);
            else    
                fout_features<<" "<<(features[i][j]%2);
        }
        fout_features<<endl;
    }
    fout_pred_label.close();
    fout_gt_label.close();
    fout_features.close();

    return pred_labels_;
}

void NarrowBandVoxels::FindPointIdx(vector<float> pt)
{
    PointType idata;
    idata.x=pt[0];
    idata.y=pt[1];
    idata.z=pt[2];

    vector<int> idx;
    vector<float> dist;
    kdtree_off_->nearestKSearch(idata, 1, idx, dist);
    cout<<"Find point idx: "<<idx[0]<<endl;
}

void NarrowBandVoxels::CreateIdxOnAndOff(){
    idx_on_.clear();
    idx_off_.clear();
    int cnt_on=0;
    int cnt_off=0;

    for(int i=0;i< dat_[depth_-1].size(); i++){
        if(dat_[depth_-1][i]->pts_idx_.size()>0){
            idx_on_.push_back(i);
            dat_[depth_-1][i]->id_on_=(cnt_on++);
        }
        else{
            idx_off_.push_back(i);
            dat_[depth_-1][i]->id_off_=(cnt_off++);
        }
    }
}


void NarrowBandVoxels::SaveVoxelsStatus(string save_path, vector<int> status)
{
    pcl::PointCloud<PointType>::Ptr cloud(new pcl::PointCloud<PointType>);
    pcl::PointCloud<PointType>::Ptr cloud_inner(new pcl::PointCloud<PointType>);
    pcl::PointCloud<PointType>::Ptr cloud_outer(new pcl::PointCloud<PointType>);    
    pcl::PointCloud<PointType>::Ptr cloud_uncertain(new pcl::PointCloud<PointType>);    

    for(int i=0;i<idx_off_.size();i++){
        VoxelInfo* pcell=dat_[depth_-1][idx_off_[i]];
        cloud->points.push_back(PointType(pcell->centre_.x, pcell->centre_.y, pcell->centre_.z));
        if(status[i]==1)
            cloud_outer->points.push_back(PointType(pcell->centre_.x, pcell->centre_.y, pcell->centre_.z, 255, 0, 0));
        else if(status[i]==-1)
            cloud_inner->points.push_back(PointType(pcell->centre_.x, pcell->centre_.y, pcell->centre_.z, 0, 255, 0));
        else if(status[i]==-2)
            cloud_uncertain->points.push_back(PointType(pcell->centre_.x, pcell->centre_.y, pcell->centre_.z, 0, 0, 255));
    }
    pcl::io::savePLYFileBinary(save_path+"voxels.ply", *cloud);
    pcl::io::savePLYFileBinary(save_path+"voxels_inner.ply", *cloud_inner);
    pcl::io::savePLYFileBinary(save_path+"voxels_outer.ply", *cloud_outer);
    pcl::io::savePLYFileBinary(save_path+"voxels_uncertain.ply", *cloud_uncertain);
}

/* Create the point indices in each cell */
void NarrowBandVoxels::CreatePointIdx(){    
    // get representation point cloud for all cells                  
    pcl::PointCloud<PointType>::Ptr cloud_for_all_cell_centre(new pcl::PointCloud<PointType>());       
    for(int i=0;i<dat_[depth_-1].size();i++){
        cloud_for_all_cell_centre->points.push_back(PointType(dat_[depth_-1][i]->centre_.x, dat_[depth_-1][i]->centre_.y, dat_[depth_-1][i]->centre_.z));
    }

    pcl::search::KdTree<PointType>::Ptr kdtree_for_all_cell_centre(new pcl::search::KdTree<PointType>);
    kdtree_for_all_cell_centre->setInputCloud(cloud_for_all_cell_centre);        
    for(int i=0; i < cloud_->points.size(); i++){
        vector<int> idx;
        vector<float> dist;
        kdtree_for_all_cell_centre->nearestKSearch(cloud_->points[i], 1, idx, dist);
        dat_[depth_-1][idx[0]]->pts_idx_.push_back(i);
    }
}


vector<vector<float>> NarrowBandVoxels::GetCornersOfNarrowBandGrid(){
    return corners_;
}

vector<vector<int>> NarrowBandVoxels::GetLinesOfNarrowBandGrid(){
    if(dat_[depth_-1][0]->lines_by_id_.size()>0){                    
        vector<vector<int>> lines;
        for(int i=0;i<dat_[depth_-1].size();i++){
            for(int k=0;k<12;k++){
                lines.push_back(dat_[depth_-1][i]->lines_by_id_[k]); 
            }
        }
        return lines;
    }
    else 
        cout<<"Error: please call CreateLinesOfNarrowBandGrid() first."<<endl;       
}

vector<vector<int>> NarrowBandVoxels::GetFacesOfNarrowBandGrid(){        
    vector<vector<int>> faces;
    if(dat_[depth_-1][0]->corners_.size()>0){     
        for(int i=0;i<dat_[depth_-1].size();i++){           
            vector<vector<int>> face_tmp=dat_[depth_-1][i]->GenerateFaces();
            faces.insert(faces.end(), face_tmp.begin(), face_tmp.end());
        }
    }
    else 
        cout<<"Error: please call GetCornersOfAllAdaptiveCells() first."<<endl;  
    
    return faces;
}

/****************************************************
 *  Get Section
 * *************************************************/
vector<int> NarrowBandVoxels::GetCellsStatus(){
    vector<int> rst;
    for(int i=0; i< dat_[depth_-1].size(); i++){
        rst.push_back(dat_[depth_-1][i]->flag_);
    }
    return rst;
}

vector<vector<float>> NarrowBandVoxels::GetColorsOfNarrowBandGrid(){
    LabelCellsByGTNormal();

    vector<vector<float>> rst;        
    if(flag_are_cells_labelled_==1){
        // colors
        vector<float> red,green,blue;
        red.push_back(1.0); 
        red.push_back(0.0);
        red.push_back(0.0);
        green.push_back(0.0);
        green.push_back(1.0);
        green.push_back(0.0);
        blue.push_back(0.0);
        blue.push_back(0.0);
        blue.push_back(1.0);

        // 
        for(int i=0;i<dat_[depth_-1].size();i++){
            if(dat_[depth_-1][i]->flag_==BOUNDARY){
                for(int j=0;j<12;j++){
                    rst.push_back(red);
                }
            }
            else if(dat_[depth_-1][i]->flag_==OneSide){
                for(int j=0;j<12;j++){
                    rst.push_back(green);
                }
            }
            else if(dat_[depth_-1][i]->flag_==TheOtherSide){
                for(int j=0;j<12;j++){
                    rst.push_back(blue);
                }
            }
            else{
                cout<<"Error: flag_ error! check function GetColorsOfNarrowBandGrid()"<<endl;
            }
        }
    }
    else{
        cout<<"You should label the created cells at first, please call LabelCellsByGTNormal."<<endl;
    }        
    return rst;
}   

vector<vector<float>> NarrowBandVoxels::GetMaximumCorners(){
    vector<vector<float>> rst;        
    rst=dat_[0][0]->GenerateEightCorners();
    return rst;
}

std::tuple<vector<float>, vector<float>> NarrowBandVoxels::GetRay(){
    vector<float> o,d;
    V3 origin=dat_[depth_-1][0]->centre_;
    o.push_back(origin.x);
    o.push_back(origin.y);
    o.push_back(origin.z);

    d.push_back(0);
    d.push_back(1);
    d.push_back(0);

    return std::make_tuple(o,d);
}

vector<vector<int>> NarrowBandVoxels::QueryIntersectVoxelWithRay(vector<float> pt1, vector<float> pt2){
    vector<vector<int>> rst;
    Ray ray1(V3(pt1[0], pt1[1], pt1[2]), V3(pt2[0], pt2[1], pt2[2]), point_to_point);
    for(int i=0; i<dat_[depth_-1].size(); i++){
        auto [is_intersect, dist]= ray1.IsIntersect(AABB(dat_[depth_-1][i]->bmin_, dat_[depth_-1][i]->bmin_));
        if(is_intersect==true && dat_[depth_-1][i]->pts_idx_.size()>0){
            rst=dat_[depth_-1][i]->lines_by_id_;
            break;
        }
    }
    return rst;
}

void NarrowBandVoxels::LabelCellsByGTNormal(){      
    if(cloud_!=NULL){
        // label cells containing points
        for(int i=0;i<gt_labels_.size();i++){        
            vector<int> idx;
            vector<float> dist;
            int itmp=idx_off_[i];
            kdtree_->nearestKSearch(PointType(dat_[depth_-1][itmp]->centre_.x,dat_[depth_-1][itmp]->centre_.y,dat_[depth_-1][itmp]->centre_.z),1, idx, dist);
            V3 a2b= V3(dat_[depth_-1][itmp]->centre_.x - cloud_->points[idx[0]].x,
                        dat_[depth_-1][itmp]->centre_.y - cloud_->points[idx[0]].y,
                        dat_[depth_-1][itmp]->centre_.z - cloud_->points[idx[0]].z).Normalize();
            
            V3 nrm= V3(cloud_->points[idx[0]].normal_x, cloud_->points[idx[0]].normal_y, cloud_->points[idx[0]].normal_z);
            float vdot=Dot(a2b,nrm);
            if(vdot>0){
                gt_labels_[i]=TheOtherSide;
            }
            else{
                gt_labels_[i]=OneSide;
            }             
        }        
    }
    else{
        cout<<"Error: cloud is not available, please create module with cloud!"<<endl;
    }
}

void NarrowBandVoxels::CreateCornersOfNarrowBandGrid(){
    // create corners
    if(dat_[depth_-1][0]->id_of_corners_.size()==0){
        pcl::PointCloud<PointType>::Ptr cloud_for_corners(new pcl::PointCloud<PointType>);
        // generate all corners and corresponding point cloud                       
        for(int i=0;i<dat_[depth_-1].size();i++){
            vector<vector<float>> corners_tmp= dat_[depth_-1][i]->GenerateEightCorners();
            corners_.insert(corners_.end(),corners_tmp.begin(), corners_tmp.end());                
            for(int j=0;j<corners_tmp.size();j++){
                cloud_for_corners->points.push_back(PointType(corners_tmp[j][0], corners_tmp[j][1], corners_tmp[j][2]));
            }
        }

        // update corners indices to cellinfo               
        pcl::search::KdTree<PointType>::Ptr kdtree_for_corners(new pcl::search::KdTree<PointType>());
        kdtree_for_corners->setInputCloud(cloud_for_corners);
        for(int i=0;i<dat_[depth_-1].size();i++){
            for(int j=0;j<8;j++){ // eight corners
                vector<int> idx;
                vector<float> dist;
                kdtree_for_corners->nearestKSearch(PointType(dat_[depth_-1][i]->corners_[j][0],
                                                             dat_[depth_-1][i]->corners_[j][1],
                                                             dat_[depth_-1][i]->corners_[j][2]), 1, idx, dist);
                dat_[depth_-1][i]->id_of_corners_.push_back(idx[0]);
            }
        }
    }
}

void NarrowBandVoxels::CreateLinesOfNarrowBandGrid(){
    if(dat_[depth_-1][0]->lines_by_id_.size()==0){           
        // update lines information in cell    
        for(int i=0;i<dat_[depth_-1].size();i++){           
            dat_[depth_-1][i]->GenerateLines();                          
        }
    }
}

void NarrowBandVoxels::CreateZeroBandGrid(){
    // Info 1: obtain all the on-surface voxels in bottom layer
    for(int i=0; i<dat_[depth_-1].size(); i++){
        if(dat_[depth_-1][i]->pts_idx_.size()>0){
            dat_on_surface_[depth_-1].push_back(dat_[depth_-1][i]);
        }
    }

    // Info 2: update the on-surface child voxel for each parent voxel
    for(int i=depth_-2; i>=0; i--){
        // from child to parent
        for(int j=0; j< dat_on_surface_[i+1].size(); j++){
            VoxelInfo* pParent=dat_on_surface_[i+1][j]->pParent_;           
            pParent->child_on_.push_back(dat_on_surface_[i+1][j]);
        }
        // from parent to child
        for(int j=0; j< dat_[i].size(); j++){
            if( dat_[i][j]->child_on_.size() !=0){
                dat_on_surface_[i].push_back(dat_[i][j]);
            }
        }
    }
}

VoxelInfo* NarrowBandVoxels::CreateNarrowBandGrid(V3 bmin, V3 bmax, int level){
    // make sure bmin is the minimum corner, and bmax is the maximum corner
    CorrectBoxMinMax(bmin,bmax);

    // calculate radius
    V3 centre=(bmin+bmax)/2.0;
    float radius= bmin.EuclideanDistance(centre);
    vector<int> idx;
    vector<float> dist;
    kdtree_->radiusSearch(PointType(centre.x,centre.y,centre.z), 4*radius, idx, dist);    

    // if it contains points, we establish it
    if(idx.size()>0){
        // new a cell
        VoxelInfo* new_cell= new VoxelInfo(bmin,bmax, level);            

        // continue or return
        if(level<depth_){
            dat_[level].push_back(new_cell);       

            // cells in sub-level            
            VoxelInfo* child_0 = CreateNarrowBandGrid(new_cell->corners_[0], new_cell->centre_, level+1);
            if(child_0!=NULL){
                child_0->pParent_=new_cell;
                new_cell->child_.push_back(child_0);
            } 
            
            VoxelInfo* child_1 = CreateNarrowBandGrid(new_cell->corners_[1], new_cell->centre_, level+1);
            if(child_1!=NULL){
                child_1->pParent_=new_cell;
                new_cell->child_.push_back(child_1);          
            } 

            VoxelInfo* child_2 = CreateNarrowBandGrid(new_cell->corners_[2], new_cell->centre_, level+1);
            if(child_2!=NULL){
                child_2->pParent_=new_cell;
                new_cell->child_.push_back(child_2);
            }                 
                
            VoxelInfo* child_3 = CreateNarrowBandGrid(new_cell->corners_[3], new_cell->centre_, level+1);
            if(child_3!=NULL){
                child_3->pParent_=new_cell;
                new_cell->child_.push_back(child_3);
            }                 

            VoxelInfo* child_4 = CreateNarrowBandGrid(new_cell->corners_[4], new_cell->centre_, level+1);
            if(child_4!=NULL){
                child_4->pParent_=new_cell;
                new_cell->child_.push_back(child_4); 
            }                

            VoxelInfo* child_5 = CreateNarrowBandGrid(new_cell->corners_[5], new_cell->centre_, level+1);
            if(child_5!=NULL){
                child_5->pParent_=new_cell;
                new_cell->child_.push_back(child_5);  
            }               

            VoxelInfo* child_6 = CreateNarrowBandGrid(new_cell->corners_[6], new_cell->centre_, level+1);
            if(child_6!=NULL){
                child_6->pParent_=new_cell;
                new_cell->child_.push_back(child_6);
            }                 

            VoxelInfo* child_7 = CreateNarrowBandGrid(new_cell->corners_[7], new_cell->centre_, level+1);
            if(child_7!=NULL){
                child_7->pParent_=new_cell;
                new_cell->child_.push_back(child_7);  
            }                               
            
            return new_cell;
        }           
        else                
            return NULL;                     
    }
    else
        return NULL; 
}

void NarrowBandVoxels::ExpandBoundingBox(PointType minPt, PointType maxPt){
   // get length in each axis
    float x_length=maxPt.x-minPt.x;
    float y_length=maxPt.y-minPt.y;
    float z_length=maxPt.z-minPt.z;

    // get spacing in each axis
    float x_spacing_=x_length/pow(2,depth_-1);
    float y_spacing_=y_length/pow(2,depth_-1);
    float z_spacing_=z_length/pow(2,depth_-1);

    // update bounding box
    bmin_.x=minPt.x-5*x_spacing_;
    bmin_.y=minPt.y-5*y_spacing_;
    bmin_.z=minPt.z-5*z_spacing_;

    bmax_.x=maxPt.x+5*x_spacing_;
    bmax_.y=maxPt.y+5*y_spacing_;
    bmax_.z=maxPt.z+5*z_spacing_;
}

/**
 * @brief Query intersect voxel with ray, we utilize the octree structure to accelerate the processing procedure
 * 
 * @param ry 
 * @return int 
 */
int NarrowBandVoxels::QueryIntersectVoxelWithRay_Fast(Ray ry)
{
    int total_num_of_itsc=0;
    vector<VoxelInfo*> intersect_cells_in_current_layer, intersect_cells_in_next_layer;
    bool is_finish=false;

    // step 01: find all intersect cells in current layer
    for(int i=0; i< dat_on_surface_[1].size(); i++){
        VoxelInfo* cell_tmp= dat_on_surface_[1][i];
        auto [is_intersect, dist]=ry.IsIntersect(AABB(cell_tmp->bmin_, cell_tmp->bmax_));
        if(is_intersect==true){
            intersect_cells_in_current_layer.push_back(cell_tmp);
        }
    }
   

    // step 02: obtain all intersect voxels
    vector<float>  dists_to_ray;
    while(is_finish!=true){   
        dists_to_ray.clear();
        // find all intersect cells in the next layer
        for(int i=0; i<intersect_cells_in_current_layer.size(); i++){
            for(int j=0; j< intersect_cells_in_current_layer[i]->child_on_.size(); j++){
                VoxelInfo* cell_tmp= intersect_cells_in_current_layer[i]->child_on_[j];

                auto [is_intersect, dist_ray_to_aabb]=ry.IsIntersect(AABB(cell_tmp->bmin_, cell_tmp->bmax_));
                if(is_intersect==true){
                    dists_to_ray.push_back(dist_ray_to_aabb);
                    intersect_cells_in_next_layer.push_back(cell_tmp);
                }                
            }
        }

        // update current layer
        intersect_cells_in_current_layer=intersect_cells_in_next_layer;
        intersect_cells_in_next_layer.clear();

        // determine whether it is finished by 
        int count=0;
        for(int i=0; i<intersect_cells_in_current_layer.size(); i++){
            if(intersect_cells_in_current_layer[i]->child_on_.size()==0) // if it is leaf voxel
                count++;
        }
        if(count==intersect_cells_in_current_layer.size())
            is_finish=true;
    }
    
    // whether it has intersect points
    if(intersect_cells_in_current_layer.size()!=0){
        DBSCAN db(dists_to_ray, 3*voxel_size_, 1);
        vector<int> p2c=db.p2c_;
        vector<vector<int>> c2p=db.c2p_; 

        // step 03: count number of intersection points
        for(int i=0; i < c2p.size(); i++){
            int num_of_itsc=0;

            if(c2p[i].size()==1)
                num_of_itsc=1;
            else{
                // collect points for continues voxels 
                vector<vector<float>> pts;
                vector<AABB*> range;

                for(int j=0; j<c2p[i].size(); j++){
                    int itmp=c2p[i][j];     

                    range.push_back(new AABB(intersect_cells_in_current_layer[itmp]->bmin_, intersect_cells_in_current_layer[itmp]->bmax_));

                    vector<VoxelInfo*> wcell;
                    wcell.push_back(intersect_cells_in_current_layer[itmp]);

                    wcell.insert(wcell.end(), intersect_cells_in_current_layer[itmp]->connected_voxels_.begin(), 
                                            intersect_cells_in_current_layer[itmp]->connected_voxels_.end());
                    for(int j=0; j< wcell.size(); j++){
                        for(int k=0; k< wcell[j]->pts_idx_.size(); k++){
                            int idx_tmp= wcell[j]->pts_idx_[k];
                            pts.push_back(V3(cloud_->points[idx_tmp].x , cloud_->points[idx_tmp].y ,cloud_->points[idx_tmp].z).ToFloat());               
                        }
                    }
                }           

                // step 03-2: Delaunay
                Delaunay2D dy(pts);
                dy.Recon();
                if(debug==1){
                    dy.EnableDebug();
                    OBJManagerGeometricEx scene_voxels;
                    for(int j=0; j<intersect_cells_in_current_layer.size(); j++)
                        scene_voxels.AddBox(intersect_cells_in_current_layer[j]);
                    scene_voxels.SaveOBJ("/home/i9/experiment_nc/special_cases/scene_voxels.obj");
                }                                    
                num_of_itsc=dy.IsIntersect(ry);
                if(debug==1)
                    dy.DisableDebug();
            }            
            total_num_of_itsc = total_num_of_itsc + num_of_itsc;           
        }

        return total_num_of_itsc;
    }
    else 
        return 0;  
}

bool NarrowBandVoxels::QueryIntersectVoxelWithLineSegment_Fast(LineSegment ls)
{
    vector<int> idx;
    vector<float> dist;
    PointType pt(ls.origin_.x, ls.origin_.y, ls.origin_.z);
    kdtree_on_->radiusSearch(pt,ls.t_o2e_, idx, dist);

    for(int i=0; i< idx.size(); i++){
        VoxelInfo* cur_voxel=dat_[depth_-1][idx_on_[idx[i]]];
        auto [is_intersect, dist]=ls.IsIntersect((AABB*)cur_voxel);
        if(is_intersect==true){
            return true;
        }
    }

    return false;
}

float NarrowBandVoxels::GetGridSize()
{
    float size=dat_[depth_-1][0]->bmin_.EuclideanDistance(dat_[depth_-1][0]->bmax_);
    return size;
}

int NarrowBandVoxels::CountValid(vector<float> dat, float& eps)
{
    int count=0;    
    if(dat.size()!=0){
        sort(dat.begin(),dat.end());       
        for(int i=1; i< dat.size();i++){
            if(dat[i]-dat[i-1] > eps){
                count++;
            }
        }
        count++;
    }
    else{
        count=0;
    }       
    return count;
}

int NarrowBandVoxels::GetIdxOffSurface(int idx)
{
    return idx_off_[idx];
}

tuple<float,float,float> NarrowBandVoxels::GetSideLengthOfVoxel()
{
    float lengthx=(bmax_.x-bmin_.x)/pow(2,depth_);
    float lengthy=(bmax_.y-bmin_.y)/pow(2,depth_);
    float lengthz=(bmax_.z-bmin_.z)/pow(2,depth_);
    return make_tuple(lengthx, lengthy, lengthz);
}

void NarrowBandVoxels::CreateConnectedGraph()
{
    pcl::PointCloud<PointType>::Ptr cloud_for_voxels(new pcl::PointCloud<PointType>);
    pcl::search::KdTree<PointType>::Ptr kdtree(new pcl::search::KdTree<PointType>);
    for(int i=0;i<dat_[depth_-1].size();i++){
        V3 ptmp=dat_[depth_-1][i]->centre_;
        cloud_for_voxels->points.push_back(PointType(ptmp.x, ptmp.y, ptmp.z));
    }
    kdtree->setInputCloud(cloud_for_voxels);

    // traverse all cells to get their connected graph
    float lx=dat_[depth_-1][0]->bmax_.x-dat_[depth_-1][0]->bmin_.x;
    float ly=dat_[depth_-1][0]->bmax_.y-dat_[depth_-1][0]->bmin_.y;
    float lz=dat_[depth_-1][0]->bmax_.z-dat_[depth_-1][0]->bmin_.z;    

    // 
    for(int i=0;i<dat_[depth_-1].size();i++){
        VoxelInfo* current_cell=dat_[depth_-1][i];       
        V3& centre=dat_[depth_-1][i]->centre_;

        // connected pts in six direction
        vector<PointType> connected_pts;
        connected_pts.push_back(PointType(centre.x-lx, centre.y-ly, centre.z+lz));      // 1
        connected_pts.push_back(PointType(centre.x-lx,    centre.y, centre.z+lz));      // 2
        connected_pts.push_back(PointType(centre.x-lx, centre.y+ly, centre.z+lz));      // 3
        connected_pts.push_back(PointType(   centre.x, centre.y-ly, centre.z+lz));      // 4
        connected_pts.push_back(PointType(   centre.x,    centre.y, centre.z+lz));      // 5
        connected_pts.push_back(PointType(   centre.x, centre.y+ly, centre.z+lz));      // 6
        connected_pts.push_back(PointType(centre.x+lx, centre.y-ly, centre.z+lz));      // 7
        connected_pts.push_back(PointType(centre.x+lx,    centre.y, centre.z+lz));      // 8
        connected_pts.push_back(PointType(centre.x+lx, centre.y+ly, centre.z+lz));      // 9

        connected_pts.push_back(PointType(centre.x-lx, centre.y-ly, centre.z));      // 1
        connected_pts.push_back(PointType(centre.x-lx,    centre.y, centre.z));      // 2
        connected_pts.push_back(PointType(centre.x-lx, centre.y+ly, centre.z));      // 3
        connected_pts.push_back(PointType(   centre.x, centre.y-ly, centre.z));      // 4
        // connected_pts.push_back(PointType(   centre.x,    centre.y, centre.z));      // 5
        connected_pts.push_back(PointType(   centre.x, centre.y+ly, centre.z));      // 6
        connected_pts.push_back(PointType(centre.x+lx, centre.y-ly, centre.z));      // 7
        connected_pts.push_back(PointType(centre.x+lx,    centre.y, centre.z));      // 8
        connected_pts.push_back(PointType(centre.x+lx, centre.y+ly, centre.z));      // 9

        connected_pts.push_back(PointType(centre.x-lx, centre.y-ly, centre.z-lz));      // 1
        connected_pts.push_back(PointType(centre.x-lx,    centre.y, centre.z-lz));      // 2
        connected_pts.push_back(PointType(centre.x-lx, centre.y+ly, centre.z-lz));      // 3
        connected_pts.push_back(PointType(   centre.x, centre.y-ly, centre.z-lz));      // 4
        connected_pts.push_back(PointType(   centre.x,    centre.y, centre.z-lz));      // 5
        connected_pts.push_back(PointType(   centre.x, centre.y+ly, centre.z-lz));      // 6
        connected_pts.push_back(PointType(centre.x+lx, centre.y-ly, centre.z-lz));      // 7
        connected_pts.push_back(PointType(centre.x+lx,    centre.y, centre.z-lz));      // 8
        connected_pts.push_back(PointType(centre.x+lx, centre.y+ly, centre.z-lz));      // 9

        for(int j=0; j< connected_pts.size(); j++){
            vector<int> idx;
            vector<float> dist;
            kdtree->nearestKSearch(connected_pts[j], 1, idx, dist);
            dist[0]=sqrt(dist[0]);
            // if(dist[0]<0.00001)
            current_cell->connected_voxels_.push_back(dat_[depth_-1][idx[0]]);
        }  
    }

    // correct
    CorrectAdjacentList();

    off_surface_adjacent_list_26_.resize(idx_off_.size());
    for(int i=0; i< idx_off_.size(); i++){
        for(int j=0; j<dat_[depth_-1][idx_off_[i]]->connected_voxels_.size(); j++){
            if(dat_[depth_-1][idx_off_[i]]->connected_voxels_[j]->pts_idx_.size()==0){
                off_surface_adjacent_list_26_[i].push_back(dat_[depth_-1][idx_off_[i]]->connected_voxels_[j]->id_off_);               
            }
        }
    }

    OBJManager scene_adj_list;
    for(int i=0; i< idx_off_.size(); i++){
        for(int j=0; j<dat_[depth_-1][idx_off_[i]]->connected_voxels_.size(); j++){
            if(dat_[depth_-1][idx_off_[i]]->connected_voxels_[j]->pts_idx_.size()==0){
                scene_adj_list.AddLine(dat_[depth_-1][idx_off_[i]]->centre_.ToFloat(), dat_[depth_-1][idx_off_[i]]->connected_voxels_[j]->centre_.ToFloat());
            }
        }
    }
    scene_adj_list.SaveOBJ("/home/i9/experiment_nc/tmp/adj_list.obj");


    off_surface_adjacent_list_6_.resize(idx_off_.size());
    for(int i=0; i< idx_off_.size(); i++){
        // P4: up        
        if(dat_[depth_-1][idx_off_[i]]->connected_voxels_[4]->pts_idx_.size()==0)
            off_surface_adjacent_list_6_[i].push_back(dat_[depth_-1][idx_off_[i]]->connected_voxels_[4]->id_off_);               
        // P21: down        
        if(dat_[depth_-1][idx_off_[i]]->connected_voxels_[21]->pts_idx_.size()==0)
            off_surface_adjacent_list_6_[i].push_back(dat_[depth_-1][idx_off_[i]]->connected_voxels_[21]->id_off_);               
        // P15: front
        if(dat_[depth_-1][idx_off_[i]]->connected_voxels_[15]->pts_idx_.size()==0)
            off_surface_adjacent_list_6_[i].push_back(dat_[depth_-1][idx_off_[i]]->connected_voxels_[15]->id_off_);
        // P8:back
        if(dat_[depth_-1][idx_off_[i]]->connected_voxels_[8]->pts_idx_.size()==0)
            off_surface_adjacent_list_6_[i].push_back(dat_[depth_-1][idx_off_[i]]->connected_voxels_[8]->id_off_);
        // P12:left
        if(dat_[depth_-1][idx_off_[i]]->connected_voxels_[12]->pts_idx_.size()==0)
            off_surface_adjacent_list_6_[i].push_back(dat_[depth_-1][idx_off_[i]]->connected_voxels_[12]->id_off_);
        // P13:right
        if(dat_[depth_-1][idx_off_[i]]->connected_voxels_[13]->pts_idx_.size()==0)
            off_surface_adjacent_list_6_[i].push_back(dat_[depth_-1][idx_off_[i]]->connected_voxels_[13]->id_off_);        
    }
}

void NarrowBandVoxels::WriteVoxels()
{
    for(int i=0; i<dat_[depth_-1].size(); i++){        
        if(dat_[depth_-1][i]->pts_idx_.size()>0){
            ofstream fout("/home/i9/workspace/P04_normal_consistency/dat_for_presentation/dat.txt", ios::trunc);

            // write corners
            for(int j=0; j< dat_[depth_-1][i]->corners_.size(); j++){
                fout<<dat_[depth_-1][i]->corners_[j][0]<<","<< dat_[depth_-1][i]->corners_[j][1]<<","<< dat_[depth_-1][i]->corners_[j][2]<<endl;
            }

            // write voxel pts
            vector<VoxelInfo*> wcell;
            wcell.push_back(dat_[depth_-1][i]);
            wcell.insert(wcell.end(), dat_[depth_-1][i]->connected_voxels_.begin(), dat_[depth_-1][i]->connected_voxels_.end());

            for(int j=0; j< wcell.size(); j++){
                for(int k=0; k< wcell[j]->pts_idx_.size(); k++){
                    int idx= wcell[j]->pts_idx_[k];
                    cout<< cloud_->points[idx].x << ","<< cloud_->points[idx].y<<","<<cloud_->points[idx].z<<endl;
                    fout<< cloud_->points[idx].x << ","<< cloud_->points[idx].y<<","<<cloud_->points[idx].z<<endl;
                }
            }

            cout<<"ok"<<endl;
            fout.close();
        }
    }
}

int NarrowBandVoxels::IsIntersect(Ray ry, int idx)
{
    // out parameters
    vector<vector<float>> pts;

    // collect all points in voxel and its twelve neighbour voxels    
    if(dat_[depth_-1][idx]->pts_idx_.size()>0){

        // collect points in a voxel and its neighbour voxels
        vector<VoxelInfo*> wcell;
        wcell.push_back(dat_[depth_-1][idx]);
        wcell.insert(wcell.end(), dat_[depth_-1][idx]->connected_voxels_.begin(), dat_[depth_-1][idx]->connected_voxels_.end());

        for(int j=0; j< wcell.size(); j++){
            for(int k=0; k< wcell[j]->pts_idx_.size(); k++){
                int idx_tmp= wcell[j]->pts_idx_[k];
                pts.push_back(V3(cloud_->points[idx_tmp].x , cloud_->points[idx_tmp].y ,cloud_->points[idx_tmp].z).ToFloat());               
            }
        }
    }

    // face
    Delaunay2D dy(pts);
    vector<vector<int>> fid=dy.fid_;

    // traverse all faces
    int count=0;
    for(int i=0; i< fid.size(); i++){
        Triangle tri_tmp(pts[fid[i][0]], pts[fid[i][3]], pts[fid[i][2]]);
        auto [whether, itsc]=ry.IsIntersect(tri_tmp);
        if(whether==true)
            count++;
    }

    return count;
}

vector<int> NarrowBandVoxels::GetIdxOnSurface()
{
    return idx_on_;
}

vector<vector<float>> NarrowBandVoxels::GetOffVoxelRepresentationCloud()
{
    vector<vector<float>> out_pts(cloud_off_->points.size(), vector<float>(3));
    for(int i=0; i<cloud_off_->points.size(); i++){
        out_pts[i][0]=cloud_off_->points[i].x;
        out_pts[i][1]=cloud_off_->points[i].y;
        out_pts[i][2]=cloud_off_->points[i].z;
    }
    return out_pts;
}

void NarrowBandVoxels::CorrectAdjacentList()
{
    for(int i=0; i<dat_[depth_-1].size(); i++){
        VoxelInfo* cur_vi=dat_[depth_-1][i];
        vector<int> idx_to_disconnected;
        for(int j=0; j<dat_[depth_-1][i]->connected_voxels_.size(); j++){
            VoxelInfo* nbr_vi=dat_[depth_-1][i]->connected_voxels_[j];
            LineSegment ls_tmp=LineSegment(cur_vi->GetCentre(), nbr_vi->GetCentre());
            bool is_intersect=QueryIntersectVoxelWithLineSegment_Fast(ls_tmp);
            if(is_intersect==true){
                idx_to_disconnected.push_back(j);
            }
        }

        for(int j=idx_to_disconnected.size()-1; j>=0; j--){
            int idx_tmp=idx_to_disconnected[j];
            dat_[depth_-1][i]->connected_voxels_.erase(dat_[depth_-1][i]->connected_voxels_.begin() + idx_tmp);
        }
    }
}

void NarrowBandVoxels::GenerateMarchingCubeEdgePoints()
{
    map<tuple<int,int>,int> counter;
    for(int i=0; i<idx_on_.size(); i++){
        VoxelInfo* current_cell=dat_[depth_-1][idx_on_[i]]; 
        for(int j=0; j<12; j++){
            int edge_pt_a_idx=current_cell->id_of_corners_[e2c[j][0]];
            int edge_pt_b_idx=current_cell->id_of_corners_[e2c[j][1]];
            if(edge_pt_a_idx>edge_pt_b_idx){
                int swap=edge_pt_a_idx;
                edge_pt_a_idx=edge_pt_b_idx;
                edge_pt_b_idx=swap;
            }

            if(counter.count({edge_pt_a_idx,edge_pt_b_idx})==0){
                int cnt=counter.size();
                counter[{edge_pt_a_idx,edge_pt_b_idx}]=cnt;
                current_cell->mc_edge_pts_id_.push_back(cnt);
                V3 e= (V3(corners_[edge_pt_a_idx]) + V3(corners_[edge_pt_b_idx]))/2.0;
               
                mc_edge_pts_.push_back(e.ToFloat());
            }
            else{
                current_cell->mc_edge_pts_id_.push_back(counter[{edge_pt_a_idx,edge_pt_b_idx}]);
            }
        }
    }
}