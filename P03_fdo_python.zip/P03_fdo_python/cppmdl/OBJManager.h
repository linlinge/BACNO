#pragma once
#include <vector>
#include <string>
#include <fstream>
#include <StringExtend.h>
using namespace std;

class OBJManager
{
    public:
        vector<vector<float>> vtx_;
        vector<vector<int>> faces_;
        vector<vector<int>> lines_;
 
        OBJManager(){};
        void ReadMesh(string path);
        void AddMesh(vector<vector<float>> v, vector<vector<int>> f);
        void AddMesh(vector<vector<float>> v, vector<vector<int>> f, vector<vector<int>> lines);
        void AddRay(vector<vector<int>> lines);  
        void AddPoints(vector<vector<float>> pts);      
        void AddPoints(vector<vector<float>> pts, vector<vector<float>> colors);
        void AddLine(vector<float> pt_start, vector<float> pt_end);
        void AddLines(vector<vector<float>> pts, vector<vector<int>> fid);
        void AddLines(vector<vector<int>> fid);
        void SaveOBJ(string save_path);        
};