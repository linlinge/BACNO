#pragma once
#include <vector>
using namespace std;

template<class T1>
class V2
{
    public:
        T1 x_,y_;
        bool operator<(V2 dat){
            if((x_<dat.x_) && (y_<dat.y_))
                return true;
            else 
                return false;
        }
        bool operator==(V2 dat){
            if((x_==dat.x_) && (y_ == dat.y_)){
                return true;
            }
            else 
                return false;
        }
};