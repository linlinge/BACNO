#pragma once
#include <vector>
#include <iostream>
#include <math.h>
#include <Geometric.h>
#include <algorithm>
#include <PCLExtend.h>
using namespace std;

/*
*   @样本点类型
*-- DB_CORE:   邻域半径R内样本点的数量大于等于minpoints的点叫做核心点。
*-- DB_BORDER: 不属于核心点但在某个核心点的邻域内的点叫做边界点。
*-- DB_NOISE:  既不是核心点也不是边界点的是噪声点。
*/
enum DBSCAN_POINT_Type{DB_CORE, DB_BORDER, DB_NOISE};

class DBPointN: public PointN
{
    public:
        int cluster=0;               //所属类（一个标识代号，属于同一类的样本具有相同的cluster）
        int pointType = DB_NOISE;	 // 1:noise 	2:border 	3:core  （初始默认为噪声点）
        int num_of_ngbrs_ = 0;				 // points in MinPts （指定领域内样本点的个数）
        vector<int> neighborCoreIdx; //对所有的corepoint，记录其eps范围内的core point下标
        int visited = 0;			 //是否被遍历访问过
        
        DBPointN(int i, float idata): PointN(i, idata){
            id_=i;
            dat_.push_back(idata);
        }

        DBPointN(vector<float> dat): PointN(dat){
            dat_=dat;
        }

        DBPointN(int i, vector<float> dat): PointN(i, dat){
            id_=i;
            dat_=dat;
        }        

        float DistTo(DBPointN& b){
            float r=0;
            for(int i=0; i<dat_.size(); i++){
                r+=pow(dat_[i]-b.dat_[i],2);
            }
            return sqrt(r);
        }
};

class DBSCAN
{
    public:
        vector<int> p2c_;
        vector<vector<int>> c2p_;
        int num_of_clusters_;

        DBSCAN(vector<float> pts, float eps, int minPts=1);
        DBSCAN(vector<vector<float>> pts, float eps, int minPts=1);
        tuple<vector<vector<int>>, vector<int>> Apply(vector<DBPointN*> pts, float eps, int minPts);
};

