#pragma once
#include <vector>
#include <fstream>
#include <V2.hpp>
#include <V3.hpp>
#include <PCLExtend.h>
#include <Geometric.h>
#include <LocalMeshGenerator.h>
#include <OBJManager.h>
#include <MarchingCube.h>
#include <Clustering.h>
#define UNFLAG 100
#define OneSide 0
#define TheOtherSide 1
#define UNDETERMINED 2
#define BOUNDARY 3

using namespace std;

class VoxelInfo: public AABB{
    public:
        V3 centre_;
        
        vector<int> id_of_corners_; 
        vector<vector<int>> lines_by_id_;
        vector<vector<int>> faces_by_id_;
        vector<int> pts_idx_;
        int level_;
        int flag_;
        vector<VoxelInfo*> child_, child_on_;    // pointer to child voxel, pointer to child voxel on surface
        vector<VoxelInfo*> connected_voxels_; 
        VoxelInfo* pParent_;   
        vector<vector<int>> mc_triangulated_id_;           // idx for triangular
        vector<int> mc_edge_pts_id_;
        int id_on_;
        int id_off_;

        VoxelInfo(V3& bmin, V3& bmax, int level);
        VoxelInfo(){};
        void operator =(VoxelInfo& dat);
        vector<vector<int>> GenerateLines();
        vector<vector<int>> GenerateFaces();        
        vector<vector<float>> GenerateTwelveMiddlePoints();
         
};

VoxelInfo* UnionVoxel(VoxelInfo* idata1, VoxelInfo* idata2);

class BaseVoxelsManager{
    public:
        vector<vector<VoxelInfo*>> dat_;
        vector<vector<VoxelInfo*>> dat_on_surface_; // parent on surface
        vector<vector<float>> corners_;
        V3 bmin_,bmax_;
        int depth_; 
        int flag_are_cells_labelled_;                
        pcl::PointCloud<PointType>::Ptr     cloud_;      
        pcl::PointCloud<PointType>::Ptr     cloud_on_and_off_=NULL;
        pcl::PointCloud<PointType>::Ptr     cloud_on_=NULL;
        pcl::PointCloud<PointType>::Ptr     cloud_off_=NULL;
        pcl::search::KdTree<PointType>::Ptr kdtree_;        
        pcl::search::KdTree<PointType>::Ptr kdtree_on_and_off_;        
        pcl::search::KdTree<PointType>::Ptr kdtree_on_;    
        pcl::search::KdTree<PointType>::Ptr kdtree_off_; 

    public:
        std::tuple<vector<float>, vector<float>, vector<float>> GetCell(int level, int idx);
        void CorrectBoxMinMax(V3& dmin, V3& dmax);        
        void CreateRepCloud();
        void CreateCloudOnAndOff();        

        virtual void ExpandBoundingBox(PointType minPt, PointType maxPt){};
};

class NaiveVoxels: public BaseVoxelsManager{
    public:
        vector<float> x_sequence_,y_sequence_,z_sequence_;
    public:
        void InitNaiveGrids(vector<float> bmin, vector<float> bmax, int depth);
        std::tuple< vector<vector<float>>,vector<vector<int>>> GetCornersOfNaiveGrids();
        void ExpandBoundingBox(PointType minPt, PointType maxPt);

    private:
        void CreateNaiveCell(V3 bmin, V3 bmax, int level);
};

class NarrowBandVoxels: public BaseVoxelsManager{
    public:
        vector<int> idx_on_, idx_off_;   
        vector<V3> drct_;              
        vector<vector<float>> mc_edge_pts_;
        vector<vector<float>> cloud_xyz_;
        vector<vector<int>> off_surface_adjacent_list_26_, off_surface_adjacent_list_6_;
        vector<int> gt_labels_;
        int debug;
        float voxel_size_;
        ofstream fout;

    public:
        NarrowBandVoxels(){}
        void InitNarrowBandVoxels(vector<vector<float>> pyCloud_xyz, int depth, vector<vector<float>> pyCloud_nrm={{}});
        void LabelCellsByGTNormal();
        void CreatePointIdx();
        void SaveVoxelsStatus(string save_path, vector<int> status);
        vector<vector<float>> GetPredictNormal(vector<int> flgCell, string save_path);  
        vector<vector<float>> GetOffCloud();
        
        int QueryIntersectVoxelWithRay_Fast(Ray ry);
        bool QueryIntersectVoxelWithLineSegment_Fast(LineSegment ls);

        tuple<int,vector<int>> IsTheVoxelInside(int idx);                      // CreateIdxOnAndOff -> Get_One_IsIntersect_fast       
        vector<int> GetFeatures(string path_to_gt_labels, string path_to_pred_labels, string path_to_features); // CreateIdxOnAndOff -> isTheVoxelInside -> GetFeatures
        vector<vector<float>> GetCornersOfNarrowBandGrid();
        vector<vector<int>>   GetLinesOfNarrowBandGrid();   // GetCornersOfNarrowBandGrid -> GetLinesOfNarrowBandGrid
        vector<vector<int>>   GetFacesOfNarrowBandGrid();   // GetCornersOfNarrowBandGrid -> GetFacesOfNarrowBandGrid
        vector<int>           GetCellsStatus();
        vector<vector<float>> GetColorsOfNarrowBandGrid();  // LabelCellsByGTNormal -> GetColorsOfNarrowBandGrid
        vector<vector<float>> GetMaximumCorners();          
        tuple<vector<float>, vector<float>> GetRay();
        float GetGridSize();
        int GetIdxOffSurface(int idx);
        void WriteVoxels();

        /* find idx by point */
        void FindPointIdx(vector<float> pt);

        /* delaunay triangulation */
        vector<int> GetIdxOnSurface();
        int IsIntersect(Ray ry, int i);
        void WhetherIntersect();        
        void GenerateMarchingCubeEdgePoints();

        /* */
        vector<vector<float>> GetOffVoxelRepresentationCloud();

        /**/
        void CorrectAdjacentList();
    
        /* discard */
        vector<vector<int>> QueryIntersectVoxelWithRay(vector<float> pt1, vector<float> pt2);   // Query by traverse, discard becase it quite slow

    private:
        VoxelInfo* CreateNarrowBandGrid(V3 bmin, V3 bmax, int level);
        void CreateZeroBandGrid();      // CreateNarrowBandGrid -> CreatePointIdx -> CreateZeroBandGrid           
        void ExpandBoundingBox(PointType minPt, PointType maxPt);
        void CreateCornersOfNarrowBandGrid();
        void CreateLinesOfNarrowBandGrid();    
        void CreateIdxOnAndOff();           
        int  CountValid(vector<float> dat, float& eps);
        void CreateConnectedGraph();    // create connected graph
        tuple<float,float,float> GetSideLengthOfVoxel();
};
