#pragma once
#include <math.h>
#include <omp.h>
#include <string>
#include <pcl/point_types.h>
#include <pcl/io/ply_io.h>
#include <pcl/io/vtk_lib_io.h>
#include <pcl/geometry/polygon_mesh.h>
#include <pcl/kdtree/kdtree_flann.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/features/normal_3d.h>
#include <pcl/surface/gp3.h>
#include <pcl/octree/octree.h>
#include <pcl/point_cloud.h>
#include <pcl/visualization/cloud_viewer.h>
#include <pcl/segmentation/conditional_euclidean_clustering.h>
#include <Eigen/Dense>
#include <fstream>
#include <iostream>
#include <vector>
#ifndef PointType
#define PointType pcl::PointXYZRGBNormal
#endif
using namespace std;
double GetCellSize(pcl::PointCloud<PointType>::Ptr cloud, int level);
vector<vector<int>> SearchKNearestFaces(pcl::PolygonMesh::Ptr mesh, pcl::PointCloud<PointType>::Ptr mesh_pts, PointType find_pt, int k);