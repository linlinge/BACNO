#include <Clustering.h>
DBSCAN::DBSCAN(vector<float> idata, float eps, int minPts)
{
    vector<DBPointN*> pts;
    for(int i=0; i<idata.size(); i++){
        pts.push_back(new DBPointN(i, idata[i]));
    }
    Apply(pts, eps, minPts);
    num_of_clusters_=c2p_.size();
}

DBSCAN::DBSCAN(vector<vector<float>> idata, float eps, int minPts)
{
    vector<DBPointN*> pts;
    for(int i=0; i<idata.size(); i++){
        pts.push_back(new DBPointN(i, idata[i]));
    }
    Apply(pts, eps, minPts);
    num_of_clusters_=c2p_.size();
}

tuple<vector<vector<int>>, vector<int>>  DBSCAN::Apply(vector<DBPointN*> pts, float eps, int minPts)
{
    int count=0;
    int len=pts.size();

    /* calculate number of neghbours of each point */
    for(int i=0; i < pts.size(); i++){
        for(int j=i; j<pts.size(); j++){
            if(pts[i]->DistTo(*pts[j])<eps){
                pts[i]->num_of_ngbrs_++;
                pts[j]->num_of_ngbrs_++;
            }
        }
    }

    // core point ，若某个点在其领域Eps范围内的点个数>=MinPts，称该点为core point核心点	
	// 核心点集合索引（索引为样本点原本的索引，从0开始）
    vector<int> corePtInxVec;
    for(int i=0; i<pts.size(); i++){
        if(pts[i]->num_of_ngbrs_>=minPts){
            pts[i]->pointType=DB_CORE;
            pts[i]->cluster=(count++);
            corePtInxVec.push_back(i);
        }
    }

    //合并core point
    for (int i = 0; i < corePtInxVec.size(); i++){
		for (int j = i + 1; j < corePtInxVec.size(); j++){
            //对所有的corepoint，将其eps范围内的core point下标添加到vector<int> corepts中
			if (pts[corePtInxVec[i]]->DistTo(*pts[corePtInxVec[j]]) < eps){
				pts[corePtInxVec[i]]->neighborCoreIdx.push_back(corePtInxVec[j]);
				pts[corePtInxVec[j]]->neighborCoreIdx.push_back(corePtInxVec[i]);
			}
        }
    }

    //对于所有的corepoint，采用深度优先的方式遍历每个core point的所有corepts，使得相互连接的core point具有相同的cluster编号
	for (int i = 0; i < corePtInxVec.size(); i++){
		for (int j = 0; j < pts[corePtInxVec[i]]->neighborCoreIdx.size(); j++){
			int idx = pts[corePtInxVec[i]]->neighborCoreIdx[j];
			pts[idx]->cluster = pts[corePtInxVec[i]]->cluster;
		}
	}

    //不属于核心点但在某个核心点的邻域内的点叫做边界点
	//border point, joint border point to core point
	for (int i = 0; i < len; i++){
		if(pts[i]->pointType == DB_CORE) //忽略核心点
			continue;

		for (int j = 0; j < corePtInxVec.size(); j++){
			int idx = corePtInxVec[j]; //核心点索引
			if(pts[i]->DistTo(*pts[idx]) < eps){
				pts[i]->pointType = DB_BORDER;
				pts[i]->cluster = pts[idx]->cluster;				
				break;
			}
		}
	}

    // 
    int max_cid=-INT16_MAX;
    for(int i=0; i<pts.size(); i++)
        max_cid= max_cid > pts[i]->cluster ? max_cid: pts[i]->cluster;

    vector<vector<int>> redundancy_cluster_info(max_cid+1);
    for(int i=0; i<pts.size(); i++){
        redundancy_cluster_info[pts[i]->cluster].push_back(i);
    }
    
    for(int i=0; i<redundancy_cluster_info.size(); i++){
        if(redundancy_cluster_info[i].size()>0){
            c2p_.push_back(redundancy_cluster_info[i]);
        }
    }

    for(int i=0; i<c2p_.size(); i++){
        for(int j=0; j<c2p_[i].size(); j++){
            pts[c2p_[i][j]]->cluster=i;
        }
    }

    // 
    p2c_.resize(pts.size());
    for(int i=0; i<c2p_.size(); i++){
        for(int j=0; j< c2p_[i].size(); j++){
            p2c_[c2p_[i][j]]=i;
        }
    }
    return make_tuple(c2p_, p2c_);
}
