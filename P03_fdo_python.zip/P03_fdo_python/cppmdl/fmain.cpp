#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include <GridManager.h>
using namespace std;
namespace py = pybind11;

PYBIND11_MODULE(fmdl, m)
{
    /* optional module docstring */
    m.doc() = "pybind11 example plugin";
    py::class_<NarrowBandVoxels>(m,"NarrowBandVoxels", py::dynamic_attr())   
        .def(py::init<>())        
        .def("InitNarrowBandVoxels",&NarrowBandVoxels::InitNarrowBandVoxels)                 
        .def("GetCornersOfNarrowBandGrid",&NarrowBandVoxels::GetCornersOfNarrowBandGrid)   
        .def("GetLinesOfNarrowBandGrid",&NarrowBandVoxels::GetLinesOfNarrowBandGrid)
        .def("GetFacesOfNarrowBandGrid",&NarrowBandVoxels::GetFacesOfNarrowBandGrid)  
        .def("GetColorsOfNarrowBandGrid",&NarrowBandVoxels::GetColorsOfNarrowBandGrid)                     
        .def("GetMaximumCorners",&NarrowBandVoxels::GetMaximumCorners)                
        .def("GetCellsStatus",&NarrowBandVoxels::GetCellsStatus)                   
        .def("QueryIntersectVoxelWithRay",&NarrowBandVoxels::QueryIntersectVoxelWithRay)
        .def("QueryIntersectVoxelWithRay_Fast",&NarrowBandVoxels::QueryIntersectVoxelWithRay_Fast)        
        .def("GetGridSize",&NarrowBandVoxels::GetGridSize)
        .def("GetFeatures",&NarrowBandVoxels::GetFeatures)                
        .def("SaveVoxelsStatus",&NarrowBandVoxels::SaveVoxelsStatus)        
        .def("GetIdxOffSurface",&NarrowBandVoxels::GetIdxOffSurface)
        .def("GetIdxOnSurface",&NarrowBandVoxels::GetIdxOnSurface)  
        .def("GetOffCloud",&NarrowBandVoxels::GetOffCloud)      
        .def("GetOffVoxelRepresentationCloud",&NarrowBandVoxels::GetOffVoxelRepresentationCloud)  
        .def_readwrite("off_surface_adjacent_list_26_", &NarrowBandVoxels::off_surface_adjacent_list_26_)        
        .def_readwrite("off_surface_adjacent_list_6_", &NarrowBandVoxels::off_surface_adjacent_list_6_)        
        .def("FindPointIdx", &NarrowBandVoxels::FindPointIdx)     
        ;
}