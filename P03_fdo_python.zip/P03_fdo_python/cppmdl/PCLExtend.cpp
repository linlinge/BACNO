#include "PCLExtend.h"
#define MAX2(A, B) ((A) > (B) ? (A) : (B))
#define MAX3(A, B, C) MAX2(MAX2(A, B), C)
#define MIN2(A, B) ((A) < (B) ? (A) : (B))
#define MIN3(A, B, C) MIN2(MIN2(A, B), C)

double GetCellSize(pcl::PointCloud<PointType>::Ptr cloud, int level)  // level是？ 计算获得cell的size
{
    PointType pmin, pmax;
    pcl::getMinMax3D(*cloud, pmin, pmax);
    /*
    Get the minimum and maximum values on each of the 3 (x-y-z) dimensions in a
    given pointcloud. Parameters [in]	cloud	the point cloud data message
        [out]	min_pt	the resultant minimum bounds
        [out]	max_pt	the resultant maximum bounds
    */
    double cellsize = MAX3(abs(pmax.x - pmin.x), abs(pmax.y - pmin.y), abs(pmax.z - pmax.z));  // abs函数是计算绝对值
    return cellsize / pow(2, level);
}

vector<vector<int>> SearchKNearestFaces(pcl::PolygonMesh::Ptr mesh, pcl::PointCloud<PointType>::Ptr mesh_pts, PointType find_pt, int k)
{
    pcl::search::KdTree<PointType>::Ptr kdtree(new pcl::search::KdTree<PointType>);
    kdtree->setInputCloud(mesh_pts);
    vector<int> idx;
    vector<float> dist;
    kdtree->nearestKSearch(find_pt, k, idx, dist);
    
    vector<vector<int>> fid(idx.size(), vector<int>(3));
    for(int i=0; i<idx.size(); i++){
        fid[i][0]=mesh->polygons[i].vertices[0];
        fid[i][1]=mesh->polygons[i].vertices[1];
        fid[i][2]=mesh->polygons[i].vertices[2];
    }

    return fid;
}
