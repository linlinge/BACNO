#include <LocalMeshGenerator.h>

PoissonRecon::PoissonRecon(vector<vector<float>>& pts)
{
    pts_=pts;
}

void PoissonRecon::Recon()
{
    Plane pl(pts_);


    // construct point cloud
    pcl::PointCloud<PointType>::Ptr cloud(new pcl::PointCloud<PointType>);
    for(int i=0; i< pts_.size(); i++){
        cloud->points.push_back(PointType(pts_[i][0], pts_[i][1], pts_[i][2]));
    }

    pcl::NormalEstimation<PointType , pcl::Normal> n ;//法线估计对象
    pcl::PointCloud<pcl::Normal>::Ptr normals(new pcl::PointCloud<pcl::Normal>) ;//存储估计的法线
    pcl::search::KdTree<PointType>::Ptr tree(new pcl::search::KdTree<PointType>) ;
    Eigen::Vector4f centroid;  //质心 
    pcl::compute3DCentroid(*cloud,centroid); // 计算质心

    tree->setInputCloud(cloud) ;
    n.setViewPoint(centroid.x(),centroid.y(),centroid.z());
    n.setInputCloud(cloud) ;
    n.setSearchMethod(tree) ;
    n.setKSearch(12) ;
    n.compute(*normals) ;
    for(int i=0; i<normals->points.size(); i++){
        cloud->points[i].normal_x=normals->points[i].normal_x;
        cloud->points[i].normal_y=normals->points[i].normal_y;
        cloud->points[i].normal_z=normals->points[i].normal_z;
    }

    pcl::search::KdTree<PointType>::Ptr tree2(new pcl::search::KdTree<PointType>) ;
    tree2->setInputCloud(cloud) ;
    pcl::Poisson<PointType> pn ;
    pn.setSearchMethod(tree2) ;
    pn.setInputCloud(cloud) ;    
    pn.setConfidence(true) ; // 设置置信标志，为true时，使用法线向量长度作为置信度信息，false则需要对法线进行归一化处理
    pn.setManifold(false) ; // 设置流行标志，如果设置为true，则对多边形进行细分三角话时添加重心，设置false则不添加
    pn.setOutputPolygons(false) ;//设置是否输出为多边形
    pn.setIsoDivide(5) ;
    pn.setDepth(3);
    pn.setSamplesPerNode(1.5) ;//设置每个八叉树节点上最少采样点数目

    pcl::PolygonMesh mesh ;
    pn.performReconstruction(mesh);
    
    
    pcl::PointCloud<pcl::PointXYZ>::Ptr out_cloud(new pcl::PointCloud<pcl::PointXYZ>);
    pcl::fromPCLPointCloud2(mesh.cloud, *out_cloud);
    vector<vector<float>> out_pts(out_cloud->points.size(), vector<float>(3));
    for(int i=0; i<out_cloud->points.size(); i++){
        out_pts[i][0]=out_cloud->points[i].x;
        out_pts[i][1]=out_cloud->points[i].y;
        out_pts[i][2]=out_cloud->points[i].z;
    }

    vector<vector<int>> out_fid(mesh.polygons.size(), vector<int>(3));
    fid_.resize(mesh.polygons.size());
    for(int i=0;i<out_fid.size(); i++){
        fid_[i].push_back(mesh.polygons[i].vertices[0]);
        fid_[i].push_back(mesh.polygons[i].vertices[1]);
        fid_[i].push_back(mesh.polygons[i].vertices[2]);
    }
}

Delaunay2D::Delaunay2D(vector<vector<float>>& pts)
{
    debug=0;
    pts_=pts;
}

void Delaunay2D::EnableDebug()
{
    debug=1;
}

void Delaunay2D::DisableDebug()
{
    debug=0;
}

void Delaunay2D::Recon()
{
    /*     */
    AABB* bb=new AABB(pts_);
    Plane pl(pts_);	
	Quaterniond trans_=Quaterniond::FromTwoVectors(Vector3d(pl.A_,pl.B_,pl.C_), Vector3d(0,0,1));
	MatrixXd T_=trans_.toRotationMatrix();

    MatrixXd D(pts_.size(), 3); // nx3
	for(int i=0; i< pts_.size(); i++){
		D(i,0)=pts_[i][0];
		D(i,1)=pts_[i][1];
		D(i,2)=pts_[i][2];
	}	
    MatrixXd D_bar_repeat_n=MatrixXd::Ones(pts_.size(), pts_.size())*D;
	D_bar_repeat_n=D_bar_repeat_n/pts_.size();
    MatrixXd D_tf=(T_*(D-D_bar_repeat_n).transpose()).transpose();
    vector<vector<float>> pts_tf(pts_.size(), vector<float>(3));
	for(int i=0; i<pts_.size(); i++){		
		pts_tf[i][0]=D_tf(i,0);
		pts_tf[i][1]=D_tf(i,1);
		pts_tf[i][2]=D_tf(i,2);		
	}


    vector<pair<point_2,unsigned> > pointsList;    
    for(int i=0; i<pts_.size(); i++)
        pointsList.push_back(std::make_pair( point_2(pts_tf[i][0],pts_tf[i][1]), i )); 


    delaunay_2 triangulation;
    triangulation.insert(pointsList.begin(),pointsList.end());

    for(delaunay_2::Finite_faces_iterator fit = triangulation.finite_faces_begin(); fit != triangulation.finite_faces_end(); ++fit) {
        delaunay_2::Face_handle face = fit;        
        fid_.push_back(V3(face->vertex(0)->info(), face->vertex(1)->info(), face->vertex(2)->info()).ToInt());
    }

    // OBJManagerGeometricEx scene_mesh;    
    // scene_mesh.AddMesh(pts_, fid_);
    // scene_mesh.SaveOBJ("/home/i9/experiment_nc/stanford/not_close/scene_mesh.obj");

    // OBJManagerGeometricEx scene_plane;    
    // scene_plane.AddPlane(pl,bb);
    // scene_plane.SaveOBJ("/home/i9/experiment_nc/stanford/not_close/scene_plane.obj");
}

int Delaunay2D::IsIntersect(Ray ry)
{
    if(debug==1){
        OBJManagerGeometricEx scene_pts;
        scene_pts.AddPoints(pts_);
        scene_pts.SaveOBJ("/home/i9/experiment_nc/special_cases/scene_pts.obj");

        OBJManagerGeometricEx scene_dy;
        scene_dy.AddMesh(pts_, fid_);
        scene_dy.SaveOBJ("/home/i9/experiment_nc/special_cases/scene_dy.obj");

        OBJManagerGeometricEx scene_ry;
        scene_ry.AddRay(ry);
        scene_ry.SaveOBJ("/home/i9/experiment_nc/special_cases/scene_ry.obj");
        cout<<"wokaka"<<endl;
    }
   

    vector<vector<float>> set_of_itsc;
    for(int i=0; i<fid_.size(); i++){
        V3 v0(pts_[fid_[i][0]]);
        V3 v1(pts_[fid_[i][1]]);
        V3 v2(pts_[fid_[i][2]]);
        Triangle tri(v0, v1, v2);
        auto [num_of_itsc, itsc]=ry.IsIntersect(tri);     
        if(num_of_itsc>0)
            set_of_itsc.push_back(itsc);
    }

    // cout<<set_of_itsc.size()<<endl;

    if(set_of_itsc.size()>1){
        DBSCAN db(set_of_itsc,0.00001);
        return db.num_of_clusters_;
    }
    else 
        return set_of_itsc.size();
    
}


Delaunay3D::Delaunay3D(vector<vector<float>>& pts)
{
    pts_=pts;
}

void Delaunay3D::Recon()
{
    // construction from a list of points :
    std::vector<std::pair<point_3, int>> pointsList;
    // make pair with index
    for(int i=0; i<pts_.size(); i++)
        pointsList.push_back(std::make_pair(point_3(pts_[i][0], pts_[i][1], pts_[i][2]), i));


    delaunay_3 triangulation;
    triangulation.insert(pointsList.begin(), pointsList.end());

    for (delaunay_3::Finite_facets_iterator it = triangulation.finite_facets_begin(); it != triangulation.finite_facets_end(); it++) 
    {
        std::pair<delaunay_3::Cell_handle, int> facet = *it;
        delaunay_3::Vertex_handle v1 = facet.first->vertex( (facet.second+1)%4 );
        delaunay_3::Vertex_handle v2 = facet.first->vertex( (facet.second+2)%4 );
        delaunay_3::Vertex_handle v3 = facet.first->vertex( (facet.second+3)%4 );
        fid_.push_back(V3(v1->info(), v2->info(), v3->info()).ToInt());
    }
}