#include <PaperPlot.h>
ChartFlow::ChartFlow(string filepath)
{
    pcl::PointCloud<PointType>::Ptr cloud(new pcl::PointCloud<PointType>);
    pcl::io::loadPLYFile(filepath,*cloud);
    vector<vector<float>> dat_xyz;
    dat_xyz.resize(cloud->points.size());
    for(int i=0;i<cloud->points.size();i++){
        dat_xyz[i].push_back(cloud->points[i].x);
        dat_xyz[i].push_back(cloud->points[i].y);
        dat_xyz[i].push_back(cloud->points[i].z);
    }

    obj_=new NarrowBandVoxels();
    obj_->InitNarrowBandVoxels(dat_xyz,6); 
}
void ChartFlow::PlotNarrowBandVoxels()
{
    vector<vector<int>> gfid;
    for(int i=0; i< obj_->dat_[obj_->depth_-1].size(); i++){
        gfid.insert(gfid.end(), obj_->dat_[obj_->depth_-1][i]->lines_by_id_.begin(),obj_->dat_[obj_->depth_-1][i]->lines_by_id_.end());
    }

    OBJManager scene_voxel;
    scene_voxel.AddLines(obj_->corners_, gfid);
    scene_voxel.SaveOBJ("/home/i9/experiment_nc/scene_voxel.obj_");
}

void ChartFlow::PlotOnOffNarrowBandVoxels()
{
    /* extract voxels on surface */
    vector<vector<int>> fid_on;
    for(int i=0; i<obj_->idx_on_.size(); i++){
        fid_on.insert(fid_on.end(), obj_->dat_[obj_->depth_-1][obj_->idx_on_[i]]->lines_by_id_.begin(), obj_->dat_[obj_->depth_-1][obj_->idx_on_[i]]->lines_by_id_.end());
    }    
    OBJManager scene_voxel_on_surface;
    scene_voxel_on_surface.AddLines(obj_->corners_, fid_on);
    scene_voxel_on_surface.SaveOBJ("/home/i9/experiment_nc/scene_voxel_on.obj_");

    /* extract voxels off surface */
    vector<vector<int>> fid_off;
    for(int i=0; i<obj_->idx_off_.size(); i++){        
        fid_off.insert(fid_off.end(), obj_->dat_[obj_->depth_-1][obj_->idx_off_[i]]->lines_by_id_.begin(), obj_->dat_[obj_->depth_-1][obj_->idx_off_[i]]->lines_by_id_.end());
    }
    OBJManager scene_voxel_off_surface;
    scene_voxel_off_surface.AddLines(obj_->corners_, fid_off);
    scene_voxel_off_surface.SaveOBJ("/home/i9/experiment_nc/scene_voxel_off.obj_");

    /* ray */
    OBJManagerGeometricEx scene_ray;
    V3 origin=obj_->dat_[obj_->depth_-1][obj_->idx_off_[0]]->centre_;
    LineSegment lg_0(origin, origin+V3(2000,0,0));
    scene_ray.AddLineSegment(lg_0);
    LineSegment lg_1(origin, origin+V3(-2000,0,0));
    scene_ray.AddLineSegment(lg_1);
    LineSegment lg_2(origin, origin+V3(0,2000,0));
    scene_ray.AddLineSegment(lg_2);
    LineSegment lg_3(origin, origin+V3(0,-2000,0));
    scene_ray.AddLineSegment(lg_3);
    LineSegment lg_4(origin, origin+V3(0,0,2000));
    scene_ray.AddLineSegment(lg_4);
    LineSegment lg_5(origin, origin+V3(0,0,-2000));
    scene_ray.AddLineSegment(lg_5);    
    scene_ray.SaveOBJ("/home/i9/experiment_nc/scene_ray.obj_");
}

void ChartFlow::PlotIntersectVoxels(int i)
{
    vector<vector<int>> itsc_cells;
    vector<Ray> rys;
    V3 origin=obj_->dat_[obj_->depth_-1][i]->centre_;
    rys.push_back(Ray(origin, V3(1,0,0), point_with_direction));
    rys.push_back(Ray(origin, V3(-1,0,0), point_with_direction));
    rys.push_back(Ray(origin, V3(0,1,0), point_with_direction));
    rys.push_back(Ray(origin, V3(0,-1,0), point_with_direction));
    rys.push_back(Ray(origin, V3(0,0,1), point_with_direction));
    rys.push_back(Ray(origin, V3(0,0,-1), point_with_direction));
}