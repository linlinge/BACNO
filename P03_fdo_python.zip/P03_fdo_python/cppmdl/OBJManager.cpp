#include <OBJManager.h>
void OBJManager::ReadMesh(string path)
{
    ifstream fin(path);
    while(!fin.eof()){
        string line;
        getline(fin,line);
        if(line!=""){
            vector<string> ss=StrSplit(line," ");

            // if it is vertex
            if(ss.size()>0){
                if(ss[0]=="v"){
                    vector<float> tmp;
                    for(int i=1;i<ss.size(); i++)
                        tmp.push_back(atof(ss[i].c_str()));
                    vtx_.push_back(tmp);
                }
                else if(ss[0]=="f"){
                    vector<int> tmp;
                    for(int i=1;i<ss.size(); i++)
                        tmp.push_back(atoi(ss[i].c_str()));
                    faces_.push_back(tmp);
                }
            }
            else 
                cout<<"obj file format error!"<<endl;
        }              
    }
}
void OBJManager::AddMesh(vector<vector<float>> v, vector<vector<int>> f)
{
    vtx_.insert(vtx_.end(), v.begin(), v.end());
    int start_pos=faces_.size();
    for(int i=0; i<f.size(); i++){
        for(int j=0; j<3; j++){
            f[i][j]+=start_pos;
        }
        faces_.push_back(f[i]);
    }
}
void OBJManager::AddMesh(vector<vector<float>> v, vector<vector<int>> f, vector<vector<int>> lines)
{    
    vtx_.insert(vtx_.end(), v.begin(), v.end());
    int start_pos=faces_.size();
    for(int i=0; i<f.size(); i++){
        for(int j=0; j<3; j++){
            f[i][j]+=start_pos;
        }
        faces_.push_back(f[i]);
    }
    
    start_pos=lines_.size();
    for(int i=0; i< lines.size(); i++){
        for(int j=0; j<2; j++){
            lines[i][j]+=start_pos;
        }
        lines_.push_back(lines[i]);
    }
}



void OBJManager::AddPoints(vector<vector<float>> pts)
{
    vtx_.insert(vtx_.end(), pts.begin(), pts.end());
}

void OBJManager::AddPoints(vector<vector<float>> pts, vector<vector<float>> colors)
{
    for(int i=0;i<pts.size(); i++){
        vector<float> line;
        line.insert(line.end(), pts[i].begin(), pts[i].end());
        line.insert(line.end(), colors[i].begin(), colors[i].end());
        vtx_.push_back(line);
    }
}

void OBJManager::SaveOBJ(string save_path)
{
    ofstream fout(save_path);
    // write vertex
    for(int i=0;i< vtx_.size(); i++){
        fout<<"v";
        for(int j=0; j<vtx_[i].size(); j++)
            fout<<" "<<vtx_[i][j];
        fout<<endl;
    }

    // write faces
    for(int i=0;i< faces_.size(); i++){
        fout<<"f "<<faces_[i][0]+1<<" "<<faces_[i][1]+1<<" "<<faces_[i][2]+1<<endl;
    }

    // write lines
    for(int i=0;i< lines_.size(); i++){
        fout<<"l "<<lines_[i][0]+1<<" "<<lines_[i][1]+1<<endl;
    }
    fout.close();
}

void OBJManager::AddLine(vector<float> pt_start, vector<float> pt_end)
{
    vector<int> line;
    vtx_.push_back(pt_start);
    line.push_back(vtx_.size()-1);

    vtx_.push_back(pt_end);
    line.push_back(vtx_.size()-1);

    lines_.push_back(line);    
}

void OBJManager::AddLines(vector<vector<float>> pts, vector<vector<int>> fid)
{
    int offset=vtx_.size();
    vtx_.insert(vtx_.end(), pts.begin(), pts.end());
    for(int i=0; i< fid.size(); i++){
        fid[i][0]+=offset;
        fid[i][1]+=offset;
    }
    lines_.insert(lines_.end(), fid.begin(), fid.end());
}

void OBJManager::AddLines(vector<vector<int>> lines)
{
    lines_.insert(lines_.end(), lines.begin(), lines.end());
}