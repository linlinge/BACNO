import numpy as np  
import trimesh
  
def add_gaussian_noise(point_cloud, noise_ratio, noise_std):  
    """  
    给真值点云添加高斯噪声  
  
    参数:  
        point_cloud (numpy.array): 真值点云，形状为 (N, 3)，N 是点的数量，每个点有 x、y、z 三个坐标值  
        noise_ratio (float): 噪声占比，取值范围为 [0, 1]  
        noise_std (float): 高斯噪声的标准差  
  
    返回:  
        numpy.array: 添加噪声后的点云，形状与输入点云相同  
    """  
    num_points = point_cloud.shape[0]  
    num_noise_points = int(num_points * noise_ratio)  
      
    # 生成随机索引用于选择要添加噪声的点  
    noise_indices = np.random.choice(num_points, size=num_noise_points, replace=False)  
      
    # 生成高斯噪声  
    noise = np.random.normal(loc=0, scale=noise_std, size=(num_noise_points, 3))  
      
    # 将噪声添加到选定的点上  
    noisy_point_cloud = np.copy(point_cloud)  
    noisy_point_cloud[noise_indices] += noise  
      
    return noisy_point_cloud  

def list_all_files(rootdir, pattern="", is_recurse=False):
    import os
    _files = []
    pattern=pattern if pattern=="" else pattern.split("&")
    words_contained=[x for x in pattern if x.find("~")==-1]
    words_not_contained=[w[1:] for w in pattern if w.find("~")!=-1]

    #列出文件夹下所有的目录与文件
    list_file = os.listdir(rootdir)
    
    for i in range(0,len(list_file)):
        # 构造路径
        path = os.path.join(rootdir,list_file[i])

        # 判断路径是否是一个文件目录或者文件
        # 如果是文件目录，继续递归        
        if is_recurse==True and os.path.isdir(path):
            _files.extend(list_all_files(path))
        if os.path.isfile(path):
            if pattern=="":
                _files.append(path)
            else:                
                is_contained=True if len([1 for w in words_contained if path.find(w)!=-1])==len(words_contained) else False
                is_not_contained=True if len([1 for w in words_not_contained if path.find(w)!=-1])!=0 else False
                if is_contained==True and is_not_contained==False:
                    _files.append(path)                
    return _files

def save_ply_in_compatibility_mode(opath, cloud_xyz, cloud_nrm, cloud_rgb = None):
    if cloud_rgb!=None:
        mesh = trimesh.Trimesh(vertices=np.asarray(cloud_xyz), vertex_normals=np.asarray(cloud_nrm), vertex_colors = np.asarray(cloud_rgb) )  
        mesh.export(opath, file_type="ply")  
    else:
        mesh = trimesh.Trimesh(vertices=np.asarray(cloud_xyz), vertex_normals=np.asarray(cloud_nrm))  
        mesh.export(opath, file_type="ply")  